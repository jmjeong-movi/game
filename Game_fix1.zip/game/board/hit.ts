// 역할: Board 히트/타겟 컬럼 선택 로직 분리
// - Board.ts 비대화를 줄이고, 히트 처리 로직을 한 곳에서 유지합니다.

import { math } from 'cc';

import { TARGET_LEFTMOST } from '../Config';

// 현재 colorId로 맞출 수 있는 바닥(앞줄) 컬럼을 찾습니다.
export function findShootableColumn(b: any, colorId: number): number {
    const start = TARGET_LEFTMOST ? 0 : math.randomRangeInt(0, b.cols);

    for (let k = 0; k < b.cols; k++) {
        const c = (start + k) % b.cols;
        if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) continue;

        const e = b.entAt(0, c);
        if (!e) continue;

        // LOCK(잠김)은 키를 얻기 전까지 발사 대상에서 제외
        const sp = e.view.getSpecial?.();
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) continue;

        if ((e.view.colorId | 0) === (colorId | 0)) return c;
    }
    return -1;
}

// 히트 처리(일반): (스택 pop) 또는 (제거 + 중력 + 공급)까지 처리합니다.
// - 기존 구현은 row0(바닥)만을 대상으로 했지만,
//   "바닥에 타겟이 더 이상 없고(기둥 제외)" 공중(row>0)의 체인 세그먼트를
//   히트할 수 있어야 하는 요구사항이 추가되어 row/col 기반으로 확장합니다.
export async function handleHitCell(b: any, rowHit: number, colHit: number): Promise<void> {
    const row0 = rowHit | 0;
    const col0 = colHit | 0;
    const e0 = b.entAt(row0, col0);

    // 타겟이 이미 사라진 경우: 예약/바쁨을 가능한 범위에서 해제
    if (!e0) {
        const m0 = (b.colResMask?.[col0] ?? 0) | 0;
        const m = m0 !== 0 ? m0 : 1 << col0;
        for (let c = 0; c < b.cols; c++) {
            if (!(m & (1 << c))) continue;
            b.colReserved[c] = 0;
            b.colBusy[c] = 0;
            b.colResMask[c] = 0;
        }
        return;
    }

    // 영향 컬럼 마스크(우선: 발사 시 저장된 colResMask)
    const sp0 = (e0.view.depth ?? 1) <= 1 ? e0.view.getSpecial?.() : null;
    let mask = (b.colResMask?.[col0] ?? 0) | 0;
    if (!mask) {
        mask =
            sp0?.t === 'CHAIN_SEG'
                ? b.chainColMask(String((sp0 as any).id ?? ''))
                : b.entColMask(e0);
        if (!mask) mask = 1 << col0;
    }

    // 이미 다른 히트가 처리 중이면 이번 히트는 무시하되, 예약만 풀어 교착을 방지
    for (let c = 0; c < b.cols; c++) {
        if (!(mask & (1 << c))) continue;
        if (b.colBusy[c]) {
            for (let cc = 0; cc < b.cols; cc++) {
                if (!(mask & (1 << cc))) continue;
                b.colReserved[cc] = 0;
                b.colResMask[cc] = 0;
            }
            return;
        }
    }

    for (let c = 0; c < b.cols; c++) {
        if (mask & (1 << c)) b.colBusy[c] = 1;
    }

    try {
        const depthBefore = (e0.view.depth ?? 1) | 0;
        const sp = depthBefore <= 1 ? e0.view.getSpecial?.() : null;

        // (0) LOCK(잠김)은 히트 무시(타수 차감도 하지 않음)
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) return;

        // 유효 히트 1회 = remainingTiles 1 감소(=필요 탄 1 소모)
        b.remainingTiles = Math.max(0, (b.remainingTiles | 0) - 1);

        // 히트 파티클
        e0.view.playHitFx?.();

        // (0.5) 2x2(큰 블럭) HP 처리
        if (e0.w > 1 || e0.h > 1) {
            const side: -1 | 1 = colHit - e0.col < e0.w / 2 ? -1 : 1;
            e0.view.hitSide?.(side, b.tileSize * 0.08);

            const hpLeft = e0.view.decHp?.(1) ?? 0;
            if (hpLeft > 0) {
                b.tweenPop(e0.view.node).catch(() => {});
                return;
            }

            // hp==0: 제거 + 중력 + 공급
            await b.tweenScaleOut(e0.view.node);

            e0.view.node.getWorldPosition(b._tmpAim);
            b.playShatterFxAtWorld(b._tmpAim, e0.view.colorId);

            // BIG LOCK 해제
            if ((b.currentBigTargetId | 0) === (e0.id | 0)) b.currentBigTargetId = 0;

            b.removeEnt(e0);
            b._notifyBlockDestroyed(e0.worth);

            const moved = b.settleGravity();
            const spawned = b.fillTopHoles(mask);
            b.revealHiddenAtBottom();

            const spSpawned = b.processSpawnerBoxes();
            for (const e of spSpawned) b.snapEntImmediate(e);

            // ✅ 렌더 오더 동기화(바닥이 항상 앞)
            // - spawn/스냅 과정에서 setParent 순서가 섞여도 UI가 역전되지 않게 정리
            b.syncDrawOrder?.();

            for (const e of moved) b.moveEnt(e, 0.08).catch(() => {});
            for (const e of spawned) {
                const dropRows = Math.max(1, ((b.rows ?? 10) | 0) - (((e as any).row ?? 0) | 0));
                const dur = Math.min(0.35, 0.10 + 0.02 * dropRows);
                b.moveEnt(e, dur).catch(() => {});
            }
            return;
        }

        // (0) CHAIN_SEG: 체인 묶음은 "히트되면 꼬리부터" 1칸씩 제거
        if (sp?.t === 'CHAIN_SEG') {
            const chainId = String((sp as any).id ?? '');
            let tail: any = null;
            let bestOrd = -2147483648;

            // 성능: 해당 체인 seg만 순회
            const seg = b._chainSegIds?.get?.(chainId);
            if (seg && seg.size > 0) {
                for (const entId of seg) {
                    const ee = b.ents.get(entId | 0);
                    if (!ee) continue;
                    const s2 = (ee.view.depth ?? 1) <= 1 ? ee.view.getSpecial?.() : null;
                    if (s2?.t !== 'CHAIN_SEG') continue;
                    if (String((s2 as any).id ?? '') !== chainId) continue;
                    const ord = Number.isFinite((s2 as any).order) ? (((s2 as any).order as any) | 0) : 0;
                    if (!tail || ord > bestOrd) {
                        tail = ee;
                        bestOrd = ord;
                    }
                }
            } else {
                // fallback(매우 드묾)
                for (const ee of b.ents.values()) {
                    const s2 = (ee.view.depth ?? 1) <= 1 ? ee.view.getSpecial?.() : null;
                    if (s2?.t !== 'CHAIN_SEG') continue;
                    if (String((s2 as any).id ?? '') !== chainId) continue;
                    const ord = Number.isFinite((s2 as any).order) ? (((s2 as any).order as any) | 0) : 0;
                    if (!tail || ord > bestOrd) {
                        tail = ee;
                        bestOrd = ord;
                    }
                }
            }

            const target = tail ?? e0;

            // 체인 세그먼트에 스택이 남아있다면 1겹만 제거
            const depthT = (target.view.depth ?? 1) | 0;
            if (depthT > 1) {
                await b.tweenPop(target.view.node);
                target.view.popTop?.();
                return;
            }

            await b.tweenScaleOut(target.view.node);
            target.view.node.getWorldPosition(b._tmpAim);
            b.playShatterFxAtWorld(b._tmpAim, target.view.colorId);

            b.removeEnt(target);
            b._notifyBlockDestroyed(target.worth);

            const moved = b.settleGravity();
            const spawned = b.fillTopHoles(mask);
            b.revealHiddenAtBottom();

            const spSpawned = b.processSpawnerBoxes();
            for (const e of spSpawned) b.snapEntImmediate(e);

            // ✅ 렌더 오더 동기화(바닥이 항상 앞)
            b.syncDrawOrder?.();

            for (const e of moved) b.moveEnt(e, 0.08).catch(() => {});
            for (const e of spawned) b.moveEnt(e, 0.1).catch(() => {});
            return;
        }

        // (0) CHAIN: hp를 줄이고, hp가 남으면 타일은 유지
        if (sp?.t === 'CHAIN') {
            const nextHp = Math.max(0, (sp.hp | 0) - 1);
            if (nextHp > 0) {
                await b.tweenPop(e0.view.node);
                e0.view.setSpecial?.({ t: 'CHAIN', hp: nextHp });
                return;
            }
            // hp==0: 이번 히트에서 제거 처리
            e0.view.setSpecial?.(null);
        }

        // (A) 스택이 남아있으면 1겹만 pop
        if (depthBefore > 1) {
            await b.tweenPop(e0.view.node);
            e0.view.popTop?.();
            return;
        }

        // (1) KEY: 키를 얻으면 동일 id의 LOCK을 전부 해제 + LOCK 유닛(첫 순서) 해제 이벤트 발생
        if (sp?.t === 'KEY') {
            try {
                b.collectKey?.(sp.id);
            } catch {
                try {
                    b.unlockedLocks.add(sp.id);
                } catch {}
            }
            e0.view.setSpecial?.(null);
        }

        // (1) SPAWNER: queue를 현재 컬럼 supply에 주입
        if (sp?.t === 'SPAWNER') {
            const q = Array.isArray(sp.queue) ? sp.queue : [];
            if (q.length > 0) {
                const rev = q.slice().reverse();
                b.colSupply[colHit].unshift(...rev);
            }
            e0.view.setSpecial?.(null);
        }

        // (B) 제거
        await b.tweenScaleOut(e0.view.node);

        e0.view.node.getWorldPosition(b._tmpAim);
        b.playShatterFxAtWorld(b._tmpAim, e0.view.colorId);

        b.removeEnt(e0);
        b._notifyBlockDestroyed(e0.worth);

        const moved = b.settleGravity();
        const spawned = b.fillTopHoles(mask);
        b.revealHiddenAtBottom();

        const spSpawned = b.processSpawnerBoxes();
        for (const e of spSpawned) b.snapEntImmediate(e);

        // ✅ 렌더 오더 동기화(바닥이 항상 앞)
        b.syncDrawOrder?.();

        for (const e of moved) b.moveEnt(e, 0.08).catch(() => {});
        for (const e of spawned) b.moveEnt(e, 0.1).catch(() => {});
    } finally {
        // 어떤 경로로 빠져나가든 영향 컬럼 전체 정리
        for (let c = 0; c < b.cols; c++) {
            if (!(mask & (1 << c))) continue;
            b.colReserved[c] = 0;
            b.colBusy[c] = 0;
            b.colResMask[c] = 0;
        }
    }
}

// 호환 API: 기존 row0 히트 경로 유지
export async function handleHitColumn(b: any, colHit: number): Promise<void> {
    return handleHitCell(b, 0, colHit);
}
