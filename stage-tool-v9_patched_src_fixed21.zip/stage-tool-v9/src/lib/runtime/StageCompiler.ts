// Stage compiler entrypoint used by the stage tool.
//
// IMPORTANT:
// - This must match the real game logic (game_patched_v7) 1:1.
// - We keep the implementation in ./stage/* (copied from the game).
// - validator_tools/game/StageCompiler.js also re-exports this function so replay/export use the same compiler.

export { compileRuntimeFromV2 } from './stage/compileRuntimeFromV2';
