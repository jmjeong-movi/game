import { _decorator, Component, Node, Button, Sprite, SpriteAtlas, SpriteFrame, find, resources } from 'cc';

const { ccclass, property } = _decorator;

export type ItemUseMode = 0 | 1 | 2 | 3;

@ccclass('ItemUseOverlay')
export class ItemUseOverlay extends Component {
    @property({ type: Node, tooltip: 'Canvas/UI/Root/Item Use/Dimmed_Area_Bottom' })
    dimmedAreaBottom: Node | null = null;

    @property({ type: Node, tooltip: 'Canvas/UI/Root/Item Use/Dimmed_Area_Top' })
    dimmedAreaTop: Node | null = null;

    @property({ type: Node, tooltip: 'Canvas/UI/Root/Item Use/Dimmed_Shuffle' })
    dimmedShuffle: Node | null = null;

    @property({ type: Node, tooltip: 'Canvas/UI/Root/Item Use/TextBox' })
    textBox: Node | null = null;

    @property({ type: Button, tooltip: 'Canvas/UI/Root/Item Use/Dimmed_Shuffle/Btn_Shuffle' })
    btnShuffle: Button | null = null;

    @property({ type: Button, tooltip: 'Canvas/UI/Root/Item Use/TextBox/Exit' })
    btnExit: Button | null = null;

    @property({ type: Sprite, tooltip: 'Canvas/UI/Root/Item Use/TextBox/Icon_Board/Icon (Sprite)' })
    iconSprite: Sprite | null = null;

    @property({ type: SpriteAtlas, tooltip: '요구사항: Common 아틀라스' })
    commonAtlas: SpriteAtlas | null = null;

    private _sfItem1: SpriteFrame | null = null;
    private _sfItem2: SpriteFrame | null = null;
    private _sfItem3: SpriteFrame | null = null;

    private _mode: ItemUseMode = 0;

    private _tryAutoBindRefs(): void {
        // ✅ 프리팹 인스펙터 연결이 누락되어도 동작하도록 내부 참조를 자동으로 채웁니다.
        // (노드 구조가 동일하다는 가정 하에, this.node 기준으로 탐색)
        const root = this.node;

        if (!this.dimmedAreaBottom || !this.dimmedAreaBottom.isValid) {
            this.dimmedAreaBottom = find('Dimmed_Area_Bottom', root);
        }
        if (!this.dimmedAreaTop || !this.dimmedAreaTop.isValid) {
            this.dimmedAreaTop = find('Dimmed_Area_Top', root);
        }
        if (!this.dimmedShuffle || !this.dimmedShuffle.isValid) {
            this.dimmedShuffle = find('Dimmed_Shuffle', root);
        }
        if (!this.textBox || !this.textBox.isValid) {
            this.textBox = find('TextBox', root);
        }

        if (!this.btnShuffle || !this.btnShuffle.isValid) {
            const n = find('Dimmed_Shuffle/Btn_Shuffle', root);
            this.btnShuffle = (n?.getComponent(Button) as Button) ?? this.btnShuffle;
        }
        if (!this.btnExit || !this.btnExit.isValid) {
            const n = find('TextBox/Exit', root);
            this.btnExit = (n?.getComponent(Button) as Button) ?? this.btnExit;
        }
        if (!this.iconSprite || !this.iconSprite.isValid) {
            const n = find('TextBox/Icon_Board/Icon', root);
            this.iconSprite = (n?.getComponent(Sprite) as Sprite) ?? this.iconSprite;
        }

        // ✅ 아틀라스 누락 시: 아이콘 교체만 안 될 뿐 오버레이 표시에는 치명적이지 않음
        // 그래도 가능하면 자동 로드 시도(프로젝트마다 경로가 다를 수 있어 2개 경로를 시도)
        if (!this.commonAtlas) {
            resources.load('Common', SpriteAtlas, (err, atlas) => {
                if (!err && atlas && !this.commonAtlas) {
                    this.commonAtlas = atlas;
                    this._cacheItemIconFrames();
                }
            });
            resources.load('Atlas/Common', SpriteAtlas, (err, atlas) => {
                if (!err && atlas && !this.commonAtlas) {
                    this.commonAtlas = atlas;
                    this._cacheItemIconFrames();
                }
            });
        }
    }

    onLoad() {
        this._tryAutoBindRefs();
        // 역할: 아이템 아이콘 프레임 1회 캐싱
        this._cacheItemIconFrames();
        // 역할: 시작 시 오버레이 OFF
        this.close();
    }

    public get mode(): ItemUseMode {
        return this._mode;
    }

    public isOpen(): boolean {
        return this._mode !== 0 && !!(this.textBox && this.textBox.active);
    }

    public open(mode: ItemUseMode) {
        // 역할: 모드별 dim/textBox 활성 + 아이콘 교체
        this._mode = mode;

        if (this.dimmedAreaBottom) this.dimmedAreaBottom.active = false;
        if (this.dimmedAreaTop) this.dimmedAreaTop.active = false;
        if (this.dimmedShuffle) this.dimmedShuffle.active = false;
        if (this.textBox) this.textBox.active = false;

        if (mode === 0) return;

        if (mode === 1) {
            if (this.dimmedAreaBottom) this.dimmedAreaBottom.active = true;
        } else if (mode === 2) {
            if (this.dimmedShuffle) this.dimmedShuffle.active = true;
        } else if (mode === 3) {
            if (this.dimmedAreaTop) this.dimmedAreaTop.active = true;
        }

        if (this.textBox) this.textBox.active = true;
        this._applyItemIcon(mode);
    }

    public close() {
        // 역할: 오버레이 완전 종료(노드 OFF)
        this._mode = 0;
        if (this.dimmedAreaBottom) this.dimmedAreaBottom.active = false;
        if (this.dimmedAreaTop) this.dimmedAreaTop.active = false;
        if (this.dimmedShuffle) this.dimmedShuffle.active = false;
        if (this.textBox) this.textBox.active = false;
    }

    private _cacheItemIconFrames() {
        // 역할: Common 아틀라스의 아이콘 프레임 캐시(런타임 getSpriteFrame 반복 최소화)
        const a = this.commonAtlas;
        if (!a) return;

        const getF = (name: string) => a.getSpriteFrame(name) ?? a.getSpriteFrame(`${name}.png`) ?? null;
        this._sfItem1 = getF('UI_Icon_Item_01');
        this._sfItem2 = getF('UI_Icon_Item_02');
        this._sfItem3 = getF('UI_Icon_Item_03');
    }

    private _applyItemIcon(mode: ItemUseMode) {
        // 역할: TextBox/Icon_Board/Icon SpriteFrame을 모드에 맞게 교체
        const sp = this.iconSprite;
        if (!sp || !sp.node || !sp.node.isValid) return;

        if (!this._sfItem1 && !this._sfItem2 && !this._sfItem3) this._cacheItemIconFrames();

        let f: SpriteFrame | null = null;
        if (mode === 1) f = this._sfItem1;
        else if (mode === 2) f = this._sfItem2;
        else if (mode === 3) f = this._sfItem3;

        if (f) sp.spriteFrame = f;
    }
}
