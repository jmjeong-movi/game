// 역할: UnitLineRack 타겟 선택 로직 분리
// - BIG 고정 매칭 + sticky 타겟 + moving 제외 정책을 한 곳에서 관리

export function pickTargetsSkippingMoving(
    rack: any,
    b: any,
    colorId: number,
    wantShots: number,
    slot: any,
    plan: any,
) {
    // 항상 좌→우(왼쪽 우선)
    const pref: any = 'LEFT';

    const applySticky = (picked: any[]) => {
        if (picked && picked.length > 0) {
            slot.targetEntId = picked[0].entId | 0;
            slot.targetCol = picked[0].col | 0;
            // keep sticky at least a bit to avoid flicker; will auto-invalidate when target disappears.
            slot.targetStickyT = Math.max(slot.targetStickyT, 0.5);
        }
        return picked;
    };

    // BIG 고정 매칭 우선 적용
    const assigned = rack._bigAssignByColor.get(colorId | 0);
    const assignedEntId = (assigned?.unitToEnt.get(slot.index | 0) ?? 0) | 0;
    const hasAssignedBig = assignedEntId > 0;
    // ✅ 1 타겟 = 1 유닛: 이미 같은 색 다른 유닛이 이 BIG(entId)을 계획(plan)에서 선점했다면
    // 이 유닛은 해당 BIG을 다시 잡지 않습니다.
    // - 원인: 쿨다운/스킵 프레임에서 plan.ent 선점이 누락되면
    //   다른 유닛이 같은 BIG을 새로 잡아 "여러 유닛이 한 BIG을 쏘는" 현상이 생길 수 있음.
    // - UnitLineRack에서 plan을 선등록하더라도, 여기서 한 번 더 방어합니다.
    const takenByOther = hasAssignedBig && plan?.ent?.has?.(assignedEntId | 0) && ((slot?.targetEntId | 0) !== (assignedEntId | 0));
    if (!takenByOther && hasAssignedBig && b?.isShootableEnt) {
        const okA = b.isShootableEnt(colorId, assignedEntId);
        if (okA && okA.ok) {
            const colA = (okA.col | 0) as number;
            const eA = b.entAt?.(0, colA);

            // ✅ 성능: 월드좌표 Vec3 풀 사용(가능하면)
            const wA =
                typeof b?.cellWorldPosInto === 'function' && typeof b?.tmpV3 === 'function'
                    ? b.cellWorldPosInto(0, colA, b.tmpV3())
                    : b.cellWorldPos?.(0, colA);
            const t0: any = {
                col: colA,
                entId: assignedEntId,
                world: wA,
                isBig: true,
                hp: eA?.view?.getHp?.() ?? 0,
            };

            // mark used for same-color planning
            plan.ent.add(assignedEntId);
            plan.bigEnt.add(assignedEntId);

            // set sticky to the assigned BIG (prevents swap)
            slot.targetEntId = assignedEntId;
            slot.targetCol = colA;
            slot.targetStickyT = Math.max(slot.targetStickyT, 0.8);

            if (wantShots <= 1) return applySticky([t0]);

            // second shot: never pick another BIG if this unit already owns a BIG
            const more = b.pickShootTargets(colorId, wantShots - 1, pref, plan.ent, false);
            return applySticky([t0, ...more].slice(0, wantShots));
        }
    }

    // 0) Sticky target 유지
    if ((slot.targetEntId | 0) > 0) {
        const okSticky = b?.isShootableEnt
            ? b.isShootableEnt(colorId, slot.targetEntId | 0)
            : { ok: false, col: -1 };
        if (okSticky && okSticky.ok) {
            // Mark current target into plan so other same-color units won't pick it.
            plan.ent.add(slot.targetEntId | 0);

            const stickyCol = (okSticky.col | 0) as number;
            slot.targetCol = stickyCol;

            // ✅ 공중 체인(row>0) sticky 지원
            // - row0 스캔(entAt(0,col))만 쓰면 공중 체인 타겟이 즉시 해제되어 흔들림/끊김이 생깁니다.
            // - 우선: ents Map에서 entId로 직접 조회
            const ee = b?.ents?.get ? b.ents.get(slot.targetEntId | 0) : null;
            const row = ee ? ((ee.row ?? 0) | 0) : 0;
            const isBig = !!(ee && (ee.w > 1 || ee.h > 1));
            if (isBig) plan.bigEnt.add(slot.targetEntId | 0);

            // ✅ 성능: 월드좌표 Vec3 풀 사용(가능하면)
            const wS =
                typeof b?.cellWorldPosInto === 'function' && typeof b?.tmpV3 === 'function'
                    ? b.cellWorldPosInto(row, stickyCol, b.tmpV3())
                    : b.cellWorldPos?.(row, slot.targetCol | 0);
            const t0: any = {
                col: stickyCol,
                entId: slot.targetEntId | 0,
                world: wS,
                isBig,
                hp: isBig ? (ee?.view?.getHp?.() ?? 0) : 0,
                row,
            };

            if (wantShots <= 1) return applySticky([t0]);

            // second shot: if assigned BIG exists, do NOT steal another BIG
            const allowBig2 = !hasAssignedBig && plan.bigEnt.size < Math.max(0, plan.bigBudget | 0);
            const more = b.pickShootTargets(colorId, wantShots - 1, pref, plan.ent, allowBig2);
            return applySticky([t0, ...more].slice(0, wantShots));
        } else {
            // Invalidate sticky if not shootable anymore.
            slot.targetEntId = 0;
            slot.targetCol = -1;
            slot.targetStickyT = 0;
        }
    }

    // 1) Fresh pick (with plan excludes)
    const allowBig = !hasAssignedBig && plan.bigEnt.size < Math.max(0, plan.bigBudget | 0);
    const targets = b.pickShootTargets(colorId, wantShots, pref, plan.ent, allowBig);
    if (targets.length > 0 && !!targets[0]?.isBig) {
        plan.bigEnt.add((targets[0] as any).entId | 0);
    }

    // board가 moving 판별 API가 없으면 그대로 사용
    const isMovingFn = b?.isEntMoving;
    if (typeof isMovingFn !== 'function') return applySticky(targets);

    // 1) moving 아닌 것만 먼저
    const stable: any[] = [];
    for (let i = 0; i < targets.length; i++) {
        const t: any = targets[i];
        if (!t) continue;
        if (!isMovingFn.call(b, t.entId)) stable.push(t);
    }
    if (stable.length > 0) {
        // 듀얼이면 2개까지
        if (stable.length >= wantShots) return applySticky(stable.slice(0, wantShots));
        // 부족하면 나머지로 채우기
        const out = stable.slice();
        for (let i = 0; i < targets.length && out.length < wantShots; i++) {
            const t: any = targets[i];
            if (!t) continue;
            if (out.indexOf(t) >= 0) continue;
            out.push(t);
        }
        return applySticky(out);
    }

    // 2) stable이 하나도 없으면 원래 targets로
    return applySticky(targets);
}
