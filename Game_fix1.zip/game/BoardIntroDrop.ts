import { _decorator, Component, Node, UITransform, UIOpacity, Vec3, Tween, tween } from 'cc';
import type { TweenEasing } from 'cc';
import type { IntroDropPlayArgs } from './BoardTypes';

const { ccclass, property } = _decorator;

type NodeIntroCache = {
    posA: Vec3;
    posB: Vec3;
    scaleA: Vec3;
    scaleB: Vec3;
};

@ccclass('BoardIntroDrop')
export class BoardIntroDrop extends Component {
    @property({ tooltip: '스테이지 로드 시, 블럭이 위에서 쏟아지는 인트로 드랍 연출 사용' })
    IntroEnabled = true;

    @property({ tooltip: '인트로 드랍 시작 전 대기 시간(초). 예: 2면 2초 후 떨어짐' })
    startDelay = 2.0;

    @property({ tooltip: '인트로 드랍 기본 시간(초) - 실제는 거리 기반으로 더 짧아질 수 있음' })
    duration = 0.35;

    @property({ tooltip: '행(row)별 지연(초). 값이 클수록 위쪽 블럭이 약간 늦게 떨어져 “쏟아짐” 느낌' })
    rowDelay = 0.015;

    @property({ tooltip: '버스트(무리) 하나에 떨어지는 블럭 최소 개수' })
    burstMin = 6;

    @property({ tooltip: '버스트(무리) 하나에 떨어지는 블럭 최대 개수' })
    burstMax = 14;

    @property({ tooltip: '버스트 사이 텀 최소(초)' })
    burstGapMin = 0.06;

    @property({ tooltip: '버스트 사이 텀 최대(초)' })
    burstGapMax = 0.16;

    @property({ tooltip: '버스트 내부 미세 랜덤 지연(초). 0.00~0.06 추천' })
    microSpread = 0.04;

    @property({ tooltip: '좌우 흔들림 최대 픽셀(작게). 0~18 추천' })
    xJitter = 12;

    @property({ tooltip: '바닥에서 살짝 더 내려갔다가 튕기는 Y(픽셀). 0~18 추천' })
    bounceY = 10;

    @property({ tooltip: '중앙에서 바깥으로 살짝 밀려나는 X 가중치(픽셀/컬럼). 0~2 추천' })
    pushX = 1.2;

    @property({ tooltip: '드랍 시작 스케일(작게 시작). 0.85~0.98 추천' })
    scaleStart = 0.92;

    @property({ tooltip: '스케일 피크(살짝 커졌다가 복귀). 1.02~1.08 추천' })
    scalePeak = 1.05;

    @property({ tooltip: '바닥(row0)→상단(row9)로 넘어갈 때 층별 시작 오프셋(초). 섞임 정도' })
    rowPhaseGap = 0.06;

    @property({ tooltip: '스폰 라인(보드 상단)에서 추가로 더 위로 띄울 픽셀' })
    spawnPadding = 120;

    @property({ tooltip: '우박처럼 높낮이 랜덤(픽셀). 0이면 랜덤 없음' })
    spawnRandHeight = 140;

    @property({ tooltip: '0이면 랜덤. 고정값 넣으면 같은 패턴 재현 가능(디버그용)' })
    seed = 0;

    // ✅ play() 호출마다 new Vec3/Array를 만들지 않기 위한 재사용 버퍼들
    // - 역할: 스테이지 로드 직후(인트로 드랍)에서 GC 스파이크 방지
    private _tmpWorldTop = new Vec3();
    private _tmpTopLocal = new Vec3();
    private _tmpEndLocal = new Vec3();
    private _tmpEndWorld = new Vec3();
    private _tmpStartWorld = new Vec3();
    private _tmpStartLocal = new Vec3();
    private _list: Array<{ e: any; key: number }> = [];

    public play(args: IntroDropPlayArgs): void {
        if (!this.enabled) return;
        if (!this.IntroEnabled) return;
        if (!args.tileLayer || !args.tileLayer.isValid) return;

        const baseDelay = Math.max(0, this.startDelay);

        // ✅ 거리 기반 낙하
        const durMax = Math.max(0.18, this.duration);
        const durMin = 0.1;
        const fallSpeed = 2800; // px/sec

        // 버스트
        const microSpread = Math.max(0, this.microSpread);
        const burstMin = Math.max(1, this.burstMin | 0);
        const burstMax = Math.max(burstMin, this.burstMax | 0);
        const gapMin = Math.max(0, this.burstGapMin);
        const gapMax = Math.max(gapMin, this.burstGapMax);

        // 스폰 라인
        const spawnPad = Math.max(0, this.spawnPadding | 0);
        const spawnRand = Math.max(0, this.spawnRandHeight | 0);

        // 흔들림/바운스/밀림/스케일
        const xJitter = Math.max(0, this.xJitter);
        const bounceY = Math.max(0, this.bounceY);
        const pushX = this.pushX;
        const s0 = this.scaleStart;
        const s1 = this.scalePeak;

        // 바닥 우선 + 섞임
        const rowBias = Math.max(0, this.rowDelay);
        const rowJitter = Math.max(0, this.rowPhaseGap);

        // ---- PRNG (xorshift32) ----
        let seed = this.seed | 0;
        if (seed === 0) seed = ((Math.random() * 0x7fffffff) | 0) ^ ((args.cols * 2654435761) | 0);
        const rnd = () => {
            seed ^= seed << 13;
            seed ^= seed >>> 17;
            seed ^= seed << 5;
            return (seed >>> 0) / 0xffffffff;
        };
        const rndRange = (a: number, b: number) => a + (b - a) * rnd();
        const rndInt = (a: number, b: number) => (a + Math.floor(rnd() * (b - a + 1))) | 0;

        // tileLayer 상단 월드 Y
        const layerUI = args.tileLayer.getComponent(UITransform);
        if (!layerUI) return;

        // ✅ tileLayer의 앵커(anchorY)까지 반영한 "상단 로컬 Y"를 계산
        // - convertToWorldSpaceAR는 AR좌표(앵커 기준)이므로 height*0.5 고정은 잘못될 수 있음
        // - topLocalY = height * (1 - anchorY)
        const topLocalY = layerUI.height * (1 - layerUI.anchorY);
        this._tmpTopLocal.set(0, topLocalY, 0);
        layerUI.convertToWorldSpaceAR(this._tmpTopLocal, this._tmpWorldTop);
        const spawnWorldYBase = this._tmpWorldTop.y + spawnPad;

        const mid = (args.cols - 1) * 0.5;

        // 엔티티 수집 + 정렬 키
        // ✅ list 재사용(할당/GC 방지)
        const list = this._list;
        list.length = 0;
        for (const e of args.ents) {
            const key = e.row * rowBias + (rowJitter > 0 ? rndRange(0, rowJitter) : 0) + rndRange(0, 0.006);
            list.push({ e, key });
        }
        list.sort((a, b) => a.key - b.key);

        // 버스트 타임라인
        let tCursor = 0;
        let burstCount = 0;
        let burstSize = rndInt(burstMin, burstMax);

        // ✅ 임시 Vec3 재사용(공유) — convert용(할당/GC 방지)
        const tmpEndWorld = this._tmpEndWorld;
        const tmpStartWorld = this._tmpStartWorld;
        const tmpStartLocal = this._tmpStartLocal;

        for (const it of list) {
            const e = it.e;
            const n: Node | null = e.view?.node;
            if (!n || !n.isValid) continue;

            Tween.stopAllByTarget(n);

            const t = args.getEntParentAndLocal(e);
            if (!t.parent || !t.parent.isValid) continue;

            // UIOpacity 재사용
            const op = n.getComponent(UIOpacity) ?? n.addComponent(UIOpacity);
            Tween.stopAllByTarget(op);

            // 노드별 캐시(Vec3) 확보: 여기서 1회만 생성되고 이후 재사용
            const cache = this.getOrCreateNodeCache(n);

            n.setParent(t.parent);

            const endX = t.local.x;
            const endY = t.local.y;
            const endZ = t.local.z;

            const push = (e.col - mid) * pushX;
            const jitterX = xJitter > 0 ? rndRange(-xJitter, xJitter) : 0;

            // ✅ 최종 정착 위치는 "그리드 좌표"를 그대로 사용(딱 붙게)
            // - push/jitter는 "중간 경로"에만 사용해 연출 감만 주고,
            //   최종 위치는 반드시 endX(=그리드)로 스냅합니다.
            const endX2 = endX; // final = grid
            const midX = endX + push + jitterX;

            const parentUI = t.parent.getComponent(UITransform);
            if (!parentUI) continue;

            // ✅ end world (endLocal Vec3 재사용)
            this._tmpEndLocal.set(endX2, endY, endZ);
            parentUI.convertToWorldSpaceAR(this._tmpEndLocal, tmpEndWorld);

            // start world Y(천장)
            const startWorldY = spawnWorldYBase + (spawnRand > 0 ? rndRange(0, spawnRand) : 0);
            tmpStartWorld.set(tmpEndWorld.x + jitterX * 0.2, startWorldY, tmpEndWorld.z);

            // start local
            parentUI.convertToNodeSpaceAR(tmpStartWorld, tmpStartLocal);

            // 거리 기반 duration
            const fallDist = Math.abs(tmpStartLocal.y - endY);
            const dur = Math.min(durMax, Math.max(durMin, fallDist / fallSpeed));

            const micro = microSpread > 0 ? rndRange(0, microSpread) : 0;
            const delay = baseDelay + it.key + tCursor + micro;

            // 버스트 진행
            burstCount++;
            if (burstCount >= burstSize) {
                burstCount = 0;
                burstSize = rndInt(burstMin, burstMax);
                tCursor += rndRange(gapMin, gapMax);
            }

            // 시작 상태(위)
            // ✅ 픽셀 스냅(정수 좌표) — 정지 상태에서 생기는 얇은 틈(시임) 방지
            const startX = Math.round(tmpStartLocal.x);
            const startY = Math.round(tmpStartLocal.y);

            n.setPosition(startX, startY, endZ);

            // ✅ 스케일도 "현재 스케일"을 기준으로 상대 적용
            // - Board에서 오버스케일(겹침)을 적용한 경우에도, 인트로 드랍이 1.0으로 되돌려
            //   다시 틈이 생기지 않도록 baseScale로 복귀시킵니다.
            const bsx = n.scale.x;
            const bsy = n.scale.y;
            const bsz = n.scale.z;
            n.setScale(bsx * s0, bsy * s0, bsz);
            op.opacity = 0;

            // 페이드 인
            tween(op).delay(delay).to(0.03, { opacity: 255 }, { easing: 'quadOut' as TweenEasing }).start();

            // ✅ 포지션 타겟 Vec3를 "노드 캐시"에 set해서 재사용 (할당 없음)
            cache.posA.set(Math.round(midX), Math.round(endY - bounceY), endZ);
            cache.posB.set(Math.round(endX2), Math.round(endY), endZ);

            tween(n)
                .delay(delay)
                .to(dur * 0.82, { position: cache.posA }, { easing: 'quadIn' as TweenEasing })
                .to(dur * 0.18, { position: cache.posB }, { easing: 'backOut' as TweenEasing })
                .start();

            // ✅ 스케일 타겟도 캐시 Vec3 재사용
            cache.scaleA.set(bsx * s1, bsy * s1, bsz);
            cache.scaleB.set(bsx, bsy, bsz);

            tween(n)
                .delay(delay)
                .to(0.06, { scale: cache.scaleA }, { easing: 'quadOut' as TweenEasing })
                .to(0.08, { scale: cache.scaleB }, { easing: 'quadIn' as TweenEasing })
                .start();
        }
    }

    // 노드별 Vec3 캐시 확보 (최초 1회만 생성)
    private getOrCreateNodeCache(n: Node): NodeIntroCache {
        const anyN = n as any;
        let c: NodeIntroCache | undefined = anyN.__introDropCache;
        if (!c) {
            c = {
                posA: new Vec3(),
                posB: new Vec3(),
                scaleA: new Vec3(),
                scaleB: new Vec3(),
            };
            anyN.__introDropCache = c;
        }
        return c;
    }
}
