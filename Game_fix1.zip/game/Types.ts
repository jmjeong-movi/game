import { DEFAULT_PALETTE_HEX_12 } from './ColorPalette';

export type ColorId = number;
export type Color8 = string;

// ----------------- Color / Palette (single source of truth) -----------------

// stage-tool(에디터)에서 쓰는 "색상 토큰".
// 이 순서가 runtime colorId(0~11) 및 스프라이트(01~12) 매핑의 기준입니다.
//
// ✅ 기본(12색) 순서
// R,O,Y,G,B,P,M,C,S,L,K,W
// - 10색(meta.colorCount=10) 스테이지면 앞 10개만 사용 → M=6, C=7
// - 과거 기본값에 K/W(검정/흰색)가 앞쪽에 끼어 C/M이 8/9로 밀리며
//   Enemy_Block_Small_07 자리에 _10이 들어가는 현상이 발생할 수 있습니다.
export type ColorToken = 'R' | 'O' | 'Y' | 'G' | 'B' | 'P' | 'M' | 'C' | 'S' | 'L' | 'K' | 'W';

export const COLOR_TOKEN_ORDER: readonly ColorToken[] = [
    'R',
    'O',
    'Y',
    'G',
    'B',
    'P',
    'M',
    'C',
    'S',
    'L',
    'K',
    'W',
] as const;

// 토큰 → colorId (미지원 토큰이면 -1)
// 토큰 → colorId (0~11)
// ⚠️ 중요
// - stage.meta.colorCount는 "스테이지에서 실제로 쓰는 색의 개수"일 뿐,
//   토큰(R/Y/B 등)이 어떤 id에 매핑되는지의 기준이 아닙니다.
// - 따라서 colorCount로 토큰 검색 범위를 자르면,
//   colorCount=3인 스테이지에서 'B'가 -1로 떨어져 빨강(0)으로 덮이는 현상이 발생합니다.
// - 여기서는 항상 12색 전체 토큰 순서(COLOR_TOKEN_ORDER)를 기준으로 id를 반환합니다.
export function colorIdFromToken(token: string, _colorCount?: number): number {
    const t = (token ?? '').trim().toUpperCase();
    for (let i = 0; i < COLOR_TOKEN_ORDER.length; i++) {
        if (COLOR_TOKEN_ORDER[i] === t) return i;
    }
    return -1;
}

// 표준 12색 팔레트(위 COLOR_TOKEN_ORDER와 1:1 매칭)
// - 필요 시 colorCount만큼 앞에서 잘라 사용하세요.
export const COLOR_PALETTE_HEX_12: readonly string[] = [
    '#ff3b30', // R
    '#ff9f0a', // O
    '#ffd60a', // Y
    '#34c759', // G
    '#0a84ff', // B
    '#bf5af2', // P
    '#ff2d55', // M
    '#64d2ff', // C
    '#30d158', // S
    '#ac8e68', // L
    '#1c1c1e', // K
    '#ffffff', // W
] as const;

export function paletteHexByColorCount(colorCount: number): string[] {
    const max = Math.max(0, Math.min(COLOR_PALETTE_HEX_12.length, colorCount | 0));
    return COLOR_PALETTE_HEX_12.slice(0, max);
}

// colorId → 스프라이트 인덱스(01~12)
export function spriteIndexFromColorId(colorId: number): number {
    const id = colorId | 0;
    return id >= 0 ? id + 1 : 0;
}

export function buildPaletteHex(colorCount: number): string[] {
    const n = Math.max(0, Math.min(DEFAULT_PALETTE_HEX_12.length, colorCount | 0));
    return DEFAULT_PALETTE_HEX_12.slice(0, n);
}

export type WithUid = { uid: string };
export type WithLayer = { layer?: number };

export type SupplyMode = string;

// ----------------- 카드/슬롯 -----------------

export type GunState = {
    colorId: ColorId;
    ammoMax: number;
    ammoLeft: number;
};

export type UnitKind = 'NORMAL' | 'CHAIN' | 'LOCK' | 'SPAWNER';

export type CardData = {
    colorId: ColorId;
    ammo: number;

    // 유닛 발사 모드: 1=1발, 2=2발 (없으면 런타임에서 확률로 부여)
    shotCount?: 1 | 2;

    // // 역할: 유닛 섞기 아이템에서 제외 판정용(없으면 NORMAL 취급)
    kind?: UnitKind;

    // ✅ 클리어 힌트(표시용): 0이 최우선, 값이 작을수록 우선도가 높습니다.
    // - 역할: StageCompiler가 추천 순서를 계산해 UI에 노출(예: ★/• 마크)
    // - 주의: 게임 로직에는 영향 없음(표시 전용)
    hintRank?: number;

    // ✅ 장착 순번(표시용): 1..slotCount
    // - stage.equipOrder 또는 시뮬 결과를 StageCompiler가 부여
    // - 게임 로직에는 영향 없음(표시 전용)
    hintStep?: number;

    // ✅ 장착 순번(런타임 우선순위): 먼저 장착된 유닛의 발사/타겟 우선권을 위해 사용
    // - UnitLineRack에서 자동으로 부여(1부터 증가)
    // - 외부(툴/JSON)에서 미리 넣어둘 수도 있습니다.
    equipSeq?: number;
};

export type StageV2 = {
    id: number;
    meta: {
        blockCount: number;
        colorCount: number;
        slotCount: number;
        waitLineCount?: number;
        shot2Rate?: number;
        connectShooterCount?: number;
        hiddenShooterCount?: number;
        lockShooterCount?: number;
        ammoMin: number;
        ammoMax: number;
        seed?: number;

        // UI(카드판) 레이아웃
        pickerCols?: number;
        pickerRows?: number;
        pickerMaxCards?: number;

        // 스택(겹) 관련
        layerCount?: number;

        // 공급 설정
        supplyMode?: SupplyMode;
        supply?: { columns: number[][] };

        // 팔레트(8색 알파벳) 사용 여부
        palette?: Color8[];
    };
    // stage-tool 버전에 따라 objects가 루트이거나 board 안에 있을 수 있어 둘 다 허용합니다.
    objects?: StageObject[];
    board?: { w?: number; h?: number; objects: StageObject[] };

    // 카드/공급/슈터가 버전에 따라 별도 필드로 올 수 있어 방어적으로 optional
    cards?: {
        // GENERATE: 런타임(컴파일 단계)에서 분배 생성
        // MANUAL/AUTHORED/FIXED: stage JSON에 카드 리스트가 이미 들어있음(순서 포함)
        mode?: 'GENERATE' | 'MANUAL' | 'AUTHORED' | 'FIXED';
        // stage-tool "클리어 보장 export"에서 생성되는 카드 리스트(순서 포함)
        // - color: 토큰("R","Y"...) 또는 숫자(colorId)
        // - ammo: 탄 수
        // - shotCount: 1/2 (옵션)
        authored?: { color: Color8 | number; ammo: number; shotCount?: 1 | 2 }[];
        // 호환: FIXED/list 형태를 쓰는 경우
        list?: { color: Color8 | number; ammo: number; shotCount?: 1 | 2 }[];
        rules?: {
            ammoStep?: number;
            totalAmmoEquals?: 'BOARD_BLOCKS' | number;
        };
    };
    supply?: {
        mode?: SupplyMode;
        perCol?: number[];
        columns?: number[][];
        pages?: { objects: any[] }[];
    };
    shooters?: {
        slots?: { slot: number; type: string }[];
    };

    // ✅ Export 힌트(옵션): 슬롯 순서대로 권장 장착 유닛 (예: "R2", "Y1")
    // 게임 로직에는 영향이 없고, UI에서 힌트 표시에 사용 가능합니다.
    equipOrder?: string[];
};

// ----------------- v2 스테이지팩 -----------------

export type StagePackV2 = {
    schemaVersion: 2;
    stages: StageV2[];
};

export type StageObject =
    | (WithUid & WithLayer & { type: 'BLOCK_NORMAL'; x: number; y: number; color: Color8 })
    | (WithUid & WithLayer & { type: 'BLOCK_SMALL'; x: number; y: number; color: Color8 }) // (호환)
    // // BLOCK_LARGE는 2x2 "진짜 엔티티"로 처리합니다. hp가 있으면 그만큼 맞아야 파괴됩니다.
    | (WithUid & WithLayer & { type: 'BLOCK_LARGE'; x: number; y: number; w: 2; h: 2; color: Color8; hp?: number })
    | (WithUid & WithLayer & { type: 'BLOCK_LARGE_HIDDEN'; x: number; y: number; w: 2; h: 2; hp?: number })
    | (WithUid & WithLayer & { type: 'BLOCK_HIDDEN'; x: number; y: number; revealRule: 'REACH_BOTTOM' })
    | (WithUid &
          WithLayer & {
              type: 'CHAIN_BARRIER';
              x: number;
              y: number;
              color: Color8;
              // ✅ 체인(슬라임) 그룹 정보(툴/에디터 export 호환)
              // - chainId: 같은 체인 묶음 식별자(여러 셀이 1묶음)
              // - chainOrder: 0=head(머리) / 큰 값일수록 tail(꼬리)
              // - chainLen: (스턱난 export 대비) 한 묶음의 길이 힌트
              //   * 관례: chainLen=1 -> 2칸(기본 1칸 + 추가 1칸)
              chainId?: string;
              chainOrder?: number;
              chainLen?: number;
          })
    | (WithUid & WithLayer & { type: 'KEY'; x: number; y: number; keyId: string })
    | (WithUid & WithLayer & { type: 'LOCK'; x: number; y: number; lockId: string })
    | (WithUid & WithLayer & { type: 'PILLAR'; x: number; y: number; h: number })
    | (WithUid &
          WithLayer & {
              type: 'SPAWNER_BOX';
              x: number;
              y: number;
              // ✅ 생성박스는 "박스 자체"가 2x2로 점유합니다.
              // - (x,y)는 박스(2x2)의 하단-좌측입니다.
              // - 실제 생성(spawn)은 박스 바로 아래 1줄에서 수행됩니다.
              //   spawn row = (x,y-1) / (x+1,y-1)
              // - hp는 "생성할 블럭 수(=생성 HP)"입니다. (스몰 블럭 1개 생성할 때마다 1 감소)
              // - spawn.poolColors는 생성될 블럭의 색(권장: 2개)입니다.
              //   ✅ 의미 변경(v48+): poolColors[0]=왼쪽 셀 고정 색, poolColors[1]=오른쪽 셀 고정 색
              //   (구버전 호환을 위해 1개 이상도 허용)
              w?: 2;
              h?: 2;
              hp?: number;
              // 구버전 호환 필드(이전에는 "깨지면 queue 주입" 형태)
              spawnCount?: number;
              spawn?: { poolColors: Color8[] };
          });

// ----------------- 런타임(보드에 실제로 적용되는 형태) -----------------

// // 보드 셀에 붙는 특수 규칙(로직용). (시각표현은 추후 확장)
export type RuntimeSpecial =
    | { t: 'CHAIN'; hp: number }
    // ✅ CHAIN_SEG: 체인 블럭(여러 셀로 이어진 1묶음)
    // - 한 번 히트되면 '꼬리(tail)부터' 1칸씩 줄어듭니다.
    // - id: 같은 체인 묶음 식별자
    // - order: 0=head(머리), 큰 값일수록 tail(꼬리)
    | { t: 'CHAIN_SEG'; id: string; order: number }
    | { t: 'KEY'; id: string }
    | { t: 'LOCK'; id: string }
    | { t: 'PILLAR' }
    // 구버전/호환: (이전) 스포너 = 깨지면 queue를 공급에 주입
    | { t: 'SPAWNER'; queue: number[] }
    // 신규: (생성박스) 고정 오브젝트.
    // - 박스 바로 아래(2x1 spawn row)가 비어있는 칸만큼 블럭을 생성(좌→우)
    // - queue 길이만큼 생성하면 박스는 제거
    | {
          t: 'SPAWNER_BOX';
          // queue 길이 = 남은 생성 횟수(=남은 HP)
          queue: number[];
          // ✅ v52+: queue.shift() 대신 cursor(i)로 소비(성능)
          // - 남은 생성 횟수 = queue.length - (i|0)
          // - i가 queue.length에 도달하면 박스 제거
          i?: number;
          // 고정 색상(좌/우)
          // - spawn row의 (x,y) 셀은 colors[0]
          // - spawn row의 (x+1,y) 셀은 colors[1]
          colors?: [number, number];
      };

export type RuntimeSpawnerBox = {
    // 박스(2x2)의 하단-좌측
    x: number;
    y: number;
    // queue 길이 = 남은 "생성할 블럭 수".
    // - spawn row = (y-1, x) / (y-1, x+1) 셀 중 비어있는 칸만큼 생성합니다.
    // - 좌→우 순서로 1개씩 소비합니다.
    queue: number[];

    // 좌/우 고정 색상. (Stage JSON: spawn.poolColors[0/1])
    colors?: [number, number];
};

// 2x2 큰 블럭(진짜 엔티티) 정보
export type RuntimeLargeBlock = {
    x: number; // col
    y: number; // row
    w: 2;
    h: 2;
    colorId: number;
    hp: number;
    hpMax: number;
    hidden?: boolean; // ✅ LARGE_HIDDEN 지원(시작 숨김)
};

// ----------------- Supply: LARGE(2x2) 토큰 -----------------

// columnSupply는 pop() 기반이어서 기본적으로 "셀 1개 = 토큰 1개"로 흘러갑니다.
// 그러나 공급에서 2x2 LARGE를 "진짜 엔티티"로 생성하려면
// 2x2 footprint(4셀)에 대해 서로 연결된 토큰을 넣고, 런타임에서 1회에 BIG 1개로 합쳐 생성해야 합니다.
//
// 인코딩 규칙:
// - SMALL/HIDDEN: 기존처럼 colorId(>=0) / -(colorId+1)
// - LARGE: SUPPLY_LARGE_BASE + (idx*4 + cell)
//   - idx: supplyLargeDefs 배열 인덱스
//   - cell: 0..3 ( (0,0)(1,0)(0,1)(1,1) )  // anchor(좌하단) 기준
export const SUPPLY_LARGE_BASE = 1_000_000;

export type RuntimeSupplyLarge = {
    colorId: number;
    hp: number;
    hpMax: number;
    hidden?: boolean;
};

export type StageRuntime = {
    id: number;
    slotCount: number;

    // ✅ 대기 라인 수(1~3)
    waitLineCount: number;

    paletteHex: string[];
    board: number[][];
    hiddenMask?: boolean[][];
    special?: (RuntimeSpecial | null)[][];
    largeBlocks?: RuntimeLargeBlock[];
    largeMask?: boolean[][];
    boardStacks?: number[][][];
    columnSupply: number[][];

    // ✅ 생성박스(2x2 영역)
    // - 박스 자체는 타격 대상이 아니고(=totalBlocks에 포함하지 않음),
    //   queue에 들어있는 블럭들이 실제로 보드에 생성됩니다.
    spawnerBoxes?: RuntimeSpawnerBox[];

    // ✅ PILLAR(기둥)
    // - (x,y)는 바닥 셀, h만큼 위로 차지하는 고정 장애물
    pillars?: { x: number; y: number; h: number }[];

    // ✅ 공급에서 LARGE를 생성하기 위한 정의 목록(위 SUPPLY_LARGE_* 토큰이 참조)
    supplyLargeDefs?: RuntimeSupplyLarge[];
    totalBlocks: number;

    // ✅ 클리어 힌트(표시/디버그용)
    // - firstShooterColors: 시작 시점(바닥 row=0)에서 바로 타격 가능한 색상
    // - cardOrder: 추천 카드 인덱스(앞쪽 일부)
    clearHint?: { firstShooterColors: number[]; cardOrder: number[]; actions?: string[] };

    cards: CardData[];
    pickerCols: number;
    pickerRows: number;
};
