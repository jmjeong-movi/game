declare module 'cc' {
  export const _decorator: any;
  export class Asset {}
  export class TextAsset extends Asset { constructor(text?: string); text: string }
  export class JsonAsset extends Asset { constructor(json?: any); json: any }

  export class Component { node: any; isValid: boolean; enabled: boolean; scheduleOnce(fn: (...args: any[]) => any, delay?: number): void }
  export class Vec3 { constructor(x?: number, y?: number, z?: number); x: number; y: number; z: number; set(x: any, y?: any, z?: any): this; clone(): Vec3; static distance(a: Vec3, b: Vec3): number }
  export class Mat4 { static invert(out: Mat4, a: Mat4): Mat4 }
  export class Node { constructor(name?: string); name: string; active: boolean; isValid: boolean; parent: any; children: any[]; setParent(p: any): void; addComponent(cls: any): any; getComponent(cls: any): any; getChildByName(name: string): any; getChildByPath(path: string): any; removeFromParent(): void; destroy(): void; on(...args: any[]): void; off(...args: any[]): void; setPosition(...args: any[]): void; setWorldPosition(...args: any[]): void; getWorldPosition(out?: any): any; setScale(...args: any[]): void }
  export namespace Node { const EventType: any }
  export class Prefab {}
  export class UITransform { constructor(node?: any); width: number; height: number; convertToNodeSpaceAR(v: any, out?: any): any; convertToWorldSpaceAR(v: any, out?: any): any }
  export const math: any;
  export class NodePool { constructor(name?: string); size(): number; get(): any; put(n: any): void; clear(): void }
  export class Tween { static stopAllByTarget(target: any): void; stop(): this }
  export function tween(target: any): any;
  export function instantiate(prefab: any): any;
  export class ParticleSystem {}
  export class ParticleSystem2D {}
  export const GradientRange: any;
  export class CurveRange {}
  export class EventTouch {}
  export class Color { constructor(r?: number, g?: number, b?: number, a?: number); r: number; g: number; b: number; a: number }
  export class SpriteAtlas {}
  export class SpriteFrame {}
  export class Label {}
  export class UIOpacity {}
  export const sp: any;
  export const resources: any;
  export const director: any;
}
