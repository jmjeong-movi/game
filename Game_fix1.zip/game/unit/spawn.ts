// 역할: UnitLineRack 유닛 스폰/소켓/라벨 결합 로직 분리
// - UnitLineRack.ts 비대화를 줄이고, 스폰 규칙을 한 곳에서 유지합니다.

import { Node, instantiate, sp, Label, UIOpacity, UITransform } from 'cc';

import type { CardData } from '../Types';
import { BONE_CENTER, BONE_LEFT, BONE_RIGHT, IK_TARGET_BONE, PATH_CENTER, PATH_LEFT, PATH_RIGHT, PATH_LABEL } from './rackConst';

type LineKind = 'S' | 'W1' | 'W2' | 'W3';

// 역할: 풀링 재사용 시 Label_Num 등 특정 노드가 루트 직속이 아닌 곳(예: Skeleton 아래)으로 이동해도 안정적으로 찾기
// - 재귀 대신 재사용 스택(배열)로 DFS 탐색 → GC/스택오버플로우 방지
export function findNodeByNameDFS(r: any, root: Node, name: string): Node | null {
    if (!root || !root.isValid) return null;

    const st: Node[] = r._tmpNodeStack ?? (r._tmpNodeStack = []);
    st.length = 0;
    st.push(root);

    while (st.length > 0) {
        const n = st.pop()!;
        if (!n || !n.isValid) continue;
        if (n.name === name) return n;

        const ch = n.children;
        for (let i = ch.length - 1; i >= 0; i--) st.push(ch[i]);
    }
    return null;
}

// 역할: child를 newParent 아래로 이동하면서 월드 좌표는 유지
function reparentKeepWorldPos(r: any, child: Node, newParent: Node) {
    if (!child || !child.isValid || !newParent || !newParent.isValid) return;

    child.getWorldPosition(r._tmpReparentW);
    child.setParent(newParent);

    const tr = newParent.getComponent(UITransform);
    if (tr) {
        tr.convertToNodeSpaceAR(r._tmpReparentW, r._tmpReparentL);
        child.setPosition(r._tmpReparentL);
    } else {
        child.setWorldPosition(r._tmpReparentW);
    }
}

// 역할: 기존 sockets를 최대한 유지하면서, 우리가 쓰는 3개 머즐 + 라벨 소켓만 교체
function mergeSocketsKeepOthers(skel: sp.Skeleton, c: Node, l: Node, r: Node, labelNode: Node | null) {
    const cur = Array.isArray(skel.sockets) ? skel.sockets : [];
    const next: sp.SpineSocket[] = [];

    for (let i = 0; i < cur.length; i++) {
        const s = cur[i];
        const p = (s as any)?.path;
        if (p === PATH_CENTER || p === PATH_LEFT || p === PATH_RIGHT || p === PATH_LABEL) continue;
        next.push(s);
    }

    next.push(new sp.SpineSocket(PATH_CENTER, c));
    next.push(new sp.SpineSocket(PATH_LEFT, l));
    next.push(new sp.SpineSocket(PATH_RIGHT, r));
    if (labelNode && labelNode.isValid) next.push(new sp.SpineSocket(PATH_LABEL, labelNode));

    skel.sockets = next;
}

// Spawn / Socket / Label
export function spawnTo(r: any, line: LineKind, index: number, data: CardData) {
    const p: Node | null = r._placeOf(line, index);
    if (!p || !p.isValid) return;

    const nd: Node | null = r._pool.size() > 0 ? r._pool.get()! : r.unitPrefab ? instantiate(r.unitPrefab) : null;
    if (!nd) return;

    nd.active = true;
    nd.setParent(p);
    nd.setPosition(0, 0, 0);

    const s = r._scaleOf(line);
    nd.setScale(s, s, 1);
    nd.setRotationFromEuler(0, 0, 0);

    const op = nd.getComponent(UIOpacity) || nd.addComponent(UIOpacity);
    op.opacity = 255;

    nd.off(Node.EventType.TOUCH_END, r._onUnitTouchEnd, r);
    nd.on(Node.EventType.TOUCH_END, r._onUnitTouchEnd, r);

    let skel: sp.Skeleton | null = nd.getComponent(sp.Skeleton);
    if (!skel) skel = nd.getComponentInChildren(sp.Skeleton);

    // Label_Num은 풀링 재사용 시 Skeleton 아래로 옮겨질 수 있어 DFS로 안전하게 찾습니다.
    let labelNode: Node | null = nd.getChildByName('Label_Num');
    if (!labelNode && skel && skel.node && skel.node.isValid) labelNode = skel.node.getChildByName('Label_Num');
    if (!labelNode) labelNode = findNodeByNameDFS(r, nd, 'Label_Num');

    let ammoLabel: Label | null = null;
    if (labelNode && labelNode.isValid && skel && skel.isValid) {
        const host = skel.node;
        if (labelNode.parent !== host) reparentKeepWorldPos(r, labelNode, host);
        ammoLabel = labelNode.getComponent(Label);
    } else if (labelNode && labelNode.isValid) {
        ammoLabel = labelNode.getComponent(Label);
    }

    let muzzleCenter: Node | null = null;
    let muzzleLeft: Node | null = null;
    let muzzleRight: Node | null = null;

    let boneCenter: any | null = null;
    let boneLeft: any | null = null;
    let boneRight: any | null = null;
    let ikTarget: any | null = null;

    if (skel && skel.isValid) {
        const host = skel.node;

        muzzleCenter = host.getChildByName('Muzzle_Center');
        if (!muzzleCenter) {
            muzzleCenter = new Node('Muzzle_Center');
            muzzleCenter.setParent(host);
        }

        muzzleLeft = host.getChildByName('Muzzle_Left');
        if (!muzzleLeft) {
            muzzleLeft = new Node('Muzzle_Left');
            muzzleLeft.setParent(host);
        }

        muzzleRight = host.getChildByName('Muzzle_Right');
        if (!muzzleRight) {
            muzzleRight = new Node('Muzzle_Right');
            muzzleRight.setParent(host);
        }

        mergeSocketsKeepOthers(skel, muzzleCenter, muzzleLeft, muzzleRight, labelNode);

        // 잔여 발사 FX 제거(풀링 재사용 시 유령 FX 방지)
        r._despawnMuzzleFxUnder(muzzleCenter);
        r._despawnMuzzleFxUnder(muzzleLeft);
        r._despawnMuzzleFxUnder(muzzleRight);

        // 소켓/라벨 기본 로컬 변형 정리(풀링 잔상 방지)
        muzzleCenter.setPosition(0, 0, 0);
        muzzleCenter.setRotationFromEuler(0, 0, 0);
        muzzleCenter.setScale(1, 1, 1);

        muzzleLeft.setPosition(0, 0, 0);
        muzzleLeft.setRotationFromEuler(0, 0, 0);
        muzzleLeft.setScale(1, 1, 1);

        muzzleRight.setPosition(0, 0, 0);
        muzzleRight.setRotationFromEuler(0, 0, 0);
        muzzleRight.setScale(1, 1, 1);

        if (labelNode && labelNode.isValid) {
            labelNode.setPosition(0, 0, 0);
            labelNode.setRotationFromEuler(0, 0, 0);
            labelNode.setScale(1, 1, 1);
        }
        try {
            const spskel: any = (skel as any)._skeleton;
            // ✅ IK/조준은 내부 runtime bone을 사용해야 합니다.
            // - skel.findBone이 wrapper를 반환하는 환경에서는 x/y 변경이 반영되지 않을 수 있습니다.
            const findBone = (name: string): any | null => {
                if (spskel?.findBone) return (spskel.findBone(name) as any) || null;
                return ((skel as any).findBone?.(name) as any) ?? null;
            };

            boneCenter = findBone(BONE_CENTER);
            boneLeft = findBone(BONE_LEFT);
            boneRight = findBone(BONE_RIGHT);

            // ✅ IK 타겟은 기본적으로 Cannon_Target(=IK_TARGET_BONE)를 사용합니다.
            // - 일부 리그 호환을 위해 보조 이름만 fallback
            // - 주의: Cannon_Target_Mirror는 IK 타겟이 아닐 수 있어 "마지막" fallback으로 둡니다.
            // ✅ IK 타겟은 Cannon_Target만 사용합니다.
            ikTarget = findBone(IK_TARGET_BONE) || null;
        } catch {}
    }

    const slot: any = {
        node: nd,
        data,
        line,
        index: index | 0,
        equipSeq: (data as any)?.equipSeq ?? 0,
        moving: false,
        equipQueued: false,
        moveParam: null,
        appearParam: null,
        moveDoneCb: null,
        skel,

        ammoLabel,
        opacity: op,

        muzzleCenter,
        muzzleLeft,
        muzzleRight,

        boneCenter,
        boneLeft,
        boneRight,

        ikTarget,

        aimHasTarget: false,
        aimCurX: 0,
        aimCurY: 0,
        aimDesX: 0,
        aimDesY: 0,
        aimInited: false,
        aimRefreshCd: 0,
        aimLockT: 0,

        targetEntId: 0,
        targetCol: -1,
        targetStickyT: 0,

        aimHomeX: 0,
        aimHomeY: 0,
        aimHomeInited: false,
        aimHomeAnim: '',

        targetHoldT: 0,
        reacquireDelayT: 0,
        postEquipDelayT: 0,

        canShootNow: false,
        dualFlip: 0,

        pendingDual: false,
        pendingT: 0,
        pendingCol: -1,
        pendingColorId: 0,
        pendingMuzzle: 'L',
        pendingIsBig: false,

        lastAnim: '',
        shotSfxIdx: r._ensureShotSfxIdx(data),
    };

    r._slotByNode.set(nd, slot);
    r._setSlot(line, index, slot);

    r._applySkinByColor(slot);
    r._applyAmmoLabelVisual(slot);
    r._ensureAnim(slot, 'Idle');
    r._resetUnitPose(slot);

    if (line === 'S') r._cooldownsS[index | 0] = 0;
}
