(async()=>{
  try{
    await import('./test_replay.ts');
  }catch(e){
    console.error('CAUGHT', e);
    if(e && typeof e==='object'){
      console.error('keys', Object.keys(e));
      console.error('stack', e.stack);
    }
    process.exit(1);
  }
})();
