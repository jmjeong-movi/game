#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOOL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || cd "$TOOL_DIR/.." && pwd)"
cd "$REPO_ROOT"
CLI_JS="$TOOL_DIR/src/validator_tools/cli.js"
[[ -f "$CLI_JS" ]] || { echo "validator CLI not found: $CLI_JS"; exit 2; }

node "$CLI_JS" repair \
  --input stagepack_v2_replay_solved_fixed21.json \
  --output stagepack_v2_replay_solved_fixed21_validation.json \
  --report stagepack_v2_replay_solved_fixed21_report.json \
  --fail-dump stagepack_v2_replay_solved_fixed21_failed.json || true

node "$TOOL_DIR/src/validator_tools/gen_test_matrix.mjs"

node "$CLI_JS" repair \
  --input stagepack_v2_matrix_120_seed.json \
  --output stagepack_v2_matrix_120.json \
  --report stagepack_v2_matrix_120_report.json \
  --fail-dump stagepack_v2_matrix_120_failed.json || true

python - <<'PY'
import json
rep=json.load(open('stagepack_v2_matrix_120_report.json','r',encoding='utf-8'))
rows=rep.get('results',[])
uns=[r for r in rows if str(r.get('status'))!='SOLVED']
reason={}
for r in uns:
    k=str(r.get('reason','UNKNOWN'))
    reason[k]=reason.get(k,0)+1
print('[matrix] total=',len(rows),'unsolved=',len(uns),'reason=',reason)
if uns:
    raise SystemExit(3)
PY
