const KEY = 'stage_tool_pack_v2';

export function loadSavedPackText(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function savePackText(text: string) {
  try {
    localStorage.setItem(KEY, text);
  } catch {
    // ignore
  }
}

export function clearSaved() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    // ignore
  }
}
