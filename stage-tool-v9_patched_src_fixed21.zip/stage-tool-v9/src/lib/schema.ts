import { z } from 'zod';

/**
 * 색상 코드(툴 기준)
 * - 기존 8색(R/O/Y/G/B/P/K/W)에서 확장하여, 기획에 맞춘 추가 색을 포함합니다.
 * - 현재 툴 팔레트(총 11종): 빨/주/노/초/파/보/분홍/하늘/파스텔파랑/연녹/검
 *
 * ⚠️ 게임 런타임이 8색만 지원한다면, 런타임/컴파일러도 동일한 코드/팔레트로 확장되어야 합니다.
 */
/**
 * 색상 표시 순서(툴 UI/자동 colorCount 증가 기준)
 * - z.enum에 바로 넣을 수 있도록 tuple(as const)로 유지합니다.
 */
// ✅ 12색 팔레트(툴/스테이지 데이터 기준)
// 역할: 보드/히든/공급/스포너 등에서 사용할 수 있는 색상 키의 단일 소스입니다.
// (이전 코드에서 이름이 COLOR12/Color12 이었는데, 실제로는 12개라 혼동을 줄 수 있어 명확히 변경)
export const COLOR12 = ['R', 'O', 'Y', 'G', 'B', 'P', 'M', 'C', 'S', 'L', 'K', 'W'] as const;

export type Color12 = (typeof COLOR12)[number];

/** 색상 라벨(툴 표시용) */
export const COLOR_LABEL: Record<Color12, string> = {
  R: '빨강',
  O: '주황',
  Y: '노랑',
  G: '초록',
  B: '파랑',
  P: '보라',
  M: '분홍',
  C: '하늘',
  S: '파스텔파랑',
  L: '연녹',
  K: '검정',
  W: '하양',
};

// ✅ Supply는 "패턴 페이지" 기반으로만 동작합니다.
// - 초기(Initial)는 board.objects
// - 공급(Supply)은 supply.pages(0..N-1)
// - supply.pages가 비어있으면: 초기 패턴을 반복해서 공급(규칙 기반)
export type SupplyMode = 'PATTERN';

export type BoardObjectType =
  | 'BLOCK_NORMAL'
  | 'BLOCK_LARGE'
  | 'BLOCK_LARGE_HIDDEN'
  | 'PILLAR'
  | 'BLOCK_HIDDEN'
  | 'CHAIN_BARRIER'
  | 'KEY'
  | 'LOCK'
  | 'SPAWNER_BOX';

export type BoardObject =
  | { uid: string; type: 'BLOCK_NORMAL'; x: number; y: number; color: Color12; layer?: number }
  | {
      uid: string;
      type: 'BLOCK_LARGE';
      x: number;
      y: number;
      w: 2;
      h: 2;
      color: Color12;
      /** 라지 블록 HP(=블록 수). 예) hp=80이면 “블록 80개”로 계산 */
      hp: number;
      layer?: number;
    }
  | {
      uid: string;
      type: 'BLOCK_LARGE_HIDDEN';
      x: number;
      y: number;
      w: 2;
      h: 2;
      color: Color12;
      /** 라지 히든 블록 HP(=블록 수). 예) hp=80이면 "블록 80개"로 계산 */
      hp: number;
      /** 히든 공개 규칙(현재는 바닥 도달 시 공개만 사용) */
      revealRule: 'REACH_BOTTOM';
      layer?: number;
    }
  | { uid: string; type: 'PILLAR'; x: number; y: number; h: number; layer?: number }
  | { uid: string; type: 'BLOCK_HIDDEN'; x: number; y: number; color: Color12; revealRule: 'REACH_BOTTOM'; layer?: number }
  | {
      uid: string;
      type: 'CHAIN_BARRIER';
      x: number;
      y: number;
      color: Color12;
      /**
       * ✅ 체인 묶음 식별자
       * - 같은 chainId를 가진 CHAIN_BARRIER 셀은 1개의 체인으로 동작합니다.
       * - 붙어있는(인접한) 것만으로는 묶이지 않습니다.
       */
      chainId?: string;
      /**
       * ✅ 체인 순서
       * - 0=head(머리), 값이 클수록 tail(꼬리)
       * - 런타임은 tail부터 1칸씩 줄어드는 동작을 합니다.
       */
      chainOrder?: number;
      layer?: number;
    }
  | { uid: string; type: 'KEY'; x: number; y: number; keyId: string; layer?: number }
  | { uid: string; type: 'LOCK'; x: number; y: number; lockId: string; layer?: number }
  | {
      uid: string;
      type: 'SPAWNER_BOX';
      x: number;
      y: number;
      // ✅ 생성박스는 2x2 영역으로 취급합니다.
      // - (x,y)는 2x2 영역의 하단-좌측(spawn row)
      // - 박스 몸통은 (x,y+1)과 (x+1,y+1)에 존재한다고 가정(2x1)
      // - hp는 "생성할 블럭 수"(총 생성량, 1블럭 생성 시 1 감소)
      // - spawn.poolColors는 생성 색상 풀(권장: 2개)
      // - 구버전 호환: spawnCount(예전 queue 길이)도 읽을 수 있게 optional로 유지
      // 구버전 호환을 위해 1도 허용(툴은 기본 2x2로 생성)
      w?: 1 | 2;
      h?: 1 | 2;
      hp?: number;
      spawnCount?: number;
      spawn?: { poolColors: Color12[] };
      layer?: number;
    };

export type SupplyPageV2 = {
  /** 10x10 페이지(초기 보드 이후에 내려오는 “다음 10x10”) */
  objects: BoardObject[];
};

export type StageV2 = {
  id: number;
  /** ✅ Export 힌트(옵션): 슬롯 순서대로 권장 장착 유닛 (예: "R2"=R색 2총구, "Y1"=Y색 1총구) */
  equipOrder?: string[];
  meta: {
    blockCount: number; // ✅ total blocks = initial + supply
    /** ✅ 보드 겹(레이어) 수: 1~5 */
    layerCount: number;
    /** ✅ 사용 색상 개수(1~COLOR12.length) */
    colorCount: number;

    /** ✅ 캐넌 장착 슬롯 수(3~5) */
    slotCount: number;

    /** ✅ 캐넌 대기 라인 수(3~5) */
    waitLineCount: number;

    /** ✅ 커넷(연결) 슈터 개수(툴 설정값) */
    connectShooterCount: number;

    /** ✅ 히든 슈터 개수(툴 설정값) */
    hiddenShooterCount: number;

    /** ✅ 락 슈터 개수(LOCK 블록 개수 기반 자동) */
    lockShooterCount: number;

    ammoMin: number;
    ammoMax: number;
    seed?: number;
    pickerCols: number;
    pickerMaxCards: number;
  };
  board: {
    w: 10;
    h: 10;
    objects: BoardObject[];
  };
  /**
   * ✅ 공급 패턴 페이지들(옵션)
   * - 10x10 페이지(초기 보드 이후에 내려오는 “다음 10x10”)
   * - supply.pages가 0개면: 초기 패턴(board.objects)을 반복 공급(규칙 기반)
   */
  supply: {
    mode?: SupplyMode;
    pages?: SupplyPageV2[];
  };
  cards: {
    mode: 'GENERATE' | 'AUTHORED';
    rules?: { ammoStep: 10; totalAmmoEquals: 'BOARD_BLOCKS' | number };
    // hintStep: Export 시 "클리어 가능한 장착 순서"(전체 덱 순번)
    authored?: { color: Color12; ammo: number; shotCount?: 1 | 2; hintStep?: number }[];
  };
  shooters: {
    // placeholder for future (tool UI는 추후 확장)
    slots: Array<{ slot: number; type: string; lockId?: string }>;
  };
};

export type StagePackV2 = {
  schemaVersion: 2;
  stages: StageV2[];
};

// ---------------- Zod (Import 검증용) ----------------

const Color12Z = z.enum(COLOR12);

const ObjZ = z.discriminatedUnion('type', [
  z.object({ type: z.literal('BLOCK_NORMAL'), x: z.number(), y: z.number(), color: Color12Z, layer: z.number().optional() }).passthrough(),
  z
    .object({ type: z.literal('BLOCK_LARGE'), x: z.number(), y: z.number(), w: z.literal(2), h: z.literal(2), color: Color12Z, hp: z.number().optional(), layer: z.number().optional() })
    .passthrough(),
  z
    .object({ type: z.literal('BLOCK_LARGE_HIDDEN'), x: z.number(), y: z.number(), w: z.literal(2), h: z.literal(2), color: Color12Z, hp: z.number().optional(), revealRule: z.literal('REACH_BOTTOM'), layer: z.number().optional() })
    .passthrough(),
  z.object({ type: z.literal('PILLAR'), x: z.number(), y: z.number(), h: z.number(), layer: z.number().optional() }).passthrough(),
  z.object({ type: z.literal('BLOCK_HIDDEN'), x: z.number(), y: z.number(), color: Color12Z, revealRule: z.literal('REACH_BOTTOM'), layer: z.number().optional() }).passthrough(),
  z
    .object({
      type: z.literal('CHAIN_BARRIER'),
      x: z.number(),
      y: z.number(),
      color: Color12Z,
      // ✅ 체인 묶음/순서(옵션)
      chainId: z.string().optional(),
      chainOrder: z.number().optional(),
      layer: z.number().optional(),
    })
    .passthrough(),
  z.object({ type: z.literal('KEY'), x: z.number(), y: z.number(), keyId: z.string(), layer: z.number().optional() }).passthrough(),
  z.object({ type: z.literal('LOCK'), x: z.number(), y: z.number(), lockId: z.string(), layer: z.number().optional() }).passthrough(),
  z
    .object({
      type: z.literal('SPAWNER_BOX'),
      x: z.number(),
      y: z.number(),
      w: z.number().optional(),
      h: z.number().optional(),
      hp: z.number().optional(),
      // 구버전 호환(예전 queue 길이)
      spawnCount: z.number().optional(),
      spawn: z.object({ poolColors: z.array(Color12Z) }).optional(),
      layer: z.number().optional(),
    })
    .passthrough(),
]);

const StageZ = z.object({
  id: z.number(),
  equipOrder: z
    .array(z.string().regex(/^(R|O|Y|G|B|P|M|C|S|L|K|W)[12]$/))
    .optional(),
  meta: z.object({
    blockCount: z.number(),
    layerCount: z.number(),
    colorCount: z.number(),
    slotCount: z.number(),
    waitLineCount: z.number(),
    connectShooterCount: z.number(),
    hiddenShooterCount: z.number(),
    lockShooterCount: z.number(),
    ammoMin: z.number(),
    ammoMax: z.number(),
    seed: z.number().optional(),
    pickerCols: z.number(),
    pickerMaxCards: z.number(),
  }),
  board: z.object({ w: z.literal(10), h: z.literal(10), objects: z.array(ObjZ) }),
  // ✅ 신규: supply.pages
  // ✅ 구버전 호환: supplyPages / supply.mode+perCol 은 parsePack에서 흡수/정규화합니다.
  supply: z
    .object({
      mode: z.enum(['PATTERN']).optional(),
      pages: z.array(z.object({ objects: z.array(ObjZ) })).optional(),
    })
    .passthrough(),
  cards: z.object({
    mode: z.enum(['GENERATE', 'AUTHORED']),
    rules: z.object({ ammoStep: z.literal(10), totalAmmoEquals: z.union([z.literal('BOARD_BLOCKS'), z.number()]) }).optional(),
    authored: z
      .array(
        z.object({
          color: Color12Z,
          ammo: z.number(),
          shotCount: z.union([z.literal(1), z.literal(2)]).optional(),
          hintStep: z.number().optional(),
        }),
      )
      .optional(),
  }),
  shooters: z.object({ slots: z.array(z.object({ slot: z.number(), type: z.string(), lockId: z.string().optional() })) }),
});

export const StagePackV2Z = z.object({
  schemaVersion: z.literal(2),
  stages: z.array(StageZ),
});

export type StagePackV2Json = z.infer<typeof StagePackV2Z>;
