"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AtlasCache = exports.LabelPalette = exports.ColorPalette = exports.DEFAULT_COLOR_TOKENS_12 = exports.DEFAULT_PALETTE_HEX_12 = void 0;
exports.pad2 = pad2;
exports.toSpriteIndex = toSpriteIndex;
exports.colorFromId = colorFromId;
const cc_1 = require("cc");
exports.DEFAULT_PALETTE_HEX_12 = [
    '#fc5a59', // 01 Red
    '#e87c48', // 02 Orange
    '#e2ab2e', // 03 Yellow
    '#7fbe63', // 04 Green
    '#5eb2e4', // 05 Blue
    '#9f85e4', // 06 Purple
    '#e485c1', // 07 Pink
    '#73c7bf', // 08 Sky
    '#728fe9', // 09 Pastel Blue
    '#b2cc6f', // 10 Light Green
    '#7c7d8f', // 11 Black
    '#8b90a0', // 12 White-ish
];
exports.DEFAULT_COLOR_TOKENS_12 = [
    'R',
    'O',
    'Y',
    'G',
    'B',
    'P',
    'M',
    'C',
    'S',
    'L',
    'K',
    'W',
];
const DEFAULT_TINT_HEX_12 = exports.DEFAULT_PALETTE_HEX_12.slice();
const LEGACY_8_TO_SPRITE_12 = [1, 2, 3, 4, 5, 6, 11, 12];
function clampInt(v, min, max) {
    return Math.max(min, Math.min(max, (v | 0)));
}
function hexToColor(hex) {
    const h = (hex ?? '').trim().replace('#', '');
    const r = parseInt(h.substring(0, 2), 16);
    const g = parseInt(h.substring(2, 4), 16);
    const b = parseInt(h.substring(4, 6), 16);
    if ([r, g, b].some((n) => Number.isNaN(n)))
        return new cc_1.Color(255, 255, 255, 255);
    return new cc_1.Color(r, g, b, 255);
}
function pad2(n) {
    const v = clampInt(n, 0, 99);
    return v < 10 ? `0${v}` : `${v}`;
}
function toSpriteIndex(colorId, colorCount) {
    const cc = clampInt(colorCount, 1, 12);
    const id = clampInt(colorId, 0, cc - 1);
    // 8색 이하일 때: 12색 아틀라스에 맞춰 맵핑
    if (cc <= 8)
        return LEGACY_8_TO_SPRITE_12[id] ?? 1;
    // 12색 스킴: 0->01 ... 11->12
    return id + 1;
}
class ColorPalette {
    // // 팔레트(hex 리스트)를 설정합니다(없거나 비면 기본 12색 유지).
    static setFromHex(hexList) {
        const list = Array.isArray(hexList) && hexList.length > 0 ? hexList : DEFAULT_TINT_HEX_12;
        this._colors = list.map(hexToColor);
    }
    // // 현재 팔레트 색상 개수를 반환합니다.
    static count() {
        return this._colors.length;
    }
    // // colorId에 해당하는 Color를 반환합니다(범위 밖이면 wrap).
    static get(colorId) {
        const n = this._colors.length;
        if (n <= 0)
            return cc_1.Color.WHITE;
        const i = ((colorId % n) + n) % n;
        const c = this._colors[i];
        return new cc_1.Color(c.r, c.g, c.b, 255);
    }
}
exports.ColorPalette = ColorPalette;
ColorPalette._colors = DEFAULT_TINT_HEX_12.map(hexToColor);
class LabelPalette {
    // // 인스펙터에서 지정한 라벨 색상(12개)을 등록합니다.
    static setCustom(colors) {
        if (Array.isArray(colors) && colors.length === 12) {
            this._custom = colors.map((c) => new cc_1.Color(c.r, c.g, c.b, 255));
        }
        else {
            this._custom = null;
        }
    }
    // // colorId에 해당하는 라벨 색상을 반환합니다.
    static get(colorId, colorCount) {
        const idx0 = toSpriteIndex(colorId, colorCount) - 1; // 0..11
        const src = (this._custom ?? this._defaults)[clampInt(idx0, 0, 11)];
        return new cc_1.Color(src.r, src.g, src.b, 255);
    }
}
exports.LabelPalette = LabelPalette;
LabelPalette._custom = null;
LabelPalette._defaults = exports.DEFAULT_PALETTE_HEX_12.map(hexToColor);
class AtlasCache {
    // // 사용할 SpriteAtlas를 등록합니다.
    static setAtlas(atlas) {
        this._atlas = atlas;
        this._map.clear();
    }
    // // 이름으로 SpriteFrame을 얻습니다(없으면 null).
    static frame(name) {
        const a = this._atlas;
        if (!a)
            return null;
        // 1) 캐시
        const cached = this._map.get(name);
        if (cached)
            return cached;
        // 2) 아틀라스 키가 `.png` 확장자를 포함하는 프로젝트가 있어 fallback 처리
        const f0 = a.getSpriteFrame(name) ?? null;
        const f1 = f0 ? f0 : (a.getSpriteFrame(`${name}.png`) ?? null);
        if (f1)
            this._map.set(name, f1);
        return f1;
    }
}
exports.AtlasCache = AtlasCache;
AtlasCache._atlas = null;
AtlasCache._map = new Map();
// // 외부에서 간단히 쓰기 위한 헬퍼
function colorFromId(colorId) {
    return ColorPalette.get(colorId);
}
