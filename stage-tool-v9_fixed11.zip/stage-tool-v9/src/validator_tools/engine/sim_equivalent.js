/* eslint-disable no-console */

const { loadExternalEngine } = require('./real_game_bridge');

let isRealEngine = false;
let engineInfo = { source: 'builtin-failsafe', detail: 'REAL_GAME_VALIDATOR_MODULE not configured' };
let external = null;

try {
  const loaded = loadExternalEngine();
  if (loaded && loaded.mod) {
    external = loaded.mod;
    isRealEngine = external.isRealEngine === true;
    engineInfo = { source: 'external-module', detail: loaded.modPath };
  }
} catch (e) {
  isRealEngine = false;
  engineInfo = { source: 'external-module-error', detail: String(e?.message ?? e) };
}

async function validateStageEquivalent(stage, opts = {}) {
  if (external && typeof external.validateStageEquivalent === 'function') {
    return external.validateStageEquivalent(stage, opts);
  }
  return {
    status: 'UNSOLVED',
    reason: 'REAL_ENGINE_BRIDGE_NOT_CONFIGURED',
    failStep: -1,
    opsUsed: [],
  };
}

module.exports = { isRealEngine, engineInfo, validateStageEquivalent };
