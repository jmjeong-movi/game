"use strict";
// Stage compiler entrypoint used by the stage tool.
//
// IMPORTANT:
// - This must match the real game logic (game_patched_v7) 1:1.
// - We keep the implementation in ./stage/* (copied from the game).
// - validator_tools/game/StageCompiler.js also re-exports this function so replay/export use the same compiler.
Object.defineProperty(exports, "__esModule", { value: true });
exports.compileRuntimeFromV2 = void 0;
var compileRuntimeFromV2_1 = require("./stage/compileRuntimeFromV2");
Object.defineProperty(exports, "compileRuntimeFromV2", { enumerable: true, get: function () { return compileRuntimeFromV2_1.compileRuntimeFromV2; } });
