import {
    _decorator,
    Component,
    Node,
    Prefab,
    UITransform,
    instantiate,
    Vec3,
    tween,
    NodePool,
    Tween,
    ParticleSystem,
    GradientRange,
    EventTouch,
} from 'cc';
import type { TweenEasing } from 'cc';

import { GRID_ROWS, GRID_COLS, TILE_W, TILE_H, TILE_SIZE, PROJECTILE_POOL_WARMUP } from './Config';
import type { StageRuntime, RuntimeSupplyLarge } from './Types';
import { SUPPLY_LARGE_BASE } from './Types';
import { ColorPalette } from './ColorPalette';
import { TileView } from './TileView';
import { ProjectileView } from './ProjectileView';
import { BoardIntroDrop } from './BoardIntroDrop';
import { ChainBarrierView } from './ChainBarrierView';
import { AudioManager } from '../core/AudioManager';
import { revealHiddenAtBottom as _revealHiddenAtBottom, processKeysAtBottom as _processKeysAtBottom, processSpawnerBoxes as _processSpawnerBoxes } from './board/special';

import {
    isShootableTarget as _isShootableTarget,
    isShootableEnt as _isShootableEnt,
    listShootableBigEnts as _listShootableBigEnts,
    listRow0BigEnts as _listRow0BigEnts,
    countRow0Big as _countRow0Big,
    countShootableBig as _countShootableBig,
    countShootableColumns as _countShootableColumns,
    pickShootTargets as _pickShootTargets,
    tryShootAtColumnEx as _tryShootAtColumnEx,
} from './board/shoot';

import { useItemMoveColorBlocksToTop as _useItemMoveColorBlocksToTop } from './board/itemMove';
import { estimateRequiredShotsByColorFront as _estimateRequiredShotsByColorFront } from './board/estimate';
import {
    findShootableColumn as _findShootableColumn,
    handleHitColumn as _handleHitColumn,
    handleHitCell as _handleHitCell,
} from './board/hit';
import { settleGravity as _settleGravity, settleGravityExcluding as _settleGravityExcluding, canFall as _canFall, moveDownOne as _moveDownOne } from './board/gravity';
import { fillTopHoles as _fillTopHoles } from './board/supply';

const { ccclass, property } = _decorator;

type BlockEnt = {
    id: number;
    row: number; // 앵커(좌하단)
    col: number; // 앵커(좌하단)
    w: number;
    h: number;
    view: TileView;
    // remaining 카운트(툴/컴파일러가 셀 기준으로 blockCount를 계산하므로 footprint 만큼 제거)
    worth: number;
};
export type ShootTargetPref = 'LEFT' | 'CENTER';

type ShootTarget = {
    col: number;
    entId: number;
    world: Vec3;
    // ✅ 추가 정보: 큰블럭(2x2) 여부와 남은 HP(연사 템포용)
    isBig?: boolean;
    hp?: number;
};

export type ShootAttemptOut = {
    entId: number;
    col0: number; // 예약된 첫 컬럼
    col1: number; // 예약된 둘째 컬럼(없으면 -1)
    isBig: boolean;
};

// BIG(2x2) shootable list item
export type ShootableBig = { entId: number; col: number };

@ccclass('Board')
export class Board extends Component {
    @property({ tooltip: '작은(1x1) 블럭 프리펩(Pre_Enemy_Block_Small)' })
    tilePrefab: Prefab | null = null;

    @property({ tooltip: '큰(2x2) 블럭 프리펩(Pre_Enemy_Block_Big). BLOCK_LARGE는 이 프리펩을 1개만 생성합니다.' })
    bigTilePrefab: Prefab | null = null;

    @property({ tooltip: '총알 프리팹(Mechanic_Ball)' })
    projectilePrefab: Prefab | null = null;

    @property({ tooltip: '그리드 한 칸 크기 - W(px). 스몰(1x1) 블럭 기준 폭' })
    tileSize = TILE_W;

    @property({ tooltip: '그리드 한 칸 크기 - H(px). 스몰(1x1) 블럭 기준 높이' })
    tileSizeY = TILE_H;

    // ✅ Deprecated
    // - 기존에는 셀 사이 얇은 틈(스프라이트 여백/필터링) 숨김을 위해 "오버스케일 패딩"을 두었으나,
    //   프로젝트 요구사항이 "셀 W/H를 인스펙터에서 지정" + "블럭 크기 자동 정합"으로 바뀌면서
    //   패딩 파라미터는 더 이상 사용하지 않습니다.
    // - 직렬화 호환(씬/프리팹 깨짐 방지)을 위해 필드는 유지하되, 인스펙터에는 노출하지 않습니다.
    @property({ tooltip: '[Deprecated] not used', visible: false })
    overscalePadSmall = 0;

    @property({ tooltip: '[Deprecated] not used', visible: false })
    overscalePadBig = 0;

    @property({ tooltip: '낙하 착지 스쿼시(스케일 변화) 사용 여부(갭/축소 느낌 이슈 시 OFF 권장)' })
    enableLandFx = false;

    @property({ tooltip: '작은 블럭 풀 예열 개수(0이면 예열 안 함)' })
    warmupSmall = 40;

    @property({ tooltip: '큰 블럭 풀 예열 개수(0이면 예열 안 함)' })
    warmupBig = 8;

    @property({ tooltip: '총알 풀 예열 개수(0이면 Config(PROJECTILE_POOL_WARMUP) 사용)' })
    warmupProjectiles = 0;

    @property({ type: Node, tooltip: '블럭이 생성될 부모 노드(UI2/Enemys/Blocks)' })
    tileLayer: Node | null = null;

    @property({
        type: BoardIntroDrop,
        tooltip: '인트로 드랍 연출 컴포넌트(BoardIntroDrop). 비워두면 인트로 드랍을 실행하지 않습니다.',
    })
    introDrop: BoardIntroDrop | null = null;

    @property({ type: Node, tooltip: '프로젝타일(총알)이 생성될 부모 노드(UI2/Mechanic/Projectiles 등)' })
    projectileLayer: Node | null = null;

    @property({
        type: Node,
        tooltip: 'FX(파티클)가 생성될 부모 노드(없으면 tileLayer 사용). 블럭 위에 띄우려면 별도 FX 레이어를 권장',
    })
    fxLayer: Node | null = null;

    // ----------------- Special Visual Prefabs -----------------

    @property({
        type: Prefab,
        tooltip:
            '✅ KEY(열쇠) 오브젝트 프리팹(예: Pre_Enemy_OBJ_Key). KEY 특수 블럭 위에 오버레이로 붙습니다.',
    })
    keyPrefab: Prefab | null = null;

    @property({
        type: Prefab,
        tooltip:
            '✅ 생성박스(탱크 기믹) 프리팹(예: Pre_Enemy_OBJ_Create). SPAWNER_BOX 특수 엔티티 위에 오버레이로 붙고 Create 애니메이션을 재생합니다.',
    })
    spawnerBoxPrefab: Prefab | null = null;

    @property({
        tooltip:
            '✅ (튜닝) 생성박스 오버레이 비주얼 가로(X) 크기 배율(2x2 셀 기준). 1=딱 맞춤, 1.1~1.35 추천. 플레이 중에도 값 변경 시 즉시 반영됩니다.',
    })
    spawnerBoxScale = 1.15;

    @property({
        tooltip:
            '✅ (튜닝) 생성박스 오버레이 비주얼 세로(Y) 크기 배율(2x2 셀 기준). 1=딱 맞춤, 1.1~1.35 추천. 플레이 중에도 값 변경 시 즉시 반영됩니다.',
    })
    spawnerBoxScaleY = 1.15;

    @property({
        type: Prefab,
        tooltip:
            '✅ PILLAR(기둥) 프리팹(예: Pre_Enemy_OBJ_Fix). PILLAR 특수 엔티티 위에 오버레이로 붙습니다.',
    })
    pillarPrefab: Prefab | null = null;

    @property({
        type: Prefab,
        tooltip:
            '✅ 체인 블럭(슬라임) 프리팹(예: Pre_Enemy_OBJ_Chain). CHAIN_SEG 그룹당 1개를 생성하여 길이를 본(Target_Left/Right)으로 조절합니다.',
    })
    chainPrefab: Prefab | null = null;

    @property({ tooltip: '제거 FX(Particle_Shatter) 풀 예열 개수' })
    warmupShatterFx = 24;

    private readonly rows = GRID_ROWS;
    private readonly cols = GRID_COLS;

    private colSupply: number[][] = []; // length=cols, pop()으로 공급
    private supplyLargeDefs: RuntimeSupplyLarge[] = [];

    // 셀 점유: -1 비어있음, 그 외는 엔티티 id
    private occ: Int32Array = new Int32Array(this.rows * this.cols);
    private ents = new Map<number, BlockEnt>();
    private nextEntId = 1;

    // 0/1 플래그(typed array)로 GC/접근 비용을 줄입니다.
    private colReserved: Uint8Array = new Uint8Array(this.cols);
    private colBusy: Uint8Array = new Uint8Array(this.cols);

    // ✅ 컬럼 예약 마스크 캐시(예외 복구 + per-hit 배열 할당 제거)
    // - 한 발(또는 1개 엔티티)에 의해 예약된 컬럼들의 bitmask를 각 컬럼에 저장
    // - handleHitColumn에서 target이 순간적으로 사라져도 정확히 예약 해제가 가능
    public colResMask: Int32Array = new Int32Array(this.cols);

    // 오브젝트 풀
    private smallPool = new NodePool();
    private bigPool = new NodePool();
    private projectilePool = new NodePool();

    // ✅ 제거 FX(Particle_Shatter) 오브젝트 풀
    private shatterFxPool = new NodePool();
    private shatterFxTemplate: Node | null = null;
    private shatterFxRecycleDelay = 0; // 템플릿 기반 자동 계산(하드코딩 제거)
    private remainingTiles = 0;
    private _totalBlocks = 0;
    private _destroyedBlocks = 0;
    private _onBlockDestroyed: ((destroyed: number, total: number) => void) | null = null;
    private unlockedLocks = new Set<string>();

    // ✅ KEY 블럭 획득 이벤트(LOCK 유닛/블럭 해제)
    private _onKeyCollected: ((keyId: string) => void) | null = null;
    private initialized = false;

    private initFailed = false;
    private initFailLogged = false;

    // ✅ 이동 중 엔티티(낙하/정렬 Tween 진행 중) ref-count
    // - 역할: 발사 타겟 선택에서 moving 블럭을 우선 제외하여 발사 템포를 일정하게 유지
    private _movingEntRef = new Map<number, number>();

    // ✅ 아이템3(블록 이동) 활성화 여부: 다음 블록 탭으로 색상 선택
    private _itemMoveBlockActive = false;

    // ✅ 아이템3 임시 버퍼(재사용 → GC 최소화)
    private _tmpOccItem: Int32Array = new Int32Array(this.rows * this.cols);
    private _tmpMovableEnts: BlockEnt[] = [];
    private _tmpMoveNewR: number[] = [];
    private _tmpMoveNewC: number[] = [];
    private _tmpMovedEnts: BlockEnt[] = [];
    private _tmpItemCols: number[] = []; // 아이템3: 영향받은 컬럼 목록(재사용)

    // ✅ 히든 공개/변환 임시 버퍼(재사용 → GC 최소화)
    // - 역할: 바닥에 닿은 히든 트리거를 감지하고, 히든 그룹 + 인접 연결 컴포넌트 변환을 수행
    private _tmpRevealBottomHidden: number[] = [];
    private _tmpRevealQueue: number[] = [];
    private _tmpRevealVisited: Uint8Array = new Uint8Array(this.rows * this.cols);
    private _tmpRevealEntSet: Set<number> = new Set();
    private _tmpRevealSeedCellByColor: Int32Array = new Int32Array(12); // colorId(0~11) -> seed cell index
    private _tmpRevealChangedEnt: Set<number> = new Set();

    // ✅ 타겟 선택(pickShootTargets) GC 줄이기용(재사용)
    // - 역할: pickShootTargets는 유닛 조준/리플레이에서 자주 호출되므로 매 호출 new Set을 피합니다.
    private _tmpPickUsedEnt: Set<number> = new Set();

    // ✅ 컬럼 uniq 처리(공급/정렬)용 버퍼(Set/Array.from 제거)
    private _tmpColMark: Uint8Array = new Uint8Array(this.cols);
    private _tmpColUniq: number[] = [];

    // ✅ SPAWNER_BOX 엔티티 추적(매번 ents 전체 스캔 제거)
    private _spawnerIds: Set<number> = new Set();

    // ✅ CHAIN_SEG 그룹 캐시(매번 ents 전체 스캔/Set 생성 제거)
    // - segIds: 체인 id -> 세그먼트 엔티티 id 집합
    // - colMask: 체인 id -> 점유 컬럼 bitmask
    private _chainSegIds: Map<string, Set<number>> = new Map();
    private _chainColMask: Map<string, number> = new Map();

    // ✅ 체인블럭(슬라임) 뷰(체인 id당 1개)
    private _chainViewById: Map<string, Node> = new Map();

    // ✅ 아이템3 임시: 선택된 엔티티 id Set(재사용 → GC 최소화)
    private _tmpMoveSelIds: Set<number> = new Set();
    // ✅ 아이템3 임시: 중력 처리 대상 리스트(재사용)
    private _tmpGravityList: BlockEnt[] = [];

    // ✅ BIG 타겟 전역 LOCK: 한 번 BIG을 쏘기 시작하면 파괴될 때까지 다른 BIG은 타겟 불가
    private currentBigTargetId: number = 0;

    // ✅ 임시 Vec3 풀(프레임 단위 재사용)
    // - 역할: 타겟 월드좌표/임시 변환에서 Vec3 할당을 줄입니다.
    // - 주의: 이 풀에서 얻은 Vec3는 "프레임 내"에서만 사용하세요(지속 보관 금지).
    private _tmpV3Pool: Vec3[] = [];
    private _tmpV3i = 0;
    private _tmpCellLocal = new Vec3();
    private _tmpWorldBase = new Vec3();
    private _tileUi: UITransform | null = null;

    // ✅ Tween 파라미터 Vec3(상수) - 매 호출 new Vec3() 제거
    private readonly _v3ScaleOut = new Vec3(0.0, 0.0, 1.0);
    private readonly _v3PopUp = new Vec3(1.12, 1.12, 1.0);
    private readonly _v3PopDown = new Vec3(1.0, 1.0, 1.0);

    // ✅ 안전한 Tween Promise 해제
    // - 역할: Tween.stopAllByTarget로 인해 onComplete가 호출되지 않아
    //   Promise/플래그가 영구 고착되는 문제를 막습니다.
    private _twDone: Map<string, (() => void) | null> = new Map();

    // ✅ 디버그/복구: 보드 BUSY 고착 감지(예약/바쁨/프로젝타일)
    // - 특정 상황에서 projectile tween/callback 누락으로 reserved/busy가 풀리지 않으면
    //   유닛이 "타겟이 있는데도 못 찾는" 것처럼 보일 수 있어 최소한의 스냅샷을 1회 출력합니다.
    private _busyAccT = 0;
    private _busyWarned = false;

    // ✅ 인스펙터 튜닝(생성박스 크기) 변경 감지
    private _prevSpawnerBoxScale = -999;
    private _prevSpawnerBoxScaleY = -999;


    // UI2(Enemys/Blocks/Line_01~15) 레이아웃 지원
    private useLineLayout = false;
    private lineNodes: Node[] = [];
    private colX: number[] = [];
    private lineDy = 0; // Line 간격(세로)
    private bottomLineIdx = 0; // lineNodes 기준 바닥 라인 인덱스

    // ✅ tileLayer(UITransform) 크기 기반 10x10 자동 배치용 캐시(라인 레이아웃 아닐 때 사용)
    private gridW = 0;
    private gridH = 0;
    private stepX = 0;
    private stepY = 0;
    private originX = 0;
    private originY = 0;

    private _tmpAim = new Vec3();

    // // 외부(CannonRack)에서 “중간점” 계산 시 할당을 줄이기 위한 임시 Vec3 제공
    public tmpVec3(): Vec3 {
        return this._tmpAim;
    }

    // 컬럼 개수(외부 시스템이 TTL 배열 등 크기 맞출 때 사용)
    public getColCount(): number {
        return this.cols;
    }

    // Validate that a (colorId, entId) is currently shootable at row0/col.
    // Used by UnitLineRack to keep a stable target (avoid per-shot retarget jitter).
    public isShootableTarget(colorId: number, entId: number, col: number): boolean {
        return _isShootableTarget(this, colorId, entId, col);
    }

    // ✅ 엔티티 기준 shootable 판정(컬럼 고정 불필요)
    // - 요구사항: BIG(2x2)처럼 여러 컬럼을 점유해도, "엔티티"를 고정으로 잡고 쏠 수 있어야 함
    // - UnitLineRack의 sticky/assignment가 entId 기반으로 동작하도록 지원
    public isShootableEnt(colorId: number, entId: number): { ok: boolean; col: number } {
        return _isShootableEnt(this, colorId, entId);
    }

    // ✅ 현재(row0)에서 colorId로 쏠 수 있는 BIG(2x2) 엔티티 목록을 좌→우로 반환
    // - 같은 BIG이 2컬럼을 차지하므로, entId 중복을 제거합니다.
    public listShootableBigEnts(colorId: number, pref: ShootTargetPref = 'LEFT'): ShootableBig[] {
        return _listShootableBigEnts(this, colorId, pref) as ShootableBig[];
    }

    // ✅ 현재(row0)에 존재하는 BIG(2x2) 엔티티 목록(좌→우), "사격 가능성"과 무관하게 반환
    // - 중요: colReserved/colBusy 때문에 순간적으로 shootable에서 빠져도, 유닛-타겟 고정 매칭이 깨지지 않도록 사용합니다.
    // - LOCK 미해제는 제외합니다(어차피 쏠 수 없음).
    public listRow0BigEnts(colorId: number, pref: ShootTargetPref = 'LEFT'): ShootableBig[] {
        return _listRow0BigEnts(this, colorId, pref) as ShootableBig[];
    }

    // ✅ v52+: per-frame GC 줄이기용(배열 재사용)
    // - UnitLineRack에서 매 프레임 색상별로 호출되므로, out 버퍼를 받아서 채웁니다.
    public listRow0BigEntsInto(colorId: number, out: ShootableBig[], _pref: ShootTargetPref = 'LEFT'): ShootableBig[] {
        out.length = 0;
        for (let c = 0; c < this.cols; c++) {
            const e = this.entAt(0, c);
            if (!e) continue;
            if ((e.view?.colorId ?? -999) !== (colorId | 0)) continue;
            if (!(e.w > 1 || e.h > 1)) continue;
            if ((e.col | 0) !== (c | 0)) continue;

            const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id)) continue;

            out.push({ entId: e.id | 0, col: e.col | 0 });
        }
        return out;
    }

    public countRow0Big(colorId: number, pref: ShootTargetPref = 'LEFT'): number {
        return _countRow0Big(this, colorId, pref);
    }


    // ✅ countShootableBig: UnitLineRack의 BIG budget 계산용
    public countShootableBig(colorId: number, pref: ShootTargetPref = 'LEFT'): number {
        return _countShootableBig(this, colorId, pref);
    }
    // // 현재 colorId로 쏠 수 있는(앞줄 타겟이 있고 잠김/예약/바쁨이 아닌) 컬럼 개수
    public countShootableColumns(colorId: number): number {
        return _countShootableColumns(this, colorId);
    }
    // // colorId로 이번 프레임에 쏠 타겟(컬럼)을 최대 maxShots개 선택합니다.
    // // - pref: LEFT면 좌측부터, CENTER면 중앙에 가까운 순서
    // // - 엔티티(2x2 포함) 중복을 피해서 듀얼이 한 블럭에 몰빵되지 않게 합니다.
    // // - ✅ 중요: "다른 색" 유닛 그룹은 서로 간섭하지 않아야 합니다.
    // //   따라서 BIG(2x2) 전역 LOCK을 사용하지 않고, BIG은 "우선순위"만 높게 두되
    // //   colorId가 다르면 SMALL 타겟 탐색을 계속합니다.
    // NOTE: excludeEnt is a per-color, per-frame planning aid.
    // It prevents multiple units of the same color from picking the same target entity
    // before reservations are actually applied by tryShootAtColumnEx.
    public pickShootTargets(
        colorId: number,
        maxShots: number,
        pref: ShootTargetPref = 'LEFT',
        excludeEnt?: Set<number>,
        allowBig: boolean = true,
    ): ShootTarget[] {
        return _pickShootTargets(this, colorId, maxShots, pref, excludeEnt, allowBig) as ShootTarget[];
    }

    // // shooterWorld    // // shooterWorld에서 “지정 컬럼(col)”로 colorId 발사를 시도합니다(가능하면 true).
    // // - 성공 시: 해당 엔티티가 점유하는 모든 컬럼을 colReserved로 예약(2x2 동시타격 방지)
    // // shooterWorld에서 “지정 컬럼(col)”로 colorId 발사를 시도합니다(가능하면 true).
    // // - 성공 시: 해당 엔티티가 점유하는 모든 컬럼을 colReserved로 예약(2x2 동시타격 방지)
    // // - out: 성공 시 예약된 컬럼 정보(할당 없이 재사용)
    public tryShootAtColumnEx(shooterWorld: Vec3, colorId: number, col: number, out: ShootAttemptOut): boolean {
        return _tryShootAtColumnEx(this, shooterWorld, colorId, col, out);
    }

    // 기존 API(호환): boolean만 필요할 때 사용
    public tryShootAtColumn(shooterWorld: Vec3, colorId: number, col: number): boolean {
        const tmp: ShootAttemptOut = { entId: 0, col0: -1, col1: -1, isBig: false };
        // ⚠️ 이 경로는 할당이 발생하므로, 런타임(연사)에서는 UnitLineRack에서 tryShootAtColumnEx를 사용하세요.
        return this.tryShootAtColumnEx(shooterWorld, colorId, col, tmp);
    }

    onLoad() {
        // 플래그/배열을 미리 만들어 재할당을 줄입니다.
        this.colReserved = new Uint8Array(this.cols);
        this.colBusy = new Uint8Array(this.cols);
        this.colResMask = new Int32Array(this.cols);
        this.colResMask.fill(0);
        this.occ.fill(-1);
    }

    // ✅ 스테이지 전환 시 남아있는 잔상(블럭 스프라이트/FX/투사체) 정리
    // - "게임 진행엔 무관하지만 몇 개 남아서 안 없어지는" 현상 방지
    // - clearAllEntities()가 관리하는 엔티티 외에, 풀/스케줄 기반으로 남을 수 있는 노드들을 안전하게 회수
    private cleanupStageTransitionArtifacts() {
        // (1) 보드에 예약된 scheduleOnce(예: shatter FX recycle) 제거
        try {
            this.unscheduleAllCallbacks();
        } catch {
            // ignore
        }

        // (2) 투사체 레이어 정리
        try {
            const pl = this.projectileLayer;
            if (pl && pl.isValid) {
                const kids = pl.children.slice();
                for (let i = 0; i < kids.length; i++) {
                    try {
                        this.releaseProjectile(kids[i]);
                    } catch {
                        // ignore
                    }
                }
            }
        } catch {
            // ignore
        }

        // (3) shatter FX(Particle_Shatter) 잔존 노드 정리
        // - 타일 프리팹 내부의 Particle_Shatter(블럭 내부)는 건드리지 않기 위해
        //   TileView의 자식/하위는 제외합니다.
        try {
            const root = (this.fxLayer && this.fxLayer.isValid ? this.fxLayer : null) ||
                (this.tileLayer && this.tileLayer.isValid ? this.tileLayer : null);
            if (root) {
                const stack: Node[] = [root];
                while (stack.length > 0) {
                    const n = stack.pop()!;
                    const children = n.children;
                    for (let i = 0; i < children.length; i++) {
                        const ch = children[i];
                        if (!ch || !ch.isValid) continue;

                        // 블럭 내부(=TileView 하위) FX는 스킵
                        if (ch.getComponentInParent(TileView)) {
                            stack.push(ch);
                            continue;
                        }

                        if (ch.name === 'Particle_Shatter') {
                            try {
                                Tween.stopAllByTarget(ch);
                            } catch {
                                // ignore
                            }

                            try {
                                const ps = ch.getComponentsInChildren(ParticleSystem);
                                for (let j = 0; j < ps.length; j++) {
                                    try {
                                        ps[j].stop();
                                        ps[j].clear();
                                    } catch {
                                        // ignore
                                    }
                                }
                            } catch {
                                // ignore
                            }

                            ch.active = false;
                            ch.removeFromParent();
                            try {
                                this.shatterFxPool.put(ch);
                            } catch {
                                // pool이 초기화되지 않은 경우 대비
                                try {
                                    ch.destroy();
                                } catch {
                                    // ignore
                                }
                            }
                            continue;
                        }

                        stack.push(ch);
                    }
                }
            }
        } catch {
            // ignore
        }
    }

    // ✅ 엔티티 관리에서 빠진(TileView 기반) 잔존 블럭 노드 정리
    private purgeDanglingTileViews() {
        try {
            if (!this.tileLayer || !this.tileLayer.isValid) return;
            const tvs = this.tileLayer.getComponentsInChildren(TileView);
            for (let i = 0; i < tvs.length; i++) {
                const tv = tvs[i];
                if (!tv || !tv.node || !tv.node.isValid) continue;
                try {
                    this.releaseTile(tv);
                } catch {
                    // ignore
                }
            }
        } catch {
            // ignore
        }
    }

    update(dt: number) {
        // ✅ 프레임 단위 임시 Vec3 풀 리셋
        this._tmpV3i = 0;

        // ✅ (튜닝) 생성박스 오버레이 크기 배율(X/Y)을 플레이 중 인스펙터에서 바꿔도 즉시 반영
        // - spawnerBoxScale(X), spawnerBoxScaleY(Y) 값이 변하면 기존 타일(TileView)에도 힌트를 다시 주입하고, 스포너만 리프레시합니다.
        try {
            let changed = false;
            const vx = Number(this.spawnerBoxScale);
            const vy = Number(this.spawnerBoxScaleY);
            if (isFinite(vx) && Math.abs(vx - this._prevSpawnerBoxScale) > 1e-6) {
                this._prevSpawnerBoxScale = vx;
                changed = true;
            }
            if (isFinite(vy) && Math.abs(vy - this._prevSpawnerBoxScaleY) > 1e-6) {
                this._prevSpawnerBoxScaleY = vy;
                changed = true;
            }
            if (changed) this._reapplySpecialHintsToTiles(true);
        } catch {
            // ignore
        }

        // ✅ BUSY 고착 감지(1회 스냅샷)
        // - projectile tween/callback 누락, handleHitColumn hang 등으로 reserved/busy가 풀리지 않으면
        //   유닛이 "타겟이 있는데도 못 찾는" 것처럼 보일 수 있습니다.
        try {
            const busyNow = this.isBusy();
            if (busyNow) {
                this._busyAccT += Math.max(0, dt || 0);
                if (this._busyAccT >= 3.0 && !this._busyWarned) {
                    this._busyWarned = true;

                    const cols = this.cols | 0;
                    const stuckCols: any[] = [];
                    for (let c = 0; c < cols; c++) {
                        const r = this.colReserved?.[c] ?? 0;
                        const b = this.colBusy?.[c] ?? 0;
                        if (!r && !b) continue;
                        const e0 = this.entAt(0, c);
                        const depth0 = e0 ? ((e0.view?.depth ?? 1) | 0) : 0;
                        const sp0 = e0 && depth0 <= 1 ? (e0.view?.getSpecial?.() ?? null) : null;

                        stuckCols.push({
                            c,
                            r: r | 0,
                            b: b | 0,
                            m: (this.colResMask?.[c] ?? 0) | 0,
                            entId: e0 ? (e0.id | 0) : 0,
                            colorId: e0 ? ((e0.view?.colorId ?? -999) | 0) : -999,
                            depth: depth0,
                            sp: (sp0 as any)?.t ?? null,
                        });
                    }

                    console.warn('[Board][BUSY_STUCK?]', {
                        t: Number(this._busyAccT.toFixed(3)),
                        remaining: this.remainingTiles | 0,
                        ents: this.ents?.size ?? 0,
                        movingEnt: this._movingEntRef?.size ?? 0,
                        projectileChildren: this.projectileLayer?.children?.length ?? 0,
                        stuckCols,
                    });
                }
            } else {
                this._busyAccT = 0;
                this._busyWarned = false;
            }
        } catch {
            // ignore
        }
    }

    // ✅ 특수 프리팹/셀 크기 힌트를 기존 타일에 재주입
    // - refreshSpawnerOnly=true: SPAWNER_BOX 타일만 forceRefresh
    private _reapplySpecialHintsToTiles(refreshSpawnerOnly: boolean) {
        try {
            if (!this.tileLayer || !this.tileLayer.isValid) return;

            const tvs = this.tileLayer.getComponentsInChildren(TileView);
            for (let i = 0; i < tvs.length; i++) {
                const tv = tvs[i];
                if (!tv || !tv.node || !tv.node.isValid) continue;

                try {
                    tv.setSpecialPrefabHints({
                        keyPrefab: this.keyPrefab,
                        spawnerBoxPrefab: this.spawnerBoxPrefab,
                        pillarPrefab: this.pillarPrefab,
                        tileW: this.tileSize,
                        tileH: this.tileSizeY,
                        spawnerBoxScaleX: this.spawnerBoxScale,
                        spawnerBoxScaleY: this.spawnerBoxScaleY,
                    });
                } catch {
                    // ignore
                }

                if (!refreshSpawnerOnly) {
                    try {
                        tv.forceRefresh();
                    } catch {}
                    continue;
                }

                // 스포너만 즉시 반영
                try {
                    const sp = tv.getSpecial?.();
                    if (sp?.t === 'SPAWNER_BOX') tv.forceRefresh();
                } catch {
                    // ignore
                }
            }
        } catch {
            // ignore
        }
    }

    start() {
        this.initOnce();
    }

    // 남은 타일 수(승리 조건 판단용)를 반환합니다.
    remaining(): number {
        return this.remainingTiles;
    }

    // 블럭이 완전히 제거될 때 호출할 리스너를 등록합니다.
    public setOnBlockDestroyed(fn: ((destroyed: number, total: number) => void) | null): void {
        this._onBlockDestroyed = fn;
    }

    // ✅ KEY 획득 이벤트 리스너 등록(LOCK 유닛/블럭 해제)
    public setKeyCollectedCallback(fn: ((keyId: string) => void) | null): void {
        this._onKeyCollected = fn;
    }

    // ✅ KEY 획득 처리(LOCK 해제)
    public collectKey(keyId: string): void {
        const id = String(keyId ?? '').trim();
        if (!id) return;
        this.unlockedLocks.add(id);
        try {
            this._onKeyCollected?.(id);
        } catch {
            // ignore
        }
    }

    // 현재 스테이지 총 블럭 수(목표치)를 반환합니다.
    public totalBlocks(): number {
        return this._totalBlocks;
    }

    // ✅ 엔티티가 현재 이동(낙하/정렬 Tween) 중인지 반환합니다.
    // - UnitLineRack에서 moving 타겟을 우선 제외해 “스몰→빅 전환 시 느려짐(컬럼 busy 대기)”을 줄입니다.
    public isEntMoving(entId: number): boolean {
        const c = this._movingEntRef.get(entId | 0) ?? 0;
        return c > 0;
    }

    // ✅ 임시 Vec3를 얻습니다(프레임 단위 재사용).
    // - 주의: 반환된 Vec3를 프레임 밖으로 저장/보관하면 안 됩니다.
    private tmpV3(): Vec3 {
        const i = this._tmpV3i++;
        let v = this._tmpV3Pool[i];
        if (!v) {
            v = new Vec3();
            this._tmpV3Pool[i] = v;
        }
        return v;
    }

    public beginItemMoveBlocksToTop() {
        // // 역할: 블록 이동 아이템 시작(다음 블록 탭으로 색상 선택)
        this._itemMoveBlockActive = true;
    }

    public cancelItemMoveBlocksToTop() {
        // // 역할: 블록 이동 아이템 강제 종료
        this._itemMoveBlockActive = false;
    }

    // ✅ 터치 이벤트의 target이 자식 노드인 경우를 대비해 TileView를 상위로 탐색합니다.
    private _getTileViewFromTarget(n: Node | null): TileView | null {
        // // 역할: 작은 블럭(내부 Root/Sprite 등) 터치 시에도 TileView를 정확히 찾기
        let cur: Node | null = n;
        while (cur && cur.isValid) {
            const tv = cur.getComponent(TileView);
            if (tv) return tv;
            cur = cur.parent;
        }
        return null;
    }

    private _onTileTouchEnd = (ev: EventTouch) => {
        // // 역할: 아이템3 활성화 상태에서만 동작(다음 블록 탭으로 색상 결정)
        if (!this._itemMoveBlockActive) return;

        const n = (ev?.target as Node | null) ?? null;
        if (!n || !n.isValid) return;

        const tv = this._getTileViewFromTarget(n);
        if (!tv) return;

        // 히든 제외
        if ((tv as any).isHidden?.()) return;

        // 일반 빅/스몰만: 체인/락/스포너 등 특수 블록 제외
        const sp = (tv.depth ?? 1) <= 1 ? tv.getSpecial?.() : null;
        if (sp) return;

        const cid = tv.colorId | 0;
        if (cid < 0) return;

        this._itemMoveBlockActive = false;
        this.useItemMoveColorBlocksToTop(cid).catch(() => {});
    };

    public async useItemMoveColorBlocksToTop(colorId: number, moveSec = 0.16): Promise<boolean> {
        return _useItemMoveColorBlocksToTop(this, colorId, moveSec);

    }

    // ✅ (CardTray용) 색상별 “필요 탄 수”를 추정합니다.
    // - 이름은 Front지만, 실제로는 "현재 보드 + 남은 supply + 스포너 큐"까지 포함합니다.
    // - 역할: 카드 탄약이 부족해지는 문제 방지(스테이지 로드 직후 1회 호출 권장)
    public estimateRequiredShotsByColorFront(): Map<number, number> {
        return _estimateRequiredShotsByColorFront(this);

    }

    // 컬럼 애니메이션/프로젝타일이 남아있는지 여부를 반환합니다.
    isBusy(): boolean {
        // 역할: 예약/바쁨 플래그 + 남아있는 프로젝타일까지 포함해 "보드가 아직 진행 중인지" 판단
        for (let c = 0; c < this.cols; c++) {
            if (this.colReserved[c] || this.colBusy[c]) return true;
        }
        if (this.projectileLayer && this.projectileLayer.isValid && this.projectileLayer.children.length > 0) return true;
        return false;
    }

    // 현재 colorId로 즉시 발사가 가능한 컬럼이 있는지 확인합니다.
    canShootColor(colorId: number): boolean {
        return this.findShootableColumn(colorId) >= 0;
    }

    // 바닥(앞줄)에서 해당 colorId가 존재하는지 확인합니다.
    hasFrontColor(colorId: number): boolean {
        for (let c = 0; c < this.cols; c++) {
            const e = this.entAt(0, c);
            if (!e) continue;
            const top = e.view.colorId;
            if (top === colorId) return true;
        }
        return false;
    }

    // 엔티티를 현재 row/col에 맞게 즉시 스냅(라인 레이아웃 부모까지 재설정)
    private snapEntImmediate(e: BlockEnt) {
        const n = e.view.node;
        const t = this.entParentAndLocal(e);
        if (!n || !t.parent) return;
        n.setParent(t.parent);
        n.setPosition(t.local);
    }

    // StageRuntime을 받아 보드/공급/남은블록을 초기화합니다.
    load(runtime: StageRuntime) {
        this.initOnce();
        if (!this.isReady()) return;

        // ✅ 스테이지 전환 시 남는 블럭/FX 잔상 정리
        // - 게임 진행과 무관한 시각적 잔존 노드 제거
        this.cleanupStageTransitionArtifacts();
        this.resetBusyFlags();

        // ✅ tileLayer 크기(10x10 자동 배치 기준)를 최신으로 캐시
        // (레이아웃/리사이즈가 런타임 중에 바뀌는 경우를 대비)
        this.cacheTileLayerGridMetrics();

        // 기존 엔티티/점유 제거
        this.clearAllEntities();

        // clearAllEntities()로 회수되지 않은(엔티티 관리 밖) TileView 잔존 노드 정리
        this.purgeDanglingTileViews();

        // 공급 스택 복사
        this.colSupply = Array.from({ length: this.cols }, (_, c) =>
            runtime.columnSupply?.[c] ? runtime.columnSupply[c].slice() : [],
        );
        // supply LARGE 정의 복사
        this.supplyLargeDefs = Array.isArray((runtime as any).supplyLargeDefs)
            ? ((runtime as any).supplyLargeDefs as RuntimeSupplyLarge[]).slice()
            : [];

        // 키/락 상태 초기화
        this.unlockedLocks.clear();

        // ✅ remainingTiles는 “남은 제거 타수(=필요 탄 수)”로 사용
        // - 스택(겹) = 겹 수만큼
        // - CHAIN = hp만큼
        // - 큰 블럭 = hpMax만큼
        // - supply/스포너 큐 = 길이만큼
        this.remainingTiles = this.computeTotalHitsFromRuntime(runtime);

        // 진행도는 '총 블럭 수(totalBlocks)' 기준(블럭이 완전히 제거될 때만 증가)
        this._totalBlocks = Math.max(0, (runtime.totalBlocks ?? (runtime as any).blockCount ?? 0) | 0);
        this._destroyedBlocks = 0;

        // 1x1 생성 (largeMask=true는 skip)
        const largeMask = runtime.largeMask;

        // ✅ 생성/배치 순서(렌더 오더 안정화)
        // - 역할: "맨 아래(row=0)"가 가장 늦게 생성되어 UI 상에서 더 앞(위)에 오도록
        // - 주의: 로직(점유/중력/공급)은 동일, 자식 순서만 정리
        for (let r = this.rows - 1; r >= 0; r--) {
            for (let c = 0; c < this.cols; c++) {
                if (largeMask?.[r]?.[c]) continue;

                const stack = runtime.boardStacks?.[r]?.[c];
                if (Array.isArray(stack) && stack.length > 0) {
                    const e = this.spawnSmall(r, c);
                    if (!e) continue;
                    e.view.setStack(stack);
                    e.view.setHidden(!!runtime.hiddenMask?.[r]?.[c]);
                    e.view.setSpecial(runtime.special?.[r]?.[c] ?? null);
                    this.commitEnt(e);
                    continue;
                }

                const v = runtime.board?.[r]?.[c] ?? -1;
                if (typeof v === 'number' && v >= 0) {
                    const e = this.spawnSmall(r, c);
                    if (!e) continue;
                    e.view.setTop(v);
                    e.view.setHidden(!!runtime.hiddenMask?.[r]?.[c]);
                    e.view.setSpecial(runtime.special?.[r]?.[c] ?? null);
                    this.commitEnt(e);
                }
            }
        }

        // 2x2 큰 블럭 생성
        // ✅ 큰 블럭도 상단→하단 순으로 생성(렌더 순서 안정화)
        const lbs = (runtime.largeBlocks ?? []).slice().sort((a, b) => ((b?.y ?? 0) | 0) - ((a?.y ?? 0) | 0));
        for (const lb of lbs) {
            const e = this.spawnBig(lb.y | 0, lb.x | 0);
            if (!e) continue;
            e.view.setTop(lb.colorId);
            e.view.setHp(lb.hp ?? 1, lb.hpMax ?? lb.hp ?? 1);
            e.view.setHidden(!!(lb as any).hidden);
            e.view.setSpecial(null);
            this.commitEnt(e);
        }

        // ✅ 생성박스(2x2) 생성
        // - (x,y)는 "박스 자체"(2x2)의 하단-좌측
        // - 실제 생성(spawn)은 박스 바로 아래 1줄(spawn row=y-1)에서 수행
        const sbs = Array.isArray((runtime as any).spawnerBoxes) ? ((runtime as any).spawnerBoxes as any[]) : [];
        for (const sb of sbs) {
            const x0 = (sb?.x ?? -1) | 0;
            const y0 = (sb?.y ?? -1) | 0;
            const q = Array.isArray(sb?.queue) ? (sb.queue as number[]).slice() : [];
            const colorsRaw = Array.isArray((sb as any)?.colors) ? ((sb as any).colors as any[]) : null;
            if (x0 < 0 || x0 + 1 >= this.cols) continue;
            // 박스(2x2)가 보드 안에 있어야 함
            if (y0 < 0 || y0 + 1 >= this.rows) continue;
            // spawn row(y0-1)가 존재하려면 y0>=1
            if (y0 < 1) continue;

            // box body = 2x2
            const e = this.spawnCustom(y0, x0, 2, 2, 'SMALL', 0);
            if (!e) continue;
            // ✅ v48+: 색상은 좌/우 고정(시각용으로는 왼쪽 색을 표시)
            const leftColor = ((colorsRaw?.[0] ?? q[0] ?? 0) as any) | 0;
            const rightColor = ((colorsRaw?.[1] ?? q[1] ?? leftColor) as any) | 0;
            e.view.setTop(leftColor);
            e.view.setHidden(false);
            e.view.setHp(1, 1);
            e.view.setSpecial({ t: 'SPAWNER_BOX', queue: q, i: 0, colors: [leftColor, rightColor] } as any);
            this.commitEnt(e);
        }

        // ✅ 기둥(PILLAR) 생성
        // - 기둥은 타겟이 될 수 없고, 중력으로 낙하하지 않는 "고정" 오브젝트입니다.
        // - 런타임에는 cells로 직접 깔지 않고 runtime.pillars로만 내려오므로 여기서 커스텀 엔티티로 생성합니다.
        const ps = Array.isArray((runtime as any).pillars) ? (((runtime as any).pillars as any[]) as any[]) : [];
        for (const p of ps) {
            const x0 = (p?.x ?? -1) | 0;
            const y0 = (p?.y ?? -1) | 0;
            const h0 = Math.max(1, Math.floor(p?.h ?? 1));
            if (x0 < 0 || x0 >= this.cols) continue;
            if (y0 < 0 || y0 >= this.rows) continue;
            const hClamped = Math.min(h0, this.rows - y0);

            const e = this.spawnCustom(y0, x0, 1, hClamped, 'SMALL', 0);
            if (!e) continue;
            e.view.setTop(0);
            e.view.setHidden(false);
            e.view.setHp(1, 1);
            e.view.setSpecial({ t: 'PILLAR' } as any);
            this.commitEnt(e);
        }

        // 로드 직후 중력 정리: 떠있는 블럭을 바닥(row=0)까지 내림
        const moved = this.settleGravity();
        for (const e of moved) this.snapEntImmediate(e);

        // 히든 블럭이 바닥에 닿아 있으면 즉시 공개
        this.revealHiddenAtBottom();

        // ✅ 생성박스가 바닥에 닿아 spawn row(2칸)가 비어있다면 즉시 생성
        const spSpawned0 = this.processSpawnerBoxes();
        for (const e of spSpawned0) this.snapEntImmediate(e);

        // 만약 보드가 완전히 비었는데 supply는 있다면: 1회 채워서 시작 가능하게 함
        if (this.ents.size === 0) {
            let hasSupply = false;
            for (let c = 0; c < this.cols; c++) {
                if (this.colSupply[c] && this.colSupply[c].length > 0) {
                    hasSupply = true;
                    break;
                }
            }

            if (hasSupply) {
                const cols = Array.from({ length: this.cols }, (_, i) => i);
                const spawned = this.fillTopHoles(cols);
                for (const e of spawned) this.snapEntImmediate(e);
                this.revealHiddenAtBottom(cols);

                const spSpawned1 = this.processSpawnerBoxes();
                for (const e of spSpawned1) this.snapEntImmediate(e);
            }
        }

        // ✅ 인트로 드랍 연출(옵션)
        this.playIntroDropIfAny();

        // ✅ 최종 렌더 오더 동기화
        // - 역할: load/스냅/인트로 드랍(setParent) 이후에도 row 기준으로 앞/뒤가 고정되게 함
        this.syncDrawOrder();
    }

    // ✅ 인트로 드랍 연출을 실행합니다(Inspector에서 BoardIntroDrop를 연결한 경우만).
    // - 역할: 보드 로직(점유/중력)과 분리된 연출만 재생
    // - 성능: BoardIntroDrop 내부에서 Vec3 캐시/Opacity 재사용
    private playIntroDropIfAny(): void {
        const intro = this.introDrop ?? this.getComponent(BoardIntroDrop);
        if (!intro || !intro.isValid) return;
        if (!intro.enabled || !intro.IntroEnabled) return;
        if (!this.tileLayer || !this.tileLayer.isValid) return;

        // entParentAndLocal은 private이므로 여기서만 브릿지합니다.
        intro.play({
            tileLayer: this.tileLayer,
            cols: this.cols,
            ents: this.ents.values(),
            getEntParentAndLocal: (e: any) => this.entParentAndLocal(e as any),
        });

        // ✅ 인트로 드랍은 내부에서 setParent를 다시 수행하므로,
        //    즉시 row 기반 렌더 오더를 재동기화(바닥이 항상 앞에 오도록)
        this.syncDrawOrder();
    }

    // ✅ StageRuntime 기준 “총 필요 타수(=필요 탄 수)”를 계산합니다.
    // - 역할: CardTray 탄약 분배/승리 판정(remainingTiles) 정확도 보장
    // - 성능: 스테이지 로드 시 1회만 호출(런타임 중 매 프레임 호출 금지)
    private computeTotalHitsFromRuntime(runtime: StageRuntime): number {
        let total = 0;

        const largeMask = runtime.largeMask;
        const board = runtime.board;
        const stacks = runtime.boardStacks;
        const special = runtime.special;

        // 1) 1x1 셀(스택/체인/일반)
        for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
                if (largeMask?.[r]?.[c]) continue;

                const sp = special?.[r]?.[c] ?? null;
                if (sp?.t === 'CHAIN') {
                    total += Math.max(1, sp.hp | 0);
                } else {
                    const st = stacks?.[r]?.[c];
                    if (Array.isArray(st) && st.length > 0) total += st.length;
                    else {
                        const v = board?.[r]?.[c] ?? -1;
                        if (typeof v === 'number' && v >= 0) total += 1;
                    }
                }

                // SPAWNER(구버전) / SPAWNER_BOX(신규)의 queue도 결국 나오는 블럭이므로 필요 타수에 포함
                if (sp?.t === 'SPAWNER') {
                    const q = Array.isArray((sp as any).queue) ? (sp as any).queue : [];
                    total += q.length;
                } else if (sp?.t === 'SPAWNER_BOX') {
                    const q = Array.isArray((sp as any).queue) ? (sp as any).queue : [];
                    const i = ((sp as any).i ?? 0) | 0;
                    total += Math.max(0, (q.length | 0) - i);
                }
            }
        }

        // ✅ 신규 생성박스(runtime.spawnerBoxes)의 queue도 포함
        const sbs = Array.isArray((runtime as any).spawnerBoxes) ? ((runtime as any).spawnerBoxes as any[]) : [];
        for (const sb of sbs) {
            const q = Array.isArray(sb?.queue) ? (sb.queue as any[]) : [];
            total += q.length | 0;
        }

        // 2) 2x2 큰 블럭(HP 기반)
        const lbs = runtime.largeBlocks ?? [];
        for (let i = 0; i < lbs.length; i++) {
            const lb = lbs[i];
            const hpMax = (lb as any).hpMax ?? (lb as any).hp ?? 1;
            total += Math.max(1, hpMax | 0);
        }

        // 3) column supply
        // - SMALL/HIDDEN: 토큰 1개 = 1타
        // - LARGE(2x2): 토큰은 footprint(4셀)로 4개가 들어오지만, 필요 타수는 hpMax 1회만 더합니다.
        const cs = runtime.columnSupply ?? [];
        const seenLarge = new Set<number>();

        for (let c = 0; c < this.cols; c++) {
            const st = cs[c];
            if (!Array.isArray(st)) continue;
            for (let i = 0; i < st.length; i++) {
                const enc = st[i] | 0;
                if (enc >= SUPPLY_LARGE_BASE) {
                    const idx = Math.floor((enc - SUPPLY_LARGE_BASE) / 4);
                    if (idx >= 0) seenLarge.add(idx);
                } else {
                    total += 1;
                }
            }
        }

        const defs = Array.isArray((runtime as any).supplyLargeDefs)
            ? ((runtime as any).supplyLargeDefs as RuntimeSupplyLarge[])
            : [];
        for (const idx of seenLarge) {
            const d = defs[idx];
            const hpMax = (d as any)?.hpMax ?? (d as any)?.hp ?? 1;
            total += Math.max(1, hpMax | 0);
        }

        return Math.max(0, total | 0);
    }

    // shooterWorld에서 colorId로 발사를 시도합니다(가능하면 true).
    tryShoot(shooterWorld: Vec3, colorId: number): boolean {
        if (!this.projectilePrefab || !this.projectileLayer) return false;

        const col = this.findShootableColumn(colorId);
        if (col < 0) return false;

        const targetEnt = this.entAt(0, col);
        if (!targetEnt) return false;

        // ✅ 핵심: “타겟 엔티티가 점유하는 모든 컬럼”을 예약해서
        // (특히 2x2가 두 컬럼을 차지할 때) 다른 메카닉이 같은 블럭을 동시에 쏘지 못하게 막습니다.
        const sp0 = (targetEnt.view.depth ?? 1) <= 1 ? targetEnt.view.getSpecial() : null;
        // ✅ 성능: reservedCols 배열 할당 제거(컬럼 bitmask)
        const reservedMask =
            sp0?.t === 'CHAIN_SEG'
                ? this.chainColMask(String((sp0 as any).id ?? ''))
                : this.entColMask(targetEnt);

        for (let c = 0; c < this.cols; c++) {
            if (!(reservedMask & (1 << c))) continue;
            this.colReserved[c] = 1;
            this.colResMask[c] = reservedMask | 0;
        }

        const projectileNode = this.obtainProjectile();
        if (!projectileNode) {
            for (let c = 0; c < this.cols; c++) {
                if (!(reservedMask & (1 << c))) continue;
                this.colReserved[c] = 0;
                this.colResMask[c] = 0;
            }
            return false;
        }

        const pv = projectileNode.getComponent(ProjectileView);
        pv?.setColor(colorId);

        const layerUI = this.projectileLayer.getComponent(UITransform);
        if (!layerUI) {
            this.releaseProjectile(projectileNode);
            for (let c = 0; c < this.cols; c++) {
                if (!(reservedMask & (1 << c))) continue;
                this.colReserved[c] = 0;
                this.colResMask[c] = 0;
            }
            return false;
        }

        // ✅ 성능: convertToNodeSpaceAR의 반환 Vec3 할당 제거(프로젝타일당 Vec3 캐시 사용)
        const pv0 = projectileNode.getComponent(ProjectileView) as any;
        const v0: Vec3 = pv0?.tmp0 ? pv0.tmp0() : new Vec3();
        const v1: Vec3 = pv0?.tmp1 ? pv0.tmp1() : new Vec3();

        layerUI.convertToNodeSpaceAR(shooterWorld, v0);
        const endWorld = this.cellWorldPos(0, col);
        layerUI.convertToNodeSpaceAR(endWorld, v1);

        Tween.stopAllByTarget(projectileNode);
        projectileNode.parent = this.projectileLayer;
        projectileNode.active = true;
        projectileNode.setScale(1, 1, 1);
        projectileNode.setPosition(v0);

        const dist = Vec3.distance(v0, v1);
        const speed = 20000;
        const duration = Math.max(0.05, dist / speed);

        tween(projectileNode)
            .to(duration, { position: v1 })
            .call(() => {
                this.releaseProjectile(projectileNode);
                // ✅ 예약 해제는 handleHitColumn에서 “영향 컬럼 전체”를 정리하도록 바꿉니다.
                this.handleHitColumn(col).catch(() => {
                    // 예외 복구(최악의 경우 예약이 영구 고착되는 것을 방지)
                    for (let c = 0; c < this.cols; c++) {
                        if (!(reservedMask & (1 << c))) continue;
                        this.colReserved[c] = 0;
                        this.colResMask[c] = 0;
                    }
                    this.clearBusyAll();
                });
            })
            .start();

        return true;
    }

    // ---------------- 히트/중력/공급 ----------------

    // 현재 colorId로 맞출 수 있는 바닥(앞줄) 컬럼을 찾습니다.
    private findShootableColumn(colorId: number): number {
        return _findShootableColumn(this as any, colorId);
    }

    // 히트 처리(기본): row0(바닥) 히트
    private async handleHitColumn(colHit: number): Promise<void> {
        return _handleHitColumn(this as any, colHit);
    }

    // ✅ 확장 히트: row/col 기반
    // - 공중(row>0)의 체인 세그먼트를 타격해야 하는 요구사항 지원
    private async handleHitCell(rowHit: number, colHit: number): Promise<void> {
        return _handleHitCell(this as any, rowHit, colHit);
    }

    // ---------------- 진행도 ----------------

    // 블럭이 완전히 제거될 때만 진행도를 올리고 콜백을 호출합니다.
    private _notifyBlockDestroyed(worth: number): void {
        const t = this._totalBlocks | 0;
        if (t <= 0) return;

        const w = Math.max(0, worth | 0);
        if (w <= 0) return;

        const next = this._destroyedBlocks + w;
        this._destroyedBlocks = next > t ? t : next;
        const cb = this._onBlockDestroyed;
        if (cb) {
            try {
                cb(this._destroyedBlocks, t);
            } catch {}
        }
    }

    // ---------------- 엔티티/점유 ----------------

    // (row,col)에 점유된 엔티티를 반환합니다.
    private entAt(row: number, col: number): BlockEnt | null {
        if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) return null;
        const id = this.occ[this.indexOf(row, col)];
        if (id < 0) return null;
        return this.ents.get(id) ?? null;
    }

    // 엔티티가 점유하는 컬럼 목록을 반환합니다.
    // ✅ CHAIN_SEG(체인 묶음) 예약/바쁨 처리용: 체인 묶음이 점유하는 "전체 컬럼"을 반환
    // - 체인 히트 시 꼬리가 다른 컬럼에서 제거될 수 있으므로, 묶음 전체를 동시에 쏘지 못하게 막습니다.
    private _regChainSeg(e: BlockEnt, chainId: string) {
        const id = String(chainId ?? '');
        if (!id) return;
        let set = this._chainSegIds.get(id);
        if (!set) {
            set = new Set<number>();
            this._chainSegIds.set(id, set);
        }
        set.add(e.id | 0);

        const c = e.col | 0;
        if (c >= 0 && c < this.cols) {
            const m = (this._chainColMask.get(id) ?? 0) | 0;
            this._chainColMask.set(id, (m | (1 << c)) | 0);
        }

        // ✅ 체인 그룹 뷰 보장(체인 id당 1개)
        this._ensureChainView(id);
    }

    private _recalcChainMask(id: string, set?: Set<number>): number {
        let m = 0;

        if (set) {
            if (set.size <= 0) {
                this._chainSegIds.delete(id);
                this._chainColMask.delete(id);
                return 0;
            }
            for (const entId of set) {
                const ee = this.ents.get(entId | 0);
                if (!ee) continue;
                const c = ee.col | 0;
                if (c >= 0 && c < this.cols) m |= 1 << c;
            }
        } else {
            // fallback: set이 없을 때만 전체 스캔
            for (const ee of this.ents.values()) {
                const s2 = (ee.view.depth ?? 1) <= 1 ? ee.view.getSpecial() : null;
                if (s2?.t !== 'CHAIN_SEG') continue;
                if (String((s2 as any).id ?? '') !== id) continue;
                const c = ee.col | 0;
                if (c >= 0 && c < this.cols) m |= 1 << c;
            }
        }

        this._chainColMask.set(id, m | 0);
        return m | 0;
    }

    private _unregChainSeg(e: BlockEnt, chainId: string) {
        const id = String(chainId ?? '');
        if (!id) return;
        const set = this._chainSegIds.get(id);
        if (!set) {
            this._chainColMask.delete(id);
            return;
        }
        set.delete(e.id | 0);
        if (set.size <= 0) {
            this._chainSegIds.delete(id);
            this._chainColMask.delete(id);

            // ✅ 체인 그룹이 사라지면 뷰도 제거
            this._removeChainView(id);
            return;
        }
        this._recalcChainMask(id, set);
    }

    // ✅ 체인 그룹이 점유하는 컬럼 bitmask를 반환합니다.
    // - 성능: 사격/검증에서 매번 ents 전체 스캔 + Set 생성 + sort를 제거
    private chainColMask(chainId: string): number {
        const id = String(chainId ?? '');
        if (!id) return 0;

        const cached = this._chainColMask.get(id);
        if (cached !== undefined) return cached | 0;

        // lazy build: stage 로드 직후/외부 setSpecial로 인해 캐시가 비어있을 수 있음
        let set = this._chainSegIds.get(id);
        if (!set) {
            set = new Set<number>();
            this._chainSegIds.set(id, set);
        }

        for (const ee of this.ents.values()) {
            const s2 = (ee.view.depth ?? 1) <= 1 ? ee.view.getSpecial() : null;
            if (s2?.t !== 'CHAIN_SEG') continue;
            if (String((s2 as any).id ?? '') !== id) continue;
            set.add(ee.id | 0);
        }

        return this._recalcChainMask(id, set);
    }

    // ✅ 엔티티 footprint 컬럼 bitmask
    // - 성능: entCols()의 배열 할당 없이 컬럼 체크/예약 가능
    private entColMask(e: BlockEnt): number {
        let m = 0;
        for (let dx = 0; dx < e.w; dx++) {
            const c = (e.col + dx) | 0;
            if (c >= 0 && c < this.cols) m |= 1 << c;
        }
        return m | 0;
    }

    private chainGroupCols(chainId: string): number[] {
        const m = this.chainColMask(chainId);
        const out: number[] = [];
        for (let c = 0; c < this.cols; c++) {
            if (m & (1 << c)) out.push(c);
        }
        return out;
    }

    // 엔티티가 점유하는 컬럼 목록을 반환합니다.
    private entCols(e: BlockEnt): number[] {
        const out: number[] = [];
        for (let dx = 0; dx < e.w; dx++) {
            const c = e.col + dx;
            if (c >= 0 && c < this.cols) out.push(c);
        }
        return out;
    }

    // ----------------- Chain View (Slime) -----------------

    // ChainBarrierView에서 참조(런타임에서만 사용)
    public getEntById(id: number): BlockEnt | undefined {
        return this.ents.get(id | 0);
    }

    // ChainBarrierView에서 참조(런타임에서만 사용)
    public getChainSegIds(chainId: string): Set<number> | undefined {
        return this._chainSegIds.get(String(chainId ?? ''));
    }

    private _ensureChainView(chainId: string) {
        const id = String(chainId ?? '');
        if (!id) return;
        if (this._chainViewById.has(id)) return;
        if (!this.chainPrefab) return;

        // 체인은 블럭 위에 보이는 것이 자연스럽기 때문에 fxLayer가 있으면 그 위에 붙입니다.
        const parent = this.fxLayer ?? this.tileLayer ?? this.node;
        if (!parent) return;

        const nd = instantiate(this.chainPrefab);
        nd.setParent(parent);
        // 항상 위에 보이게 맨 뒤로
        try {
            nd.setSiblingIndex(parent.children.length - 1);
        } catch {}

        const cmp = nd.addComponent(ChainBarrierView);
        cmp.init(this, id);
        this._chainViewById.set(id, nd);
    }

    private _removeChainView(chainId: string) {
        const id = String(chainId ?? '');
        if (!id) return;
        const nd = this._chainViewById.get(id);
        if (nd) {
            try {
                if (nd.isValid) nd.destroy();
            } catch {}
        }
        this._chainViewById.delete(id);
    }


    // ✅ 임의 크기(w*h)의 엔티티를 생성합니다.
    // - 역할: 2x2(생성박스), 1xN/Nx1(체인) 등 확장 대비
    // - 주의: 시각표현(프리팹/스파인)은 별도이며, 여기서는 로직/점유를 우선합니다.
    private spawnCustom(row: number, col: number, w: number, h: number, skin: 'SMALL' | 'BIG', worth?: number): BlockEnt | null {
        const tv = this.obtainTile(skin);
        if (!tv) return null;

        tv.row = row;
        tv.col = col;
        tv.clear();

        tv.node.active = true;
        // obtainTile()에서 setSpecialPrefabHints + 스케일 정규화를 수행하므로 여기서는 건드리지 않습니다.

        const ent: BlockEnt = {
            id: this.nextEntId++,
            row,
            col,
            w: Math.max(1, w | 0),
            h: Math.max(1, h | 0),
            view: tv,
            worth: worth ?? Math.max(1, (w | 0) * (h | 0)),
        };

        // 배치(라인 레이아웃이면 Line_XX / 아니면 tileLayer 기준 10x10)
        const t = this.entParentAndLocal(ent);
        tv.node.setParent(t.parent);
        tv.node.setPosition(t.local);
        return ent;
    }

    // 1x1 엔티티(작은 블럭)를 생성합니다.
    private spawnSmall(row: number, col: number): BlockEnt | null {
        return this.spawnCustom(row, col, 1, 1, 'SMALL', 1);
    }

    // 2x2 엔티티(큰 블럭)를 생성합니다.
    private spawnBig(row: number, col: number): BlockEnt | null {
        return this.spawnCustom(row, col, 2, 2, 'BIG', 4);
    }

    // 엔티티를 Map/점유 그리드에 반영합니다.
    private commitEnt(e: BlockEnt) {
        this.ents.set(e.id, e);

        // ✅ 특수 엔티티 추적(성능)
        // - 매 틱 ents 전체 스캔을 피하기 위해, 생성/제거 시점에만 등록합니다.
        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'SPAWNER_BOX') {
            this._spawnerIds.add(e.id | 0);
        } else if (sp?.t === 'CHAIN_SEG') {
            this._regChainSeg(e, String((sp as any).id ?? ''));
        }

        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= this.rows || c < 0 || c >= this.cols) continue;
                this.occ[this.indexOf(r, c)] = e.id;
            }
        }
    }

    // 엔티티를 제거하고 노드를 풀로 반환합니다.
    private removeEnt(e: BlockEnt) {
        // ✅ 특수 엔티티 추적 해제(성능)
        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'SPAWNER_BOX') {
            this._spawnerIds.delete(e.id | 0);
        } else if (sp?.t === 'CHAIN_SEG') {
            this._unregChainSeg(e, String((sp as any).id ?? ''));
        }

        this.ents.delete(e.id);
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= this.rows || c < 0 || c >= this.cols) continue;
                if (this.occ[this.indexOf(r, c)] === e.id) this.occ[this.indexOf(r, c)] = -1;
            }
        }
        this.releaseTile(e.view);
    }

    // 모든 엔티티를 제거(스테이지 로드 시 호출).
    private clearAllEntities() {
        for (const e of this.ents.values()) {
            this.releaseTile(e.view);
        }
        this.ents.clear();
        this._movingEntRef.clear();
        this._spawnerIds.clear();
        this._chainSegIds.clear();
        this._chainColMask.clear();

        // ✅ 체인블럭(슬라임) 뷰 정리
        for (const nd of this._chainViewById.values()) {
            try {
                if (nd && nd.isValid) nd.destroy();
            } catch {}
        }
        this._chainViewById.clear();

        this._twDone.clear();

        // ✅ 스포너 생성 연출 중 컬럼 락(외부) 초기화
        try {
            const lk = (this as any).colSpawnLock;
            if (lk && typeof lk.fill === 'function') lk.fill(0);
        } catch {}

        this.occ.fill(-1);
        this.nextEntId = 1;
    }

    // ---------------- 중력/공급 ----------------

    // ✅ 중력으로 엔티티를 아래로 떨어뜨리고, 이동한 엔티티 목록을 반환합니다.
    // - 기존처럼 pass 반복 + 매번 sort 하지 않고,
    //   바닥쪽(row 낮은)부터 "가능한 만큼" 한 번에 내립니다(정렬 1회).
    private settleGravity(): BlockEnt[] {
        return _settleGravity(this as any) as any;
    }

    // ✅ 아이템3 전용: 특정 엔티티 id는 제외하고 중력 정렬합니다.
    // - 역할: 선택된 색상 블럭을 "빼고" 나머지만 자연스럽게 내려오게 함
    // - 성능: 배열/Set을 재사용해서 GC를 최소화
    private _settleGravityExcluding(excludeIds: Set<number>, outMoved: BlockEnt[]) {
        _settleGravityExcluding(this as any, excludeIds, outMoved as any);
    }

    // 엔티티가 아래로 1칸 떨어질 수 있는지 확인합니다.
    private canFall(e: BlockEnt): boolean {
        return _canFall(this as any, e as any);
    }

    // 엔티티를 아래로 1칸 이동(점유 그리드만 갱신, 노드 위치는 트윈에서 처리).
    private moveDownOne(e: BlockEnt) {
        _moveDownOne(this as any, e as any);
    }

    // 영향을 받은 컬럼의 "위쪽 빈칸"을 supply로 채워 새 엔티티를 반환합니다.
    private fillTopHoles(cols: number[] | number): BlockEnt[] {
        return _fillTopHoles(this as any, cols as any) as any;
    }

    // ✅ 바닥(row=0)에 도달한 히든 블럭을 공개합니다.
    // - 요구사항: "히든 블럭에 인접(4방향)한 같은색 히든 블럭"만 함께 공개되어야 합니다.
    // - 즉, 일반(비히든) 블럭의 색상을 바꾸는 변환은 하지 않습니다.
    // - 안정성: cols 힌트로 제한하면 누락이 생길 수 있어(중력/공급/아이템), 전체 컬럼을 검사합니다.
    private revealHiddenAtBottom(cols?: number[]) {
        // 내부 구현은 board/special.ts로 분리
        _revealHiddenAtBottom(this as any, cols);
    }

    // ✅ KEY: 키 블럭이 바닥(0행)에 닿으면 즉시 해당 id의 LOCK을 해제합니다.
    // - 키가 제거(파괴)되지 않아도, 바닥에 '닿는 순간' 해제되도록 처리합니다.
    private processKeysAtBottom() {
        // 내부 구현은 board/special.ts로 분리
        _processKeysAtBottom(this as any);
    }

    // ✅ 생성박스 처리
    // - 조건: 박스는 낙하하지 않고 고정. 박스 바로 아래(2x1 spawn row)가 비어있는 칸만큼 생성.
    // - 동작: spawn row의 각 셀이 비어있으면 queue에서 1개씩 꺼내 스몰 블럭을 생성(좌→우 순서).
    // - hp/queue 의미: queue 길이 = 남은 "생성할 블럭 수". 1블럭 생성할 때마다 1개 소비.
    // - queue가 소진되면 박스 몸통을 제거(타격 대상이 아님)
    private processSpawnerBoxes(): BlockEnt[] {
        // 내부 구현은 board/special.ts로 분리
        return _processSpawnerBoxes(this as any) as BlockEnt[];
    }

    // ---------------- Pool / Init ----------------

    // ✅ tileLayer(UITransform) 크기를 기준으로 10x10 셀 간격/원점을 캐싱합니다.
    // - 라인 레이아웃(useLineLayout)이면 사용하지 않습니다.
    // - tileLayer의 anchorX/anchorY를 반영해서 "어떤 앵커"여도 정확히 10x10이 들어가게 합니다.
    private cacheTileLayerGridMetrics() {
        if (this.useLineLayout) return;
        if (!this.tileLayer || !this.tileLayer.isValid) return;

        const ui = this.tileLayer.getComponent(UITransform);
        if (!ui) return;

        const sx = Math.max(1, Math.round(this.tileSize || TILE_W));
        const sy = Math.max(1, Math.round(this.tileSizeY || TILE_H));

        this.stepX = sx;
        this.stepY = sy;

        const gridW = this.cols * sx;
        const gridH = this.rows * sy;
        this.gridW = gridW;
        this.gridH = gridH;

        // ✅ Tile Layer(Blocks) UITransform이 작은 값으로 저장돼 있으면
        // 셀이 bounds 밖으로 나가 "보드 밖으로 블럭이 생기는" 문제가 발생합니다.
        // 보드는 (셀W/H) * (cols/rows)로 결정되므로, 런타임에서 layer size를 grid에 맞춥니다.
        // (Blocks 컨테이너에 Widget이 붙어 있지 않은 구조라면 안전)
        if (Math.abs(ui.width - gridW) > 0.5 || Math.abs(ui.height - gridH) > 0.5) {
            ui.setContentSize(gridW, gridH);
        }

        const w = Math.max(1, ui.width);
        const h = Math.max(1, ui.height);

        // ✅ 핵심: AR 좌표의 (0,0)은 anchor 기준이므로 anchorX/Y 반영
        const ax = ui.anchorX; // 0~1
        const ay = ui.anchorY; // 0~1

        // tileLayer 로컬에서 왼쪽 끝 = -w*ax, 아래 끝 = -h*ay
        const left = -w * ax;
        const bottom = -h * ay;

        // tileLayer가 더 크면 여유를 반씩 나눠 센터링
        const extraX = (w - gridW) * 0.5;
        const extraY = (h - gridH) * 0.5;

        this.originX = left + extraX + sx * 0.5;
        this.originY = bottom + extraY + sy * 0.5;

        // ✅ 픽셀 스냅(서브픽셀 위치 → 블럭 경계에 얇은 틈이 보이는 현상 방지)
        this.originX = Math.round(this.originX);
        this.originY = Math.round(this.originY);
    }

    // ✅ 프리팹/레이어가 준비되면 풀을 초기화합니다.
    private initOnce() {
        if (this.initialized || this.initFailed) return;

        if (!this.tileLayer || !this.tilePrefab) {
            if (!this.initFailLogged) {
                this.initFailLogged = true;
                if (!this.tileLayer) console.error('[Board] tileLayer is null (UI2/Enemys/Blocks 연결 필요)');
                if (!this.tilePrefab)
                    console.error('[Board] tilePrefab(Pre_Enemy_Block_Small) is null (Prefab 연결 필요)');
            }
            this.initFailed = true;
            return;
        }

        // ✅ 셀 크기(tileSize/tileSizeY)는 인스펙터 값이 "소스 오브 트루스"입니다.
        // - 기존 코드에서는 런타임에 TILE_W/TILE_H로 강제하여(=인스펙터 값 무시)
        //   스테이지/리소스별 셀 크기 조정이 불가능했습니다.
        // - 이제는 tileSize/tileSizeY를 그대로 사용합니다.

        // UI2의 Line_01~ 레이아웃이면 자동으로 라인/컬럼 좌표를 캐싱
        this.setupLineLayoutIfAny();

        // ✅ 라인 레이아웃이 아니라면 tileLayer 크기 기반 10x10 자동 배치 캐시
        this.cacheTileLayerGridMetrics();

        // 타일/총알 풀 예열(최초 1회)
        this.prewarmTiles('SMALL', this.warmupSmall);
        this.prewarmTiles('BIG', this.warmupBig);
        const projWarm = (this.warmupProjectiles | 0) > 0 ? this.warmupProjectiles | 0 : PROJECTILE_POOL_WARMUP;
        this.prewarmProjectiles(projWarm);

        // ✅ 제거 FX(Particle_Shatter) 풀 초기화(하드코딩 없는 자동 수명 계산 포함)
        this.initShatterFxOnce();

        this.initialized = true;
    }

    // ✅ 제거(Particle_Shatter) FX 풀을 1회 초기화합니다.
    // - 역할: 블럭 노드가 즉시 풀로 반환되어도 파티클은 별도 노드로 끝까지 재생
    // - 성능: 템플릿은 1회만 추출, NodePool로 재사용
    // - 수명: ParticleSystem 설정(duration/startDelay/startLifetime) 기반으로 자동 회수 시간 계산(1.4초 하드코딩 제거)
    private initShatterFxOnce() {
        if (this.shatterFxTemplate && this.shatterFxTemplate.isValid) return;
        if (!this.tilePrefab) return;

        if (!this.fxLayer) this.fxLayer = this.tileLayer; // FX 레이어가 없으면 tileLayer 사용

        // tilePrefab을 임시 1회 인스턴스화해서 Particle_Shatter 템플릿을 추출
        const tmp = instantiate(this.tilePrefab);
        tmp.active = false;

        const sh = this.findNodeByName(tmp, 'Particle_Shatter');
        if (!sh) {
            console.warn(
                '[Board] Particle_Shatter 노드를 찾지 못했습니다. 블럭 프리팹 내부에 Particle_Shatter가 있는지 확인해주세요.',
            );
            tmp.destroy();
            return;
        }

        sh.active = false;
        this.shatterFxTemplate = instantiate(sh);
        this.shatterFxTemplate.active = false;

        // ✅ 템플릿 기반 “자동 회수 딜레이” 계산(모든 ParticleSystem 중 최대값)
        this.shatterFxRecycleDelay = this.calcParticleNodeRecycleDelay(this.shatterFxTemplate);

        const warm = Math.max(0, Math.floor(this.warmupShatterFx));
        for (let i = 0; i < warm; i++) {
            const n = instantiate(this.shatterFxTemplate);
            n.active = false;
            this.shatterFxPool.put(n);
        }

        tmp.destroy();
    }

    // ✅ 파티클 노드가 “완전히 끝날 때”까지의 최대 시간을 계산합니다.
    // - 구성: startDelay(max) + duration + startLifetime(max) + 안전 마진
    private calcParticleNodeRecycleDelay(root: Node): number {
        const ps = root.getComponentsInChildren(ParticleSystem);
        let maxT = 0;
        for (let i = 0; i < ps.length; i++) {
            const p = ps[i];
            // loop가 켜져있으면 회수 불가하므로, 재생 시 loop를 false로 강제합니다.
            // (여기서는 계산만)
            const delay = p.startDelay ? p.startDelay.getMax() : 0;
            const life = p.startLifetime ? p.startLifetime.getMax() : 0;
            const dur = Number.isFinite(p.duration) ? Math.max(0, p.duration) : 0;
            const t = delay + dur + life;
            if (t > maxT) maxT = t;
        }
        // 안전 마진(프레임/스케줄 지연 보정). 1.4초 같은 고정값이 아니라, 계산값에 소량만 더함.
        return Math.max(0.05, maxT + 0.05);
    }

    // ✅ 이름으로 자식 노드를 DFS로 탐색합니다.
    // - 역할: 프리팹 구조가 약간 달라도 Particle_Shatter를 찾을 수 있게 보강
    private findNodeByName(root: Node, name: string): Node | null {
        const stack: Node[] = [root];
        while (stack.length) {
            const n = stack.pop()!;
            if (n.name === name) return n;
            const ch = n.children;
            for (let i = ch.length - 1; i >= 0; i--) stack.push(ch[i]);
        }
        return null;
    }

    // ✅ 제거 FX(Particle_Shatter)를 월드 좌표에서 재생합니다.
    // - 역할: 블럭 제거 시 파편 파티클의 Start Color를 “블럭 색상”으로 맞춰 보여줌
    private playShatterFxAtWorld(worldPos: Vec3, colorId: number) {
        if (!this.shatterFxTemplate || !this.shatterFxTemplate.isValid) return;
        const parent = this.fxLayer ?? this.tileLayer;
        if (!parent || !parent.isValid) return;

        const fx = this.shatterFxPool.size() > 0 ? this.shatterFxPool.get() : instantiate(this.shatterFxTemplate);
        fx.active = true;
        fx.setScale(1, 1, 1);
        fx.setParent(parent);
        AudioManager.I?.playSfxByIndex(3, { volume: 1.0, minIntervalMs: 8 });

        const ui = parent.getComponent(UITransform);
        const local = ui ? ui.convertToNodeSpaceAR(worldPos) : worldPos;
        fx.setPosition(local);

        // Start Color를 해당 블럭 컬러로 세팅
        const c = ColorPalette.get(colorId);

        const ps = fx.getComponentsInChildren(ParticleSystem);
        for (let i = 0; i < ps.length; i++) {
            const p = ps[i];
            (p as any).playOnAwake = false;

            // loop 방지: 제거 FX는 1회 재생이 정상
            if (p.loop) p.loop = false;

            // Start Color 강제 적용(GradientRange.Mode.Color)
            try {
                const sc = p.startColor;
                sc.mode = GradientRange.Mode.Color;

                // Cocos 3.x: startColor.color은 Readonly<Color>로 노출될 수 있어 채널 직접 대입이 막힙니다.
                // set()을 사용하면 타입 에러 없이 동일 효과를 얻습니다.
                try {
                    (sc.color as any)?.set?.(c.r, c.g, c.b, 255);
                } catch {
                    // ignore
                }
            } catch {
                // ignore
            }

            try {
                p.stop();
                p.clear();
                p.play();
            } catch {
                // ignore
            }
        }

        // ✅ 하드코딩 제거: 템플릿 설정 기반 자동 회수
        const delay = this.shatterFxRecycleDelay > 0 ? this.shatterFxRecycleDelay : 0.05;
        this.scheduleOnce(() => {
            try {
                const ps2 = fx.getComponentsInChildren(ParticleSystem);
                for (let i = 0; i < ps2.length; i++) {
                    try {
                        ps2[i].stop();
                        ps2[i].clear();
                    } catch {
                        // ignore
                    }
                }
            } catch {
                // ignore
            }

            fx.active = false;
            fx.removeFromParent();
            this.shatterFxPool.put(fx);
        }, delay);
    }

    // // UI2 Blocks/Line_01~15 구조면 라인/컬럼 좌표를 캐싱하고 더미 슬롯을 숨깁니다.
    // // 단, "정확히 10x10 그리드"로 쓰는 구조가 아닐 경우 라인 레이아웃을 사용하지 않습니다.
    private setupLineLayoutIfAny() {
        if (!this.tileLayer) return;

        const test = this.tileLayer.getChildByName('Line_01');
        if (!test) return;

        const lines: Node[] = [];
        for (let i = 1; i <= 99; i++) {
            const name = `Line_${String(i).padStart(2, '0')}`;
            const n = this.tileLayer.getChildByName(name);
            if (!n) break;
            lines.push(n);
        }

        // ✅ "rows(10)" 개가 정확히 준비되지 않으면 라인 레이아웃 OFF
        if (lines.length !== this.rows) return;

        // ✅ "cols(10)" 개 슬롯이 Line_01에 정확히 있어야 라인 레이아웃 ON
        const slotNodes = lines[0].children;
        if (slotNodes.length < this.cols) return;

        // ✅ 라인 이름(Line_01~)의 위/아래 배치는 프로젝트마다 다를 수 있으므로,
        //    실제 y 좌표 기준으로 "바닥(row=0) -> 위(row=rows-1)" 순서로 정렬합니다.
        // - 역할: row 감소/증가와 화면 상 이동 방향이 항상 일치하도록 보장
        // - 버그픽스: 타겟 제거 후 다음 라인이 내려오지 않던 현상(라인 매핑 뒤집힘)을 방지
        const sortedByY = lines.slice().sort((a, b) => a.position.y - b.position.y);

        // ✅ 정렬 후에도 cols 슬롯이 충분한지 재검증(안전장치)
        const bottomSlots = sortedByY[0]?.children ?? [];
        if (bottomSlots.length < this.cols) return;

        this.useLineLayout = true;
        this.lineNodes = sortedByY;
        this.bottomLineIdx = 0;
        this.lineDy = Math.abs(sortedByY[1].position.y - sortedByY[0].position.y);

        // // 컬럼 X는 "바닥 라인"의 자식(더미 슬롯) 위치를 사용
        // - 라인마다 동일한 슬롯 X를 공유한다는 전제(일반적인 그리드 프리팹)
        const xs = bottomSlots
            .map((c) => c.position.x)
            .slice(0)
            .sort((a, b) => a - b);
        this.colX = xs.slice(0, this.cols);

        // ✅ 간격 정규화(요구사항: 한 셀=56px)
        // - 프리팹(더미 슬롯/라인)이 더 큰 간격으로 배치되어 있으면 블럭 사이가 벌어져 보입니다.
        // - "기존 중심"은 유지하고, 간격만 tileSize(기본 56)로 재배치합니다.
        try {
            const stepX = Math.max(1, Math.round(this.tileSize || TILE_W));
            const stepY = Math.max(1, Math.round(this.tileSizeY || TILE_H));

            // (1) Y: line 노드 자체를 재배치 → 블럭(자식) 전체가 함께 이동
            const y0 = sortedByY[0]?.position.y ?? 0;
            const yN = sortedByY[sortedByY.length - 1]?.position.y ?? y0 + stepY * (this.rows - 1);
            const cy = (y0 + yN) * 0.5;
            const startY = Math.round(cy - stepY * (this.rows - 1) * 0.5);
            for (let i = 0; i < sortedByY.length; i++) {
                const ln = sortedByY[i];
                if (ln && ln.isValid) ln.setPosition(ln.position.x, startY + i * stepY, ln.position.z);
            }
            this.lineDy = stepY;

            // (2) X: 블럭 배치 기준(colX)만 정규화(더미 슬롯 노드는 건드리지 않음)
            const x0 = this.colX[0] ?? 0;
            const xN = this.colX[this.cols - 1] ?? x0 + stepX * (this.cols - 1);
            const cx = (x0 + xN) * 0.5;
            const startX = Math.round(cx - stepX * (this.cols - 1) * 0.5);
            this.colX = Array.from({ length: this.cols }, (_, i) => startX + i * stepX);
        } catch {}

        // // 더미 슬롯을 숨김(겹침 방지)
        for (const ln of sortedByY) {
            for (const ch of ln.children) {
                // ✅ 이름 규칙이 프로젝트마다 달라서 "무조건" 숨기고 싶으면 조건을 더 넓히는 게 안전합니다.
                // 현재는 기존 조건 + 'Slot'/'Cell'류를 포함해 폭넓게 숨김.
                const nm = ch.name ?? '';
                if (
                    nm.startsWith('Enemy_') ||
                    nm.startsWith('Block_') ||
                    nm.includes('Enemy_Block') ||
                    nm.includes('Slot') ||
                    nm.includes('Cell') ||
                    nm.includes('Grid')
                ) {
                    ch.active = false;
                }
            }
        }

        // ✅ 라인(행) 렌더 순서를 "위 → 바닥"으로 정렬
        // - 역할: 바닥(row=0)이 항상 앞(위)에 렌더되도록 보장
        this.syncDrawOrder();
    }

    // 보드가 정상 초기화됐는지 반환합니다.
    public isReady(): boolean {
        return this.initialized && !this.initFailed;
    }

    // 작은/큰 블럭(TileView) 노드를 풀에서 꺼냅니다.
    private obtainTile(kind: 'SMALL' | 'BIG'): TileView | null {
        if (!this.tileLayer) return null;

        if (kind === 'BIG') {
            const prefab = this.bigTilePrefab ?? this.tilePrefab;
            if (!prefab) return null;
            const n = this.bigPool.size() > 0 ? this.bigPool.get() : instantiate(prefab);
            (n as any).__poolKind = 'BIG';
            n.parent = this.tileLayer;
            n.active = true;
            const tv = n.getComponent(TileView);
            if (!tv) {
                n.destroy();
                return null;
            }

            // ✅ 역할: 풀 재사용 시 비주얼 바디(흔들림/팝/스케일) 잔상 방지
            try {
                (tv as any).resetBodyTransform?.();
            } catch {}

            // ✅ 특수 프리팹(키/스포너/기둥 등) 힌트 주입 + 스케일 정규화
            tv.setSpecialPrefabHints({
                keyPrefab: this.keyPrefab,
                spawnerBoxPrefab: this.spawnerBoxPrefab,
                pillarPrefab: this.pillarPrefab,
                tileW: this.tileSize,
                tileH: this.tileSizeY,
                spawnerBoxScaleX: this.spawnerBoxScale,
                spawnerBoxScaleY: this.spawnerBoxScaleY,
            });
            this._normalizeTileScale(tv, 'BIG');

            const anyN = n as any;
            if (!anyN.__boundItemTouch) {
                // // 역할: (BIG) 아이템3 선택용 터치 바인딩(풀 재사용 시 중복 바인딩 방지)
                anyN.__boundItemTouch = true;
                n.on(Node.EventType.TOUCH_END, this._onTileTouchEnd, this);
            }

            return tv;
        }

        // SMALL
        if (!this.tilePrefab) return null;
        const n = this.smallPool.size() > 0 ? this.smallPool.get() : instantiate(this.tilePrefab);
        (n as any).__poolKind = 'SMALL';
        n.parent = this.tileLayer;
        n.active = true;
        const tv = n.getComponent(TileView);
        if (!tv) {
            n.destroy();
            return null;
        }

        // ✅ 역할: 풀 재사용 시 비주얼 바디(흔들림/팝/스케일) 잔상 방지
        try {
            (tv as any).resetBodyTransform?.();
        } catch {}

        // ✅ 특수 프리팹(키/스포너/기둥 등) 힌트 주입 + 스케일 정규화
        tv.setSpecialPrefabHints({
            keyPrefab: this.keyPrefab,
            spawnerBoxPrefab: this.spawnerBoxPrefab,
            pillarPrefab: this.pillarPrefab,
            tileW: this.tileSize,
            tileH: this.tileSizeY,
            spawnerBoxScaleX: this.spawnerBoxScale,
            spawnerBoxScaleY: this.spawnerBoxScaleY,
        });
        this._normalizeTileScale(tv, 'SMALL');

        const anyN = n as any;
        if (!anyN.__boundItemTouch) {
            // // 역할: (SMALL) 아이템3 선택용 터치 바인딩(풀 재사용 시 중복 바인딩 방지)
            // - 스몰 블럭이 터치 타겟이 되는 경우가 많아서 BIG과 동일하게 바인딩이 필요합니다.
            anyN.__boundItemTouch = true;
            n.on(Node.EventType.TOUCH_END, this._onTileTouchEnd, this);
        }

        return tv;
    }

    private _normalizeTileScale(tv: TileView, kind: 'SMALL' | 'BIG') {
        const ui = tv.node.getComponent(UITransform);
        if (!ui) return;

        const baseW = ui.contentSize.x;
        const baseH = ui.contentSize.y;
        if (!isFinite(baseW) || baseW <= 0 || !isFinite(baseH) || baseH <= 0) return;

        const cellW = Math.max(1, Math.round(this.tileSize || TILE_W));
        const cellH = Math.max(1, Math.round(this.tileSizeY || TILE_H));

        const wCells = kind === 'BIG' ? 2 : 1;
        const hCells = kind === 'BIG' ? 2 : 1;

        // ✅ 요구사항(예): cellW=60, cellH=65 일 때
        // - SMALL(1x1) => 60 x 65
        // - BIG(2x2)   => 120 x 135
        //
        // 위 예시는 단순히 (cellH * 2) = 130 이 아니라, 한 줄(행) 더 커버할 때
        // 세로로 추가 여유가 필요하다는 아트 규격을 반영합니다.
        // - 추가 세로 여유 = max(0, cellH - cellW)
        const extraYPerRow = Math.max(0, cellH - cellW);

        // ✅ 미세한 "틈"이 보이는 케이스 대응
        // - 프리팹 원본 크기/트리밍/필터링에 따라 셀 크기와 정확히 일치해도
        //   경계에 1~2px 정도 비어 보일 수 있습니다.
        // - 과도하게 키우면 보드 밖으로 삐져나와 보일 수 있어 최소치만 적용
        const overlap = 4; // total px (≈ 2px per side)

        const targetW = cellW * wCells + overlap;
        const targetH = cellH * hCells + extraYPerRow * (hCells - 1) + overlap;

        const scaleX = targetW / baseW;
        const scaleY = targetH / baseH;
        if (!isFinite(scaleX) || scaleX <= 0 || !isFinite(scaleY) || scaleY <= 0) return;

        tv.node.setScale(scaleX, scaleY, 1);
    }

    // 블럭 노드를 풀로 반환합니다.
    private releaseTile(tv: TileView) {
        const n = tv.node;
        // ✅ 역할: stop으로 인해 Promise가 영구 대기(=moving ref/리졸브 고착)되는 것을 방지
        this.twStop(n);

        // ✅ 비주얼 바디(흔들림/팝/스케일)도 정리
        try {
            const body = (tv as any).bodyNode?.() as Node | undefined;
            if (body && body.isValid && body !== n) this.twStop(body);
        } catch {}

        tv.clear();
        tv.setHidden(false);
        tv.setSpecial(null);
        n.active = false;
        n.removeFromParent();

        const kind = (n as any).__poolKind;
        if (kind === 'BIG') this.bigPool.put(n);
        else this.smallPool.put(n);
    }

    // 타일(블럭) 풀을 미리 채웁니다.
    private prewarmTiles(kind: 'SMALL' | 'BIG', count: number) {
        const warm = Math.max(0, Math.floor(count));
        if (warm <= 0) return;

        if (kind === 'BIG') {
            const prefab = this.bigTilePrefab ?? this.tilePrefab;
            if (!prefab) return;
            for (let i = 0; i < warm; i++) {
                const n = instantiate(prefab);
                (n as any).__poolKind = 'BIG';
                n.active = false;
                this.bigPool.put(n);
            }
            return;
        }

        // SMALL
        if (!this.tilePrefab) return;
        for (let i = 0; i < warm; i++) {
            const n = instantiate(this.tilePrefab);
            (n as any).__poolKind = 'SMALL';
            n.active = false;
            this.smallPool.put(n);
        }
    }

    // 프로젝타일 풀을 미리 채웁니다.
    private prewarmProjectiles(count: number) {
        if (!this.projectilePrefab) return;
        const warm = Math.max(0, Math.floor(count));
        for (let i = 0; i < warm; i++) {
            const n = instantiate(this.projectilePrefab);
            n.active = false;
            this.projectilePool.put(n);
        }
    }

    // 프로젝타일을 풀에서 꺼냅니다(없으면 새로 생성).
    private obtainProjectile(): Node | null {
        if (!this.projectilePrefab) return null;
        const n = this.projectilePool.size() > 0 ? this.projectilePool.get() : instantiate(this.projectilePrefab);
        return n;
    }

    // 프로젝타일을 풀로 반환합니다.
    private releaseProjectile(n: Node) {
        Tween.stopAllByTarget(n);
        n.active = false;
        n.removeFromParent();
        this.projectilePool.put(n);
    }

    // 컬럼 상태 플래그를 초기화합니다.
    private resetBusyFlags() {
        for (let c = 0; c < this.cols; c++) {
            this.colReserved[c] = 0;
            this.colBusy[c] = 0;
            if (this.colResMask) this.colResMask[c] = 0;
        }
    }

    // busy를 전부 해제합니다(예외/에러 복구용).
    private clearBusyAll() {
        for (let c = 0; c < this.cols; c++) this.colBusy[c] = 0;
    }

    // 엔티티를 목표 좌표로 이동(필요 시 Line_XX로 리페어런트)합니다.
    private _incMoving(entId: number) {
        const id = entId | 0;
        const c = this._movingEntRef.get(id) ?? 0;
        this._movingEntRef.set(id, c + 1);
    }

    private _decMoving(entId: number) {
        const id = entId | 0;
        const c = (this._movingEntRef.get(id) ?? 0) - 1;
        if (c > 0) this._movingEntRef.set(id, c);
        else this._movingEntRef.delete(id);
    }

    private moveEnt(e: BlockEnt, duration: number): Promise<void> {
        const n = e.view.node;
        const t = this.entParentAndLocal(e);

        if (!n || !t.parent) return Promise.resolve();

        // ✅ moving ref-count 증가(타겟 선택에서 제외용)
        this._incMoving(e.id);

        // Line 레이아웃에서는 row 변화 시 부모(Line)가 바뀌므로,
        // 부모가 다르면 월드좌표 유지로 리페어런트 후 이동합니다.
        const p =
            n.parent !== t.parent
                ? this.tweenMoveReparent(n, t.parent, t.local, duration)
                : this.tweenMove(n, t.local, duration);

        return p.then(
            () => {
                this._decMoving(e.id);
            },
            () => {
                this._decMoving(e.id);
            },
        );
    }

    // ---------------- Tween Helpers ----------------

    // ✅ 안전하게 Tween을 중단합니다.
    // - 역할: stop으로 콜백이 호출되지 않아도 Promise가 풀리도록 보장
    private twStop(n: Node) {
        if (!n || !n.isValid) return;

        const k = (n as any).uuid ?? n.uuid;
        const done = this._twDone.get(k);
        if (done) {
            this._twDone.delete(k);
            try {
                done();
            } catch {
                // ignore
            }
        } else if (this._twDone.has(k)) {
            this._twDone.delete(k);
        }

        try {
            Tween.stopAllByTarget(n);
        } catch {
            // ignore
        }
    }
    // ✅ 안전장치: 외부에서 Tween.stopAllByTarget(node)가 호출되면 onComplete(.call)이 실행되지 않아
    // Promise가 영구 대기(=moving ref / colBusy 고착)되는 케이스가 있습니다.
    // - 해결: "최대 지연 시간"을 두고, 그 시간이 지나도 _twDone에 남아있다면 강제로 resolve 합니다.
    private twFallback(k: string, resolve: () => void, delaySec: number, onForce?: () => void) {
        const d = Number.isFinite(delaySec) ? Math.max(0, delaySec) : 0.25;
        // scheduleOnce는 Component 스케줄러 기반(게임 루프와 함께 동작)
        this.scheduleOnce(() => {
            const cur = this._twDone.get(k);
            if (cur !== resolve) return;
            this._twDone.delete(k);
            try {
                onForce?.();
            } catch {}
            try {
                resolve();
            } catch {}
        }, d);
    }


    // ✅ TileView가 있으면 "비주얼 바디" 노드를 반환합니다.
    // - 흔들림/팝/스케일 아웃은 body에만 적용(이동 tween과 분리)
    private fxNodeOf(root: Node): Node {
        if (!root || !root.isValid) return root;
        const tv = root.getComponent(TileView);
        const b = (tv as any)?.bodyNode?.();
        return b && b.isValid ? (b as Node) : root;
    }

    // 제거 시 스케일을 줄이며 숨깁니다.
    private tweenScaleOut(n: Node, duration = 0.08) {
        const tv = n?.getComponent?.(TileView) ?? null;
        try {
            (tv as any)?.resetBodyTransform?.();
        } catch {}

        const fx = this.fxNodeOf(n);
        this.twStop(fx);
        return new Promise<void>((resolve) => {
            const k = (fx as any).uuid ?? fx.uuid;
            const dur = Number.isFinite(duration) ? Math.max(0.001, duration) : 0.08;

            this._twDone.set(k, resolve);

            // ✅ 외부 stopAllByTarget 등으로 tween이 중단되면 .call()이 실행되지 않을 수 있으므로,
            // 일정 시간이 지나면 강제로 resolve(=handleHitColumn/moveEnt 고착 방지)
            this.twFallback(k, resolve, dur + 0.15, () => {
                try {
                    if (fx && fx.isValid) fx.setScale(this._v3ScaleOut);
                } catch {}
            });

            tween(fx)
                .to(dur, { scale: this._v3ScaleOut }, { easing: 'quadIn' })
                .call(() => {
                    if (this._twDone.get(k) === resolve) this._twDone.delete(k);
                    resolve();
                })
                .start();
        });
    }

    // 스택 pop/피격 시 살짝 튀는 느낌을 줍니다.
    private tweenPop(n: Node) {
        const tv = n?.getComponent?.(TileView) ?? null;
        try {
            (tv as any)?.resetBodyTransform?.();
        } catch {}

        const fx = this.fxNodeOf(n);
        this.twStop(fx);
        return new Promise<void>((resolve) => {
            const k = (fx as any).uuid ?? fx.uuid;
            this._twDone.set(k, resolve);

            // ✅ 외부 stopAllByTarget 등으로 tween이 끊겨도 Promise가 풀리도록 fallback을 둡니다.
            this.twFallback(k, resolve, 0.2, () => {
                try {
                    if (fx && fx.isValid) fx.setScale(this._v3PopDown);
                } catch {}
            });

            tween(fx)
                .to(0.06, { scale: this._v3PopUp }, { easing: 'quadOut' })
                .to(0.06, { scale: this._v3PopDown }, { easing: 'quadIn' })
                .call(() => {
                    if (this._twDone.get(k) === resolve) this._twDone.delete(k);
                    resolve();
                })
                .start();
        });
    }

    // 이동 애니메이션을 수행합니다.
    private tweenMove(n: Node, pos: Vec3, duration: number) {
        this.twStop(n);
        return new Promise<void>((resolve) => {
            const k = (n as any).uuid ?? n.uuid;
            this._twDone.set(k, resolve);

            // ✅ 자연스러운 이동: 거리 기반 duration 보정 + 방향 easing
            const sx = n.position.x;
            const sy = n.position.y;
            const dx = pos.x - sx;
            const dy = pos.y - sy;

            const absDx = Math.abs(dx);
            const absDy = Math.abs(dy);

            // 셀 기준(라인 레이아웃이면 lineDy/colX, 아니면 stepY/stepX)
            const cy = this.useLineLayout
                ? Math.max(1e-3, Math.abs(this.lineDy || this.tileSizeY || this.tileSize))
                : Math.max(1e-3, Math.abs(this.stepY || this.tileSizeY || this.tileSize));

            const cx = this.useLineLayout
                ? Math.max(1e-3, Math.abs(((this.colX[1] ?? 0) - (this.colX[0] ?? 0)) || this.tileSize))
                : Math.max(1e-3, Math.abs(this.stepX || this.tileSize));

            const cellsY = cy > 0 ? absDy / cy : 0;
            const cellsX = cx > 0 ? absDx / cx : 0;
            const cells = Math.max(cellsY, cellsX);

            let dur = Math.max(0.001, duration);
            if (cells > 1.05) dur += (cells - 1) * 0.03;
            const maxDur = dy < -0.1 ? 0.26 : dy > 0.1 ? 0.28 : 0.24;
            if (dur > maxDur) dur = maxDur;

            let easing: TweenEasing = 'quadInOut';
            if (absDy >= absDx * 1.2) {
                if (dy < -0.1) easing = 'quadIn';
                else if (dy > 0.1) easing = 'quadOut';
            } else {
                easing = 'sineInOut';
            }


            // ✅ 외부 stopAllByTarget 등으로 이동 tween이 중단되면 .call()이 실행되지 않아
            // Promise가 영구 대기(=moving ref 고착)되는 케이스가 있습니다.
            // - dur + 여유 시간 이후에는 목표 위치로 스냅하고 resolve 합니다.
            this.twFallback(k, resolve, dur + 0.35, () => {
                try {
                    if (n && n.isValid) n.setPosition(pos);
                } catch {}
            });

            tween(n)
                .to(dur, { position: pos }, { easing })
                .call(() => {
                    // ✅ 낙하 종료 시 착지감(바디 스쿼시)
                    if (this.enableLandFx && dy < -0.1 && cellsY >= 0.75) {
                        try {
                            const tv = n.getComponent(TileView);
                            tv?.playLandFx?.(Math.min(0.12, 0.06 + cellsY * 0.01));
                        } catch {}
                    }

                    if (this._twDone.get(k) === resolve) this._twDone.delete(k);
                    resolve();
                })
                .start();
        });
    }

    // 부모를 바꾸면서(월드 위치 유지) targetLocal 로 이동합니다.
    private tweenMoveReparent(n: Node, newParent: Node, targetLocal: Vec3, duration: number) {
        this.twStop(n);

        // ✅ 성능: clone() 할당 제거
        const wp = n.getWorldPosition(this._tmpWorldBase);
        n.setParent(newParent);
        n.setWorldPosition(wp);

        return this.tweenMove(n, targetLocal, duration);
    }

    // ---------------- 좌표/인덱스 ----------------

    // 보드 좌표(row,col)를 로컬 위치(셀 중심)로 변환합니다.
    private cellPosInto(row: number, col: number, out: Vec3): Vec3 {
        // UI2: Blocks/Line_01~가 "정확히 10x10"이면 라인 좌표 사용
        if (this.useLineLayout && this.lineNodes.length > 0) {
            const line = this.lineForRow(row);
            const x = this.colX[col] ?? 0;
            const y = line ? line.position.y : 0;
            out.set(x, y, 0);
            return out;
        }

        // ✅ tileLayer 기준 10x10 자동 배치
        if (this.stepX <= 0 || this.stepY <= 0) this.cacheTileLayerGridMetrics();

        const sx = this.stepX > 0 ? this.stepX : Math.max(1, this.tileSize | 0);
        const sy = this.stepY > 0 ? this.stepY : Math.max(1, (this.tileSizeY as any) | 0);

        out.set(this.originX + col * sx, this.originY + row * sy, 0);
        return out;
    }

    private cellPos(row: number, col: number): Vec3 {
        return this.cellPosInto(row, col, new Vec3());
    }

    // 2x2 엔티티(좌하단 앵커)의 로컬 위치(중심)로 변환합니다.
    private bigPos(row: number, col: number): Vec3 {
        // 2x2는 (col,col+1) / (row,row+1)의 중간
        const p0 = this.cellPos(row, col);
        const p1 = this.cellPos(row + 1, col + 1);
        return new Vec3((p0.x + p1.x) * 0.5, (p0.y + p1.y) * 0.5, 0);
    }

    // 엔티티의 로컬 위치를 반환합니다.
    private entPos(e: BlockEnt): Vec3 {
        // ✅ 어떤 footprint(w/h)든 "점유 영역의 중심"으로 배치
        const w = (e.w ?? 1) | 0;
        const h = (e.h ?? 1) | 0;
        if (w <= 1 && h <= 1) return this.cellPos(e.row, e.col);

        const p0 = this.cellPos(e.row, e.col);
        const p1 = this.cellPos(e.row + Math.max(0, h - 1), e.col + Math.max(0, w - 1));
        return new Vec3((p0.x + p1.x) * 0.5, (p0.y + p1.y) * 0.5, 0);
    }

    // row에 해당하는 Line 노드를 반환합니다(row=0은 바닥).
    private lineForRow(row: number): Node | null {
        if (!this.useLineLayout || this.lineNodes.length === 0) return null;
        // ✅ lineNodes는 setupLineLayoutIfAny에서 y 기준으로 "바닥(row=0) -> 위" 순으로 정렬되어 있습니다.
        // - 역할: row와 실제 화면 라인 매핑을 항상 일치시킴
        const idx = row | 0;
        if (idx < 0 || idx >= this.lineNodes.length) return null;
        return this.lineNodes[idx];
    }

    // 엔티티의 부모(Line)와 로컬 좌표를 계산합니다(타일은 y=0, 2x2는 y=-dy/2).
    private entParentAndLocal(e: BlockEnt): { parent: Node; local: Vec3 } {
        if (!this.tileLayer || !this.useLineLayout || this.lineNodes.length === 0) {
            return { parent: this.tileLayer!, local: this.entPos(e) };
        }

        const topRow = e.row + e.h - 1;
        const parent = this.lineForRow(topRow) ?? this.tileLayer;

        // ✅ footprint 중앙 정렬(2x2 전용 → 일반화)
        const dx = (this.colX[1] ?? 0) - (this.colX[0] ?? 0);
        const xLeft = this.colX[e.col] ?? 0;
        const xRight = this.colX[e.col + (e.w - 1)] ?? xLeft + dx * (e.w - 1);
        const x = e.w > 1 ? (xLeft + xRight) * 0.5 : xLeft;
        const y = e.h > 1 ? -this.lineDy * (e.h - 1) * 0.5 : 0;
        return { parent, local: new Vec3(x, y, 0) };
    }

    // ✅ 셀 중심의 월드 좌표를 반환합니다.
    // - 라인 유무와 상관 없이 tileLayer 기준 변환으로 통일(계산 일관성)
    private cellWorldPos(row: number, col: number): Vec3 {
        return this.cellWorldPosInto(row, col, new Vec3());
    }

    // ✅ out Vec3에 월드 좌표를 채웁니다(할당 최소화).
    private cellWorldPosInto(row: number, col: number, out: Vec3): Vec3 {
        const local = this.cellPosInto(row, col, this._tmpCellLocal);
        const ref = this.tileLayer && this.tileLayer.isValid ? this.tileLayer : this.node;

        // ✅ UITransform 캐시(매 호출 getComponent 비용 최소화)
        let ui = this._tileUi;
        if (!ui || ui.node !== ref) ui = this._tileUi = ref.getComponent(UITransform);

        if (ui) return ui.convertToWorldSpaceAR(local, out);

        // UITransform이 없으면 월드 기준점 + 로컬 오프셋
        const base = ref.getWorldPosition(this._tmpWorldBase);
        out.set(base.x + local.x, base.y + local.y, base.z + local.z);
        return out;
    }

    // 2D -> 1D 인덱스로 변환합니다.
    private indexOf(r: number, c: number) {
        return r * this.cols + c;
    }

    // ✅ 렌더(자식 순서) 동기화
    // - 역할: 바닥(row=0)이 항상 "앞"에 보이도록 UI 드로우 오더를 정리
    // - 이유: setParent/instantiate 순서가 섞이면(로드/스냅/인트로/스폰) 렌더가 역전될 수 있음
    public syncDrawOrder(): void {
        if (!this.tileLayer || !this.tileLayer.isValid) return;

        // (1) Line 레이아웃: 라인(행) 노드의 sibling 순서만 고정하면 됨
        if (this.useLineLayout && this.lineNodes && this.lineNodes.length > 0) {
            const parent = this.tileLayer;
            const linesAsc = this.lineNodes.slice(); // row=0(바닥) -> 위
            const linesDesc = linesAsc.slice().sort((a, b) => b.position.y - a.position.y); // 위 -> 바닥

            // 라인 외 자식(배경/더미 등)은 현재 순서를 유지하고, 라인만 뒤쪽에 재정렬
            const kids = parent.children.slice();
            const lineSet = new Set<Node>(linesAsc);
            const fixed: Node[] = [];
            for (const ch of kids) {
                if (!lineSet.has(ch)) fixed.push(ch);
            }

            let idx = 0;
            for (const ch of fixed) {
                if (ch && ch.isValid) ch.setSiblingIndex(idx++);
            }
            for (const ln of linesDesc) {
                if (ln && ln.isValid) ln.setSiblingIndex(idx++);
            }

            // ✅ 같은 행(Line) 내부에서의 좌/우 렌더 순서 보정
            // - 요구사항: 같은 row에서 "맨왼쪽" 블럭이 가장 위(앞)에 렌더되어야 함
            // - 구현: col이 큰(오른쪽) 것부터 먼저 배치하고, col이 작은(왼쪽) 것이 마지막(=highest sibling)으로 오도록 정렬
            for (const ln of linesAsc) {
                if (!ln || !ln.isValid) continue;
                const kids2 = ln.children.slice();
                const fixed2: Node[] = [];
                const blocks2: Array<{ n: Node; c: number }> = [];
                for (const ch of kids2) {
                    const tv = ch?.getComponent?.(TileView);
                    if (!tv) {
                        fixed2.push(ch);
                        continue;
                    }
                    blocks2.push({ n: ch, c: (tv.col ?? 0) | 0 });
                }
                blocks2.sort((a, b) => b.c - a.c);
                let j = 0;
                for (const ch of fixed2) {
                    if (ch && ch.isValid) ch.setSiblingIndex(j++);
                }
                for (const it of blocks2) {
                    if (it.n && it.n.isValid) it.n.setSiblingIndex(j++);
                }
            }
            return;
        }

        // (2) 일반 레이아웃: 타일 노드(TileView)를 row 기준으로 정렬
        // - row가 큰(위) 것이 먼저, row가 작은(바닥) 것이 나중(앞)
        const parent = this.tileLayer;
        const kids = parent.children.slice();
        const fixed: Node[] = [];
        const blocks: Array<{ n: Node; r: number; c: number }> = [];

        for (const ch of kids) {
            const tv = ch?.getComponent?.(TileView);
            if (!tv) {
                fixed.push(ch);
                continue;
            }
            const r = (tv.row ?? 0) | 0;
            const c = (tv.col ?? 0) | 0;
            blocks.push({ n: ch, r, c });
        }

        // ✅ 같은 row에서 "맨왼쪽"이 가장 위(앞)에 렌더되도록 col 정렬을 반대로(오른쪽->왼쪽) 적용
        blocks.sort((a, b) => (b.r - a.r) || (b.c - a.c));

        let idx = 0;
        for (const ch of fixed) {
            if (ch && ch.isValid) ch.setSiblingIndex(idx++);
        }
        for (const it of blocks) {
            if (it.n && it.n.isValid) it.n.setSiblingIndex(idx++);
        }
    }

    // // 아틀라스 지연 로드/교체 등으로 인해 모든 타일의 스프라이트를 강제로 갱신합니다.
    public forceRefreshAllTiles() {
        // 역할: TileView 내부의 refresh를 재호출하여 spriteFrame/tint를 다시 적용
        for (const ent of this.ents.values()) {
            ent.view?.forceRefresh?.();
        }
    }

    public isItemMoveBlocksToTopActive(): boolean {
        // // 역할: 아이템3(블록 이동) 모드가 활성인지 외부에서 확인
        // // - BottomItemBar의 오버레이 종료 타이밍(색상 선택/취소 시 자동 닫기)에 사용
        return !!this._itemMoveBlockActive;
    }
}
