require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/ts-node/register/transpile-only');
const fs = require('fs');

(async ()=>{
  const mod = await import('./src/lib/sim_replay.ts');
  const simulateStageReplay = mod.simulateStageReplay;
  const stagepack = JSON.parse(fs.readFileSync('/mnt/data/stagepack_v2.json','utf-8'));
  const stage = stagepack.stages.find(s=>s.id===3);
  if(!stage) throw new Error('stage not found');
  const res = await simulateStageReplay(stage, { strictHintOrder: true, captureFrames: false, maxRounds: 200000, maxShots: 2000000, detail: 'round' });
  console.log('status', res.status, 'reason', res.reason, 'clicked', res.clicked, 'nextHint', res.nextHint, 'rounds', res.rounds, 'shots', res.shotsFired);
  if(res.stuck) console.log('stuck', res.stuck);
})().catch(e=>{console.error('ERR',e); process.exit(1);});
