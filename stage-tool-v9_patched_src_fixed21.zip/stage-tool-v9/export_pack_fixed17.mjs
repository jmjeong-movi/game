import fs from 'node:fs';

(async () => {
  const cliMod = await import('./src/validator_tools/cli.js');
  const repairStagePack = (cliMod?.repairStagePack ?? cliMod?.default?.repairStagePack);
  if (typeof repairStagePack !== 'function') {
    throw new Error('repairStagePack not found (validator_tools/cli.js)');
  }

  const lib = await import('./src/lib/replay_repair.ts');
  const repairStageUntilReplaySolved = lib?.repairStageUntilReplaySolved;
  const sanitizeSupplyPagesInPlace = lib?.sanitizeSupplyPagesInPlace;
  if (typeof repairStageUntilReplaySolved !== 'function') {
    throw new Error('repairStageUntilReplaySolved not found (lib/replay_repair.ts)');
  }
  if (typeof sanitizeSupplyPagesInPlace !== 'function') {
    throw new Error('sanitizeSupplyPagesInPlace not found (lib/replay_repair.ts)');
  }

  const packObj = JSON.parse(fs.readFileSync('/mnt/data/stagepack_v2.json', 'utf-8'));
  const stages = Array.isArray(packObj?.stages) ? packObj.stages.slice() : [];
  stages.sort((a, b) => ((a?.id ?? 0) | 0) - ((b?.id ?? 0) | 0));

  const bakedStages = [];
  const outStages = [];
  const reportResults = [];
  const replayFailures = [];

  for (let si = 0; si < stages.length; si++) {
    const st = stages[si];
    const id = (st?.id ?? si + 1) | 0;

    let supplyRemovedInput = 0;
    try {
      supplyRemovedInput = (sanitizeSupplyPagesInPlace(st)?.removed ?? 0) | 0;
    } catch {
      supplyRemovedInput = 0;
    }

    const onePack = { schemaVersion: packObj?.schemaVersion ?? 2, stages: [st] };

    const { pack: fixedPack, report } = await repairStagePack(
      onePack,
      50000,
      100,
      140,
      { enabled: true, depth: 10, window: 12, beam: 10, simSteps: 4000 },
      undefined,
    );

    const fixedStage = Array.isArray(fixedPack?.stages)
      ? fixedPack.stages[0]
      : Array.isArray(fixedPack)
        ? fixedPack[0]
        : null;
    if (!fixedStage) throw new Error(`stage output missing (stageId=${id})`);

    let supplyRemovedBaked = 0;
    try {
      supplyRemovedBaked = (sanitizeSupplyPagesInPlace(fixedStage)?.removed ?? 0) | 0;
    } catch {
      supplyRemovedBaked = 0;
    }

    bakedStages.push(fixedStage);

    const r0 = report?.results?.[0] ?? null;

    const { stage: replayFixedStage, report: replayFixReport, replay } = await repairStageUntilReplaySolved(fixedStage, {
      maxIters: 800,
      maxRounds: 200000,
      maxShots: 2000000,
    });

    outStages.push(replayFixedStage);

    if (r0) {
      reportResults.push({
        ...r0,
        supplySanitize: {
          inputRemoved: supplyRemovedInput,
          bakedRemoved: supplyRemovedBaked,
          replayRemoved: (replayFixReport?.supplySanitized?.removed ?? 0) | 0,
        },
        replay: {
          status: replay?.status ?? 'UNKNOWN',
          reason: replay?.reason ?? null,
          clicked: replay?.clicked ?? 0,
          rounds: replay?.rounds ?? 0,
          shotsFired: replay?.shotsFired ?? 0,
          nextHint: replay?.nextHint ?? null,
          stuck: replay?.stuck ?? null,
        },
        replayRepair: replayFixReport,
      });
    }

    const iters = replayFixReport?.iters ?? null;
    console.log(`[stage ${id}] replay=${replay?.status} reason=${replay?.reason} iters=${iters} clicked=${replay?.clicked} rounds=${replay?.rounds} shots=${replay?.shotsFired} supplyRemoved(in=${supplyRemovedInput},baked=${supplyRemovedBaked},replay=${(replayFixReport?.supplySanitized?.removed ?? 0) | 0})`);

    if (replay?.status !== 'SOLVED') {
      replayFailures.push({
        stageId: id,
        status: replay?.status ?? 'UNKNOWN',
        reason: replay?.reason ?? null,
        clicked: replay?.clicked ?? 0,
        rounds: replay?.rounds ?? 0,
        shotsFired: replay?.shotsFired ?? 0,
        nextHint: replay?.nextHint ?? null,
        stuck: replay?.stuck ?? null,
        replayRepair: replayFixReport,
      });
    }
  }

  const bakedPack = { ...packObj, schemaVersion: 2, stages: bakedStages };
  const outPack = { ...packObj, schemaVersion: 2, stages: outStages };

  const summary = {
    total: stages.length,
    replaySolved: reportResults.filter((r) => String(r?.replay?.status) === 'SOLVED').length,
    replayStuck: reportResults.filter((r) => String(r?.replay?.status) === 'STUCK').length,
    replayUnknown: reportResults.filter((r) => String(r?.replay?.status) === 'UNKNOWN').length,
    solved: reportResults.filter((r) => String(r?.status) === 'SOLVED').length,
    stuck: reportResults.filter((r) => String(r?.status) === 'STUCK').length,
    unknown: reportResults.filter((r) => String(r?.status) === 'UNKNOWN').length,
    error: reportResults.filter((r) => String(r?.status) === 'ERROR').length,
  };

  fs.writeFileSync('/mnt/data/stagepack_v2_baked_fixed17.json', JSON.stringify(bakedPack, null, 2));
  fs.writeFileSync('/mnt/data/stagepack_v2_strict_solved_fixed17.json', JSON.stringify(outPack, null, 2));
  fs.writeFileSync('/mnt/data/report_stagepack_v2_strict_solved_fixed17.json', JSON.stringify({ summary, results: reportResults, replayFailures }, null, 2));

  console.log('summary', summary);
  console.log('replayFailures', replayFailures.length);
})().catch((e) => {
  console.error('ERR', e);
  try {
    console.error('keys', e && typeof e === 'object' ? Object.keys(e) : null);
    console.error('stack', e?.stack);
  } catch {}
  process.exit(1);
});
