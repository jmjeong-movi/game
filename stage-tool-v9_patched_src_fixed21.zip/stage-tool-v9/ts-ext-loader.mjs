import path from 'node:path';

function hasExtension(spec){
  // ignore query/hash
  const clean = spec.split('?')[0].split('#')[0];
  return path.extname(clean) !== '';
}

function isRelative(spec){
  return spec.startsWith('./') || spec.startsWith('../') || spec.startsWith('/') ;
}

export async function resolve(specifier, context, defaultResolve) {
  try {
    return await defaultResolve(specifier, context, defaultResolve);
  } catch (e) {
    // Try adding TS/JS extensions for extensionless relative imports.
    // NOTE: In some loader stacks (ts-node/esm) the thrown error may not carry
    // a stable `code`, so we key off specifier shape instead.
    if (isRelative(specifier) && !hasExtension(specifier)) {
      for (const ext of ['.ts', '.tsx', '.js', '.mjs', '.cjs']) {
        try {
          return await defaultResolve(specifier + ext, context, defaultResolve);
        } catch {
          // continue
        }
      }
    }
    throw e;
  }
}
