import { uid } from './ids';
import type { StagePackV2, StageV2 } from './schema';

export function makeEmptyStage(id: number): StageV2 {
  return {
    id,
    meta: {
      blockCount: 100,
      layerCount: 1,
      // ✅ 초기화 기본은 “완전 빈 상태” + 색상 1부터 시작(배치된 색을 기준으로 자동 계산)
      colorCount: 1,
      slotCount: 3,
      // ✅ 기획상 waitLineCount는 3 고정
      waitLineCount: 3,
      connectShooterCount: 0,
      hiddenShooterCount: 0,
      lockShooterCount: 0,
      ammoMin: 40,
      ammoMax: 50,
      seed: 1000 + id,
      pickerCols: 2,
      // ✅ pickerMaxCards = pickerCols * waitLineCount(3)
      pickerMaxCards: 2 * 3,
    },
    board: { w: 10, h: 10, objects: [] },
    // ✅ supply.pages: 공급 패턴(페이지)만 저장 (초기 보드는 board.objects)
    supply: { mode: 'PATTERN', pages: [] },
    cards: { mode: 'GENERATE', rules: { ammoStep: 10, totalAmmoEquals: 'BOARD_BLOCKS' } },
    shooters: { slots: Array.from({ length: 3 }, (_, i) => ({ slot: i, type: 'SHOOTER_NORMAL' })) },
  };
}

export function makeDefaultPack(): StagePackV2 {
  // ✅ 초기화 시: 아무 오브젝트도 없는 “빈 스테이지 1개”만 생성
  return { schemaVersion: 2, stages: [makeEmptyStage(1)] };
}
