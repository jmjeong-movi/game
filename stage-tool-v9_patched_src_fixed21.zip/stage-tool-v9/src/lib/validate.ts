import type { StageV2 } from './schema';
import { buildOcc, calcInitialBlocks, objLayer } from './board';

export type ValidationIssue = {
  level: 'error' | 'warn';
  msg: string;
  at?: { x: number; y: number };
};

export function validateStage(stage: StageV2, numDraft?: Record<string, string>): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  // ✅ 숫자 입력 Draft(빈 값 허용) 검증
  // 역할: 입력 도중 빈 문자열을 허용하기 때문에, 저장 값과 별도로 검증에서 안내합니다.
  if (numDraft) {
    const key = (field: string) => `${stage.id}:${field}`;
    const hasEmpty = (field: string) =>
      Object.prototype.hasOwnProperty.call(numDraft, key(field)) && String(numDraft[key(field)] ?? '') === '';

    const required: Array<[string, 'error' | 'warn', string]> = [
      ['meta.blockCount', 'error', 'blockCount 입력란이 비어 있습니다.'],
      ['meta.layerCount', 'error', 'layerCount 입력란이 비어 있습니다.'],
      ['meta.slotCount', 'error', 'slotCount 입력란이 비어 있습니다.'],
      ['meta.waitLineCount', 'error', 'waitLineCount 입력란이 비어 있습니다.'],
      ['meta.pickerCols', 'error', 'pickerCols 입력란이 비어 있습니다.'],
      ['meta.connectShooterCount', 'warn', 'connectShooterCount 입력란이 비어 있습니다.'],
      ['meta.hiddenShooterCount', 'warn', 'hiddenShooterCount 입력란이 비어 있습니다.'],
      ['meta.seed', 'warn', 'seed 입력란이 비어 있습니다.'],
    ];

    for (const [field, level, msg] of required) {
      if (hasEmpty(field)) issues.push({ level, msg });
    }
  }

  const { objects } = stage.board;
  const { collisions, outOfBounds } = buildOcc(objects, stage.board.w, stage.board.h);

  const layerCount = Math.max(1, Math.min(5, Math.floor(stage.meta.layerCount ?? 1)));

  for (const oob of outOfBounds) {
    issues.push({
      level: 'error',
      msg: `보드 밖 배치: L${oob.layer + 1} uid=${oob.uid} (x=${oob.cell.x}, y=${oob.cell.y})`,
      at: { x: oob.cell.x, y: oob.cell.y },
    });
  }

  if (collisions.length > 0) {
    // 너무 많아질 수 있으니 셀 기준으로 uniq
    const seen = new Set<string>();
    for (const c of collisions) {
      const k = `${c.layer}:${c.cell.x},${c.cell.y}`;
      if (seen.has(k)) continue;
      seen.add(k);
      issues.push({
        level: 'error',
        msg: `겹침 충돌: L${c.layer + 1} (${c.cell.x},${c.cell.y})`,
        at: { x: c.cell.x, y: c.cell.y },
      });
    }
  }

  // layer range
  for (const o of objects) {
    const l = objLayer(o);
    if (l < 0 || l >= layerCount) {
      issues.push({
        level: 'error',
        msg: `오브젝트 layer(${l + 1})가 layerCount(${layerCount}) 범위를 벗어났습니다. uid=${(o as any).uid}`,
      });
      break;
    }
  }

  // --- supply pages: collision / oob / layer range ---
  const supplyPages = stage.supply?.pages ?? [];
  for (let pi = 0; pi < supplyPages.length; pi++) {
    const p = supplyPages[pi];
    const objs = (p?.objects ?? []) as any[];
    if (!Array.isArray(objs) || objs.length === 0) continue;

    // ✅ 공급(supply)에는 내려오는 블럭(BLOCK_*)만 배치해야 합니다.
    // - CHAIN_BARRIER / SPAWNER_BOX / PILLAR 는 고정 오브젝트이므로 supply에 들어가면 안 됩니다.
    for (const o of objs) {
      const t = String((o as any)?.type ?? '');
      if (t === 'CHAIN_BARRIER' || t === 'SPAWNER_BOX' || t === 'PILLAR' || t === 'KEY' || t === 'LOCK') { 
        issues.push({
          level: 'error',
          msg: `공급 페이지 ${pi + 1}에 고정 오브젝트(${t})가 포함되어 있습니다. (공급에서는 BLOCK_*만 허용) uid=${(o as any)?.uid ?? '?'}`,
          at: { x: Number((o as any)?.x ?? 0), y: Number((o as any)?.y ?? 0) },
        });
      }
    }

    const { collisions: pCol, outOfBounds: pOob } = buildOcc(objs as any, stage.board.w, stage.board.h);

    for (const oob of pOob) {
      issues.push({
        level: 'error',
        msg: `공급 페이지 ${pi + 1} 보드 밖 배치: L${oob.layer + 1} uid=${oob.uid} (x=${oob.cell.x}, y=${oob.cell.y})`,
        at: { x: oob.cell.x, y: oob.cell.y },
      });
    }

    if (pCol.length > 0) {
      const seen = new Set<string>();
      for (const c of pCol) {
        const k = `${c.layer}:${c.cell.x},${c.cell.y}`;
        if (seen.has(k)) continue;
        seen.add(k);
        issues.push({
          level: 'error',
          msg: `공급 페이지 ${pi + 1} 겹침 충돌: L${c.layer + 1} (${c.cell.x},${c.cell.y})`,
          at: { x: c.cell.x, y: c.cell.y },
        });
      }
    }

    // layer range
    for (const o of objs) {
      const l = objLayer(o as any);
      if (l < 0 || l >= layerCount) {
        issues.push({
          level: 'error',
          msg: `공급 페이지 ${pi + 1}: 오브젝트 layer(${l + 1})가 layerCount(${layerCount}) 범위를 벗어났습니다. uid=${(o as any).uid}`,
        });
        break;
      }
    }
  }

  // --- blockCount / supply ---
  const initial = calcInitialBlocks(objects, 10, 10);
  const bc = Math.floor((stage.meta as any).blockCount);

  if (!Number.isFinite(bc) || bc <= 0) {
    issues.push({ level: 'error', msg: `blockCount가 올바르지 않습니다: ${(stage.meta as any).blockCount}` });
  } else {
    // 10의 배수는 UX 선호(20/30 기반 카드 분할)로 남겨두되,
    // 런타임(StageCompiler)은 5/10 중 자동 선택/정확 합계를 우선하므로 경고로만 처리합니다.
    if (bc % 10 !== 0) issues.push({ level: 'warn', msg: `blockCount(${bc})가 10의 배수가 아닙니다. (권장: 10의 배수)` });

    // ✅ 런타임(StageCompiler) 기준 공급 합계 검증
    // - pages가 있으면: pages.objects 전체를 1회 flatten한 합(반복/상속 없음)
    // - pages가 없으면: (레거시) supply.perCol 합
    const supplyExpected = bc - initial;
    if (supplyExpected < 0) {
      issues.push({ level: 'error', msg: `blockCount(${bc}) < initialHits(${initial}). blockCount는 초기 블록 이상이어야 합니다.` });
    } else {
      const pages = stage.supply?.pages ?? [];
      const perColRaw = Array.isArray((stage.supply as any)?.perCol) ? ((stage.supply as any).perCol as any[]) : [];
      const perColSum = perColRaw.reduce((a, v) => a + Math.max(0, Math.floor(v ?? 0)), 0);

      const supplyHitsFromObj = (o: any): number => {
        const t = String(o?.type ?? '');
        if (t === 'BLOCK_NORMAL' || t === 'BLOCK_SMALL') return 1;
        if (t === 'BLOCK_HIDDEN') return 1;
        if (t === 'BLOCK_LARGE' || t === 'BLOCK_LARGE_HIDDEN') return Math.max(1, Math.floor(o?.hp ?? 1));
        // 런타임 supply 파서는 위 타입들만 처리합니다.
        return 0;
      };

      let supplySumHits = 0;
      let ignored = 0;
      if (pages.length > 0) {
        for (let p = 0; p < pages.length; p++) {
          const objs = (pages[p]?.objects ?? []) as any[];
          for (const o of objs) {
            const add = supplyHitsFromObj(o);
            if (add <= 0) ignored++;
            supplySumHits += add;
          }
        }
      } else {
        supplySumHits = perColSum;
      }

      if (ignored > 0) {
        issues.push({ level: 'warn', msg: `Supply에서 런타임이 무시하는 오브젝트가 ${ignored}개 있습니다. (NORMAL/HIDDEN/LARGE만 반영)` });
      }

            // spawnerTotal: 생성박스는 "생성물 수량(hp)"이 initialHits(calcInitialBlocks)에 이미 포함됩니다.
      // - 즉, supply로 더하지 않습니다.
      // - 검증 목적상 수치를 노출만 합니다.
      const spawnerTotal = objects
        .filter((o: any) => o.type === 'SPAWNER_BOX')
        .reduce((a: number, o: any) => {
          const blocks = Math.max(0, Math.floor(o?.hp ?? o?.spawnCount ?? 0));
          return a + blocks;
        }, 0);

      if (supplyExpected === 0) {
        if (pages.length > 0 || perColSum > 0) {
          issues.push({ level: 'warn', msg: `Supply가 0인데 supply 데이터가 존재합니다. (pages=${pages.length} perColSum=${perColSum})` });
        }
      } else {
        // ✅ 런타임은 supply가 부족하면(메타 blockCount가 더 큰 경우) 자동으로 supply를 채웁니다.
        // 따라서 여기서는 "초과"만 에러로, "부족"은 경고로 처리합니다.
        if (supplySumHits > supplyExpected) {
          issues.push({
            level: 'error',
            msg: `Supply 합계 초과: supplySumHits=${supplySumHits}, expected=${supplyExpected} (spawnerTotal=${spawnerTotal})`,
          });
        } else if (supplySumHits < supplyExpected) {
          issues.push({
            level: 'warn',
            msg: `Supply 합계 부족: supplySumHits=${supplySumHits}, expected=${supplyExpected} (spawnerTotal=${spawnerTotal}) — 런타임이 자동 보정합니다.`,
          });
        }
      }
    }
  }

  // --- ✅ 특수 오브젝트(라지/생성박스/체인) 상세 검증 ---
  {
    // 라지 hp
    for (const o of objects as any[]) {
      const t = String(o?.type ?? '');
      if (t === 'BLOCK_LARGE' || t === 'BLOCK_LARGE_HIDDEN') {
        const hp = Number(o?.hp);
        if (!Number.isFinite(hp)) {
          issues.push({ level: 'error', msg: `라지 블럭 hp가 숫자가 아닙니다. uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
        } else {
          if (hp <= 0) {
            issues.push({ level: 'error', msg: `라지 블럭 hp(${hp})는 1 이상이어야 합니다. uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
          }
          if (Math.floor(hp) !== hp) {
            issues.push({ level: 'warn', msg: `라지 블럭 hp(${hp})가 정수가 아닙니다. (자동으로 floor 처리될 수 있음) uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
          }
        }
      }
    }

    // 생성박스 hp / 좌우색
    for (const o of objects as any[]) {
      const t = String(o?.type ?? '');
      if (t !== 'SPAWNER_BOX') continue;

      const hp = Number(o?.hp ?? o?.spawnCount ?? 0);
      if (!Number.isFinite(hp)) {
        issues.push({ level: 'error', msg: `생성박스 hp가 숫자가 아닙니다. uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
      } else {
        if (hp <= 0) {
          issues.push({ level: 'warn', msg: `생성박스 hp(${hp})가 0 이하입니다. (생성이 0으로 처리될 수 있음) uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
        }
        if (Math.floor(hp) !== hp) {
          issues.push({ level: 'warn', msg: `생성박스 hp(${hp})가 정수가 아닙니다. uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
        }
      }

      const pool = Array.isArray(o?.spawn?.poolColors) ? (o.spawn.poolColors as any[]) : [];
      const c1 = String(pool[0] ?? '').trim();
      const c2 = String(pool[1] ?? '').trim();
      if (!c1 || !c2) {
        issues.push({ level: 'warn', msg: `생성박스 좌/우 컬러(poolColors[0/1])가 비어 있습니다. uid=${o?.uid}`, at: { x: Number(o?.x ?? 0), y: Number(o?.y ?? 0) } });
      }
    }

    // 체인: chainId 기반 1xN(가로) 규칙(권장)
    // - N: 2~10
    const chainGroups = new Map<string, any[]>();
    let chainNoId = 0;
    for (const o of objects as any[]) {
      const t = String(o?.type ?? '');
      if (t !== 'CHAIN_BARRIER') continue;
      const cid = String(o?.chainId ?? o?.chainGroupId ?? '').trim();
      if (!cid) {
        chainNoId++;
        continue;
      }
      if (!chainGroups.has(cid)) chainGroups.set(cid, []);
      chainGroups.get(cid)!.push(o);
    }

    if (chainNoId > 0) {
      issues.push({ level: 'warn', msg: `CHAIN_BARRIER 중 chainId가 없는 셀이 ${chainNoId}개 있습니다. (셀 단위 체인으로 처리됨)` });
    }

    for (const [cid, arr] of chainGroups.entries()) {
      if (arr.length < 2 || arr.length > 10) {
        issues.push({ level: 'warn', msg: `체인(${cid}) 크기=${arr.length}. (권장: 2~10칸(1xN))` });
      }

      const cells = (arr as any[]).map((o) => ({
        x: Number(o?.x ?? 0),
        y: Number(o?.y ?? 0),
        order: Number.isFinite(Number(o?.chainOrder)) ? Math.floor(Number(o?.chainOrder)) : null,
      }));

      // 1) 같은 행인지
      const y0 = cells[0]?.y ?? 0;
      const mixedY = cells.some((c) => c.y !== y0);
      if (mixedY) {
        issues.push({ level: 'warn', msg: `체인(${cid})가 1행(가로) 형태가 아닙니다. (y가 섞여있음)` });
      }

      // 2) x 연속(가로로 붙어있음)인지
      const xs = cells.map((c) => c.x).slice().sort((a, b) => a - b);
      const uniqueXs = new Set(xs);
      if (uniqueXs.size !== xs.length) {
        issues.push({ level: 'warn', msg: `체인(${cid})에 같은 x좌표가 중복됩니다.` });
      } else {
        for (let i = 1; i < xs.length; i++) {
          if (xs[i] !== xs[0] + i) {
            issues.push({ level: 'warn', msg: `체인(${cid})가 가로로 연속(붙어있는) 형태가 아닙니다. (x가 끊김)` });
            break;
          }
        }
      }

      // 3) chainOrder 권장 규칙: 0..N-1
      const orders = cells.map((c) => c.order).filter((v) => v != null) as number[];
      if (orders.length !== cells.length) {
        issues.push({ level: 'warn', msg: `체인(${cid}) chainOrder가 비어있는 셀이 있습니다. (권장: 0..N-1)` });
      } else {
        const os = orders.slice().sort((a, b) => a - b);
        const uniq = new Set(os);
        if (uniq.size !== os.length) {
          issues.push({ level: 'warn', msg: `체인(${cid}) chainOrder가 중복됩니다. (권장: 0..N-1)` });
        } else {
          for (let i = 0; i < os.length; i++) {
            if (os[i] !== i) {
              issues.push({ level: 'warn', msg: `체인(${cid}) chainOrder가 0..N-1 형식이 아닙니다. (현재: ${os.join(',')})` });
              break;
            }
          }
        }
      }
    }
  }

  // ✅ KEY -> lockShooterCount 검증
  // - 기획: KEY 블럭 1개가 생성되면(=스테이지에 존재하면) "자물쇠 유닛" 카운터가 1 증가해야 합니다.
  // - 즉, lockShooterCount는 KEY 블럭 개수(초기 + 공급)에 맞춰야 합니다.
  {
    const pages = stage.supply?.pages ?? [];
    const countType = (objs: any[], t: string) => (objs ?? []).reduce((a, o) => a + (String((o as any)?.type ?? '') === t ? 1 : 0), 0);

    const keyCount = countType(objects as any, 'KEY') + pages.reduce((a, p) => a + countType((p as any)?.objects ?? [], 'KEY'), 0);
    const lockShooterCount = Math.max(0, Math.floor((stage.meta as any)?.lockShooterCount ?? 0));

    if (keyCount > 0) {
      if (lockShooterCount < keyCount) {
        issues.push({ level: 'error', msg: `KEY 블럭이 ${keyCount}개인데 lockShooterCount=${lockShooterCount} 입니다. (KEY 개수만큼 lockShooterCount가 필요)` });
      } else if (lockShooterCount > keyCount) {
        issues.push({ level: 'warn', msg: `lockShooterCount(${lockShooterCount})가 KEY 블럭 개수(${keyCount})보다 큽니다. (남는 자물쇠 유닛이 생길 수 있음)` });
      }
    } else {
      if (lockShooterCount > 0) {
        issues.push({ level: 'warn', msg: `KEY 블럭이 없는데 lockShooterCount=${lockShooterCount} 입니다.` });
      }
    }

    const lockObjCount = countType(objects as any, 'LOCK') + pages.reduce((a, p) => a + countType((p as any)?.objects ?? [], 'LOCK'), 0);
    if (lockObjCount > 0) {
      issues.push({ level: 'warn', msg: `LOCK 오브젝트(${lockObjCount}개)가 포함되어 있습니다. (툴/런타임에서 LOCK 오브젝트는 더 이상 사용하지 않습니다)` });
    }
  }

  return issues;
}
