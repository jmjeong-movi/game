#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOOL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$REPO_ROOT" ]]; then
  REPO_ROOT="$(cd "$TOOL_DIR/../.." && pwd)"
fi
cd "$REPO_ROOT"

export REAL_GAME_VALIDATOR_MODULE="${REAL_GAME_VALIDATOR_MODULE:-$TOOL_DIR/src/validator_tools/engine/real_game_validator.js}"
"$TOOL_DIR/scripts/real_engine_preflight.sh"

node - <<'NODE'
const p = process.env.REAL_GAME_VALIDATOR_MODULE;
const mod = require(require('path').resolve(process.cwd(), p));
if (mod.isRealEngine !== true) {
  console.error('isRealEngine must be true');
  process.exit(4);
}
console.log('real engine module connected:', p);
NODE
