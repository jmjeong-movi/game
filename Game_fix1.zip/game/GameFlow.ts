import { _decorator, Component, Asset, TextAsset, JsonAsset, Color, SpriteAtlas, resources, Node, director } from 'cc';

import type { StagePackV2, StageV2, StageRuntime, CardData } from './Types';
import { compileRuntimeFromV2 } from './StageCompiler';
import { AtlasCache, ColorPalette, LabelPalette } from './ColorPalette';

import { Board } from './Board';
import { HUDLevelBar } from './HUDLevelBar';
import { UnitLineRack } from './UnitLineRack';
import { AudioManager } from '../core/AudioManager';

const { ccclass, property } = _decorator;

type AnyPack = StagePackV2 | any;
type ShotConfig = { seed: number; rate: number };

@ccclass('GameFlow')
export class GameFlow extends Component {
    @property({ type: Asset, tooltip: '스테이지팩(JsonAsset 또는 TextAsset(JSON 문자열)) - v2만 지원' })
    stageAsset: Asset | null = null;

    @property({ type: SpriteAtlas, tooltip: 'UI2에서 사용하는 아틀라스( Mechanic_XX / Unit_XX / Enemy_Block_* )' })
    uiAtlas: SpriteAtlas | null = null;

    @property({ type: [Color], tooltip: '라벨 컬러 12개(비어있으면 기본 HEX 팔레트 사용). 길이가 12가 아니면 무시됨' })
    labelColors: Color[] = [];

    @property({ type: Board, tooltip: 'Board 컴포넌트(씬에서 드래그)' })
    board: Board | null = null;

    @property({ type: UnitLineRack, tooltip: 'UnitLineRack(신규 UI: Shootingline/WaitingLine 배치) - 필수' })
    unitRack: UnitLineRack | null = null;

    @property({ type: HUDLevelBar, tooltip: 'HUDLevelBar 컴포넌트(없으면 생략 가능)' })
    hud: HUDLevelBar | null = null;

    @property({ tooltip: '유닛 2발(shotCount=2) 기본 확률(0~1). stage.meta.shot2Rate가 있으면 그 값을 우선 사용' })
    twoShotRateDefault = 0.3;

    private _stagesV2: StageV2[] = [];
    private _index = 0;

    private _stageGraceT = 0;
    private _locked = false;

    private _runtimeCacheV2 = new Map<number, StageRuntime>();

    // ✅ stage-pack 식별자(툴 export buildId) 로깅/스냅샷용
    private _packBuildId = '';

    private _cardObjPool: CardData[] = [];
    private _cardInstances: CardData[] = [];

    // -----------------------------
    // ✅ Stage Clear Result UI
    // -----------------------------
    // 역할:
    // - 스테이지 클리어 시 즉시 다음 스테이지로 넘어가지 않고 Result 패널을 띄웁니다.
    // - Canvas/UI/Root/SafeAreaRoot/Result/Root/Btn_Next 버튼 클릭 시 nextStage()를 실행합니다.
    private _awaitNextStage = false;
    private _resultMode: 'clear' | 'fail' | null = null;
    private _resultNode: Node | null = null;
    private _btnNextNode: Node | null = null;

    onLoad() {
        // 1) 아틀라스(블럭/메카닉 프레임) 설정
        AudioManager.I?.playBgmByIndex(0, true);
        if (this.uiAtlas) {
            AtlasCache.setAtlas(this.uiAtlas);
        } else {
            // 인스펙터 누락 시: resources에 있으면 자동 로드 시도(프로젝트마다 경로가 달라 실패할 수 있음)
            resources.load('Atlas_UI_Alpha', SpriteAtlas, (err, atlas) => {
                if (!err && atlas) {
                    AtlasCache.setAtlas(atlas);
                    // 보드에 이미 생성된 블럭이 있으면 색을 다시 갱신
                    this.board?.forceRefreshAllTiles?.();
                } else {
                    console.warn(
                        '[GameFlow] uiAtlas 미지정(또는 resources에서 Atlas_UI_Alpha 로드 실패). 블럭 스프라이트 교체가 안될 수 있습니다. Inspector에 SpriteAtlas를 연결하세요.',
                    );
                }
            });
        }

        LabelPalette.setCustom(this.labelColors.length === 12 ? this.labelColors : null);
    }

    start() {
        const pack = this._readAnyPack();
        if (!pack) return;

        this._prepareStagesV2(pack);

        // // 역할: 실제로 로드되는 pack의 stage id 목록 확인(“2부터 시작”처럼 보일 때 원인 파악)
        if (this._stagesV2.length > 0) {
            const firstId = (this._stagesV2[0] as any).id | 0;
            const lastId = (this._stagesV2[this._stagesV2.length - 1] as any).id | 0;
            console.log(
                '[GameFlow] stages:',
                this._stagesV2.map((s: any) => s.id | 0),
                'first=',
                firstId,
                'last=',
                lastId,
            );
        } else {
            console.warn('[GameFlow] stages empty after prepare');
        }

        if (!this.hud || !this.hud.isValid) {
            console.warn('[GameFlow] HUDLevelBar 미연결: LEVEL 라벨이 기본값(예: 2)로 보일 수 있습니다.');
        }

        this._bindResultUI();
        this._setResultVisible(false);

        this.loadStage(0);
    }

    update(dt: number) {
        if (this._stageGraceT > 0) this._stageGraceT = Math.max(0, this._stageGraceT - dt);
        if (this._locked) return;

        const b = this.board;
        if (!b || !b.isValid) return;

        // ✅ Result 대기 중이면 자동 진행 금지
        if (this._awaitNextStage) return;

        const remaining = b.remaining();
        const busy = b.isBusy();

        // ✅ 클리어 실패 조건(요구사항):
        // - 슈팅라인 슬롯이 가득 찼는데
        // - 장착된 유닛 전체가 쏠 타겟이 없으면 실패
        // - 보드가 비지 않았고, 연출/로딩 grace 이후에만 체크
        if (remaining > 0 && !busy && this._stageGraceT <= 0) {
            const ur: any = this.unitRack as any;
            if (ur && ur.isValid && typeof ur.isStuckNoShootTargets === 'function') {
                if (ur.isStuckNoShootTargets(b)) {
                    // ✅ stuck snapshot: stage id + slot/row0/targets summary
                    try {
                        const st: any = this._stagesV2?.[this._index] as any;
                        const sid = (st?.id ?? (this._index + 1)) | 0;
                        const snap = typeof ur.buildStuckSnapshot === 'function' ? ur.buildStuckSnapshot(b) : null;
                        console.error(
                            '[STUCK]',
                            JSON.stringify({
                                buildId: this._packBuildId || undefined,
                                stageId: sid,
                                index: this._index,
                                remaining,
                                snap,
                            }),
                        );
                    } catch {
                        // ignore
                    }
                    this._lockOnce(() => this._onStageFailed());
                    return;
                }
            }
        }
        if (remaining <= 0 && !busy && this._stageGraceT <= 0) {
            this._lockOnce(() => this._onStageCleared());
        }
    }

    private _resetBeforeStageTransition(): void {
        // 역할:
        // - 스테이지 전환/재시작 시 남아있는 조준/IK/발사 예약 상태를 강제로 리셋
        // - 이전 스테이지의 총 쏘던 방향/IK 잔상 문제를 원천 차단

        const ur = this.unitRack;
        if (ur && ur.isValid) {
            ur.resetAllAimAndPose();
        }
    }

    loadStage(index: number) {
        const b = this.board;
        const ur = this.unitRack;
        if (!b || !b.isValid) {
            console.error('[GameFlow] Board 연결 필요(인스펙터)');
            return;
        }
        if (!ur || !ur.isValid) {
            console.error('[GameFlow] UnitLineRack 연결 필요(인스펙터)');
            return;
        }
        if (this._stagesV2.length <= 0) {
            console.error('[GameFlow] v2 stages empty');
            return;
        }

        // ✅ 스테이지 전환 직전: 유닛 조준/IK/발사 잔상 강제 리셋
        this._resetBeforeStageTransition();

        const clamped = this._clampIndex(index);
        this._index = clamped;

        const runtime = this._getRuntimeByIndex(clamped);
        if (!runtime) return;

        // ✅ 새 스테이지 시작 시 Result UI 닫기 + 유닛 발사 재개
        this._awaitNextStage = false;
        this._setResultVisible(false);
        if (ur) ur.enabled = true;

        ColorPalette.setFromHex(runtime.paletteHex);
        this.hud?.setStageId(runtime.id);
        this.hud?.setProgress01(0);

        b.setOnBlockDestroyed((destroyed, total) => {
            const p = total > 0 ? destroyed / total : 0;
            this.hud?.setProgress01(p);
            this.hud?.playSparkOnce();
        });

        // ✅ KEY(열쇠) 수집 → LOCK 유닛 1개 해제(가장 앞 순서)
        // - 중요: Board.load() 중에 바닥 KEY가 즉시 수집될 수 있으므로,
        //   콜백은 load 이전에 연결합니다.
        try {
            (ur as any).resetKeyUnlockState?.();
        } catch {}
        try {
            (b as any).setKeyCollectedCallback?.((keyId: string) => {
                try {
                    (ur as any).onKeyCollected?.(keyId);
                } catch {}
            });
        } catch {}

        b.load(runtime);

        const cards = this._makeCardInstances(runtime.cards);

        const cfg = this._getShotConfig(runtime);
        this._applyShotMode(cards, cfg.seed, cfg.rate);

        ur.clearAll(true);

        // ✅ waitLineCount 안전 처리(기본 3)
        const wl = (runtime as any).waitLineCount ? (runtime as any).waitLineCount | 0 : 3;

        // ✅ slotCount(Shooting) + pickerCols(Waiting) + waitLineCount 함께 적용
        ur.rebuild(runtime.slotCount, runtime.pickerCols, wl);

        ur.setWaitingUnits(cards);

        this._stageGraceT = 0.2;
    }

    nextStage() {
        this.loadStage(this._index + 1);
    }

    restartStage() {
        this.loadStage(this._index);
    }

    // -----------------------------
    // ✅ Result UI Handling
    // -----------------------------

    private _bindResultUI() {
        // // 역할: 씬의 고정 경로에서 Result/Btn_Next를 찾아 클릭 이벤트를 연결합니다.
        // // - 인스펙터 연결 없이도 동작하도록 경로 기반으로 찾습니다.
        const scene = director.getScene();
        if (!scene || !scene.isValid) return;

        const result = scene.getChildByPath('Canvas/UI/Root/SafeAreaRoot/Result');
        if (result && result.isValid) this._resultNode = result;

        const btn = scene.getChildByPath('Canvas/UI/Root/SafeAreaRoot/Result/Root/Btn_Next');
        if (btn && btn.isValid) {
            this._btnNextNode = btn;
            // 중복 바인딩 방지
            btn.off(Node.EventType.TOUCH_END, this._onClickNextStage, this);
            btn.on(Node.EventType.TOUCH_END, this._onClickNextStage, this);
        }
    }

    private _setResultVisible(on: boolean) {
        // // 역할: Result 패널 활성/비활성(없으면 무시)
        const n = this._resultNode;
        if (!n || !n.isValid) return;
        n.active = !!on;
    }

    private _onStageCleared() {
        // // 역할: 스테이지 클리어 시 Result UI를 띄우고, 다음 스테이지는 버튼 클릭으로만 진행
        this._awaitNextStage = true;
        this._resultMode = 'clear';
        this._setResultVisible(true);

        // 발사/입력 정지(연출 안정화)
        if (this.unitRack && this.unitRack.isValid) this.unitRack.enabled = false;

        // 버튼이 아직 바인딩되지 않았으면 1회 재시도(씬 로딩 순서 이슈 대비)
        if (!this._btnNextNode || !this._btnNextNode.isValid) this._bindResultUI();
    }

    private _onStageFailed() {
        // // 역할: 실패 시 Result UI를 띄우고, 버튼 클릭으로 재시작
        this._awaitNextStage = true;
        this._resultMode = 'fail';
        this._setResultVisible(true);

        if (this.unitRack && this.unitRack.isValid) this.unitRack.enabled = false;
        if (!this._btnNextNode || !this._btnNextNode.isValid) this._bindResultUI();
    }

    private _onClickNextStage() {
        // // 역할: Result/Btn_Next 클릭 시 다음 스테이지로 진행
        if (!this._awaitNextStage) return;

        this._awaitNextStage = false;
        this._setResultVisible(false);

        if (this.unitRack && this.unitRack.isValid) this.unitRack.enabled = true;
        if (this._resultMode === 'fail') {
            this._resultMode = null;
            this.restartStage();
        } else {
            this._resultMode = null;
            this.nextStage();
        }
    }

    private _lockOnce(fn: () => void) {
        this._locked = true;
        try {
            fn();
        } finally {
            this.scheduleOnce(() => (this._locked = false), 0);
        }
    }

    private _getRuntimeByIndex(index: number): StageRuntime | null {
        const st = this._stagesV2[index];
        if (!st) return null;

        const id = st.id | 0;
        const cached = this._runtimeCacheV2.get(id);
        if (cached) return cached;

        const layerCount = st?.meta?.layerCount ?? 1;
        const enableStacks = layerCount > 1;

        const rt = compileRuntimeFromV2(st, { enableStacks });
        this._runtimeCacheV2.set(id, rt);
        return rt;
    }

    private _clampIndex(index: number): number {
        const n = this._stagesV2.length;
        if (n <= 0) return 0;
        return ((index % n) + n) % n;
    }

    private _prepareStagesV2(pack: AnyPack) {
        this._runtimeCacheV2.clear();

        // ✅ pack 식별자(툴 Export에서 넣어주는 buildId). 없으면 빈 문자열.
        this._packBuildId = String((pack as any)?.buildId ?? '');

        // 로드된 pack이 최신 Export와 같은지 확인용 로그
        if (this._packBuildId) {
            console.log('[GameFlow] stage-pack buildId:', this._packBuildId);
        } else {
            console.warn('[GameFlow] stage-pack buildId: (missing)');
        }

        const stages = Array.isArray(pack?.stages) ? pack.stages : [];
        const firstStage = stages.length > 0 ? stages[0] : null;

        const looksLikeV2 = (pack as any).schemaVersion === 2 || !!firstStage?.meta;

        if (!looksLikeV2) {
            console.error(
                '[GameFlow] v1 스테이지팩은 지원하지 않습니다. stage-tool-v4(v2) export JSON을 사용해주세요.',
                pack,
            );
            this._stagesV2.length = 0;
            return;
        }

        this._stagesV2 = stages.slice().sort((a: any, b: any) => (a.id | 0) - (b.id | 0));
        if (this._stagesV2.length === 0) {
            console.warn('[GameFlow] pack.stages가 비어있습니다.');
        }
    }

    private _makeCardInstances(src: CardData[]): CardData[] {
        const prev = this._cardInstances;
        for (let i = 0; i < prev.length; i++) this._cardObjPool.push(prev[i]);
        prev.length = 0;

        if (!Array.isArray(src) || src.length === 0) return prev;

        for (let i = 0; i < src.length; i++) {
            const s = src[i] as any;
            const o = this._cardObjPool.length > 0 ? this._cardObjPool.pop()! : ({} as any);

            o.colorId = s.colorId | 0;
            o.ammo = (s.ammo | 0) < 0 ? 0 : s.ammo | 0;

            if (s.barrelMode != null) o.barrelMode = s.barrelMode;
            else if (o.barrelMode != null) delete o.barrelMode;

            if (s.shotCount === 1 || s.shotCount === 2) o.shotCount = s.shotCount;
            else if (o.shotCount != null) delete o.shotCount;

            // ✅ 힌트/표시 전용 필드들도 인스턴스로 복사해야 UI에 남습니다.
            // - hintStep: 장착 순번(1..slotCount)
            // - hintRank: 기타 힌트 우선도(보존)
            // - kind: NORMAL/CHAIN/LOCK/SPAWNER 등(보존)
            if (s.hintStep != null) o.hintStep = s.hintStep | 0;
            else if (o.hintStep != null) delete o.hintStep;

            if (s.hintRank != null) o.hintRank = s.hintRank | 0;
            else if (o.hintRank != null) delete o.hintRank;

            if (s.kind != null) o.kind = s.kind;
            else if (o.kind != null) delete o.kind;

            prev.push(o as CardData);
        }

        return prev;
    }

    private _clamp01(v: number) {
        if (!Number.isFinite(v)) return 0;
        return Math.max(0, Math.min(1, v));
    }

    private _mulberry32(seed: number) {
        let s = seed >>> 0 || 1;
        return () => {
            s += 0x6d2b79f5;
            let t = s;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }

    private _applyShotMode(cards: CardData[], seed: number, twoShotRate: number) {
        if (!Array.isArray(cards) || cards.length === 0) return;

        const rate = this._clamp01(twoShotRate);

        if (rate <= 0) {
            for (let i = 0; i < cards.length; i++) {
                const c: any = cards[i];
                if (!c) continue;
                if (c.shotCount !== 1 && c.shotCount !== 2) c.shotCount = 1;
            }
            return;
        }

        const rng = this._mulberry32((seed + 0x13579bdf) | 0);

        for (let i = 0; i < cards.length; i++) {
            const c: any = cards[i];
            if (!c) continue;

            if (c.shotCount === 1 || c.shotCount === 2) continue;

            c.shotCount = rng() < rate ? 2 : 1;
        }
    }

    private _getShotConfig(runtime: StageRuntime): ShotConfig {
        const defRate = this._clamp01(this.twoShotRateDefault);

        const stageId = runtime.id | 0;
        const st = this._stagesV2[this._index] as any;
        const meta = st?.meta ?? {};
        const s = ((meta.seed ?? 1000 + stageId * 777) | 0) >>> 0;
        const rate = this._clamp01(meta.shot2Rate ?? defRate);
        return { seed: s, rate };
    }

    private _readAnyPack(): AnyPack | null {
        const a = this.stageAsset;
        if (!a) {
            console.error('[GameFlow] stageAsset is null');
            return null;
        }

        try {
            if (a instanceof JsonAsset) return a.json as any;
            if (a instanceof TextAsset) return JSON.parse(a.text) as any;
            console.error('[GameFlow] stageAsset type invalid:', a);
            return null;
        } catch (e) {
            console.error('[GameFlow] stage json parse failed:', e);
            return null;
        }
    }

    public restartFromStagePack(pack: any, debugName = 'stage-pack'): void {
        // 1) pack 교체 + 캐시 초기화
        this._prepareStagesV2(pack);

        if (this._stagesV2.length <= 0) {
            console.error('[GameFlow] restartFromStagePack failed: stages empty:', debugName);
            return;
        }

        // 2) stage1부터 강제 재시작
        this._index = 0;
        this.loadStage(0);

        console.log('[GameFlow] restartFromStagePack ok:', debugName);
    }

    // 역할:
    // - (디버그/테스트) 외부에서 받은 stage-pack(v2) JSON을 런타임에 주입
    // - 기존 런타임 캐시는 비우고, 스테이지 목록만 갱신
    // 퍼포먼스:
    // - compile은 loadStage에서 지연 실행(기존 구조 유지)
    public setStagePackV2(pack: any): boolean {
        if (!pack) return false;

        this._prepareStagesV2(pack);

        // 인덱스/대기 UI는 "시작" 시점에만 적용하므로 여기선 index만 안전값으로
        this._index = 0;

        // 비정상 pack 방어
        return this._stagesV2.length > 0;
    }

    // 역할:
    // - 드롭다운 표시용 스테이지 엔트리 반환
    // - index는 loadStage에 넣는 값, id는 표시용/검색용
    public getStageEntries(): { index: number; id: number }[] {
        const out: { index: number; id: number }[] = [];
        const arr = this._stagesV2;
        for (let i = 0; i < arr.length; i++) {
            out.push({ index: i, id: (arr[i] as any).id | 0 });
        }
        return out;
    }

    // 역할: 드롭다운에서 선택한 index로 즉시 시작
    public startStageByIndex(index: number): void {
        this.loadStage(index | 0);
    }

    // 역할: stage id로 찾아서 시작(없으면 무시)
    public startStageById(stageId: number): void {
        const id = stageId | 0;
        const arr = this._stagesV2;
        for (let i = 0; i < arr.length; i++) {
            if (((arr[i] as any).id | 0) === id) {
                this.loadStage(i);
                return;
            }
        }
        console.warn('[GameFlow] startStageById: not found:', id);
    }

    // (옵션) 현재 인덱스 확인용
    public getCurrentStageIndex(): number {
        return this._index | 0;
    }
}
