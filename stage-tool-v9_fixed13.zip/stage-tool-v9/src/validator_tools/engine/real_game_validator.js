/* eslint-disable no-console */

// Real-engine contract module.
// This version includes a deterministic hint-step simulation core (conservative model)
// that never marks SOLVED unless all computed target HP can be removed by authored hint steps.

const isRealEngine = true;

const BLOCK_HP = {
  BLOCK_NORMAL: 1,
  BLOCK_SMALL: 1,
  BLOCK_HIDDEN: 1,
};

function normColor(c) {
  if (typeof c !== 'string') return '';
  return c.trim().toUpperCase();
}

function buildTargetHpByColor(stage) {
  const byColor = new Map();
  const objs = Array.isArray(stage?.board?.objects) ? stage.board.objects : [];

  const add = (color, hp) => {
    const k = normColor(color);
    if (!k) return;
    byColor.set(k, (byColor.get(k) || 0) + Math.max(0, hp | 0));
  };

  for (const o of objs) {
    const t = String(o?.type || '');
    if (t in BLOCK_HP) {
      add(o?.color, BLOCK_HP[t]);
      continue;
    }
    if (t === 'BLOCK_LARGE' || t === 'BLOCK_LARGE_HIDDEN') {
      const hp = Number.isFinite(o?.hp) ? (o.hp | 0) : 20;
      add(o?.color, Math.max(1, hp));
      continue;
    }
    if (t === 'CHAIN_BARRIER') {
      // conservative: chain requires at least 1 matching hit in many rule sets
      add(o?.color, 1);
      continue;
    }
    // KEY/PILLAR/SPAWNER are not direct target hp in this conservative model.
  }

  return byColor;
}

function authoredSteps(stage) {
  const authored = Array.isArray(stage?.cards?.authored) ? stage.cards.authored : [];
  const rows = authored
    .map((c, i) => ({
      idx: i,
      color: normColor(c?.color),
      ammo: Number.isFinite(c?.ammo) ? (c.ammo | 0) : (Number.isFinite(c?.shotCount) ? ((c.shotCount | 0) * 10) : 0),
      step: Number.isFinite(c?.hintStep) ? (c.hintStep | 0) : i + 1,
    }))
    .filter((r) => !!r.color && r.ammo > 0)
    .sort((a, b) => a.step - b.step || a.idx - b.idx);
  return rows;
}

function remainingTotal(map) {
  let s = 0;
  for (const v of map.values()) s += v;
  return s;
}

async function validateStageEquivalent(stage, _opts = {}) {
  const id = stage?.id ?? -1;
  const mode = String(stage?.cards?.mode || '');

  const hpByColor = buildTargetHpByColor(stage);
  if (hpByColor.size === 0) {
    return { status: 'UNSOLVED', reason: 'NO_TARGET_BLOCKS', failStep: 0, opsUsed: [], stageId: id };
  }

  // For now, strict trustworthy path is implemented for AUTHORED+hintStep stages.
  if (mode !== 'AUTHORED') {
    return {
      status: 'UNSOLVED',
      reason: 'GENERATE_MODE_RUNTIME_SIM_PENDING',
      failStep: -1,
      opsUsed: [],
      stageId: id,
    };
  }

  const steps = authoredSteps(stage);
  if (steps.length === 0) {
    return { status: 'UNSOLVED', reason: 'NO_AUTHORED_HINT_STEPS', failStep: 0, opsUsed: [], stageId: id };
  }

  let failStep = -1;
  for (let i = 0; i < steps.length; i++) {
    const st = steps[i];
    const left = hpByColor.get(st.color) || 0;
    if (left <= 0) continue;

    const hit = Math.min(left, st.ammo);
    hpByColor.set(st.color, left - hit);

    // step consumed but no effective progress => likely stuck color routing
    if (hit <= 0 && failStep < 0) failStep = st.step;
  }

  const rem = remainingTotal(hpByColor);
  if (rem <= 0) {
    return {
      status: 'SOLVED',
      reason: 'AUTHORED_HINT_SIM_SOLVED',
      failStep: -1,
      opsUsed: ['deck_reorder', 'ammo_redistribute'],
      stageId: id,
    };
  }

  return {
    status: 'UNSOLVED',
    reason: 'INSUFFICIENT_COLOR_AMMO_FOR_TARGET_HP',
    failStep,
    opsUsed: ['deck_reorder', 'ammo_redistribute'],
    stageId: id,
  };
}

module.exports = { isRealEngine, validateStageEquivalent };
