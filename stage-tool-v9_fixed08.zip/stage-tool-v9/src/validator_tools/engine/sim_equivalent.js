/* eslint-disable no-console */

// Real engine contract:
// - export validateStageEquivalent(stage, opts)
// - export isRealEngine = true
//
// This default module intentionally fails-safe so no false SOLVED can pass.

const isRealEngine = false;

async function validateStageEquivalent(_stage, _opts = {}) {
  return {
    status: 'UNSOLVED',
    reason: 'SIM_ENGINE_NOT_LINKED',
    failStep: -1,
    opsUsed: [],
  };
}

module.exports = { isRealEngine, validateStageEquivalent };
