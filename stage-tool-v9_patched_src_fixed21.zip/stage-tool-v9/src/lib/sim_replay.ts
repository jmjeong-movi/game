// 간이 플레이 리플레이(=실제 게임 루프에 가까운 흐름) 생성기
// - StageCompiler.compileRuntimeFromV2 + Board(headless)를 사용해
//   "W1 클릭 → 슈팅라인 장착 → 자동 발사" 흐름을 흉내냅니다.
// - 목적: Export된 JSON(특히 AUTHORED + hintStep)이 실제 게임 진행에서
//         의도한 순서대로 노출/클릭되는지, 어느 시점에 막히는지(또는 클리어되는지)
//         스테이지툴에서 바로 확인.
//
// ✅ 중요: WaitingLine(대기라인) 컬럼 활성화 규칙은 UnitLineRack._mask5FromCount()와 동일해야 합니다.
// - pickerCols=2 인 경우 실제 게임은 중앙정렬로 (1,3) 컬럼을 씁니다.
// - pickerCols=3 인 경우 (1,2,3) 컬럼을 씁니다.
// - 이 규칙을 무시하면 hintStep 기반 클릭/오버플로 분배가 달라져 "리플레이=STUCK" 오탐이 발생합니다.

import { Node, Prefab } from 'cc';
import { COLOR_TOKEN_ORDER, colorIdFromToken } from './runtime/Types';

// validator_tools 쪽 타입은 JS 기반이므로 최소만 로컬로 정의

type CardData = {
  colorId: number;
  ammo?: number;
  shotCount?: number;
  hintStep?: number;
  kind?: any;
};

type CardState = {
  colorId: number;
  token: string;
  ammo: number; // 현재 남은 탄(슈팅라인에서는 감소)
  shotCount: number;
  hintStep: number;
  srcIdx: number;
  kind?: string;
};

export type ReplayCell =
  | null
  | {
      token: string;
      colorId: number;
      entId: number;
      hp: number;
      isBig: boolean;
      hidden: boolean;
      special?: string | null;
    };

export type ReplayCardView =
  | null
  | {
      token: string;
      colorId: number;
      ammo: number;
      shotCount: number;
      hintStep: number;
      srcIdx: number;
      kind?: string;
    };

export type ReplayFrame = {
  idx: number;
  event:
    | { type: 'INIT' }
    | { type: 'CLICK'; hintStep: number; col: number; shooterIdx: number; token: string; ammo: number; shotCount: number }
    | { type: 'ROUND'; fired: number; round: number }
    | { type: 'END'; status: 'SOLVED' | 'UNKNOWN' }
    | { type: 'STUCK'; reason: string };
  board: { rows: number; cols: number; remaining: number; cells: ReplayCell[] };
  shooter: ReplayCardView[];
  waiting: {
    /** 활성 컬럼 수(=pickerCols 기반 mask 적용 후 on인 컬럼 개수) */
    cols: number;
    /** 5칸 기준 활성 마스크(디버그용) */
    activeMask: boolean[];
    waitLineCount: number;
    w1: ReplayCardView[];
    w2: ReplayCardView[];
    w3: ReplayCardView[];
    overflowCounts: number[];
    overflowHeads: ReplayCardView[];
  };
  progress: { nextHint: number; clicked: number; shotsFired: number; rounds: number };
};

export type ReplayDetail = 'compact' | 'round';

export type SimReplayOpts = {
  /** 최대 시뮬레이션 틱 수(=시간 흐름). 기존 이름(maxRounds)과 호환 유지. */
  maxRounds?: number;
  maxShots?: number;
  detail?: ReplayDetail;
  /** hintStep 순서대로만 클릭(기본 true). false면 W1을 좌→우로 채웁니다. */
  strictHintOrder?: boolean;
  /** 프레임(보드/라인 스냅샷) 저장 여부. Export 검증 등에서는 false를 권장. */
  captureFrames?: boolean;
};

export type SimReplayResult = {
  status: 'SOLVED' | 'STUCK' | 'UNKNOWN';
  reason?: string;
  /** Remaining tiles at the end of the replay (or at STUCK). */
  remaining: number;
  /** STUCK 시점의 디버그/수정용 스냅샷(프레임 저장 여부와 무관하게 제공). */
  stuck?: {
    reason: string;
    /** 다음 클릭해야 할 hintStep - 1 (즉, "앞에서 몇 장을 이미 클릭했는지"에 해당) */
    deckIdx: number;
    /** 현재 보드에서 "쏠 수 있는" 색상별 타겟 수(=pickShootTargets 기반) */
    needCounts: number[];
    /** 보드 front-row(0행) 기준 색상 카운트(디버그용) */
    row0Counts: number[];
    /** 아직 클릭되지 않은 카드 구간(deckIdx..end)의 색상 카드 수(디버그용) */
    deckColorCounts: number[];
    /** 슈팅라인 슬롯 색상 */
    slotColors: number[];
    /** 슈팅라인 슬롯 잔탄 */
    slotAmmo: number[];
    /** 슈팅라인 슬롯이 참조하는 원본 덱 인덱스(srcIdx) */
    slotDeckPos: number[];
  };
  frames: ReplayFrame[];
  clicked: number;
  rounds: number;
  shotsFired: number;
  nextHint: number;
};

function computeNeedCountsFromBoard(board: any, out?: Int32Array): Int32Array {
  // Prefer runtime Board API if present.
  try {
    if (typeof board?.getFrontColorCounts === 'function') {
      return board.getFrontColorCounts(out);
    }
  } catch {}

  const arr = out ?? new Int32Array(12);
  arr.fill(0);
  const cols = Math.max(1, (board?.cols ?? board?._cols ?? 10) | 0);
  for (let c = 0; c < cols; c++) {
    let ent: any = null;
    try {
      ent = board?.entAt?.(0, c) ?? null;
    } catch {
      ent = null;
    }
    const cid = (ent?.view?.colorId ?? -1) | 0;
    if (cid >= 0 && cid < 12) arr[cid] += 1;
  }
  return arr;
}

// Counts only *shootable* targets by delegating to Board.pickShootTargets.
// - LOCK/KEY 등 실제 런타임 타겟 선택 규칙과 일치하도록 함.
function computeShootableNeedCountsFromBoard(board: any, out?: Int32Array): Int32Array {
  const arr = out ?? new Int32Array(12);
  arr.fill(0);
  const cols = Math.max(1, (board?.cols ?? board?._cols ?? 10) | 0);
  if (typeof board?.pickShootTargets === 'function') {
    for (let cid = 0; cid < 12; cid++) {
      try {
        const ts = board.pickShootTargets(cid, Math.max(1, cols), 'LEFT', undefined, true) ?? [];
        arr[cid] = (Array.isArray(ts) ? ts.length : 0) | 0;
      } catch {
        arr[cid] = 0;
      }
    }
    return arr;
  }
  return computeNeedCountsFromBoard(board, arr);
}

function buildStuckSnapshot(args: {
  reason: string;
  board: any;
  deck: CardState[];
  shooter: Array<CardState | null>;
  nextHint: number;
}): SimReplayResult['stuck'] {
  const { reason, board, deck, shooter, nextHint } = args;
  const deckIdx = Math.max(0, (nextHint | 0) - 1);
  const need = computeShootableNeedCountsFromBoard(board);
  const row0 = computeNeedCountsFromBoard(board);

  const deckColorCounts = new Int32Array(12);
  for (let i = Math.max(0, deckIdx); i < deck.length; i++) {
    const c = (deck[i]?.colorId ?? -1) | 0;
    if (c >= 0 && c < 12) deckColorCounts[c] += 1;
  }

  const slotColors = shooter.map((s) => (s ? (s.colorId | 0) : -1));
  const slotAmmo = shooter.map((s) => (s ? (s.ammo | 0) : 0));
  const slotDeckPos = shooter.map((s) => (s ? (s.srcIdx | 0) : -1));

  return {
    reason: String(reason ?? ''),
    deckIdx,
    needCounts: Array.from(need),
    row0Counts: Array.from(row0),
    deckColorCounts: Array.from(deckColorCounts),
    slotColors,
    slotAmmo,
    slotDeckPos,
  };
}

function cjsPick<T = any>(mod: any, name: string): T {
  return (mod?.[name] ?? mod?.default?.[name] ?? mod?.default) as T;
}

function resolveColorIdAny(v: any): number {
  if (typeof v === 'number' && Number.isFinite(v)) return v | 0;
  if (typeof v === 'string') return colorIdFromToken(v) | 0;
  return -1;
}

function getCardColorIdAny(cd: any): number {
  if (!cd) return -1;
  const cid = (cd as any)?.colorId;
  if (typeof cid === 'number' && Number.isFinite(cid)) return cid | 0;
  const c = (cd as any)?.color;
  const id1 = resolveColorIdAny(c);
  if (id1 >= 0) return id1 | 0;
  const id2 = resolveColorIdAny(cid);
  return id2 | 0;
}

function toToken(colorId: number): string {
  const t = COLOR_TOKEN_ORDER[colorId | 0];
  return typeof t === 'string' && t.length > 0 ? t : '?';
}

function cloneCardToState(cd: CardData, srcIdx: number): CardState {
  const colorId = getCardColorIdAny(cd) | 0;
  const ammo = Math.max(0, (cd?.ammo ?? 0) | 0);
  const shotCount = Math.max(1, (cd?.shotCount ?? 1) | 0);
  const hintStepRaw = (cd as any)?.hintStep;
  const hintStep = hintStepRaw == null ? 0 : Math.max(0, hintStepRaw | 0);
  const kind = typeof (cd as any)?.kind === 'string' ? String((cd as any).kind) : undefined;
  return {
    colorId,
    token: toToken(colorId),
    ammo,
    shotCount,
    hintStep,
    srcIdx: srcIdx | 0,
    kind,
  };
}

function viewCard(c: CardState | null): ReplayCardView {
  if (!c) return null;
  return {
    token: c.token,
    colorId: c.colorId | 0,
    ammo: c.ammo | 0,
    shotCount: c.shotCount | 0,
    hintStep: c.hintStep | 0,
    srcIdx: c.srcIdx | 0,
    kind: c.kind,
  };
}

async function createHeadlessBoard(BoardCtor: any, runtime: any) {
  const b = new BoardCtor();
  (b as any).tilePrefab = new Prefab();
  (b as any).bigTilePrefab = new Prefab();
  (b as any).projectilePrefab = new Prefab();
  (b as any).tileLayer = new Node('tileLayer');
  (b as any).projectileLayer = new Node('projectileLayer');
  (b as any).fxLayer = new Node('fxLayer');
  (b as any).onLoad?.();
  (b as any).start?.();
  b.load(runtime);
  return b;
}

async function hit(board: any, col: number): Promise<void> {
  const fn = (board as any)['handleHitColumn'];
  if (typeof fn !== 'function') throw new Error('Board.handleHitColumn not found');
  await fn.call(board, col | 0);
}

function snapshotBoard(board: any): { rows: number; cols: number; remaining: number; cells: ReplayCell[] } {
  const rows = Math.max(1, (board?.rows ?? board?._rows ?? 10) | 0);
  const cols = Math.max(1, (board?.cols ?? board?._cols ?? 10) | 0);
  const rem = typeof board?.remaining === 'function' ? (board.remaining() | 0) : ((board?.remainingTiles ?? 0) | 0);
  const cells: ReplayCell[] = new Array(rows * cols);

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      let e: any = null;
      try {
        e = board?.entAt?.(r, c) ?? null;
      } catch {
        e = null;
      }
      const idx = r * cols + c;
      if (!e) {
        cells[idx] = null;
        continue;
      }
      const view = e.view;
      const colorId = (view?.colorId ?? -1) | 0;
      const token = toToken(colorId);
      const isBig = !!(e.w > 1 || e.h > 1);
      const hp = (view?.getHp?.() ?? 1) | 0;
      const hidden = !!(view?.isHidden?.() ?? view?.hidden);
      const sp = view?.getSpecial?.() ?? null;
      const special = sp && typeof sp?.t === 'string' ? String(sp.t) : null;

      cells[idx] = {
        token,
        colorId,
        entId: (e.id ?? 0) | 0,
        hp: Math.max(0, hp),
        isBig,
        hidden,
        special,
      };
    }
  }

  return { rows, cols, remaining: rem, cells };
}

// =============================================================
// WaitingLine(대기라인) 모델
// =============================================================

function mask5FromCount(count: number): boolean[] {
  const c = Math.max(0, Math.min(5, count | 0));
  switch (c) {
    case 1:
      return [false, false, true, false, false];
    case 2:
      return [false, true, false, true, false];
    case 3:
      return [false, true, true, true, false];
    case 4:
      return [true, true, true, true, false];
    case 5:
      return [true, true, true, true, true];
    default:
      return [false, false, false, false, false];
  }
}

function activeColsFromMask(mask: boolean[]): number[] {
  const out: number[] = [];
  for (let i = 0; i < 5; i++) if (!!mask[i]) out.push(i);
  return out;
}

type WaitingState = {
  /** 활성 컬럼 수 */
  cols: number;
  /** 5칸 기준 활성 마스크 */
  activeMask: boolean[];
  /** 실제 활성 컬럼 인덱스 목록(0..4) */
  activeCols: number[];
  waitLineCount: number;
  w1: Array<CardState | null>; // len=5
  w2: Array<CardState | null>; // len=5
  w3: Array<CardState | null>; // len=5
  overflow: Array<CardState[]>; // len=5
};

function initWaiting(deck: CardState[], pickerCols: number, waitLineCount: number): WaitingState {
  const wl = Math.max(1, Math.min(3, waitLineCount | 0));
  const mask = mask5FromCount(Math.max(0, Math.min(5, pickerCols | 0)));
  const activeCols = activeColsFromMask(mask);
  const cols = activeCols.length;

  const w1: Array<CardState | null> = new Array(5).fill(null);
  const w2: Array<CardState | null> = new Array(5).fill(null);
  const w3: Array<CardState | null> = new Array(5).fill(null);
  const overflow: Array<CardState[]> = Array.from({ length: 5 }, () => []);

  const cap = Math.max(0, Math.min(15, wl * cols));
  const count = Math.min(cap, deck.length);

  if (cols > 0) {
    // (A) W1~W3 채우기: row-wise (k/cols)
    for (let k = 0; k < count; k++) {
      const lineIdx = (k / cols) | 0;
      const colIdx = activeCols[k % cols];
      const cd = deck[k];
      if (lineIdx === 0) w1[colIdx] = cd;
      else if (lineIdx === 1) {
        if (wl >= 2) w2[colIdx] = cd;
      } else {
        if (wl >= 3) w3[colIdx] = cd;
      }
    }

    // (B) 초과분: column별 overflow 큐
    for (let k = count; k < deck.length; k++) {
      const colIdx = activeCols[k % cols];
      overflow[colIdx].push(deck[k]);
    }
  }

  return { cols, activeMask: mask, activeCols, waitLineCount: wl, w1, w2, w3, overflow };
}

function isActiveCol(st: WaitingState, col: number): boolean {
  const c = col | 0;
  return c >= 0 && c < 5 && !!st.activeMask[c];
}

function refillFromOverflow(st: WaitingState, col: number) {
  if (st.waitLineCount < 3) return;
  const c = col | 0;
  if (!isActiveCol(st, c)) return;
  if (st.w3[c]) return;
  const q = st.overflow[c];
  if (!q || q.length <= 0) return;
  const next = q.shift() ?? null;
  if (next) st.w3[c] = next;
}

function shiftColumn(st: WaitingState, col: number) {
  const c = col | 0;
  if (!isActiveCol(st, c)) return;

  const w2On = st.waitLineCount >= 2;
  const w3On = st.waitLineCount >= 3;

  const tryRefill = () => {
    if (w3On && !st.w3[c]) refillFromOverflow(st, c);
  };

  // (1) W1 empty => pull from W2 or W3
  if (!st.w1[c]) {
    const s2 = w2On ? st.w2[c] : null;
    const s3 = w3On ? st.w3[c] : null;

    if (s2) {
      st.w1[c] = s2;
      st.w2[c] = null;
      // W2 hole => W3 -> W2
      if (w3On && !st.w2[c] && st.w3[c]) {
        st.w2[c] = st.w3[c];
        st.w3[c] = null;
      }
      tryRefill();
      return;
    }

    if (s3) {
      st.w1[c] = s3;
      st.w3[c] = null;
      tryRefill();
      return;
    }

    tryRefill();
    return;
  }

  // (2) W1 filled, W2 empty, W3 filled => W3 -> W2
  if (w2On && w3On && !st.w2[c] && st.w3[c]) {
    st.w2[c] = st.w3[c];
    st.w3[c] = null;
    tryRefill();
    return;
  }

  // (3) Just refill W3 if empty
  tryRefill();
}

// 게임의 UnitLineRack.tick()에서 매 프레임 호출되는 유지 로직을 단순화해 재현합니다.
// - W1/W2/W3 사이의 "구멍"을 메우고(위로 당기기)
// - W3가 비면 overflow에서 보충합니다.
function maintainWaitingOverflow(st: WaitingState) {
  const w2On = st.waitLineCount >= 2;
  const w3On = st.waitLineCount >= 3;
  for (const c of st.activeCols) {
    if (!st.w1[c]) {
      if (w2On && st.w2[c]) {
        st.w1[c] = st.w2[c];
        st.w2[c] = null;
      }
      if (!st.w1[c] && w3On && st.w3[c]) {
        st.w1[c] = st.w3[c];
        st.w3[c] = null;
      }
    }

    if (w2On && w3On && !st.w2[c] && st.w3[c]) {
      st.w2[c] = st.w3[c];
      st.w3[c] = null;
    }

    if (w3On && !st.w3[c]) {
      refillFromOverflow(st, c);
    }
  }
}

function findFirstEmptyShooter(shooter: Array<CardState | null>): number {
  for (let i = 0; i < shooter.length; i++) if (!shooter[i]) return i;
  return -1;
}

function findW1ByHint(st: WaitingState, nextHint: number): number {
  const want = nextHint | 0;
  if (want <= 0) return -1;
  for (const c of st.activeCols) {
    const cd = st.w1[c];
    if (!cd) continue;
    if ((cd.hintStep | 0) === want) return c;
  }
  return -1;
}

function findW1Leftmost(st: WaitingState): number {
  for (let c = 0; c < 5; c++) if (st.w1[c]) return c;
  return -1;
}

function snapshotFrame(args: {
  capture: boolean;
  frames: ReplayFrame[];
  board: any;
  shooter: Array<CardState | null>;
  waiting: WaitingState;
  progress: { nextHint: number; clicked: number; shotsFired: number; rounds: number };
  event: ReplayFrame['event'];
}) {
  const { capture, frames, board, shooter, waiting, progress, event } = args;
  if (!capture) return;
  const idx = frames.length;
  frames.push({
    idx,
    event,
    board: snapshotBoard(board),
    shooter: shooter.map(viewCard) as ReplayCardView[],
    waiting: {
      cols: waiting.cols,
      activeMask: waiting.activeMask.slice(),
      waitLineCount: waiting.waitLineCount,
      w1: waiting.w1.map(viewCard) as ReplayCardView[],
      w2: waiting.w2.map(viewCard) as ReplayCardView[],
      w3: waiting.w3.map(viewCard) as ReplayCardView[],
      overflowCounts: waiting.overflow.map((q) => (q?.length ?? 0) | 0),
      overflowHeads: waiting.overflow.map((q) => viewCard(q && q.length > 0 ? q[0] : null)) as ReplayCardView[],
    },
    progress: { ...progress },
  });
}


export async function simulateStageReplay(stage: any, opts?: SimReplayOpts): Promise<SimReplayResult> {
  // ✅ "검증은 실제 로직대로"를 위해, 리플레이 시뮬레이터는
  // Board + UnitLineRack(=실제 게임의 대기라인/슈팅라인 로직)을 그대로 구동합니다.
  //
  // - StageCompiler.compileRuntimeFromV2 로 runtime을 만든 뒤
  // - Board.load(runtime)
  // - UnitLineRack.rebuild(slotCount, pickerCols, waitLineCount)
  // - UnitLineRack.setWaitingUnits(runtime.cards)
  // - update(dt) 루프를 돌리며:
  //   * hintStep 순서 클릭(옵션)
  //   * 자동 발사(tryShootAtColumn → handleHitColumn)
  //
  // 결과적으로 Export 검증/리페어(=repairStageUntilReplaySolved)는 "실제 게임 흐름" 기준으로만 합격합니다.

  const maxRounds = Math.max(1, (opts?.maxRounds ?? 200000) | 0);
  const maxShots = Math.max(1, (opts?.maxShots ?? 2000000) | 0);
  const detail: ReplayDetail = (opts?.detail ?? 'compact') as any;
  const strictHintOrder = opts?.strictHintOrder !== false;
  const captureFrames = opts?.captureFrames !== false;

  // Headless simulation에서는 Tween/애니메이션 의존으로 진행이 멈추거나(특히 대형 스테이지)
  // 매우 느려질 수 있습니다. validator_tools 쪽에서 이 플래그를 읽어 즉시 완료 처리합니다.
  (globalThis as any).__STAGE_TOOL_FAST_SIM__ = true;

  // -----------------------------
  // StageCompiler → runtime
  // -----------------------------
  // NOTE(Node/headless): dynamic import uses Node ESM resolver semantics.
  // In that environment extensionless specifiers do not resolve to CommonJS .js files.
  // Keep explicit .js so both Vite and headless Node tests can load the validator runtime.
  const stageCompilerMod = await import('../validator_tools/game/StageCompiler.js');
  const compileRuntimeFromV2 = cjsPick<(s: any, o?: any) => any>(stageCompilerMod, 'compileRuntimeFromV2');
  if (typeof compileRuntimeFromV2 !== 'function') throw new Error('validator_tools: compileRuntimeFromV2 not found');

  const layerCount = stage?.meta?.layerCount ?? 1;
  const enableStacks = (layerCount | 0) > 1;
  const runtime = compileRuntimeFromV2(stage as any, { enableStacks });

  // -----------------------------
  // Board
  // -----------------------------
  const boardMod = await import('../validator_tools/game/Board.js');
  const BoardCtor = cjsPick<any>(boardMod, 'Board');
  if (typeof BoardCtor !== 'function') throw new Error('validator_tools: Board ctor not found');
  const board = await createHeadlessBoard(BoardCtor, runtime);

  const remaining = () => {
    try {
      return typeof board?.remaining === 'function' ? (board.remaining() | 0) : ((board?.remainingTiles ?? 0) | 0);
    } catch {
      return ((board?.remainingTiles ?? 0) | 0);
    }
  };

  // Shots counter (hit 횟수 추적)
  let shotsFired = 0;
  const origHandleHit = (board as any)['handleHitColumn'];
  if (typeof origHandleHit === 'function') {
    (board as any)['handleHitColumn'] = async function (col: number) {
      shotsFired += 1;
      return await origHandleHit.call(this, col | 0);
    };
  }

  // -----------------------------
  // UnitLineRack (실제 대기/슈터 로직)
  // -----------------------------
  const rackMod = await import('../validator_tools/game/UnitLineRack.js');
  const UnitLineRackCtor = cjsPick<any>(rackMod, 'UnitLineRack');
  if (typeof UnitLineRackCtor !== 'function') throw new Error('validator_tools: UnitLineRack ctor not found');

  const pickerCols = Math.max(1, (runtime?.pickerCols ?? 5) | 0);
  const waitLineCount = Math.max(1, (runtime?.waitLineCount ?? 3) | 0);
  const slotCount = Math.max(1, (runtime?.slotCount ?? 5) | 0);

  // IMPORTANT:
  // We must be able to map a card currently living in W1/W2/W3/Shooting slots
  // back to its authored deck index.
  //
  // - In the browser/Electron runtime, UnitLineRack may clone/move card objects.
  // - Relying only on object identity (WeakMap) makes slotDeckPos unstable.
  //
  // So we wrap the runtime cards with stable metadata:
  //   { ...card, idx, token, hintRank }
  // and then prefer `cd.idx` when reconstructing slotDeckPos.
  const deckCardsRaw: CardData[] = Array.isArray(runtime?.cards) ? runtime.cards : [];
  const deckCards: any[] = deckCardsRaw.map((card: any, i: number) => {
    const colorId = getCardColorIdAny(card) | 0;
    const hintRank = (((card as any)?.hintRank ?? (card as any)?.hintStep ?? 0) as any) | 0;
    return { ...card, colorId, idx: i | 0, token: toToken(colorId), hintRank };
  });

  // card object → authored deck index (best-effort fallback)
  const posMap = new WeakMap<object, number>();
  for (let i = 0; i < deckCards.length; i++) {
    const cd: any = deckCards[i];
    if (cd && typeof cd === 'object') posMap.set(cd, ((cd as any).idx ?? i) | 0);
  }

  const createLine = (name: string, includeUnitPlaces: boolean) => {
    const line = new Node(name);
    for (let i = 1; i <= 5; i++) {
      const nn = i < 10 ? `0${i}` : String(i);
      const place = new Node(`Place${nn}`);
      place.setParent(line);
      if (includeUnitPlaces) {
        const up = new Node(`UnitPlace${nn}`);
        up.setParent(line);
      }
    }
    return line;
  };

  const rackNode = new Node('UnitLineRack');
  const unitRack: any = (rackNode as any).addComponent(UnitLineRackCtor);

  // 최소 필드 세팅
  unitRack.board = board;
  unitRack.unitPrefab = new Prefab(); // 없으면 대기라인 유닛이 생성되지 않음
  unitRack.shootingLine = createLine('ShootingLine', true);
  unitRack.waitingLine01 = createLine('WaitingLine01', false);
  unitRack.waitingLine02 = createLine('WaitingLine02', false);
  unitRack.waitingLine03 = createLine('WaitingLine03', false);

  unitRack.shootingLine.setParent(rackNode);
  unitRack.waitingLine01.setParent(rackNode);
  unitRack.waitingLine02.setParent(rackNode);
  unitRack.waitingLine03.setParent(rackNode);

  unitRack.onLoad?.();
  unitRack.rebuild(slotCount, pickerCols, waitLineCount);
  unitRack.setWaitingUnits(deckCards);

  // -----------------------------
  // Snapshot helpers
  // -----------------------------
  const viewFromCardData = (cd: any): ReplayCardView => {
    if (!cd) return null;
    const colorId = getCardColorIdAny(cd) | 0;
    const ammo = Math.max(0, ((cd?.ammo ?? 0) | 0));
    const shotCount = Math.max(1, ((cd?.shotCount ?? 1) | 0));
    const hintStep = ((cd as any)?.hintStep ?? 0) | 0;
    const kind = typeof (cd as any)?.kind === 'string' ? String((cd as any).kind) : undefined;
    let srcIdx = (typeof cd === 'object' && cd) ? ((((cd as any).idx ?? posMap.get(cd) ?? -1) as any) | 0) : -1;
    // Fallback: if the rack cloned the card and lost `.idx`, infer from hintStep (strictHintOrder deck=hint).
    if (srcIdx < 0) {
      const hs = ((cd as any)?.hintStep ?? 0) | 0;
      if (hs > 0) srcIdx = ((hs - 1) | 0);
    }
    return { token: toToken(colorId), colorId: colorId | 0, ammo, shotCount, hintStep, srcIdx, kind };
  };

  const snapshotShooter = (): ReplayCardView[] => {
    const out: ReplayCardView[] = [];
    const slots: any[] = Array.isArray(unitRack?._slotS) ? unitRack._slotS : [];
    const shootMask = mask5FromCount(slotCount);
    const shootCols = activeColsFromMask(shootMask);
    for (const col of shootCols) out.push(viewFromCardData(slots[col]?.data ?? null));
    return out;
  };

  const snapshotWaiting = () => {
    const mask = mask5FromCount(pickerCols);
    const activeCols = activeColsFromMask(mask);
    const cols = activeCols.length;

    const w1Slots: any[] = Array.isArray(unitRack?._slotW1) ? unitRack._slotW1 : [];
    const w2Slots: any[] = Array.isArray(unitRack?._slotW2) ? unitRack._slotW2 : [];
    const w3Slots: any[] = Array.isArray(unitRack?._slotW3) ? unitRack._slotW3 : [];

    const w1: ReplayCardView[] = new Array(5).fill(null).map((_, i) => viewFromCardData(w1Slots[i]?.data ?? null));
    const w2: ReplayCardView[] = new Array(5).fill(null).map((_, i) => viewFromCardData(w2Slots[i]?.data ?? null));
    const w3: ReplayCardView[] = new Array(5).fill(null).map((_, i) => viewFromCardData(w3Slots[i]?.data ?? null));

    const overflowByCol: any[] = Array.isArray(unitRack?._overflowByCol) ? unitRack._overflowByCol : Array.from({ length: 5 }, () => []);
    const headByCol: any[] = Array.isArray(unitRack?._overflowHeadByCol) ? unitRack._overflowHeadByCol : [0, 0, 0, 0, 0];

    const overflowCounts: number[] = [];
    const overflowHeads: ReplayCardView[] = [];
    for (let c = 0; c < 5; c++) {
      const q: any[] = Array.isArray(overflowByCol[c]) ? overflowByCol[c] : [];
      const head = Math.max(0, (headByCol[c] ?? 0) | 0);
      const rem = Math.max(0, (q.length | 0) - head);
      overflowCounts[c] = rem;
      overflowHeads[c] = rem > 0 ? viewFromCardData(q[head]) : null;
    }

    return { cols, activeMask: mask.slice(), waitLineCount, w1, w2, w3, overflowCounts, overflowHeads };
  };

  const progress = { nextHint: 1, clicked: 0, shotsFired: 0, rounds: 0 };
  const frames: ReplayFrame[] = [];

  const pushFrame = (event: ReplayFrame['event']) => {
    if (!captureFrames) return;
    progress.shotsFired = shotsFired | 0;
    frames.push({
      idx: frames.length,
      event,
      board: snapshotBoard(board),
      shooter: snapshotShooter(),
      waiting: snapshotWaiting(),
      progress: { ...progress },
    });
  };

  pushFrame({ type: 'INIT' });

  // -----------------------------
  // Gameplay helpers
  // -----------------------------
  const findFirstEmptyShooter = (): number => {
    const fn = unitRack?._findFirstEmptyShooting;
    if (typeof fn === 'function') {
      try {
        return (fn.call(unitRack) ?? -1) | 0;
      } catch {
        // fallthrough
      }
    }
    const places: any[] = Array.isArray(unitRack?._placesS) ? unitRack._placesS : [];
    const slots: any[] = Array.isArray(unitRack?._slotS) ? unitRack._slotS : [];
    for (let i = 0; i < 5; i++) {
      if (!places[i]?.activeInHierarchy) continue;
      if (!slots[i]?.data) return i;
    }
    return -1;
  };

  const findW1ByHint = (hintStep: number): number => {
  const w1Slots: any[] = Array.isArray(unitRack?._slotW1) ? unitRack._slotW1 : [];
  const h = hintStep | 0;
  const waitMask = mask5FromCount(pickerCols);
  const waitCols = activeColsFromMask(waitMask);
  for (const c of waitCols) {
    const d = w1Slots[c]?.data;
    if (!d) continue;
    const hs = ((d as any)?.hintStep ?? 0) | 0;
    if (hs === h) return c;
  }
  return -1;
};


  const findW1Leftmost = (): number => {
  const w1Slots: any[] = Array.isArray(unitRack?._slotW1) ? unitRack._slotW1 : [];
  const waitMask = mask5FromCount(pickerCols);
  const waitCols = activeColsFromMask(waitMask);
  for (const c of waitCols) if (w1Slots[c]?.data) return c;
  return -1;
};


  const canAnyShooterShoot = (): boolean => {
    const places: any[] = Array.isArray(unitRack?._placesS) ? unitRack._placesS : [];
    const slots: any[] = Array.isArray(unitRack?._slotS) ? unitRack._slotS : [];
    for (let i = 0; i < 5; i++) {
      if (!places[i]?.activeInHierarchy) continue;
      const d = slots[i]?.data;
      if (!d) continue;
      const ammo = ((d?.ammo ?? 0) | 0);
      if (ammo <= 0) continue;
      const colorId = (d?.colorId ?? -1) | 0;
      const wantShots = Math.max(1, ((d?.shotCount ?? 1) | 0));
      try {
        const ts = board.pickShootTargets(colorId, wantShots, 'LEFT', new Set(), true) ?? [];
        if (Array.isArray(ts) && ts.length > 0) return true;
      } catch {
        // ignore
      }
    }
    return false;
  };

  const canClickNow = (): boolean => {
    if (findFirstEmptyShooter() < 0) return false;
    const col = strictHintOrder ? findW1ByHint(progress.nextHint) : findW1Leftmost();
    return col >= 0;
  };

  const buildStuckSnapshotReal = (reason: string): SimReplayResult['stuck'] => {
    const deckIdx = Math.max(0, (progress.nextHint | 0) - 1);
    const need = computeShootableNeedCountsFromBoard(board);
    const row0 = computeNeedCountsFromBoard(board);

    const deckColorCounts = new Int32Array(12);
    for (let i = Math.max(0, deckIdx); i < deckCards.length; i++) {
      const cd: any = deckCards[i];
      const c = getCardColorIdAny(cd) | 0;
      if (c >= 0 && c < 12) deckColorCounts[c] += 1;
    }

    const slotColors: number[] = [];
    const slotAmmo: number[] = [];
    const slotDeckPos: number[] = [];
    const sSlots: any[] = Array.isArray(unitRack?._slotS) ? unitRack._slotS : [];

    // ✅ Shooting slots are also center-aligned by _mask5FromCount(slotCount).
    // Reading 0..slotCount-1 is wrong when slotCount<5.
    const shootMask = mask5FromCount(slotCount);
    const shootCols = activeColsFromMask(shootMask);

    for (const col of shootCols) {
      const d = sSlots[col]?.data;
      const c = d ? (getCardColorIdAny(d) | 0) : -1;
      const a = d ? ((d?.ammo ?? 0) | 0) : 0;
      let p = d && typeof d === 'object' ? ((((d as any).idx ?? posMap.get(d) ?? -1) as any) | 0) : -1;
      if (p < 0) {
        const hs = ((d as any)?.hintStep ?? 0) | 0;
        if (hs > 0) p = ((hs - 1) | 0);
      }
      slotColors.push(c);
      slotAmmo.push(a);
      slotDeckPos.push(p);
    }

    return {
      reason: String(reason ?? ''),
      deckIdx,
      needCounts: Array.from(need),
      row0Counts: Array.from(row0),
      deckColorCounts: Array.from(deckColorCounts),
      slotColors,
      slotAmmo,
      slotDeckPos,
    };
  };

  const flushBoard = async () => {
    // handleHitColumn/moveEnt 등이 Promise 체인으로 돌기 때문에 microtask를 몇 번 양보해줍니다.
    for (let i = 0; i < 2; i++) await Promise.resolve();
    let guard = 0;
    while (typeof board?.isBusy === 'function' && board.isBusy() && guard++ < 4000) {
      await Promise.resolve();
    }
    for (let i = 0; i < 2; i++) await Promise.resolve();
  };

  // -----------------------------
  // Main loop
  // -----------------------------
  let status: SimReplayResult['status'] = 'UNKNOWN';
  let reason: string | undefined = undefined;

  while (remaining() > 0 && progress.rounds < maxRounds && shotsFired < maxShots) {
    // (1) Click phase: 빈 슈터가 있는 동안 가능한 만큼 클릭(연타)
    let madeClick = false;
    while (findFirstEmptyShooter() >= 0) {
      const col = strictHintOrder ? findW1ByHint(progress.nextHint) : findW1Leftmost();
      if (col < 0) break;

      const shooterIdx = findFirstEmptyShooter();
      const w1Slots: any[] = Array.isArray(unitRack?._slotW1) ? unitRack._slotW1 : [];
      const d = w1Slots[col]?.data;
      if (!d) break;

      const hintStep = ((d as any)?.hintStep ?? 0) | 0;
      const token = toToken((d?.colorId ?? 0) | 0);
      const ammo = ((d?.ammo ?? 0) | 0);
      const shotCount = Math.max(1, ((d?.shotCount ?? 1) | 0));

      const eq = unitRack?._equipFromWaiting;
      const ok = typeof eq === 'function' ? !!eq.call(unitRack, 'W1', col | 0) : false;
      if (!ok) break;

      progress.clicked += 1;
      if (strictHintOrder) progress.nextHint += 1;
      else progress.nextHint = (progress.clicked + 1) | 0;
      madeClick = true;

      pushFrame({ type: 'CLICK', hintStep, col: col | 0, shooterIdx: shooterIdx | 0, token, ammo, shotCount });
    }

    if (remaining() <= 0) break;

    // (2) Shoot/update tick
    const prevShots = shotsFired | 0;
    const dt = 1 / 60;

    try {
      unitRack.update?.(dt);
    } catch (e) {
      status = 'UNKNOWN';
      reason = `UPDATE_EXCEPTION: ${String((e as any)?.message ?? e)}`;
      break;
    }

    progress.rounds += 1;
    await flushBoard();

    // fired in this tick
    const fired = Math.max(0, (shotsFired | 0) - prevShots);

    if (detail === 'round' || fired > 0 || (!madeClick && fired === 0)) {
      pushFrame({ type: 'ROUND', fired, round: progress.rounds });
    }

    if (remaining() <= 0) break;

    // (3) STUCK 조건(=게임 + 소프트락)
    const isBusy = typeof board?.isBusy === 'function' ? !!board.isBusy() : false;
    if (!isBusy) {
      let hardStuck = false;
      try {
        hardStuck = typeof unitRack?.isStuckNoShootTargets === 'function' ? !!unitRack.isStuckNoShootTargets(board) : false;
      } catch {
        hardStuck = false;
      }

      if (hardStuck) {
        status = 'STUCK';
        reason = 'FULL_AND_NO_TARGETS';
        const stuck = buildStuckSnapshotReal(reason);
        pushFrame({ type: 'STUCK', reason });
        return {
          status,
          reason,
          remaining: remaining() | 0,
          stuck,
          frames,
          clicked: progress.clicked,
          rounds: progress.rounds,
          shotsFired: shotsFired | 0,
          nextHint: progress.nextHint | 0,
        };
      }

      // soft lock: 앞으로도 클릭/발사가 모두 불가능한데 remaining>0
      if (!canAnyShooterShoot() && !canClickNow()) {
        status = 'STUCK';
        reason = strictHintOrder ? `NO_SHOOT_AND_NO_CLICK (nextHint=${progress.nextHint})` : 'NO_SHOOT_AND_NO_CLICK';
        const stuck = buildStuckSnapshotReal(reason);
        pushFrame({ type: 'STUCK', reason });
        return {
          status,
          reason,
          remaining: remaining() | 0,
          stuck,
          frames,
          clicked: progress.clicked,
          rounds: progress.rounds,
          shotsFired: shotsFired | 0,
          nextHint: progress.nextHint | 0,
        };
      }
    }
  }

  if (remaining() <= 0) {
    status = 'SOLVED';
    pushFrame({ type: 'END', status: 'SOLVED' });
    return {
      status,
      remaining: remaining() | 0,
      frames,
      clicked: progress.clicked,
      rounds: progress.rounds,
      shotsFired: shotsFired | 0,
      nextHint: progress.nextHint | 0,
    };
  }

  status = 'UNKNOWN';
  if (!reason) reason = progress.rounds >= maxRounds ? 'MAX_ROUNDS' : shotsFired >= maxShots ? 'MAX_SHOTS' : undefined;
  pushFrame({ type: 'END', status: 'UNKNOWN' });

  return {
    status,
    reason,
    remaining: remaining() | 0,
    frames,
    clicked: progress.clicked,
    rounds: progress.rounds,
    shotsFired: shotsFired | 0,
    nextHint: progress.nextHint | 0,
  };
}
