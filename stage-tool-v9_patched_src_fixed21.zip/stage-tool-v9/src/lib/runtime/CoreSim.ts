import type { StageRuntime, CardData, RuntimeLargeBlock, RuntimeSupplyLarge } from './Types';
import { SUPPLY_LARGE_BASE } from './Types';

// -----------------
// Engine-free core sim (subset of game rules)
// -----------------

type Special = any; // stage-tool doesn't need full typing here

type Ent = {
  id: number;
  row: number; // anchor (bottom-left)
  col: number; // anchor
  w: number;
  h: number;
  colorId: number;
  hp: number; // for LARGE only, 1 for small
  hidden: boolean;
  // stack depth support (1..n). When depth>1, a hit only decrements depth.
  depth: number;
  special: Special | null;
  worth: number; // how much remainingTiles decreases when destroyed (1 or hp for large)
};

export type SimPlan = {
  // equip order in terms of indices into the authored array
  equipCardIndices: number[];
};

export type VerifyResult = {
  ok: boolean;
  failEquipStep: number; // 1-based equip step where stuck occurred
  remainingTiles: number;
  snapshot?: any;
  // When failed by deadlock, the verifier may suggest a color that would be shootable on board.
  desiredColor?: number;
  // Extra debug/repair signals (used by prefix-repair planner)
  shootableColors?: number[]; // colors that have at least 1 target on board at fail time
  shooterColors?: number[];   // colors currently occupying shooters (duplicates possible)
  // 1-based equipStep indices where the given color was last seen
  lastEquipStepByColor?: number[];
  lastW1StepByColor?: number[];
  // A quick flag for the classic deadlock: shooters filled & no shooter color is shootable.
  deadly?: boolean;
  // Preventive deadlock flag: near/full shooters are dominated by an unshootable color (used to steer repair earlier).
  preDeadly?: boolean;
};

function tokenFrom(colorId: number, shotCount: 1 | 2, colorTokens: string[]): string {
  const t = colorTokens[colorId] ?? 'R';
  return `${t}${shotCount === 2 ? 2 : 1}`;
}

function isLargeToken(v: number): boolean {
  return v >= SUPPLY_LARGE_BASE;
}

function largeIndexOf(v: number): { idx: number; cell: number } {
  const d = v - SUPPLY_LARGE_BASE;
  const idx = Math.floor(d / 4);
  const cell = d % 4;
  return { idx, cell };
}

export class BoardCore {
  rows: number = 10;
  cols: number = 10;

  private occ: Int32Array;
  private ents = new Map<number, Ent>();
  private nextEntId = 1;

  private colSupply: number[][] = [];
  private supplyLargeDefs: RuntimeSupplyLarge[] = [];

  // used by failure rule checks
  // NOTE:
  // - The game-side "remaining" is a stage-wide hit budget (initial board + future supply/spawn).
  // - StageCompiler provides this as `totalBlocks`.
  // - Therefore we should start from `rt.totalBlocks` when available, and decrement by 1 per valid hit.
  remainingTiles = 0;

  constructor(rt: StageRuntime) {
    this.rows = rt.board.length;
    this.cols = rt.board[0]?.length ?? 10;
    this.occ = new Int32Array(this.rows * this.cols);
    this.occ.fill(-1);
    this.colSupply = (rt.columnSupply ?? []).map((a) => (Array.isArray(a) ? a.slice() : []));
    this.supplyLargeDefs = Array.isArray(rt.supplyLargeDefs) ? rt.supplyLargeDefs.slice() : [];

    // ✅ Match the game's "remaining" semantics.
    // GameFlow's `board.remaining()` starts from StageCompiler's `totalBlocks` (initial + future supply/spawn).
    // Our verifier should do the same; otherwise it will declare CLEAR too early and miss STUCK states.
    const tb = (rt as any).totalBlocks;
    const preCounted = typeof tb === 'number' && Number.isFinite(tb) && tb > 0;
    if (preCounted) {
      this.remainingTiles = tb | 0;
    } else {
      // Fallback: approximate total hit budget from initial board + column supply.
      // (Most packs should have `totalBlocks`.)
      let total = 0;
      for (let r = 0; r < this.rows; r++) {
        for (let c = 0; c < this.cols; c++) {
          const cid = rt.board?.[r]?.[c];
          if (typeof cid === 'number' && cid >= 0) total += 1;
        }
      }
      const lbs: RuntimeLargeBlock[] = Array.isArray(rt.largeBlocks) ? (rt.largeBlocks as any) : [];
      for (const lb of lbs) total += Math.max(1, lb.hp | 0);
      // Column supply tokens: small counts 1, large counts hp.
      for (let col = 0; col < (rt.columnSupply?.length ?? 0); col++) {
        const arr: any[] = (rt.columnSupply as any)?.[col] ?? [];
        for (let i = 0; i < arr.length; i++) {
          const v = arr[i];
          if (typeof v !== 'number') continue;
          if (v < 0) continue;
          if (isLargeToken(v)) {
            const li = largeIndexOf(v);
            const def = this.supplyLargeDefs?.[li.idx];
            total += Math.max(1, (def?.hp ?? 1) | 0);
          } else {
            total += 1;
          }
        }
      }
      this.remainingTiles = total;
    }

    // initial stacks
    const depthAt: number[][] = [];
    for (let r = 0; r < this.rows; r++) {
      depthAt[r] = [];
      for (let c = 0; c < this.cols; c++) depthAt[r][c] = 1;
    }
    const stacks = rt.boardStacks;
    if (Array.isArray(stacks)) {
      for (let r = 0; r < Math.min(this.rows, stacks.length); r++) {
        const row = stacks[r];
        if (!Array.isArray(row)) continue;
        for (let c = 0; c < Math.min(this.cols, row.length); c++) {
          const colStack = row[c];
          if (Array.isArray(colStack) && colStack.length > 0) depthAt[r][c] = Math.max(1, colStack.length);
        }
      }
    }

    // specials
    const spAt: (Special | null)[][] = [];
    if (Array.isArray(rt.special)) {
      for (let r = 0; r < this.rows; r++) {
        spAt[r] = [];
        for (let c = 0; c < this.cols; c++) spAt[r][c] = (rt.special?.[r]?.[c] ?? null) as any;
      }
    }

    // hidden mask
    const hiddenAt: boolean[][] = [];
    for (let r = 0; r < this.rows; r++) {
      hiddenAt[r] = [];
      for (let c = 0; c < this.cols; c++) hiddenAt[r][c] = !!rt.hiddenMask?.[r]?.[c];
    }

    // place initial smalls
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const colorId = rt.board?.[r]?.[c];
        if (typeof colorId !== 'number' || colorId < 0) continue;
        // will be overwritten by large if occupied
        const id = this.allocEnt({
          row: r,
          col: c,
          w: 1,
          h: 1,
          colorId,
          hp: 1,
          hidden: hiddenAt[r][c],
          depth: depthAt[r][c],
          special: spAt[r]?.[c] ?? null,
          worth: 1,
        });
        this.setOcc(id, r, c);
        // remainingTiles is stage-wide budget; do not increment per placed ent.
      }
    }

    // place initial large blocks
    const larges: RuntimeLargeBlock[] = Array.isArray(rt.largeBlocks) ? rt.largeBlocks : [];
    for (const lb of larges) {
      const id = this.allocEnt({
        row: lb.y,
        col: lb.x,
        w: 2,
        h: 2,
        colorId: lb.colorId,
        hp: Math.max(1, lb.hp | 0),
        hidden: !!lb.hidden,
        depth: 1,
        special: null,
        worth: Math.max(1, lb.hp | 0),
      });
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) this.setOcc(id, lb.y + dy, lb.x + dx);
      // remainingTiles is stage-wide budget; do not increment per placed ent.
    }
  }

  private indexOf(r: number, c: number): number {
    return r * this.cols + c;
  }

  private setOcc(id: number, r: number, c: number) {
    if (r < 0 || r >= this.rows || c < 0 || c >= this.cols) return;
    this.occ[this.indexOf(r, c)] = id;
  }

  private clearOcc(id: number) {
    for (let i = 0; i < this.occ.length; i++) if (this.occ[i] === id) this.occ[i] = -1;
  }

  private allocEnt(partial: Omit<Ent, 'id'>): number {
    const id = this.nextEntId++;
    this.ents.set(id, { id, ...partial });
    return id;
  }

  entAt(r: number, c: number): Ent | null {
    if (r < 0 || r >= this.rows || c < 0 || c >= this.cols) return null;
    const id = this.occ[this.indexOf(r, c)];
    if (id < 0) return null;
    return this.ents.get(id) ?? null;
  }

  entCols(e: Ent): number[] {
    const cols: number[] = [];
    for (let dx = 0; dx < e.w; dx++) cols.push(e.col + dx);
    return cols;
  }

  // shoot targets: mirror Board.pickShootTargets (no cc/world)
  pickShootTargets(colorId: number, maxShots: number, excludeEnt?: Set<number>, allowBig = true): Array<{ col: number; entId: number; isBig: boolean }> {
    const want = Math.max(1, maxShots | 0);
    const out: Array<{ col: number; entId: number; isBig: boolean }> = [];
    const used = new Set<number>();
    const ex = excludeEnt;

    const tryPush = (e: Ent, col: number, isBig: boolean) => {
      if (out.length >= want) return;
      if (e.row !== 0) return;
      if (e.hidden) return; // hidden can't be shot until revealed
      if (e.colorId !== (colorId | 0)) return;
      if (used.has(e.id)) return;
      if (ex?.has(e.id)) return;
      used.add(e.id);
      if (ex) ex.add(e.id);
      out.push({ col, entId: e.id, isBig });
    };

    if (allowBig) {
      for (let c = 0; c < this.cols && out.length < want; c++) {
        const e = this.entAt(0, c);
        if (!e) continue;
        if (!(e.w > 1 || e.h > 1)) continue;
        tryPush(e, e.col, true);
      }
    }

    for (let c = 0; c < this.cols && out.length < want; c++) {
      const e = this.entAt(0, c);
      if (!e) continue;
      if (e.w > 1 || e.h > 1) continue;
      tryPush(e, c, false);
    }

    return out;
  }

  // apply a single hit to a column at row0 (mirrors handleHitColumn core effects)
  hitColumn(col: number): void {
    const e0 = this.entAt(0, col);
    if (!e0) return;
    const affectedCols = this.entCols(e0);

    // LOCK support (only if special is LOCK and not unlocked; simulator treats all locks as locked)
    if (e0.special?.t === 'LOCK') return;

    // valid hit consumes 1 remaining tile
    this.remainingTiles = Math.max(0, this.remainingTiles - 1);

    // LARGE HP
    if (e0.w > 1 || e0.h > 1) {
      e0.hp = Math.max(0, e0.hp - 1);
      if (e0.hp > 0) return;
      // destroy
      this.removeEnt(e0);
      this.settleGravity();
      this.fillTopHoles(affectedCols);
      this.revealHiddenAtBottom(affectedCols);
      return;
    }

    // CHAIN
    if (e0.special?.t === 'CHAIN') {
      const nextHp = Math.max(0, (e0.special.hp | 0) - 1);
      if (nextHp > 0) {
        e0.special = { t: 'CHAIN', hp: nextHp };
        return;
      }
      e0.special = null;
    }

    // stack depth
    if ((e0.depth | 0) > 1) {
      e0.depth = Math.max(1, (e0.depth | 0) - 1);
      return;
    }

    // KEY / SPAWNER not simulated fully (rare in tool packs). Treat as normal destroy.

    this.removeEnt(e0);
    this.settleGravity();
    this.fillTopHoles(affectedCols);
    this.revealHiddenAtBottom(affectedCols);
  }

  private removeEnt(e: Ent) {
    this.clearOcc(e.id);
    this.ents.delete(e.id);
  }

  private settleGravity(): void {
    // per column, compact occupied cells downward (toward row 0)
    for (let c = 0; c < this.cols; c++) {
      const entsInCol: Ent[] = [];
      // collect unique ents that occupy this column
      const seen = new Set<number>();
      for (let r = 0; r < this.rows; r++) {
        const e = this.entAt(r, c);
        if (!e) continue;
        if (seen.has(e.id)) continue;
        // only move if this column is within its footprint
        if (c < e.col || c >= e.col + e.w) continue;
        seen.add(e.id);
        entsInCol.push(e);
      }
      // sort by row
      entsInCol.sort((a, b) => a.row - b.row);

      // clear occ for these ents; will re-set
      for (const e of entsInCol) this.clearOcc(e.id);

      let writeRow = 0;
      // place from bottom to top
      for (const e of entsInCol) {
        // only move entities whose anchor is in this column? For simplicity, adjust by delta for all columns
        const delta = e.row - writeRow;
        if (delta !== 0) {
          e.row = writeRow;
        }
        // write occupancy for entity footprint
        for (let dy = 0; dy < e.h; dy++) for (let dx = 0; dx < e.w; dx++) this.setOcc(e.id, e.row + dy, e.col + dx);
        writeRow += e.h;
      }
    }
  }

  private fillTopHoles(affectedCols: number[]): void {
    // Spawn tokens from columnSupply into empty cells above current highest occupied.
    for (const c of affectedCols) {
      for (let r = this.rows - 1; r >= 0; r--) {
        if (this.entAt(r, c)) break;
        const tok = this.colSupply[c]?.pop();
        if (tok == null) break;
        if (isLargeToken(tok)) {
          const { idx, cell } = largeIndexOf(tok);
          // only spawn on anchor cell(0). Others will be consumed by subsequent holes.
          if (cell !== 0) continue;
          const def = this.supplyLargeDefs[idx];
          if (!def) continue;
          const id = this.allocEnt({
            row: r,
            col: c,
            w: 2,
            h: 2,
            colorId: def.colorId,
            hp: Math.max(1, def.hp | 0),
            hidden: !!def.hidden,
            depth: 1,
            special: null,
            worth: Math.max(1, def.hp | 0),
          });
          for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) this.setOcc(id, r + dy, c + dx);
          // note: remainingTiles already pre-counted by compiler using hp worth; keep unchanged here
        } else {
          const hidden = tok < 0;
          const colorId = hidden ? (-tok - 1) : tok;
          const id = this.allocEnt({
            row: r,
            col: c,
            w: 1,
            h: 1,
            colorId,
            hp: 1,
            hidden,
            depth: 1,
            special: null,
            worth: 1,
          });
          this.setOcc(id, r, c);
        }
      }
    }
  }

  private revealHiddenAtBottom(cols: number[]) {
    for (const c of cols) {
      const e = this.entAt(0, c);
      if (e && e.hidden) e.hidden = false;
    }
  }

  // Used by planner
  hasAnyShootTarget(colorId: number, shotCount: 1 | 2, excludeEnt?: Set<number>, allowBig = true): boolean {
    return this.pickShootTargets(colorId, shotCount, excludeEnt, allowBig).length > 0;
  }

  isCleared(): boolean {
    return this.remainingTiles <= 0;
  }
}

function snapshot(board: BoardCore, slots: Array<{ c: CardData; ammo: number }>, colorTokens: string[]): any {
  const snap: any = {
    remainingTiles: board.remainingTiles,
    slots: slots.map((s, i) => {
      const colorId = (s.c.colorId | 0);
      const shotCount = ((s.c.shotCount ?? 1) === 2 ? 2 : 1) as 1 | 2;
      return {
        idx: i,
        token: tokenFrom(colorId, shotCount as any, colorTokens),
        colorId,
        shotCount,
        ammo: s.ammo | 0,
        targets: board.pickShootTargets(colorId, shotCount, undefined, true),
      };
    }),
    row0: [] as any[],
  };
  for (let c = 0; c < board.cols; c++) {
    const e = board.entAt(0, c);
    if (!e) {
      snap.row0.push(null);
      continue;
    }
    snap.row0.push({
      c,
      token: colorTokens[e.colorId] ?? '?',
      colorId: e.colorId,
      isBig: e.w > 1 || e.h > 1,
      hp: e.hp,
      hidden: e.hidden,
      depth: e.depth,
      special: e.special?.t ?? null,
    });
  }
  return snap;
}

/**
 * ✅ Export 전에 "정말로" 순번대로 장착하면 막힘 없이 클리어 되는지 검증
 * - 실패 조건: 슬롯이 가득 찼고, 장착된 유닛 전체가 쏠 타겟이 0이면 FAIL
 * - 성공 조건: remainingTiles==0
 */
export function verifyGuaranteedEquipPlan(rt: StageRuntime, plan: SimPlan, colorTokens: string[]): VerifyResult {
  // ✅ Match the runtime model used in the game (StageCompiler sim):
  // - shooters(slot) can only be equipped from W1 (wait[0])
  // - swap is NOT allowed (no replacing a non-empty shooter)
  // - when shooter becomes empty(ammo==0), the conveyor advances
  const board = new BoardCore(rt);
  const cards: CardData[] = Array.isArray((rt as any).cards) ? ((rt as any).cards as any[]) : [];
  const slotCount = Math.max(1, Math.min(5, (rt as any).slotCount ?? 3));
  const waitLineCount = Math.max(1, Math.min(3, (rt as any).waitLineCount ?? 1));

  // indices into cards[], -1 means empty
  const shooters: number[] = Array(slotCount).fill(-1);
  const wait: number[] = Array(waitLineCount).fill(-1);
  const remAmmo: number[] = cards.map((c) => Math.max(0, (c?.ammo ?? 0) | 0));

  // Track when each color last appeared at W1 / was equipped into a shooter.
  const colorCount = Math.max(1, colorTokens.length | 0);
  const lastEquipStepByColor: number[] = Array(colorCount).fill(-1);
  const lastW1StepByColor: number[] = Array(colorCount).fill(-1);

  let deckPos = 0;
  let equipStep = 0; // how many times we've pulled from plan into wait

  const replenishWait = () => {
    // shift forward
    for (let i = 0; i < wait.length; i++) {
      if ((wait[i] | 0) >= 0) continue;
      // pull from later wait slot if any
      for (let j = i + 1; j < wait.length; j++) {
        if ((wait[j] | 0) >= 0) {
          wait[i] = wait[j];
          wait[j] = -1;
          break;
        }
      }
    }
    // fill empties from deck
    for (let i = 0; i < wait.length; i++) {
      if ((wait[i] | 0) >= 0) continue;
      if (deckPos >= plan.equipCardIndices.length) break;
      wait[i] = plan.equipCardIndices[deckPos++] | 0;
      equipStep++;
    }

    // Record which color is currently sitting at W1 after shifts/fills.
    const w1 = wait.length > 0 ? (wait[0] | 0) : -1;
    if (w1 >= 0) {
      const cid = (cards[w1]?.colorId ?? -1) | 0;
      if (cid >= 0 && cid < lastW1StepByColor.length) lastW1StepByColor[cid] = Math.max(lastW1StepByColor[cid] | 0, equipStep | 0);
    }
  };

  const equipIntoEmptyShooter = (): boolean => {
    let empty = -1;
    for (let i = 0; i < shooters.length; i++) {
      if ((shooters[i] | 0) < 0) {
        empty = i;
        break;
      }
    }
    if (empty < 0) return false;

    replenishWait();
    const w1 = wait.length > 0 ? (wait[0] | 0) : -1;
    if (w1 < 0) return false;

    shooters[empty] = w1;
    {
      const cid = (cards[w1]?.colorId ?? -1) | 0;
      if (cid >= 0 && cid < lastEquipStepByColor.length) lastEquipStepByColor[cid] = Math.max(lastEquipStepByColor[cid] | 0, equipStep | 0);
    }
    wait[0] = -1;
    replenishWait();
    return true;
  };

  const isCleared = () => board.remainingTiles <= 0;

  const computeShootable = (): boolean[] => {
    const shootable = Array(colorCount).fill(false) as boolean[];
    for (let cid = 0; cid < colorCount; cid++) {
      const ts = board.pickShootTargets(cid, 1, undefined, true);
      shootable[cid] = Array.isArray(ts) && ts.length > 0;
    }
    return shootable;
  };

  const shootableColorList = (shootable: boolean[]): number[] => {
    const out: number[] = [];
    for (let cid = 0; cid < shootable.length; cid++) if (shootable[cid]) out.push(cid);
    return out;
  };

  const shooterColorList = (): number[] => {
    const out: number[] = [];
    for (let i = 0; i < shooters.length; i++) {
      const idx = shooters[i] | 0;
      if (idx < 0) continue;
      const cid = (cards[idx]?.colorId ?? -1) | 0;
      out.push(cid);
    }
    return out;
  };

  const pickShooterToFire = (shootable: boolean[]): number => {
    for (let i = 0; i < shooters.length; i++) {
      const idx = shooters[i] | 0;
      if (idx < 0) continue;
      if ((remAmmo[idx] | 0) <= 0) continue;
      const cid = (cards[idx]?.colorId ?? -1) | 0;
      if (cid >= 0 && cid < shootable.length && shootable[cid]) return i;
    }
    return -1;
  };

  const pickDesiredShootableColor = (shootable: boolean[]): number => {
    for (let cid = 0; cid < shootable.length; cid++) {
      if (!shootable[cid]) continue;
      // prefer a shootable color that is NOT currently in shooters
      let inShooter = false;
      for (let i = 0; i < shooters.length; i++) {
        const idx = shooters[i] | 0;
        if (idx < 0) continue;
        if (((cards[idx]?.colorId ?? -1) | 0) === cid) {
          inShooter = true;
          break;
        }
      }
      if (!inShooter) return cid;
    }
    // fallback: any shootable
    for (let cid = 0; cid < shootable.length; cid++) if (shootable[cid]) return cid;
    return -1;
  };

  const buildSnapshot = (): any => {
    // Match the game's STUCK snapshot shape as much as possible.
    const slotsSnap: any[] = [];
    for (let i = 0; i < shooters.length; i++) {
      const ci = shooters[i] | 0;
      if (ci < 0) continue;
      const c = cards[ci];
      const shots = ((c?.shotCount ?? 1) | 0) === 2 ? 2 : 1;
      const cid = (c?.colorId ?? -1) | 0;
      const ts = board.pickShootTargets(cid, shots, undefined, true) ?? [];
      slotsSnap.push({
        idx: i + 1,
        colorId: cid,
        token: colorTokens[cid] ?? '?',
        shots,
        ammo: remAmmo[ci] | 0,
        hintStep: (c as any)?.hintStep ?? 0,
        targetsLen: Array.isArray(ts) ? ts.length : 0,
        targetCols: Array.isArray(ts) ? ts.map((t: any) => t?.col).filter((v: any) => v != null) : [],
      });
    }

    const snap: any = {
      capacity: slotCount,
      filled: slotsSnap.length,
      slots: slotsSnap,
      row0: [] as any[],
    };
    for (let c = 0; c < board.cols; c++) {
      const e = board.entAt(0, c);
      if (!e) {
        snap.row0.push(null);
        continue;
      }
      snap.row0.push({
        c,
        token: colorTokens[e.colorId] ?? '?',
        colorId: e.colorId,
        isBig: e.w > 1 || e.h > 1,
        hp: e.hp,
        hidden: e.hidden,
      });
    }
    return snap;
  };

  // init: fill wait and equip into empty shooters as much as possible
  replenishWait();
  while (equipIntoEmptyShooter()) {
    /* keep equipping */
  }

  let guard = 0;
  const MAX_SHOTS = 300000;
  while (guard++ < MAX_SHOTS) {
    if (isCleared()) return { ok: true, failEquipStep: 0, remainingTiles: 0 };

    const shootable = computeShootable();

    // fill shooters if empty
    while (equipIntoEmptyShooter()) {
      /* keep equipping */
    }


    // --- Preventive guard: avoid forming/maintaining a monopoly of an unshootable color (e.g., RRR while row0 has no R).
    // If shooters are almost/full and dominated by a color that is not currently shootable, fail early with preDeadly=true.
    {
      const shooterIdxs: number[] = [];
      for (let i = 0; i < shooters.length; i++) {
        const ci = shooters[i] | 0;
        if (ci >= 0) shooterIdxs.push(ci);
      }
      const filledN = shooterIdxs.length;
      if (filledN >= Math.max(1, slotCount - 1)) {
        const counts = new Map<number, number>();
        for (const ci of shooterIdxs) {
          const cid = (cards[ci]?.colorId ?? -1) | 0;
          if (cid >= 0) counts.set(cid, (counts.get(cid) ?? 0) + 1);
        }
        let dom = -1, domCnt = 0;
        for (const [k, v] of counts) { if (v > domCnt) { dom = k; domCnt = v; } }

        // dominated if >= capacity-1 (e.g., 2-of-3 or 3-of-3)
        if (dom >= 0 && domCnt >= Math.max(2, slotCount - 1)) {
          const domShootable = (dom < shootable.length) ? !!shootable[dom] : false;
          if (!domShootable) {
            const desired = pickDesiredShootableColor(shootable);
            const shootableColors = shootableColorList(shootable);
            const shooterColors = shooterColorList();
            // compute classic deadly too (if already full & no intersection)
            const filled = shooterColors.length >= slotCount;
            let hasIntersection = false;
            if (filled && shootableColors.length > 0) {
              const set = new Set<number>(shootableColors);
              for (const c of shooterColors) { if (set.has(c)) { hasIntersection = true; break; } }
            }
            return {
              ok: false,
              failEquipStep: Math.max(1, equipStep),
              remainingTiles: board.remainingTiles,
              snapshot: buildSnapshot(),
              desiredColor: desired,
              shootableColors,
              shooterColors,
              lastEquipStepByColor: lastEquipStepByColor.slice(),
              lastW1StepByColor: lastW1StepByColor.slice(),
              deadly: filled && !hasIntersection,
              preDeadly: true,
            } as any;
          }
        }
      }
    }

    const sIdx = pickShooterToFire(shootable);
    if (sIdx < 0) {
      const desired = pickDesiredShootableColor(shootable);
      const shootableColors: number[] = [];
      for (let cid = 0; cid < shootable.length; cid++) if (shootable[cid]) shootableColors.push(cid);
      const shooterColors: number[] = [];
      for (let i = 0; i < shooters.length; i++) {
        const idx = shooters[i] | 0;
        if (idx < 0) continue;
        const cid = (cards[idx]?.colorId ?? -1) | 0;
        if (cid >= 0) shooterColors.push(cid);
      }
      const filled = shooterColors.length >= slotCount;
      let hasIntersection = false;
      if (filled && shootableColors.length > 0) {
        const set = new Set<number>(shootableColors);
        for (const c of shooterColors) {
          if (set.has(c)) { hasIntersection = true; break; }
        }
      }
      return {
        ok: false,
        failEquipStep: Math.max(1, equipStep),
        remainingTiles: board.remainingTiles,
        snapshot: buildSnapshot(),
        desiredColor: desired,
        shootableColors,
        shooterColors,
        lastEquipStepByColor: lastEquipStepByColor.slice(),
        lastW1StepByColor: lastW1StepByColor.slice(),
        deadly: filled && !hasIntersection,
        preDeadly: false,
      };
    }

    const cardIdx = shooters[sIdx] | 0;
    if (cardIdx < 0 || (remAmmo[cardIdx] | 0) <= 0) {
      shooters[sIdx] = -1;
      replenishWait();
      continue;
    }

    const useColor = (cards[cardIdx]?.colorId ?? -1) | 0;
    const ts = board.pickShootTargets(useColor, 1, undefined, true);
    const col = Array.isArray(ts) && ts.length > 0 ? ((ts[0] as any).col | 0) : -1;
    if (col < 0) {
      // no shootable column even though shootable said true -> treat as deadlock
      const desired = pickDesiredShootableColor(computeShootable());
      const shootable = computeShootable();
      const shootableColors: number[] = [];
      for (let cid = 0; cid < shootable.length; cid++) if (shootable[cid]) shootableColors.push(cid);
      const shooterColors: number[] = [];
      for (let i = 0; i < shooters.length; i++) {
        const idx = shooters[i] | 0;
        if (idx < 0) continue;
        const cid = (cards[idx]?.colorId ?? -1) | 0;
        if (cid >= 0) shooterColors.push(cid);
      }
      return {
        ok: false,
        failEquipStep: Math.max(1, equipStep),
        remainingTiles: board.remainingTiles,
        snapshot: buildSnapshot(),
        desiredColor: desired,
        shootableColors,
        shooterColors,
        lastEquipStepByColor: lastEquipStepByColor.slice(),
        lastW1StepByColor: lastW1StepByColor.slice(),
        deadly: shooterColors.length >= slotCount,
      };
    }

    board.hitColumn(col);
    remAmmo[cardIdx] = Math.max(0, (remAmmo[cardIdx] | 0) - 1);

    if ((remAmmo[cardIdx] | 0) <= 0) {
      shooters[sIdx] = -1;
      replenishWait();
    }
  }

  return {
    ok: false,
    failEquipStep: Math.max(1, equipStep),
    remainingTiles: board.remainingTiles,
    snapshot: buildSnapshot(),
    desiredColor: -1,
    lastEquipStepByColor: lastEquipStepByColor.slice(),
    lastW1StepByColor: lastW1StepByColor.slice(),
  };
}

type SimUnit = {
  cardIdx: number;
  colorId: number;
  shotCount: 1 | 2;
  ammo: number;
};

function makeRng(seed: number): () => number {
  // mulberry32
  let a = (seed | 0) >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffleInPlace<T>(arr: T[], rnd: () => number) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
}

export function planEquipOrderByFullSim(rt: StageRuntime, colorTokens: string[], rnd?: () => number): SimPlan {
  const board = new BoardCore(rt);

  // remaining pool of card indices
  const pool: number[] = [];
  for (let i = 0; i < rt.cards.length; i++) pool.push(i);
  // Randomize tie-breaking between cards with the same color/ammo to avoid
  // pathological greedy sequences on some authored stages.
  if (rnd) shuffleInPlace(pool, rnd);

  const slots: Array<SimUnit | null> = new Array(rt.slotCount).fill(null);
  const equipSeq: number[] = [];

  // per-color big assignment: unitSlot -> entId
  const bigAssign = new Map<number, Map<number, number>>(); // colorId -> (slot -> entId)

  const remainingByColor = (): Map<number, number> => {
    const m = new Map<number, number>();
    // BoardCore keeps live ents; scan is cheap enough for tool-side planning.
    const ents: Map<number, Ent> = (board as any).ents ?? new Map();
    for (const e of ents.values()) {
      if (!e) continue;
      const worth = Math.max(1, (e.worth ?? e.hp ?? 1) | 0);
      m.set(e.colorId | 0, (m.get(e.colorId | 0) ?? 0) + worth);
    }
    return m;
  };

  const slotColorCount = (): Map<number, number> => {
    const m = new Map<number, number>();
    for (const u of slots) {
      if (!u) continue;
      const cid = u.colorId | 0;
      m.set(cid, (m.get(cid) ?? 0) + 1);
    }
    return m;
  };

  const takeCard = (wantColorIds: number[]): number | null => {
    if (pool.length === 0) return null;
    const rem = remainingByColor();
    const sc = slotColorCount();

    // 1) Prefer currently shootable colors, but avoid duplicates when possible.
    const wants = (wantColorIds ?? []).slice();
    wants.sort((a, b) => {
      // fewer in slots first, then more remaining tiles
      const da = (sc.get(a) ?? 0) - (sc.get(b) ?? 0);
      if (da !== 0) return da;
      return (rem.get(b) ?? 0) - (rem.get(a) ?? 0);
    });

    for (const cid of wants) {
      const idx = pool.findIndex((pi) => (rt.cards[pi].colorId | 0) === (cid | 0));
      if (idx >= 0) return pool.splice(idx, 1)[0];
    }

    // 2) Fallback: pick a color that is underrepresented in slots but still has remaining tiles.
    const allColors = Array.from(rem.keys());
    allColors.sort((a, b) => {
      const da = (sc.get(a) ?? 0) - (sc.get(b) ?? 0);
      if (da !== 0) return da;
      return (rem.get(b) ?? 0) - (rem.get(a) ?? 0);
    });
    for (const cid of allColors) {
      const idx = pool.findIndex((pi) => (rt.cards[pi].colorId | 0) === (cid | 0));
      if (idx >= 0) return pool.splice(idx, 1)[0];
    }

    // 3) Last resort: preserve original order.
    return pool.shift()!;
  };

  const currentShootableColors = (): number[] => {
    const colors: number[] = [];
    for (let c = 0; c < board.cols; c++) {
      const e = (board as any).entAt(0, c) as Ent | null;
      if (!e || e.hidden) continue;
      if (!colors.includes(e.colorId)) colors.push(e.colorId);
    }
    return colors;
  };

  // main loop safety limit
  let guard = 0;
  while (!board.isCleared() && guard++ < 200000) {
    // fill empty slots immediately
    for (let s = 0; s < slots.length; s++) {
      if (slots[s]) continue;
      const wants = currentShootableColors();
      const cardIdx = takeCard(wants);
      if (cardIdx == null) break;
      const cd = rt.cards[cardIdx];
      const sc: 1 | 2 = (cd.shotCount === 2 ? 2 : 1);
      slots[s] = { cardIdx, colorId: cd.colorId, shotCount: sc, ammo: cd.ammo };
      equipSeq.push(cardIdx);
    }

    // failure check: slots full and nobody can shoot
    const full = slots.every((u) => !!u);
    if (full) {
      let any = false;
      for (const u of slots) {
        if (!u) continue;
        if (board.hasAnyShootTarget(u.colorId, u.shotCount, undefined, true)) {
          any = true;
          break;
        }
      }
      if (!any) {
        // Cannot guarantee with this greedy plan; in this minimal implementation
        // we still return the best-effort sequence. Tool can warn.
        break;
      }
    }

    // one tick: each unit fires up to shotCount if targets exist
    const excludeEnt = new Set<number>();

    // build big budget per color and assign first N units to distinct big ents (sticky-ish)
    const unitsByColor = new Map<number, number[]>();
    for (let s = 0; s < slots.length; s++) {
      const u = slots[s];
      if (!u) continue;
      const arr = unitsByColor.get(u.colorId) ?? [];
      arr.push(s);
      unitsByColor.set(u.colorId, arr);
    }

    for (const [colorId, slotIds] of unitsByColor) {
      // cleanup dead assignments
      const assign = bigAssign.get(colorId) ?? new Map<number, number>();
      // detect current big ents on row0
      const bigEnts: number[] = [];
      for (let c = 0; c < board.cols; c++) {
        const e = (board as any).entAt(0, c) as Ent | null;
        if (!e || e.hidden) continue;
        if (e.colorId !== colorId) continue;
        if (e.w > 1 || e.h > 1) {
          if (!bigEnts.includes(e.id)) bigEnts.push(e.id);
        }
      }
      for (const [sid, eid] of assign) {
        if (!bigEnts.includes(eid)) assign.delete(sid);
      }
      // fill new assignments
      for (const sid of slotIds) {
        if (assign.has(sid)) continue;
        const free = bigEnts.find((eid) => !Array.from(assign.values()).includes(eid));
        if (free == null) continue;
        assign.set(sid, free);
      }
      bigAssign.set(colorId, assign);
    }

    for (let s = 0; s < slots.length; s++) {
      const u = slots[s];
      if (!u) continue;

      let fired = 0;
      // if assigned big exists and still present, force it as first shot
      const assign = bigAssign.get(u.colorId);
      const forcedBigEnt = assign?.get(s);
      if (forcedBigEnt) {
        // find its anchor col
        let col = -1;
        for (let c = 0; c < board.cols; c++) {
          const e = (board as any).entAt(0, c) as Ent | null;
          if (e && e.id === forcedBigEnt) {
            col = e.col;
            break;
          }
        }
        if (col >= 0) {
          board.hitColumn(col);
          fired++;
          excludeEnt.add(forcedBigEnt);
        }
      }

      const remainingShots = Math.max(0, u.shotCount - fired);
      if (remainingShots > 0) {
        const targets = board.pickShootTargets(u.colorId, remainingShots, excludeEnt, /*allowBig*/ !forcedBigEnt);
        for (const t of targets) {
          board.hitColumn(t.col);
          fired++;
        }
      }

      if (fired > 0) u.ammo -= fired;
      if (u.ammo <= 0) slots[s] = null;
    }
  }

  // Append remaining pool as tail to provide full 1..N steps
  for (const idx of pool) equipSeq.push(idx);

  return { equipCardIndices: equipSeq };
}

// Public API used by stage-tool export pipeline.
// NOTE: This is the function name imported by src/lib/codec.ts
export function simulateGuaranteedEquipPlan(rt: StageRuntime, colorTokens?: readonly string[]): SimPlan {
  // Default to built-in token order if caller doesn't provide.
  const tokens = (colorTokens ? Array.from(colorTokens) : undefined) as string[] | undefined;
  return planEquipOrderByFullSim(rt, tokens ?? (['R','Y','B','G','O','P','C','M','L','W','K','S'] as string[]));
}

/**
 * ✅ Robust planner used by stage-tool export.
 * Tries multiple randomized greedy runs and returns the first plan that passes verify.
 * If all attempts fail, returns the last attempt's verification result (with snapshot).
 */
export function simulateGuaranteedEquipPlanGuaranteed(
  rt: StageRuntime,
  colorTokens: readonly string[],
  opts?: { maxAttempts?: number }
): { plan: SimPlan; verify: VerifyResult; stats: GuaranteeStats } {
  const tokens = Array.from(colorTokens ?? (['R','Y','B','G','O','P','C','M','L','W','K','S'] as any));
  // Stage-tool export wants a *real* guarantee when possible.
  // We allow a much higher attempt count than the old 200-cap because some authored packs
  // require escaping early deadlocks (e.g. slot full + no-target) by reshuffling and biasing.
  const maxAttempts = Math.max(1, Math.min(5000, (opts?.maxAttempts ?? 400) | 0));
  const baseSeed = ((rt as any).seed ?? (rt as any).meta?.seed ?? 0) | 0;

  const cards: CardData[] = Array.isArray((rt as any).cards) ? ((rt as any).cards as any[]) : [];

  const promoteDesiredColorInSeq = (seq: number[], desiredColor: number, deckPosHint: number) => {
    if (desiredColor < 0) return false;
    // Move the next occurrence of desiredColor close to the front of the draw stream.
    const start = Math.max(0, Math.min(seq.length - 1, deckPosHint | 0));
    let found = -1;
    for (let i = start; i < seq.length; i++) {
      const ci = seq[i] | 0;
      if (((cards[ci]?.colorId ?? -1) | 0) === (desiredColor | 0)) {
        found = i;
        break;
      }
    }
    if (found < 0) {
      for (let i = 0; i < start; i++) {
        const ci = seq[i] | 0;
        if (((cards[ci]?.colorId ?? -1) | 0) === (desiredColor | 0)) {
          found = i;
          break;
        }
      }
    }
    if (found < 0) return false;
    // Pull toward a hint position (usually near the fail step), but keep it early enough to affect loading.
    const target = Math.max(0, Math.min(seq.length - 1, Math.min(30, start)));
    const [v] = seq.splice(found, 1);
    seq.splice(target, 0, v);
    return true;
  };

  const ensureEarlyCoverageFromSnapshot = (seq: number[], snap: any, earlyWindow: number) => {
    if (!snap || !Array.isArray(snap.row0)) return;
    const want = new Set<number>();
    for (const cell of snap.row0) {
      if (!cell) continue;
      const cid = (cell.colorId ?? -1) | 0;
      const hidden = !!cell.hidden;
      if (cid >= 0 && !hidden) want.add(cid);
    }
    if (want.size === 0) return;

    const hasInEarly = (colorId: number) => {
      const lim = Math.max(0, Math.min(seq.length, earlyWindow | 0));
      for (let i = 0; i < lim; i++) {
        const ci = seq[i] | 0;
        if (((cards[ci]?.colorId ?? -1) | 0) === (colorId | 0)) return true;
      }
      return false;
    };

    // Ensure at least one of each bottom-row color appears early.
    // We do not force *all* colors if it becomes impossible; we try best-effort.
    let insertAt = 0;
    for (const colorId of want) {
      if (hasInEarly(colorId)) continue;
      // Find any occurrence and pull it into the early region.
      let found = -1;
      for (let i = earlyWindow; i < seq.length; i++) {
        const ci = seq[i] | 0;
        if (((cards[ci]?.colorId ?? -1) | 0) === (colorId | 0)) {
          found = i;
          break;
        }
      }
      if (found < 0) continue;
      const [v] = seq.splice(found, 1);
      seq.splice(Math.min(insertAt, seq.length), 0, v);
      insertAt++;
    }
  };

  let last: { plan: SimPlan; verify: VerifyResult; stats: GuaranteeStats } | null = null;
  for (let a = 0; a < maxAttempts; a++) {
    const rnd = makeRng((baseSeed + a * 1000003) | 0);
    const basePlan = planEquipOrderByFullSim(rt, tokens, rnd);
    // copy and locally mutate the equip sequence if verifier suggests a color
    const seq = Array.from(basePlan.equipCardIndices);
    let plan: SimPlan = { equipCardIndices: seq };

    // inner refinement loop: bias sequence toward colors that would be shootable at the fail point.
    let vr = verifyGuaranteedEquipPlan(rt, plan, tokens);
    const earlyWindow = Math.max(6, Math.min(18, (rt.slotCount + ((rt as any).waitLineCount ?? 3)) * 2));
    for (let k = 0; k < 120 && !vr.ok; k++) {
      const desired = (vr as any).desiredColor ?? -1;
      const failStep = ((vr as any).failEquipStep ?? 0) | 0;
      // 1) Make sure early cards include at least one visible bottom-row color.
      ensureEarlyCoverageFromSnapshot(seq, (vr as any).snapshot, earlyWindow);
      // 2) Promote the desired color closer to where it can affect loading.
      const progressed = promoteDesiredColorInSeq(seq, desired, Math.max(0, failStep - earlyWindow));
      if (!progressed && k > 0) break;
      plan = { equipCardIndices: seq };
      vr = verifyGuaranteedEquipPlan(rt, plan, tokens);
    }

    last = { plan, verify: vr, stats: { deadlyRejected: 0, deadlyTotal: 0, pushOutCandidates: 0, pushOutImproved: 0 } };
    if (vr.ok) return last;
  }
  // should never be null because maxAttempts>=1
  const fallbackPlan = planEquipOrderByFullSim(rt, tokens);
  return last ?? { plan: fallbackPlan, verify: verifyGuaranteedEquipPlan(rt, fallbackPlan, tokens), stats: { deadlyRejected: 0, deadlyTotal: 0, pushOutCandidates: 0, pushOutImproved: 0 } };
}

export type GuaranteeProgress = {
  attempt: number;
  maxAttempts: number;
  phase: 'attempt' | 'refine' | 'done';
  refineIter?: number;
  failEquipStep?: number;
  remainingTiles?: number;
  // Progress diagnostics (cumulative)
  deadlyRejected?: number;
  deadlyTotal?: number;
  pushOutCandidates?: number;
  pushOutImproved?: number;
};

export type GuaranteeStats = {
  deadlyRejected: number;
  deadlyTotal: number;
  pushOutCandidates: number;
  pushOutImproved: number;
};

// ✅ Async 버전: Export 시 "재시도 진행률"을 UI에 보여주기 위해 주기적으로 yield 합니다.
export async function simulateGuaranteedEquipPlanGuaranteedAsync(
  rt: StageRuntime,
  colorTokens: readonly string[],
  opts?: { maxAttempts?: number; onProgress?: (p: GuaranteeProgress) => void; yieldEveryAttempts?: number }
): Promise<{ plan: SimPlan; verify: VerifyResult; stats: GuaranteeStats }> {
  const tokens = Array.from(colorTokens ?? (['R','Y','B','G','O','P','C','M','L','W','K','S'] as any));
  const maxIters = Math.max(1, Math.min(5000, (opts?.maxAttempts ?? 1200) | 0));
  const yieldEvery = Math.max(1, Math.min(200, (opts?.yieldEveryAttempts ?? 10) | 0));
  const baseSeed = ((rt as any).seed ?? (rt as any).meta?.seed ?? 0) | 0;

  const cards: CardData[] = Array.isArray((rt as any).cards) ? ((rt as any).cards as any[]) : [];
  const slotCount = ((rt as any).slotCount ?? rt.slotCount ?? 3) | 0;
  const waitLineCount = (((rt as any).waitLineCount ?? 3) | 0);

  const mkPlan = (seq: number[]): SimPlan => ({ equipCardIndices: seq });

  // 1) Start from a deterministic greedy baseline.
  const initRnd = makeRng((baseSeed + 1337) | 0);
  const initPlan = planEquipOrderByFullSim(rt, tokens, initRnd);
  let bestSeq = Array.from(initPlan.equipCardIndices);
  let bestVr = verifyGuaranteedEquipPlan(rt, mkPlan(bestSeq), tokens);
  if (bestVr.ok) {
    opts?.onProgress?.({ attempt: 1, maxAttempts: maxIters, phase: 'done' });
    return { plan: mkPlan(bestSeq), verify: bestVr, stats: { deadlyRejected: 0, deadlyTotal: 0, pushOutCandidates: 0, pushOutImproved: 0 } };
  }

  // Adaptive rollback window. Start small, grow when we get stuck.
  let K = Math.max(3, (slotCount + waitLineCount) | 0);
  let stagnation = 0;

  // Cumulative diagnostics for UI
  let deadlyTotal = 0;
  let deadlyRejected = 0;
  let pushOutCandidates = 0;
  let pushOutImproved = 0;

  const getStats = (): GuaranteeStats => ({
    deadlyRejected,
    deadlyTotal,
    pushOutCandidates,
    pushOutImproved,
  });

  const bottomColorsFromSnap = (snap: any): number[] => {
    const s = snap;
    if (!s || !Array.isArray(s.row0)) return [];
    const set = new Set<number>();
    for (const cell of s.row0) {
      if (!cell) continue;
      const cid = (cell.colorId ?? -1) | 0;
      if (cid >= 0 && !cell.hidden) set.add(cid);
    }
    return Array.from(set.values());
  };

  const pullColorIntoFront = (suffix: number[], colorId: number, frontLimit: number, rnd: () => number): boolean => {
    if (colorId < 0) return false;
    const lim = Math.max(1, Math.min(frontLimit | 0, suffix.length));

    // already in the early window
    for (let i = 0; i < lim; i++) {
      const idx = suffix[i] | 0;
      if (((cards[idx]?.colorId ?? -1) | 0) === (colorId | 0)) return true;
    }

    // find later
    let found = -1;
    for (let i = lim; i < suffix.length; i++) {
      const idx = suffix[i] | 0;
      if (((cards[idx]?.colorId ?? -1) | 0) === (colorId | 0)) { found = i; break; }
    }
    if (found < 0) return false;

    const [v] = suffix.splice(found, 1);
    // insert near the front, but not always at 0
    const ins = Math.min(lim - 1, (rnd() * Math.min(4, lim)) | 0);
    suffix.splice(ins, 0, v);
    return true;
  };

  // Push a specific color out of the early window (helps prevent unshootable colors from monopolizing shooters).
  const pushColorOutOfFront = (suffix: number[], colorId: number, frontLimit: number): boolean => {
    if (colorId < 0) return false;
    const lim = Math.max(1, Math.min(frontLimit | 0, suffix.length));
    for (let i = 0; i < lim; i++) {
      const idx = suffix[i] | 0;
      if (((cards[idx]?.colorId ?? -1) | 0) === (colorId | 0)) {
        const [v] = suffix.splice(i, 1);
        suffix.push(v);
        return true;
      }
    }
    return false;
  };

  const shuffleFrontBlock = (suffix: number[], blockLen: number, rnd: () => number) => {
    const n = Math.max(2, Math.min(blockLen | 0, suffix.length));
    for (let i = n - 1; i > 0; i--) {
      const j = (rnd() * (i + 1)) | 0;
      const tmp = suffix[i]; suffix[i] = suffix[j]; suffix[j] = tmp;
    }
  };

  // If we keep failing at the same step, fully freezing the prefix can trap us.
  // This softens the prefix by allowing a small shuffled tail (keeps color multiset, changes order).
  const softenPrefix = (prefix: number[], rnd: () => number) => {
    if (prefix.length < 8) return prefix;
    const keepLen = Math.max(0, (prefix.length * 0.7) | 0);
    const mid = prefix.slice(keepLen);
    for (let i = mid.length - 1; i > 0; i--) {
      const j = (rnd() * (i + 1)) | 0;
      const tmp = mid[i]; mid[i] = mid[j]; mid[j] = tmp;
    }
    return prefix.slice(0, keepLen).concat(mid);
  };

  for (let iter = 0; iter < maxIters; iter++) {
    opts?.onProgress?.({
      attempt: iter + 1,
      maxAttempts: maxIters,
      phase: 'refine',
      refineIter: iter + 1,
      failEquipStep: (bestVr as any).failEquipStep,
      remainingTiles: (bestVr as any).remainingTiles,
      deadlyTotal,
      deadlyRejected,
      pushOutCandidates,
      pushOutImproved,
    });
    if (iter % yieldEvery === 0) await new Promise((r) => setTimeout(r, 0));

    if (bestVr.ok) {
      opts?.onProgress?.({ attempt: iter + 1, maxAttempts: maxIters, phase: 'done' });
      return { plan: mkPlan(bestSeq), verify: bestVr, stats: getStats() };
    }

    const failStep = ((bestVr as any).failEquipStep ?? 1) | 0;
    const desired = ((bestVr as any).desiredColor ?? -1) | 0;
    const snap = (bestVr as any).snapshot;
    const bottomColors = bottomColorsFromSnap(snap);

    // --- (3) Cause-based backjump: rollback using desiredColor AND current shootableColors.
    let rollback = Math.max(0, failStep - K);
    {
      const le = Array.isArray((bestVr as any).lastEquipStepByColor) ? ((bestVr as any).lastEquipStepByColor as number[]) : null;
      const lw = Array.isArray((bestVr as any).lastW1StepByColor) ? ((bestVr as any).lastW1StepByColor as number[]) : null;
      const shootable = Array.isArray((bestVr as any).shootableColors) ? ((bestVr as any).shootableColors as number[]) : null;

      const candColors: number[] = [];
      if (desired >= 0) candColors.push(desired);
      if (shootable) for (const c of shootable) candColors.push(c | 0);

      let bestRb = rollback;
      for (const col of candColors) {
        if (col < 0) continue;
        let last = Number.POSITIVE_INFINITY;
        const a = le && col < le.length ? (le[col] | 0) : -1;
        const b = lw && col < lw.length ? (lw[col] | 0) : -1;
        if (a >= 0) last = Math.min(last, a);
        if (b >= 0) last = Math.min(last, b);
        if (Number.isFinite(last)) {
          const rb = Math.max(0, (last | 0) - 2); // margin
          bestRb = Math.min(bestRb, rb);
        }
      }
      rollback = bestRb;
    }

    // --- (2) Occupancy correction: identify shooter colors that are currently unshootable.
    const badShooterColors: number[] = [];
    {
      const shootableColors = Array.isArray((bestVr as any).shootableColors) ? ((bestVr as any).shootableColors as number[]) : null;
      const shooterColors = Array.isArray((bestVr as any).shooterColors) ? ((bestVr as any).shooterColors as number[]) : null;
      if (shootableColors && shooterColors) {
        const set = new Set<number>(shootableColors.map((v) => v | 0));
        for (const c of shooterColors) {
          const cid = c | 0;
          if (!set.has(cid)) badShooterColors.push(cid);
        }
      }
    }
    let prefix = bestSeq.slice(0, rollback);
    const suffixBase = bestSeq.slice(rollback);

    const rnd = makeRng((baseSeed + iter * 1000003) | 0);

    // soften prefix after stagnation to escape local minima
    if (stagnation >= 12) prefix = softenPrefix(prefix, rnd);

    const earlyWindow = Math.max(6, Math.min(22, (slotCount + waitLineCount) * 2));

    const candidates: Array<{ seq: number[]; meta: { pushOut: boolean } }> = [];

    // C1) Pull desiredColor & bottom colors into the early window of the suffix.
    {
      const sfx = suffixBase.slice();
      // (2) push known-bad shooter colors away so they don't monopolize the next equips
      let pushed = false;
      for (const bc of badShooterColors) pushed = pushColorOutOfFront(sfx, bc, earlyWindow) || pushed;
      pullColorIntoFront(sfx, desired, earlyWindow, rnd);
      for (const c of bottomColors) pullColorIntoFront(sfx, c, earlyWindow, rnd);
      candidates.push({ seq: prefix.concat(sfx), meta: { pushOut: pushed } });
    }

    // C2) Stronger bottom coverage first
    {
      const sfx = suffixBase.slice();
      let pushed = false;
      for (const bc of badShooterColors) pushed = pushColorOutOfFront(sfx, bc, earlyWindow) || pushed;
      for (const c of bottomColors) pullColorIntoFront(sfx, c, earlyWindow, rnd);
      if (desired >= 0) pullColorIntoFront(sfx, desired, earlyWindow, rnd);
      candidates.push({ seq: prefix.concat(sfx), meta: { pushOut: pushed } });
    }

    // C3) Local shuffle + desired pull
    {
      const sfx = suffixBase.slice();
      shuffleFrontBlock(sfx, Math.min(earlyWindow, 12), rnd);
      let pushed = false;
      for (const bc of badShooterColors) pushed = pushColorOutOfFront(sfx, bc, earlyWindow) || pushed;
      pullColorIntoFront(sfx, desired, earlyWindow, rnd);
      candidates.push({ seq: prefix.concat(sfx), meta: { pushOut: pushed } });
    }

    // C4) Backjump: enlarge rollback window and repair from there
    {
      // Use a stronger backjump based on the desired color's last appearance when available.
      let rb2 = Math.max(0, failStep - Math.min(bestSeq.length, K * 2));
      {
        const le = Array.isArray((bestVr as any).lastEquipStepByColor) ? ((bestVr as any).lastEquipStepByColor as number[]) : null;
        const lw = Array.isArray((bestVr as any).lastW1StepByColor) ? ((bestVr as any).lastW1StepByColor as number[]) : null;
        if (desired >= 0) {
          let last = Number.POSITIVE_INFINITY;
          const a = le && desired < le.length ? (le[desired] | 0) : -1;
          const b = lw && desired < lw.length ? (lw[desired] | 0) : -1;
          if (a >= 0) last = Math.min(last, a);
          if (b >= 0) last = Math.min(last, b);
          if (Number.isFinite(last)) rb2 = Math.min(rb2, Math.max(0, (last | 0) - 4));
        }
      }
      const p2 = bestSeq.slice(0, rb2);
      const sfx = bestSeq.slice(rb2);
      let pushed = false;
      for (const bc of badShooterColors) pushed = pushColorOutOfFront(sfx, bc, earlyWindow) || pushed;
      for (const c of bottomColors) pullColorIntoFront(sfx, c, earlyWindow, rnd);
      pullColorIntoFront(sfx, desired, earlyWindow, rnd);
      candidates.push({ seq: p2.concat(sfx), meta: { pushOut: pushed } });


    // C5) Dominant-color dismantle: if shooters are monopolized by an unshootable color, force 2 shootable colors into the next equip window
    // and push the dominant color out to avoid forming (e.g.) RRR while row0 has no R.
    {
      const shooterColors = Array.isArray((bestVr as any).shooterColors) ? ((bestVr as any).shooterColors as number[]) : null;
      const shootableColors = Array.isArray((bestVr as any).shootableColors) ? ((bestVr as any).shootableColors as number[]) : null;

      if (shooterColors && shooterColors.length === slotCount && shootableColors) {
        // count dominant
        const counts = new Map<number, number>();
        for (const c of shooterColors) counts.set((c | 0), (counts.get((c | 0)) ?? 0) + 1);
        let dom = -1, domCnt = 0;
        for (const [k, v] of counts) { if (v > domCnt) { dom = k; domCnt = v; } }

        const shootableSet = new Set<number>(shootableColors.map((v) => v | 0));
        // if all slots are the same color (or near-monopoly) and that color is NOT shootable, dismantle it.
        if (domCnt >= slotCount - 0 && dom >= 0 && !shootableSet.has(dom)) {
          const sfx = suffixBase.slice();
          // push dominant out multiple times (if it appears early multiple times)
          let pushed = false;
          for (let t = 0; t < slotCount; t++) pushed = pushColorOutOfFront(sfx, dom, earlyWindow) || pushed;

          // choose two shootable colors to inject (prefer desired if it is shootable)
          const picks: number[] = [];
          if (desired >= 0 && shootableSet.has(desired)) picks.push(desired);
          for (const c of bottomColors) if (shootableSet.has(c) && picks.length < 2) picks.push(c);
          for (const c of shootableColors) if (picks.length < 2) picks.push(c | 0);

          // inject up to 2 to break monopoly
          for (const p of picks.slice(0, 2)) pullColorIntoFront(sfx, p, earlyWindow, rnd);
          candidates.push({ seq: prefix.concat(sfx), meta: { pushOut: pushed } });
        }
      }
    }
    }

    // Score candidates: maximize progress, then minimize remainingTiles.
    const bestStepNow = bestVr.ok ? 1_000_000_000 : Math.max(0, (((bestVr as any).failEquipStep ?? 1) - 1));
    const bestRemNow = ((bestVr as any).remainingTiles ?? 0) | 0;
    const scored: { seq: number[]; vr: VerifyResult; step: number; rem: number; pushOut: boolean }[] = [];
    // If the deadly-guard rejects every candidate, keep the best rejected one
    // as a fallback to avoid empty candidate lists (which would crash).
    let bestRejected: { seq: number[]; vr: VerifyResult; step: number; rem: number; pushOut: boolean } | null = null;
    for (const cand of candidates) {
      const seq = cand.seq;
      const usedPushOut = !!cand.meta?.pushOut;
      deadlyTotal++;
      if (usedPushOut) pushOutCandidates++;

      const vr = verifyGuaranteedEquipPlan(rt, mkPlan(seq), tokens);
      const s = vr.ok ? 1_000_000_000 : Math.max(0, ((vr as any).failEquipStep ?? 1) - 1);
      const rem = ((vr as any).remainingTiles ?? 0) | 0;
      // --- (1) Deadly guard: discard candidates that immediately reach a classic deadlock and don't improve.
      if (!vr.ok && (((vr as any).deadly) || ((vr as any).preDeadly)) && (s <= bestStepNow) && (rem >= bestRemNow)) {
        deadlyRejected++;
        // Track the best rejected candidate as a fallback.
        if (
          !bestRejected ||
          s > bestRejected.step ||
          (s === bestRejected.step && rem < bestRejected.rem)
        ) {
          bestRejected = { seq, vr, step: s, rem, pushOut: usedPushOut };
        }
        continue;
      }
      scored.push({ seq, vr, step: s, rem, pushOut: usedPushOut });
      if (vr.ok) {
        opts?.onProgress?.({ attempt: iter + 1, maxAttempts: maxIters, phase: 'done' });
        return { plan: mkPlan(seq), verify: vr, stats: getStats() };
      }
    }

    // If everything was rejected by the deadly-guard, fall back to the best rejected
    // so the search can still make progress (or at least increase K/backjump).
    if (scored.length === 0 && bestRejected) {
      scored.push(bestRejected);
    }

    // Extremely defensive: if we still have nothing, widen rollback and try again.
    if (scored.length === 0) {
      stagnation++;
      if (stagnation % 4 == 0) K = Math.min(80, K * 2);
      continue;
    }

    scored.sort((a, b) => {
      if (b.step != a.step) return b.step - a.step;
      return a.rem - b.rem;
    });

    // As an absolute safeguard, never allow an empty scored list.
    if (scored.length === 0) {
      // No candidates at all (should be impossible). Increase rollback and continue.
      stagnation++;
      if (stagnation % 4 === 0) K = Math.min(80, K * 2);
      continue;
    }

    const bestCand = scored[0];

    const improved =
      bestCand.step > bestStepNow ||
      (bestCand.step == bestStepNow && (bestCand.rem | 0) < (((bestVr as any).remainingTiles ?? 0) | 0));

    if (improved) {
      if (bestCand.pushOut) pushOutImproved++;
      bestSeq = bestCand.seq;
      bestVr = bestCand.vr;
      stagnation = 0;
      // reduce K a bit after improvement to focus local repair again
      K = Math.max(Math.max(3, slotCount + waitLineCount), (K * 0.8) | 0);
    } else {
      stagnation++;
      // if we keep failing, grow the rollback window
      if (stagnation % 8 == 0) K = Math.min(80, K * 2);
    }
  }

  return { plan: mkPlan(bestSeq), verify: bestVr, stats: getStats() };
}

export function applyPlanToCards(rt: StageRuntime, plan: SimPlan, colorTokens?: readonly string[]): { ordered: CardData[]; equipOrder: string[] } {
  const tokens = (colorTokens ? Array.from(colorTokens) : (['R','Y','B','G','O','P','C','M','L','W','K','S'] as string[]));
  const ordered: CardData[] = [];
  const equipOrder: string[] = [];
  for (let i = 0; i < plan.equipCardIndices.length; i++) {
    const ci = plan.equipCardIndices[i];
    const c = rt.cards[ci];
    const sc: 1 | 2 = (c.shotCount === 2 ? 2 : 1);
    ordered.push({ ...c, hintStep: i + 1 });
    equipOrder.push(tokenFrom(c.colorId, sc, tokens));
  }
  return { ordered, equipOrder };
}
