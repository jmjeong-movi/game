/* eslint-disable no-console */

// NOTE:
// This module is intentionally strict-fail unless a real game-equivalent simulator is linked.
// It prevents false SOLVED outcomes.

async function validateStageEquivalent(_stage, _opts = {}) {
  return {
    status: 'UNSOLVED',
    reason: 'SIM_ENGINE_NOT_LINKED',
    failStep: -1,
    opsUsed: [],
  };
}

module.exports = { validateStageEquivalent };
