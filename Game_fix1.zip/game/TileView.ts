import { _decorator, Component, Node, Sprite, UITransform, tween, Vec3, Tween, ParticleSystem, Color, Prefab, instantiate, sp, Label } from 'cc';
import type { TweenEasing } from 'cc';
import { AtlasCache, ColorPalette, pad2, toSpriteIndex } from './ColorPalette';
import type { RuntimeSpecial } from './Types';

const { ccclass, property } = _decorator;

type TileSkin = 'SMALL' | 'BIG';

@ccclass('TileView')
export class TileView extends Component {
    @property({
        type: [Sprite],
        tooltip:
            '블럭 스프라이트 목록(아래->위). 권장: Root/Block/Block_01~05(Sprite) 순서로 드래그. 비어있으면 1회 fallback 탐색합니다.',
    })
    sprites: Sprite[] = [];

    @property({ tooltip: '큰(2x2) 블럭 프리팹이면 체크(미체크면 UITransform 크기로 추정)' })
    isBig = false;

    // 보드 좌표(로직에서 재배치 시 갱신)
    public row = 0;
    public col = 0;

    private skin: TileSkin = 'SMALL';
    private stack: number[] = []; // bottom..top
    private hidden = false;
    private special: RuntimeSpecial | null = null;

    // ----------------- Special Visual Prefab Hints (runtime-configured) -----------------
    private _prefKey: Prefab | null = null;
    private _prefSpawnerBox: Prefab | null = null;
    private _prefPillar: Prefab | null = null;
    private _tileWHint = 62.5;
    private _tileHHint = 62.5;

    // ✅ 생성박스(스포너) 오버레이 비주얼 크기 배율(2x2 셀 기준)
    // - Board 인스펙터에서 조정값을 주입(setSpecialPrefabHints)
    // - 1.0 : 2x2 셀에 딱 맞춤
    // - 1.1~1.35 : 조금 더 크게(기획/아트 튜닝)
    // - 요구사항 변경: 가로/세로를 따로 튜닝할 수 있어야 하므로 X/Y를 분리
    private _spawnerBoxScaleHint = 1.0; // legacy(=X)
    private _spawnerBoxScaleYHint = 1.0;

    // special overlay instance (pooled TileView 재사용 대응)
    private _specialOverlay: Node | null = null;
    private _specialOverlayKind: string | null = null;
    private _spawnerSkel: sp.Skeleton | null = null;

    // ✅ 스파인 이벤트 타이밍에 맞춰 블럭을 생성하기 위한 콜백(1회)
    private _spawnerSpawnOnce: (() => void) | null = null;
    private _spawnerEventBound = false;

    // ✅ Create 애니 이벤트가 누락/실패해도 스폰이 멈추지 않도록 하는 안전장치(타임아웃 fallback)
    private _spawnerSpawnFallbackFn: (() => void) | null = null;

    // 2x2(및 확장) 블럭용 HP(없으면 1)
    private hp = 1;
    private hpMax = 1;

    // 피격 흔들림 기준점
    private basePos: Vec3 | null = null;

    // ✅ 흔들림/팝/스케일 아웃은 "비주얼 바디" 노드에만 적용
    // - 역할: 보드 이동(루트 position tween)과 FX(몸통 scale/흔들림)를 분리해서
    //   Tween.stopAllByTarget 충돌/중단/스턱을 줄입니다.
    private _body: Node | null = null;

    // ✅ Sprite tint 적용용 임시 Color(할당 최소화)
    private _tmpTint = new Color();
    private _bodyInited = false;
    private _bodyBasePos: Vec3 = new Vec3();
    private _bodyBaseScale: Vec3 = new Vec3(1, 1, 1);
    private _bodyBaseRot: Vec3 = new Vec3();

    // ✅ 착지 스쿼시(낙하 후)용 스케일 타겟(재사용)
    // - 역할: 낙하가 끝날 때 "쿵" 하는 자연스러운 착지감을 줌
    private _landScaleA: Vec3 = new Vec3();

    // ✅ hitSide GC 제거용 임시 Vec3(재사용)
    private _hitP1: Vec3 = new Vec3();

    // ✅ SPAWNER_BOX bone 좌표 변환용 임시 Vec3(재사용)
    private _tmpBoneLocal: Vec3 = new Vec3();
    private _tmpBoneW0: Vec3 = new Vec3();
    private _tmpBoneW1: Vec3 = new Vec3();

    // fallback 탐색은 1회만
    private _resolvedOnce = false;

    // ✅ FX(파티클) 캐시
    // - Pre_FX_Particle_Hit : 히트 시 재생
    // - Particle_Shatter   : 제거 FX(주로 Board가 별도 풀링 노드로 재생)
    //   단, 풀링 재사용 시 자동재생/잔류를 막기 위해 TileView도 정지/비활성 관리
    private _fxHitRoot: Node | null = null;
    private _fxShatterRoot: Node | null = null;
    private _hitPS: ParticleSystem[] = [];
    private _shatterPS: ParticleSystem[] = [];

    // 최상단 색상 id (없으면 -1)
    get colorId(): number {
        return this.stack.length ? this.stack[this.stack.length - 1] | 0 : -1;
    }

    // 겹(스택) 깊이
    get depth(): number {
        return this.stack.length;
    }

    onLoad() {
        this.detectSkin();
        this.ensureSpritesResolved();
        this.ensureFxResolved(); // ✅ FX 노드(히트/제거) 1회 탐색/캐싱 + 기본 정지/비활성
        this.ensureBodyResolved();
        this.refresh();
    }

    // 스택(겹) 전체를 설정합니다.
    setStack(stack: number[]) {
        this.stack = Array.isArray(stack) ? stack.slice() : [];
        this.refresh();
    }

    // 최상단만 변경합니다(겹이 없으면 1겹으로 설정).
    setTop(colorId: number) {
        if (this.stack.length <= 0) this.stack = [colorId | 0];
        else this.stack[this.stack.length - 1] = colorId | 0;
        this.refresh();
    }

    // 최상단 1겹을 제거합니다.
    popTop(): number {
        const v = this.stack.pop();
        this.refresh();
        return typeof v === 'number' ? v | 0 : -1;
    }

    // 타일을 비웁니다.
    clear() {
        this.stack.length = 0;
        this.hidden = false;
        this.special = null;
        this.hp = 1;
        this.hpMax = 1;

        // ✅ 역할: 블럭이 풀로 반환될 때 FX가 잔류/자동재생되지 않도록 정리
        this.stopAndHideFx();

        // ✅ 역할: 풀 재사용 시 흔들림/팝/스케일 잔상 방지
        this.resetBodyTransform();

        // ✅ 역할: special overlay(키/생성박스/기둥 등) 잔상 제거
        this._destroySpecialOverlay();

        this.refresh();
    }

    // ✅ Board에서 타일 풀로 뽑을 때 1회 주입하는 특수 프리팹 힌트
    // - 프리팹은 TileView가 직접 serialize로 들고있기 어렵기 때문에(풀링 + 공용 프리팹)
    //   Board가 런타임에 주입합니다.
    setSpecialPrefabHints(opts: {
        keyPrefab?: Prefab | null;
        spawnerBoxPrefab?: Prefab | null;
        pillarPrefab?: Prefab | null;
        // ✅ 셀 크기 힌트(가로/세로). tileSize는 legacy(정사각) 호환
        tileW?: number;
        tileH?: number;
        tileSize?: number;

        // ✅ 생성박스 오버레이 크기 배율(인스펙터 튜닝용)
        // - v1: spawnerBoxScale(균일)
        // - v2: spawnerBoxScaleX/spawnerBoxScaleY(가로/세로 분리)
        spawnerBoxScale?: number; // legacy(uniform)
        spawnerBoxScaleX?: number;
        spawnerBoxScaleY?: number;
    }) {
        this._prefKey = opts.keyPrefab ?? this._prefKey;
        this._prefSpawnerBox = opts.spawnerBoxPrefab ?? this._prefSpawnerBox;
        this._prefPillar = opts.pillarPrefab ?? this._prefPillar;
        if (typeof opts.tileW === 'number' && isFinite(opts.tileW)) {
            this._tileWHint = Math.max(1, opts.tileW);
        }
        if (typeof opts.tileH === 'number' && isFinite(opts.tileH)) {
            this._tileHHint = Math.max(1, opts.tileH);
        }

        // ✅ (생성박스 스케일) X/Y 분리 입력이 있으면 우선 적용
        // - 둘 중 하나만 들어오면 나머지는 legacy/uniform 또는 기존 값으로 유지
        if (typeof opts.spawnerBoxScaleX === 'number' && isFinite(opts.spawnerBoxScaleX)) {
            this._spawnerBoxScaleHint = Math.max(0.01, opts.spawnerBoxScaleX);
        }
        if (typeof opts.spawnerBoxScaleY === 'number' && isFinite(opts.spawnerBoxScaleY)) {
            this._spawnerBoxScaleYHint = Math.max(0.01, opts.spawnerBoxScaleY);
        }
        if (typeof opts.spawnerBoxScale === 'number' && isFinite(opts.spawnerBoxScale)) {
            // legacy(uniform): X/Y가 따로 지정되지 않았으면 동일하게 적용
            const v = Math.max(0.01, opts.spawnerBoxScale);
            if (!(typeof opts.spawnerBoxScaleX === 'number' && isFinite(opts.spawnerBoxScaleX))) this._spawnerBoxScaleHint = v;
            if (!(typeof opts.spawnerBoxScaleY === 'number' && isFinite(opts.spawnerBoxScaleY))) this._spawnerBoxScaleYHint = v;
        }
        // legacy: 정사각 셀
        if (typeof opts.tileSize === 'number' && isFinite(opts.tileSize)) {
            const v = Math.max(1, opts.tileSize);
            // tileW/H가 별도로 오지 않았다면 tileSize로 동기화
            if (!(typeof opts.tileW === 'number' && isFinite(opts.tileW))) this._tileWHint = v;
            if (!(typeof opts.tileH === 'number' && isFinite(opts.tileH))) this._tileHHint = v;
        }
    }

    // ✅ 생성박스(Create) 애니메이션 재생
    // - Enemy_OBJ_Create.json 기준, Create 애니메이션 타임라인에 이벤트 name='Event'가 0.2667s에 존재
    // - 해당 이벤트에서 onSpawn 콜백을 1회 호출하도록 합니다.
    playSpawnerCreateAnim(onSpawn?: () => void) {
        this.playSpawnerCreateAnimWithSpawn(onSpawn);
    }

    private _cancelSpawnerSpawnFallback() {
        if (!this._spawnerSpawnFallbackFn) return;
        try {
            this.unschedule(this._spawnerSpawnFallbackFn);
        } catch {
            // ignore
        }
        this._spawnerSpawnFallbackFn = null;
    }

    private _scheduleSpawnerSpawnFallback(delaySec: number) {
        // 기존 예약 제거(중복 호출/누수 방지)
        this._cancelSpawnerSpawnFallback();

        const d = Math.max(0.01, Number.isFinite(delaySec) ? delaySec : 0.35);
        const fn = () => {
            // 이벤트/complete에서 이미 실행됐으면 무시
            if (!this._spawnerSpawnOnce) {
                this._spawnerSpawnFallbackFn = null;
                return;
            }
            const cb = this._spawnerSpawnOnce;
            this._spawnerSpawnOnce = null;
            this._spawnerSpawnFallbackFn = null;
            try {
                cb();
            } catch {
                // ignore
            }
        };

        this._spawnerSpawnFallbackFn = fn;
        try {
            this.scheduleOnce(fn, d);
        } catch {
            // schedule 실패 시 즉시 실행(최악의 경우라도 pending 고착 방지)
            try {
                fn();
            } catch {}
        }
    }

    /**
     * Create 애니 재생 + 이벤트('Event')에서 spawn 콜백 1회
     * - 이벤트가 누락/실패하면 complete 시점에 fallback
     */
    playSpawnerCreateAnimWithSpawn(onSpawn?: () => void) {
        // 혹시 이전 스폰이 남아있다면(풀 재사용/중복 호출) 안전하게 정리
        this._cancelSpawnerSpawnFallback();
        this._spawnerSpawnOnce = null;

        if (this.special?.t !== 'SPAWNER_BOX') {
            try {
                onSpawn?.();
            } catch {
                // ignore
            }
            return;
        }
        const sk = this._spawnerSkel;
        if (!sk || !sk.isValid) {
            try {
                onSpawn?.();
            } catch {
                // ignore
            }
            return;
        }

        this._spawnerSpawnOnce = onSpawn ?? null;
        this._bindSpawnerEventListener();

        // ✅ 안전장치: spine 이벤트/complete가 누락되면 pending이 영구 고착될 수 있으므로 타임아웃 fallback 예약
        // - Enemy_OBJ_Create.json 기준 이벤트는 약 0.2667s 부근이므로 약간 여유를 둡니다.
        if (this._spawnerSpawnOnce) this._scheduleSpawnerSpawnFallback(0.42);

        try {
            sk.setAnimation(0, 'Create', false);

            // Create 종료 시 Idle, 이벤트가 없었으면 여기서 fallback
            (sk as any).setCompleteListener?.(() => {
                if (this._spawnerSpawnOnce) {
                    const cb = this._spawnerSpawnOnce;
                    this._spawnerSpawnOnce = null;
                    this._cancelSpawnerSpawnFallback();
                    try {
                        cb();
                    } catch {
                        // ignore
                    }
                }
                try {
                    sk.setAnimation(0, 'Idle', true);
                } catch {
                    // ignore
                }
            });
        } catch {
            // ignore
        }
    }


    // ✅ SPAWNER_BOX: spine bone의 월드 좌표를 얻습니다.
    // - spine bone 좌표(worldX/worldY)는 skeleton 노드 로컬 좌표계로 간주합니다.
    private _getSpawnerBoneWorldPos(boneName: string, out: Vec3): Vec3 | null {
        const sk = this._spawnerSkel;
        if (!sk || !sk.isValid || !sk.node || !sk.node.isValid) return null;

        const anySk = sk as any;
        let bone: any = null;
        try {
            bone = typeof anySk.findBone === 'function' ? anySk.findBone(boneName) : null;
        } catch {
            bone = null;
        }
        if (!bone) return null;

        const lx = Number.isFinite(bone.worldX)
            ? (bone.worldX as number)
            : Number.isFinite(bone.x)
              ? (bone.x as number)
              : 0;
        const ly = Number.isFinite(bone.worldY)
            ? (bone.worldY as number)
            : Number.isFinite(bone.y)
              ? (bone.y as number)
              : 0;

        const ui = sk.node.getComponent(UITransform);
        if (ui) {
            this._tmpBoneLocal.set(lx, ly, 0);
            return ui.convertToWorldSpaceAR(this._tmpBoneLocal, out);
        }

        // UITransform이 없으면 skeleton 노드 월드 + bone offset을 더한 근사치
        const wp = sk.node.getWorldPosition(out);
        out.set(wp.x + lx, wp.y + ly, wp.z);
        return out;
    }

    // ✅ SPAWNER_BOX: "혀 안쪽" 월드 좌표를 반환합니다.
    // - 혀 뼈(Tongue)와 혀 끝(Tongue_End) 사이의 보간점을 사용합니다.
    public getSpawnerTongueInnerWorldPos(out?: Vec3): Vec3 | null {
        const o = out ?? new Vec3();
        const a = this._getSpawnerBoneWorldPos('Tongue', this._tmpBoneW0);
        const b = this._getSpawnerBoneWorldPos('Tongue_End', this._tmpBoneW1);

        if (a && b) {
            // ✅ 더 "안쪽"에서 시작하도록 보간 비율을 낮춤
            // - 이전(0.35)은 혀 끝에 가까워 "셀에서 뿅" 느낌이 강해질 수 있음
            const t = 0.22; // 0=Tongue, 1=Tongue_End
            o.set(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t);
            return o;
        }

        if (this._getSpawnerBoneWorldPos('Tongue_End', o)) return o;
        if (this._getSpawnerBoneWorldPos('Tongue', o)) return o;

        const ov = this._specialOverlay;
        if (ov && ov.isValid) return ov.getWorldPosition(o);
        return this.node.getWorldPosition(o);
    }

    // ✅ SPAWNER_BOX: 좌/우 각각 다른 시작점(혀 안쪽) 월드 좌표
    // - 기본: Tongue/Tongue_End 기반 "혀 안쪽" 좌표 + 셀 폭 힌트로 좌/우 오프셋
    // - fallback: 샘플 블럭 본(Sample_Block_L/R)
    public getSpawnerTongueInnerWorldPosLR(side: 'L' | 'R', out?: Vec3): Vec3 | null {
        const o = out ?? new Vec3();

        // ✅ "시작점"은 반드시 혀(안쪽) 기준이어야 자연스럽게 "혀에서 나오는" 연출이 됩니다.
        // - Sample_Block_L/R 본은 보통 "출구/샘플 위치"에 가까워서,
        //   이를 시작점으로 쓰면 셀 위치에서 바로 커지는(=뿅) 느낌이 날 수 있습니다.

        // 1) 기본: 혀 안쪽 좌표 + x 오프셋
        const base = this.getSpawnerTongueInnerWorldPos(o);
        if (base) {
            const dx = Math.max(6, (this._tileWHint || 0) * 0.28);
            o.x += side === 'L' ? -dx : dx;
            return o;
        }

        // 2) fallback: 샘플 블럭 본(좌/우)
        const boneName = side === 'L' ? 'Sample_Block_L' : 'Sample_Block_R';
        if (this._getSpawnerBoneWorldPos(boneName, o)) return o;

        const ov = this._specialOverlay;
        if (ov && ov.isValid) return ov.getWorldPosition(o);
        return this.node.getWorldPosition(o);
    }

    private _bindSpawnerEventListener() {
        const sk = this._spawnerSkel;
        if (!sk || !sk.isValid) return;
        if (this._spawnerEventBound) return;
        this._spawnerEventBound = true;

        const anySk = sk as any;
        const handler = (_entry: any, ev: any) => {
            const name = ev?.data?.name ?? ev?.name ?? '';
            if (name !== 'Event' && name !== 'Spawn' && name !== 'Create') return;
            if (!this._spawnerSpawnOnce) return;
            const cb = this._spawnerSpawnOnce;
            this._spawnerSpawnOnce = null;
            this._cancelSpawnerSpawnFallback();
            try {
                cb();
            } catch {
                // ignore
            }
        };

        try {
            if (typeof anySk.setEventListener === 'function') {
                anySk.setEventListener(handler);
            }
        } catch {
            // ignore
        }
    }

    private _destroySpecialOverlay() {
        if (this._specialOverlay && this._specialOverlay.isValid) {
            try {
                this._specialOverlay.destroy();
            } catch {
                // ignore
            }
        }
        this._specialOverlay = null;
        this._specialOverlayKind = null;
        this._spawnerSkel = null;
        this._spawnerSpawnOnce = null;
        this._cancelSpawnerSpawnFallback();
        this._spawnerEventBound = false;
    }

    private _fitOverlayToCell(nd: Node) {
        if (!nd || !nd.isValid) return;

        const pui = this.node.getComponent(UITransform);
        const nui = nd.getComponent(UITransform);
        if (!pui || !nui) return;

        const bw = Math.max(1, nui.contentSize.x);
        const bh = Math.max(1, nui.contentSize.y);
        const tw = Math.max(1, pui.contentSize.x);
        const th = Math.max(1, pui.contentSize.y);

        const sx = tw / bw;
        const sy = th / bh;

        if (isFinite(sx) && sx > 0 && isFinite(sy) && sy > 0) nd.setScale(sx, sy, 1);
    }

    private _fitOverlayToSize(nd: Node, targetW: number, targetH: number) {
        if (!nd || !nd.isValid) return;
        const nui = nd.getComponent(UITransform);
        if (!nui) return;

        const bw = Math.max(1, nui.contentSize.x);
        const bh = Math.max(1, nui.contentSize.y);
        const tw = Math.max(1, Math.round(targetW));
        const th = Math.max(1, Math.round(targetH));

        const sx = tw / bw;
        const sy = th / bh;
        if (isFinite(sx) && sx > 0 && isFinite(sy) && sy > 0) nd.setScale(sx, sy, 1);
    }

    // ✅ 자식 노드 DFS 검색(이름으로)
    // - getChildByName은 1-depth만 검색하므로, 프리팹 구조가 바뀌어도 안전하게 찾기 위함
    private _findNodeByNameDFS(root: Node, name: string): Node | null {
        if (!root || !root.isValid) return null;
        if (root.name === name) return root;

        const stack: Node[] = [root];
        while (stack.length > 0) {
            const n = stack.pop();
            if (!n || !n.isValid) continue;
            if (n.name === name) return n;
            const kids = n.children;
            for (let i = kids.length - 1; i >= 0; i--) {
                const ch = kids[i];
                if (ch && ch.isValid) stack.push(ch);
            }
        }
        return null;
    }

    private _ensureSpecialOverlay(kind: string, prefab: Prefab | null, offsetY: number, fitToCell = false) {
        // kind 동일 & 유지 가능
        if (
            this._specialOverlay &&
            this._specialOverlay.isValid &&
            this._specialOverlayKind === kind &&
            prefab
        ) {
            this._specialOverlay.setPosition(0, offsetY, 0);
            if (fitToCell) this._fitOverlayToCell(this._specialOverlay);
            return;
        }

        // 기존 제거(종류가 달라졌거나 prefab이 없거나)
        this._destroySpecialOverlay();

        if (!prefab) return;

        const nd = instantiate(prefab);
        nd.setParent(this.node);
        nd.setPosition(0, offsetY, 0);
        nd.setSiblingIndex(this.node.children.length - 1);
        if (fitToCell) this._fitOverlayToCell(nd);
        this._specialOverlay = nd;
        this._specialOverlayKind = kind;

        // spawner box는 spine 스켈레톤 캐시
        if (kind === 'SPAWNER_BOX') {
            const sk = nd.getComponent(sp.Skeleton) ?? nd.getComponentInChildren(sp.Skeleton);
            this._spawnerSkel = sk;
            if (sk && sk.isValid) {
                try {
                    sk.setAnimation(0, 'Idle', true);
                } catch {
                    // ignore
                }

                // ✅ 이벤트 리스너는 1회만 바인딩
                this._bindSpawnerEventListener();
            }
        }
    }

    // HP를 설정합니다(2x2 강도). hpMax를 생략하면 hp로 동일 설정합니다.
    setHp(hp: number, hpMax?: number) {
        const h = Math.max(1, Math.floor(hp));
        const hm = Math.max(1, Math.floor(hpMax ?? h));
        this.hp = Math.min(h, hm);
        this.hpMax = hm;
    }

    // 현재 HP를 반환합니다.
    getHp(): number {
        return this.hp;
    }

    // ✅ (읽기 전용) 최대 HP를 반환합니다.
    // - 역할: 보드/탄약 분배에서 “필요 타수” 계산에 사용
    getHpMax(): number {
        return this.hpMax;
    }

    // ✅ (읽기 전용) 내부 스택 배열 참조를 반환합니다.
    // - 역할: 보드/탄약 분배에서 색상별 “필요 타수”를 빠르게 합산
    // - 주의: 외부에서 이 배열을 수정하면 상태가 망가집니다(절대 push/pop 금지)
    getStackRef(): readonly number[] {
        return this.stack;
    }

    // HP를 감소시키고 남은 HP를 반환합니다.
    decHp(dmg = 1): number {
        const d = Math.max(1, Math.floor(dmg));
        this.hp = Math.max(0, this.hp - d);
        return this.hp;
    }

    // 피격 방향(좌/우)에 맞춰 살짝 흔들어 타격감을 줍니다.
    hitSide(side: -1 | 1, amount = 10) {
        const body = this.bodyNode();
        if (!body || !body.isValid) return;

        // 이동(루트)과 분리된 비주얼 바디만 흔듦
        this.ensureBodyResolved();
        Tween.stopAllByTarget(body);
        const p0 = this._bodyBasePos;
        const p1 = this._hitP1;
        p1.set(p0.x + side * amount, p0.y, p0.z);

        // 항상 기준 위치에서 시작(드리프트 방지)
        body.setPosition(p0);
        tween(body).to(0.05, { position: p1 }).to(0.07, { position: p0 }).start();
    }

    // ✅ 낙하 후 착지 스쿼시(살짝 눌렸다가 복귀)
    // - strength: 0~0.18 권장(0.06~0.12)
    // - 이동(루트)과 분리된 비주얼 바디만 스케일을 조정합니다.
    playLandFx(strength = 0.08) {
        const body = this.bodyNode();
        if (!body || !body.isValid) return;

        // 바디 기준값(프리팹 기본 자세)로 시작
        this.ensureBodyResolved();
        Tween.stopAllByTarget(body);
        body.setPosition(this._bodyBasePos);
        body.setScale(this._bodyBaseScale);

        const s = Math.max(0, Math.min(0.18, strength));
        const sx = this._bodyBaseScale.x * (1 + s);
        const sy = this._bodyBaseScale.y * (1 - s);
        this._landScaleA.set(sx, sy, this._bodyBaseScale.z);

        tween(body)
            .to(0.05, { scale: this._landScaleA }, { easing: 'quadOut' as TweenEasing })
            .to(0.08, { scale: this._bodyBaseScale }, { easing: 'quadIn' as TweenEasing })
            .start();
    }

    // ✅ 비주얼 바디 노드를 반환합니다.
    // - 보드 이동/점유 로직은 TileView.node(루트)를 기준으로 하고,
    //   흔들림/팝/제거 스케일은 body에만 적용합니다.
    public bodyNode(): Node {
        this.ensureBodyResolved();
        const b = this._body;
        return b && b.isValid ? b : this.node;
    }

    // ✅ 바디 트랜스폼을 프리팹 기본값으로 복구합니다.
    // - 역할: 풀링 재사용 시 스케일/포지션 잔상 제거
    public resetBodyTransform() {
        this.ensureBodyResolved();
        const b = this._body;
        if (!b || !b.isValid) return;

        Tween.stopAllByTarget(b);
        b.setPosition(this._bodyBasePos);
        b.setScale(this._bodyBaseScale);
        b.setRotationFromEuler(this._bodyBaseRot.x, this._bodyBaseRot.y, this._bodyBaseRot.z);
    }

    // 히든 블럭 표시 여부를 설정합니다.
    setHidden(hidden: boolean) {
        this.hidden = !!hidden;
        this.refresh();
    }

    public isHidden(): boolean {
        // // 역할: 히든 블록 여부(블록 이동 아이템에서 제외)
        return this.hidden;
    }

    // 특수 셀 정보를 설정합니다(체인/키/락/스포너 등).
    setSpecial(s: RuntimeSpecial | null) {
        this.special = s ? { ...s } : null;
        // ✅ 중요: special은 스프라이트/오버레이 표시에도 영향을 주므로 즉시 refresh
        // - setSpecial 이후 refresh가 호출되지 않으면(KEY/스포너/기둥 등) 프리팹이 안 뜨는 문제가 발생
        this.refresh();
    }

    // 특수 셀 정보를 가져옵니다.
    getSpecial(): RuntimeSpecial | null {
        return this.special;
    }

    // ✅ 히트 FX(Pre_FX_Particle_Hit)를 재생합니다.
    // - 역할: 타격 시 파티클을 “항상 같은 타이밍”으로 재생(리셋 후 play)
    // - ParticleSystem(3D) 기준: stop() + clear() + play()
    playHitFx() {
        this.ensureFxResolved();
        const root = this._fxHitRoot;
        if (!root || !root.isValid) return;

        root.active = true;

        let ps = this._hitPS;
        if (!ps || ps.length === 0) {
            ps = root.getComponentsInChildren(ParticleSystem);
            this._hitPS = ps;
        }

        for (let i = 0; i < ps.length; i++) {
            const p = ps[i];
            (p as any).playOnAwake = false;
            try {
                p.stop();
                p.clear();
                p.play();
            } catch {
                // ignore
            }
        }
    }

    // ✅ 프리팹 내부 FX 노드를 1회만 탐색/캐싱합니다.
    // - 역할: 히트/제거 파티클을 런타임에서 빠르게 제어
    // - 성능: 최초 1회만 탐색하고 이후 캐시 사용
    private ensureFxResolved() {
        if (this._fxHitRoot && this._fxHitRoot.isValid && this._fxShatterRoot && this._fxShatterRoot.isValid) return;

        const base = this.node.getChildByPath('Root') ?? this.node;

        this._fxShatterRoot =
            base.getChildByPath('Particle_Shatter') ??
            this.node.getChildByName('Particle_Shatter') ??
            this.node.getChildByPath('Root/Particle_Shatter') ??
            null;

        this._fxHitRoot =
            base.getChildByPath('Pre_FX_Particle_Hit') ??
            this.node.getChildByName('Pre_FX_Particle_Hit') ??
            this.node.getChildByPath('Root/Pre_FX_Particle_Hit') ??
            null;

        // 그래도 못 찾으면 DFS 1회
        if (!this._fxHitRoot || !this._fxShatterRoot) {
            const st: Node[] = [this.node];
            while (st.length) {
                const n = st.pop()!;
                const nm = n.name;
                if (!this._fxShatterRoot && nm === 'Particle_Shatter') this._fxShatterRoot = n;
                if (!this._fxHitRoot && nm === 'Pre_FX_Particle_Hit') this._fxHitRoot = n;
                if (this._fxHitRoot && this._fxShatterRoot) break;
                const ch = n.children;
                for (let i = ch.length - 1; i >= 0; i--) st.push(ch[i]);
            }
        }

        this._hitPS =
            this._fxHitRoot && this._fxHitRoot.isValid ? this._fxHitRoot.getComponentsInChildren(ParticleSystem) : [];
        this._shatterPS =
            this._fxShatterRoot && this._fxShatterRoot.isValid
                ? this._fxShatterRoot.getComponentsInChildren(ParticleSystem)
                : [];

        // 기본은 정지/비활성
        this.stopAndHideFx();
    }

    // ✅ FX를 정지하고 비활성화합니다.
    // - 역할: 풀링 재사용 시 playOnAwake/루프 파티클이 튀어나오는 현상 방지
    private stopAndHideFx() {
        const hit = this._fxHitRoot;
        if (hit && hit.isValid) {
            let ps = this._hitPS;
            if (!ps || ps.length === 0) {
                ps = hit.getComponentsInChildren(ParticleSystem);
                this._hitPS = ps;
            }
            for (let i = 0; i < ps.length; i++) {
                const p = ps[i];
                (p as any).playOnAwake = false;
                try {
                    p.stop();
                    p.clear();
                } catch {
                    // ignore
                }
            }
            hit.active = false;
        }

        const sh = this._fxShatterRoot;
        if (sh && sh.isValid) {
            let ps = this._shatterPS;
            if (!ps || ps.length === 0) {
                ps = sh.getComponentsInChildren(ParticleSystem);
                this._shatterPS = ps;
            }
            for (let i = 0; i < ps.length; i++) {
                const p = ps[i];
                (p as any).playOnAwake = false;
                try {
                    p.stop();
                    p.clear();
                } catch {
                    // ignore
                }
            }
            sh.active = false;
        }
    }

    // ---------------- 내부 ----------------

    private detectSkin() {
        if (this.isBig) {
            this.skin = 'BIG';
            return;
        }

        // 프리팹이 체크를 안 해도 큰 블럭이면 자동 추정
        const ui = this.getComponent(UITransform);
        if (ui && ui.width >= 120) this.skin = 'BIG';
        else this.skin = 'SMALL';
    }

    // sprites 배열이 비어있으면 1회만 fallback 탐색(가벼운 경로 우선)
    private ensureSpritesResolved() {
        if (Array.isArray(this.sprites) && this.sprites.length > 0) return;
        if (this._resolvedOnce) return;
        this._resolvedOnce = true;

        const out: Sprite[] = [];

        // 1) 흔한 경로(가벼움)
        const base =
            this.node.getChildByPath('Root/Block') ??
            this.node.getChildByPath('Block') ??
            this.node.getChildByPath('Root') ??
            this.node;

        for (let i = 1; i <= 5; i++) {
            const nameA = `Block_${pad2(i)}`;
            const nameB = `Block_${i}`;
            const n = base.getChildByName(nameA) ?? base.getChildByName(nameB);
            const s = n?.getComponent(Sprite) ?? null;
            if (s) out.push(s);
        }

        // 2) 그래도 없으면 전체 Sprite 수집(1회만)
        if (out.length === 0) {
            const stack: Node[] = [base];
            while (stack.length) {
                const n = stack.pop()!;
                const sp = n.getComponent(Sprite);
                if (sp) out.push(sp);
                const ch = n.children;
                for (let i = ch.length - 1; i >= 0; i--) stack.push(ch[i]);
            }
        }

        this.sprites = out;

        // 셋업 누락 경고(너무 스팸이 되지 않도록 1회만)
        if (this.sprites.length === 0) {
            console.warn(
                '[TileView] sprites가 비어있습니다. 프리팹 인스펙터에서 Block Sprite들을 sprites 배열에 연결하거나, Root/Block/Block_01~05 구조를 유지해주세요. node=',
                this.node?.name,
            );
        }
    }

    // 흔들림/팝/스케일 아웃용 "바디" 노드를 1회만 캐시합니다.
    private ensureBodyResolved() {
        if (this._bodyInited) return;
        this._bodyInited = true;

        const body =
            this.node.getChildByPath('Root/Block') ??
            this.node.getChildByPath('Block') ??
            this.node.getChildByPath('Root') ??
            this.node;

        this._body = body && body.isValid ? body : this.node;

        // 프리팹 기본 트랜스폼 저장(풀링 복구용)
        const b = this._body;
        if (b && b.isValid) {
            this._bodyBasePos.set(b.position);
            this._bodyBaseScale.set(b.scale);
            this._bodyBaseRot.set(b.eulerAngles);
        }
    }

    // 외부(아틀라스 지연 로드 등)에서 강제로 다시 그릴 때 사용합니다.
    public forceRefresh() {
        this.refresh();
    }

    // 현재 상태에 맞게 SpriteFrame을 설정합니다.
    private refresh() {
        const depth = this.stack.length;
        this.node.active = depth > 0;
        if (depth <= 0) {
            // 풀링 재사용 시 overlay 잔상 제거
            this._destroySpecialOverlay();
            return;
        }

        this.ensureSpritesResolved();
        const sprites = this.sprites;

        // 표시 개수 정리(풀링 재사용 잔상 방지)
        for (let i = 0; i < sprites.length; i++) {
            const s = sprites[i];
            if (!s) continue;
            s.enabled = i < depth;
        }

        // ✅ special 종류에 따라 기본 블럭 스프라이트를 숨기는 경우가 있습니다.
        const sp = this.special;
        const hideBaseSprites =
            (sp?.t === 'KEY' && !!this._prefKey) ||
            (sp?.t === 'SPAWNER_BOX' && !!this._prefSpawnerBox) ||
            (sp?.t === 'PILLAR' && !!this._prefPillar) ||
            sp?.t === 'CHAIN_SEG';

        // 히든: Hidden 프레임으로 통일(없으면 tint로 대체)
        if (this.hidden) {
            const nm = this.skin === 'BIG' ? 'Enemy_Block_Big_Hidden' : 'Enemy_Block_Small_Hidden';
            const f = AtlasCache.frame(nm);
            for (let i = 0; i < depth; i++) {
                const s = sprites[i];
                if (!s) continue;
                if (f) {
                    s.spriteFrame = f;
                    s.color = Color.WHITE;
                } else {
                    // 아틀라스가 없거나 키가 다르면 tint로라도 히든을 표현(회색)
                    // ✅ 중요: spriteFrame을 null로 만들면(=렌더 불가) "블럭이 안 보이는" 현상이 발생합니다.
                    // - 아틀라스가 없을 때는 인스펙터(프리팹)에 이미 연결된 spriteFrame을 유지하고,
                    //   색상 tint만 회색으로 바꿔 히든을 표현합니다.
                    // - 풀링 잔상 방지는 spriteFrame을 비우는 방식이 아니라, TileView.clear()에서 FX/상태를 정리하는 쪽으로 처리합니다.
                    // ✅ 성능: Color 할당(new) 없이 in-place 갱신
                    this._tmpTint.set(160, 160, 160, 255);
                    s.color = this._tmpTint;
                }
            }
            // hidden이어도 special overlay는 유지할 수 있지만(툴/기획에 따라),
            // 현재는 히든은 "블럭이 안 보이는" 상태가 핵심이므로 overlay는 생성하지 않습니다.
            this._destroySpecialOverlay();
            return;
        }

        // 일반: bottom..top 스택을 아래->위 스프라이트에 정확히 매핑
        for (let i = 0; i < depth; i++) {
            const colorId = this.stack[i] | 0;
            const spriteIdx = toSpriteIndex(colorId, 12); // colorId(0~11) -> 01~12
            const key = pad2(spriteIdx);
            const nm = this.skin === 'BIG' ? `Enemy_Block_Big_${key}` : `Enemy_Block_Small_${key}`;
            const f = AtlasCache.frame(nm);

            const s = sprites[i];
            if (!s) continue;

            if (f) {
                s.spriteFrame = f;
                s.color = Color.WHITE;
            } else {
                // 아틀라스 미설정/키 불일치 시 tint fallback
                // ✅ 중요: spriteFrame을 null로 만들면 블럭이 사라져 보입니다.
                // - 아틀라스가 준비되지 않았거나 키가 다르면, 기존 spriteFrame(인스펙터 연결)을 유지하고 tint로만 표현합니다.
                // - 만약 기존 spriteFrame도 없다면 그때만 null이 될 수 있지만, 기본 프리팹 연결을 권장합니다.
                // ✅ 성능: Color 할당(new) 없이 in-place 갱신
                ColorPalette.applyTo(this._tmpTint, colorId);
                s.color = this._tmpTint;
            }
        }

        // ✅ base sprite 숨김 처리(생성박스/기둥)
        if (hideBaseSprites) {
            for (let i = 0; i < sprites.length; i++) {
                const s = sprites[i];
                if (!s) continue;
                s.enabled = false;
            }
        }

        // ✅ Special Overlay(키/생성박스/기둥)
        if (sp?.t === 'KEY') {
            this._ensureSpecialOverlay('KEY', this._prefKey, 0, true);
        } else if (sp?.t === 'SPAWNER_BOX') {
            // ✅ 생성박스는 "2x2" 점유/비주얼 규격
            // - (논리 점유도 2x2)
            // - cellW=60, cellH=65 예시: 120 x 135
            // - TileView는 footprint 중심에 배치되므로, 별도 offset은 0
            this._ensureSpecialOverlay('SPAWNER_BOX', this._prefSpawnerBox, 0);
            try {
                const nd = this._specialOverlay;
                if (nd && nd.isValid) {
                    const cellW = Math.max(1, Math.round(this._tileWHint || 0));
                    const cellH = Math.max(1, Math.round(this._tileHHint || 0));
                    const extraY = Math.max(0, cellH - cellW);

                    // ✅ Board의 타일 스케일 정규화와 동일하게 아주 약간의 overlap을 주고,
                    //    추가 배율(spawnerBoxScaleHint)은 인스펙터에서 튜닝 가능하도록 합니다.
                    const overlap = 4; // total px (≈ 2px per side)
                    const mulX = Math.max(0.01, this._spawnerBoxScaleHint || 1);
                    const mulY = Math.max(0.01, this._spawnerBoxScaleYHint || this._spawnerBoxScaleHint || 1);
                    this._fitOverlayToSize(
                        nd,
                        (cellW * 2 + overlap) * mulX,
                        (cellH * 2 + extraY + overlap) * mulY,
                    );
                }
            } catch {
                // ignore
            }

            // ✅ 남은 생성 횟수(HP) 표기
            // - Pre_Enemy_OBJ_Create 프리팹의 Label_Num을 업데이트
            // - queue는 [1,1,1...] 형태(길이=총 생산량), i는 소비된 개수
            try {
                const q = Array.isArray((sp as any).queue) ? ((sp as any).queue as any[]) : [];
                const i = ((sp as any).i ?? 0) | 0;
                const remain = Math.max(0, (q.length | 0) - i);
                const root = this._specialOverlay;
                const labelNode =
                    root?.getChildByName('Label_Num') ?? (root ? this._findNodeByNameDFS(root, 'Label_Num') : null);
                const lbl = labelNode?.getComponent(Label) ?? null;
                if (lbl && lbl.isValid) {
                    lbl.string = String(remain);
                    try {
                        if (labelNode && !labelNode.active) labelNode.active = true;
                    } catch {}
                }
            } catch {
                // ignore
            }
        } else if (sp?.t === 'PILLAR') {
            // ✅ footprint 중심으로 배치되므로 오프셋 0
            this._ensureSpecialOverlay('PILLAR', this._prefPillar, 0, true);
        } else {
            this._destroySpecialOverlay();
        }
    }
}
