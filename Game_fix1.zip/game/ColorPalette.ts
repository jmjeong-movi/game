import { Color, SpriteAtlas, SpriteFrame } from 'cc';

export const DEFAULT_PALETTE_HEX_12 = [
    '#fc5a59', // 01 Red
    '#e87c48', // 02 Orange
    '#e2ab2e', // 03 Yellow
    '#7fbe63', // 04 Green
    '#5eb2e4', // 05 Blue
    '#9f85e4', // 06 Purple
    '#e485c1', // 07 Pink
    '#73c7bf', // 08 Sky
    '#728fe9', // 09 Pastel Blue
    '#b2cc6f', // 10 Light Green
    '#7c7d8f', // 11 Black
    '#8b90a0', // 12 White-ish
];
export const DEFAULT_COLOR_TOKENS_12: ReadonlyArray<string> = [
    'R',
    'O',
    'Y',
    'G',
    'B',
    'P',
    'M',
    'C',
    'S',
    'L',
    'K',
    'W',
];

const DEFAULT_TINT_HEX_12 = DEFAULT_PALETTE_HEX_12.slice();

const LEGACY_8_TO_SPRITE_12 = [1, 2, 3, 4, 5, 6, 11, 12];

function clampInt(v: number, min: number, max: number) {
    return Math.max(min, Math.min(max, (v | 0) as number));
}

function hexToColor(hex: string): Color {
    const h = (hex ?? '').trim().replace('#', '');
    const r = parseInt(h.substring(0, 2), 16);
    const g = parseInt(h.substring(2, 4), 16);
    const b = parseInt(h.substring(4, 6), 16);
    if ([r, g, b].some((n) => Number.isNaN(n))) return new Color(255, 255, 255, 255);
    return new Color(r, g, b, 255);
}

export function pad2(n: number): string {
    const v = clampInt(n, 0, 99);
    return v < 10 ? `0${v}` : `${v}`;
}

export function toSpriteIndex(colorId: number, colorCount: number): number {
    const cc = clampInt(colorCount, 1, 12);
    const id = clampInt(colorId, 0, cc - 1);

    // 8색 이하일 때: 12색 아틀라스에 맞춰 맵핑
    if (cc <= 8) return LEGACY_8_TO_SPRITE_12[id] ?? 1;

    // 12색 스킴: 0->01 ... 11->12
    return id + 1;
}

export class ColorPalette {
    private static _colors: Color[] = DEFAULT_TINT_HEX_12.map(hexToColor);

    // colorId에 해당하는 팔레트 Color 참조를 반환합니다(할당 없음).
    // - 주의: 반환된 Color를 직접 수정하면 전역 팔레트가 바뀝니다. (읽기 전용으로 사용)
    static ref(colorId: number): Color {
        const n = this._colors.length;
        if (n <= 0) return Color.WHITE;
        const i = ((colorId % n) + n) % n;
        return this._colors[i];
    }

    // colorId에 해당하는 색을 out(Color)에 복사합니다(할당 없음).
    static applyTo(out: Color, colorId: number): Color {
        const c = this.ref(colorId);
        // Cocos 3.x의 일부 프로퍼티는 Readonly<Color>로 노출됩니다.
        // 채널 직접 대입(out.r = ...) 대신 set()을 사용하면 타입/플랫폼 이슈를 줄일 수 있습니다.
        out.set(c.r, c.g, c.b, 255);
        return out;
    }

    // // 팔레트(hex 리스트)를 설정합니다(없거나 비면 기본 12색 유지).
    static setFromHex(hexList: string[]) {
        const list = Array.isArray(hexList) && hexList.length > 0 ? hexList : DEFAULT_TINT_HEX_12;
        this._colors = list.map(hexToColor);
    }

    // // 현재 팔레트 색상 개수를 반환합니다.
    static count(): number {
        return this._colors.length;
    }

    // // colorId에 해당하는 Color를 반환합니다(범위 밖이면 wrap).
    static get(colorId: number): Color {
        const c = this.ref(colorId);
        return new Color(c.r, c.g, c.b, 255);
    }
}

export class LabelPalette {
    private static _custom: Color[] | null = null;
    private static _defaults: Color[] = DEFAULT_PALETTE_HEX_12.map(hexToColor);

    // // 인스펙터에서 지정한 라벨 색상(12개)을 등록합니다.
    static setCustom(colors: Color[] | null) {
        if (Array.isArray(colors) && colors.length === 12) {
            this._custom = colors.map((c) => new Color(c.r, c.g, c.b, 255));
        } else {
            this._custom = null;
        }
    }

    // // colorId에 해당하는 라벨 색상을 반환합니다.
    static get(colorId: number, colorCount: number): Color {
        const idx0 = toSpriteIndex(colorId, colorCount) - 1; // 0..11
        const src = (this._custom ?? this._defaults)[clampInt(idx0, 0, 11)];
        return new Color(src.r, src.g, src.b, 255);
    }
}

export class AtlasCache {
    private static _atlas: SpriteAtlas | null = null;
    private static _map = new Map<string, SpriteFrame>();

    // // 사용할 SpriteAtlas를 등록합니다.
    static setAtlas(atlas: SpriteAtlas | null) {
        this._atlas = atlas;
        this._map.clear();
    }

    // // 이름으로 SpriteFrame을 얻습니다(없으면 null).
    static frame(name: string): SpriteFrame | null {
        const a = this._atlas;
        if (!a) return null;

        // 1) 캐시
        const cached = this._map.get(name);
        if (cached) return cached;

        // 2) 아틀라스 키가 `.png` 확장자를 포함하는 프로젝트가 있어 fallback 처리
        const f0 = a.getSpriteFrame(name) ?? null;
        const f1 = f0 ? f0 : (a.getSpriteFrame(`${name}.png`) ?? null);

        if (f1) this._map.set(name, f1);
        return f1;
    }
}

// // 외부에서 간단히 쓰기 위한 헬퍼
export function colorFromId(colorId: number): Color {
    return ColorPalette.get(colorId);
}
