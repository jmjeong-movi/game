# StageTool (stage-tool-v8)

웹(React + Vite) 기반 스테이지 에디터입니다.

## 1) 개발 실행

```bash
npm i
npm run dev
```

브라우저에서 열립니다.

## 2) Electron으로 데스크톱 실행(개발)

```bash
npm i
npm run electron:dev
```

## 3) 설치 파일(EXE) 만들기

```bash
npm i
npm run dist
```

- 결과물: `release/StageTool Setup 0.8.0.exe`
- 빌드 중 `release/.../d3dcompiler_47.dll: Access is denied`가 뜨면:
  1) 실행 중인 StageTool/Electron 창을 모두 종료
  2) `release/` 폴더를 삭제 후 다시 `npm run dist`

## 4) 다른 PC에서 사용

- 개발(소스) 그대로 전달: Node.js(권장 LTS) 설치 후 `npm i` 필요
- 설치형 전달: `release/...Setup...exe`만 전달하면 됩니다(설치 후 바로 실행 가능)
