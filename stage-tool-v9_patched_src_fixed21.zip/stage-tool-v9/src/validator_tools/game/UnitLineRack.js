"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var UnitLineRack_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnitLineRack = void 0;
const cc_1 = require("cc");
const Types_1 = require("./Types");
const ColorPalette_1 = require("./ColorPalette");
const Board_1 = require("./Board");
const AudioManager_1 = require("../core/AudioManager");
const { ccclass, property } = cc_1._decorator;
const MUZZLE_COLOR_HEX = [
    'FC5A59',
    'E87C48',
    'E2AB2E',
    '7FBE63',
    '5EB2E4',
    '9F85E4',
    'E485C1',
    '73C7BF',
    '728FE9',
    'B2CC6F',
    '7C7D8F',
    '8B90A0',
];
// ✅ Muzzle FX 노드 표시용(컴포넌트 추가 없이 풀링 안전하게 회수)
// - 역할: 스테이지 전환/유닛 풀링 회수 시, 아직 살아있는 발사 파티클이 유닛에 붙은 채로
//         다음 스폰에서 "유닛이 나오자마자 발사 파티클"처럼 보이는 문제를 방지
// - 설명: muzzleFxPrefab 인스턴스 노드에 이 태그를 달아두고, 유닛 회수/스폰 시 잔여 FX를 제거합니다.
const MUZZLE_FX_TAG = '__muzzleFx';
let UnitLineRack = UnitLineRack_1 = class UnitLineRack extends cc_1.Component {
    constructor() {
        super(...arguments);
        this.shootingLine = null;
        this.waitingLine01 = null;
        this.waitingLine02 = null;
        this.waitingLine03 = null;
        this.unitPrefab = null;
        this.muzzleFxPrefab = null;
        this.muzzleFxRecycleSec = 0.35;
        this.muzzleFxWarmup = 24;
        this.board = null;
        this.targetPref = 'LEFT';
        this.fireIntervalSec = 0.01;
        this.bigTargetFireIntervalSec = 0.01;
        this.dualSecondShotDelaySec = 0.016;
        this.dualSecondShotDelayBigSec = 0.0;
        this.retryIntervalSec = 0.03;
        this.maxAttemptsPerTick = 2;
        this.scaleShooting = 0.72;
        this.scaleWaiting01 = 0.82;
        this.scaleWaiting02 = 0.92;
        this.scaleWaiting03 = 1.0;
        this.equipMoveSec = 0.22;
        this.equipJumpY = 70;
        this.shiftMoveSec = 0.12;
        this.poolWarmup = 20;
        this.aimSmoothSpeed = 14;
        this.aimRefreshSec = 0.07;
        this.targetHoldSec = 0.18;
        this.reacquireDelaySec = 0.07;
        this.postEquipDelaySec = 0.1;
        this.aimMaxStepPerFrame = 45;
        this.aimReturnSpeed = 0;
        this._pool = new cc_1.NodePool('UnitLineRackPool');
        this._muzzleFxPool = new cc_1.NodePool('UnitLineRackMuzzleFxPool');
        this._fxActive = [];
        this._uiTr = null;
        // ✅ 재사용 스택(DFS 탐색용)
        // 풀링 재사용 시 Label_Num이 Skeleton 아래로 재부모화되는 케이스가 있어도 안정적으로 찾기 위함
        this._tmpNodeStack = [];
        // Place(바닥) - 활성/비활성/슬롯 유효성 판단은 이걸로
        this._placesS = [];
        // UnitPlace(유닛 레이어) - 유닛은 여기에 배치(없으면 Place로 fallback)
        this._unitPlacesS = [];
        this._placesW1 = [];
        this._placesW2 = [];
        this._placesW3 = [];
        this._slotS = [null, null, null, null, null];
        // ✅ Stage 전환 감지용 토큰(보드의 stageId/stageIndex 등을 읽어 변화 시 유닛 포즈를 1회 리셋)
        this._lastStageToken = undefined;
        // ✅ 색상별 BIG(2x2) 고정 매칭(유닛 슬롯 -> BIG entId)
        // - 같은 색 유닛 여러 개 + BIG 여러 개일 때, 각 유닛이 "자기 BIG"을 깨질 때까지 고정으로 쏘도록 합니다.
        // - 매 프레임 즉흥 선택으로 BIG을 서로 바꿔잡는(왔다갔다) 문제를 근본적으로 차단합니다.
        this._bigAssignByColor = new Map();
        this._slotW1 = [null, null, null, null, null];
        this._slotW2 = [null, null, null, null, null];
        this._slotW3 = [null, null, null, null, null];
        this._slotByNode = new WeakMap();
        // ✅ 아이템: 유닛 선택 모드(대기라인 유닛 탭 → 슈팅라인 배치)
        this._itemSelectUnitActive = false;
        // ✅ 섞기용 버퍼(재사용 → GC 최소화)
        this._tmpShuffleSlots = [];
        this._tmpShuffleData = [];
        this._overflowByCol = Array.from({ length: 5 }, () => []); // ✅ 대기라인 초과분(가상 WaitingLine04+)
        this._overflowHeadByCol = [0, 0, 0, 0, 0]; // ✅ shift() 비용 제거(컬럼별 head)
        this._tmpW0 = new cc_1.Vec3();
        this._tmpW1 = new cc_1.Vec3();
        this._tmpL0 = new cc_1.Vec3();
        this._tmpL1 = new cc_1.Vec3();
        this._tmpMuzzleW0 = new cc_1.Vec3();
        this._tmpMuzzleW1 = new cc_1.Vec3();
        this._tmpMat = new cc_1.Mat4();
        this._tmpMatInv = new cc_1.Mat4();
        this._tmpSkelLocal = new cc_1.Vec3();
        this._tmpAimWorld = new cc_1.Vec3();
        this._tmpReparentW = new cc_1.Vec3();
        this._tmpReparentL = new cc_1.Vec3();
        this._vLandUp = new cc_1.Vec3(0, 8, 0);
        this._vZero = new cc_1.Vec3(0, 0, 0);
        this._tParamPool = [];
        this._cooldownsS = [0, 0, 0, 0, 0];
        // ✅ 유닛별 슈팅 SFX(0~2) 고정 배정용 시리얼
        this._shotSfxSerial = 0;
        // ✅ 2단계 Lock: overflow(대기라인 초과분) 보충 유지용 틱(아이템/외부 로직으로 구멍이 생겨도 자동 복구)
        this._overflowMaintainCd = 0;
        this._onUnitTouchEnd = (ev) => {
            const n = ev?.target;
            if (!n || !n.isValid)
                return;
            const slot = this._slotByNode.get(n);
            if (!slot)
                return;
            // ✅ 이동 중(W2→W1 당김 포함) 탭 처리:
            // - 순간이동/중복 이동은 금지
            // - ✅ 단, 'W2→W1 당김 이동' 중 탭하면 **즉시 슈팅라인 장착**(예약 아님)
            //   - UX: 빠른 연속 탭에서도 "이동 중이라도 바로 장착" 동작
            //   - 안정성: 이동 tween(TParam)을 강제 종료해 '사라짐/튀김'을 방지
            if (slot.moving) {
                if (!this._itemSelectUnitActive && slot.line === 'W1') {
                    // 빈 슈팅 슬롯이 있을 때만 즉시 장착
                    if (this._findFirstEmptyShooting() >= 0) {
                        slot.equipQueued = false;
                        this._forceFinishMove(slot); // ✅ 이동 강제 종료(부모/좌표/스케일 정리)
                        this._equipFromWaiting('W1', slot.index | 0);
                    }
                    else {
                        // 슈팅라인이 가득 찼으면 아무것도 하지 않음(예약도 하지 않음)
                        slot.equipQueued = false;
                    }
                }
                return;
            }
            // ✅ 아이템 모드: W1/W2/W3 모두 선택 가능
            if (this._itemSelectUnitActive) {
                if (slot.line === 'W1' || slot.line === 'W2' || slot.line === 'W3') {
                    const ok = this._equipFromWaiting(slot.line, slot.index);
                    if (ok)
                        this._itemSelectUnitActive = false; // 1회 소모
                }
                return;
            }
            // 기본 모드: 기존 룰 유지(W1만 탭 장착)
            if (slot.line !== 'W1')
                return;
            this._equipFromWaiting01(slot.index);
        };
    }
    /**
     * ✅ 역할: 유닛(CardData)마다 슈팅 사운드(0~2)를 "한 번만" 정해서 고정 저장합니다.
     * 설명:
     * - data.shotSfxIdx가 이미 있으면 그대로 사용(0~2로 clamp)
     * - 없으면 serial + colorId를 섞어서 0..2를 부여 후 data에 저장
     * - 셔플/이동/재배치가 되어도 CardData에 저장되어 유지됩니다.
     */
    _ensureShotSfxIdx(data) {
        if (!data)
            return 0;
        let v = data.shotSfxIdx;
        if (typeof v === 'number') {
            v = v | 0;
            if (v < 0)
                v = 0;
            if (v > 2)
                v = 2;
            data.shotSfxIdx = v;
            return v;
        }
        const cid = (data.colorId | 0) * 7;
        const idx = ((this._shotSfxSerial++ + cid) % 3) | 0;
        data.shotSfxIdx = idx;
        return idx;
    }
    onLoad() {
        this._uiTr = this.getComponent(cc_1.UITransform) || this.addComponent(cc_1.UITransform);
        this._cachePlaces();
        this._prewarmPool();
        this._prewarmMuzzleFx();
    }
    onDestroy() {
        this.clearAll(true);
        this._pool.clear();
        this._muzzleFxPool.clear();
        this._tParamPool.length = 0;
        this._fxActive.length = 0;
    }
    update(dt) {
        const b = this.board;
        if (!b || !b.isValid)
            return;
        // 파티클 회수
        this._tickFxRecycle(dt);
        // ✅ Stage 전환 시(보드의 stageId/stageIndex 등이 바뀌는 경우) 유닛 포즈(조준/IK)를 1회 초기화
        // - 보드 구현이 다를 수 있어, 존재하는 필드만 안전하게 탐색합니다.
        const token = b.stageId ??
            b.stageIndex ??
            b.stageNo ??
            b.runtimeId ??
            b._stageId ??
            b._stageIndex;
        if (token !== undefined && token !== this._lastStageToken) {
            this._lastStageToken = token;
            this._resetAllExistingUnitPoses();
            // ✅ 스테이지가 바뀌면 BIG 고정 매칭도 초기화
            this._bigAssignByColor.clear();
        }
        const smoothSpeed = Math.max(0, this.aimSmoothSpeed);
        const returnSpeed = Math.max(0, this.aimReturnSpeed);
        const refreshSec = Math.max(0.02, this.aimRefreshSec);
        const holdSec = Math.max(0, this.targetHoldSec);
        const reacqSec = Math.max(0, this.reacquireDelaySec);
        const maxStep = Math.max(0, this.aimMaxStepPerFrame);
        // -------------------------
        // ✅ BIG(2x2) 고정 매칭(색 그룹 단위)
        // - "BIG 1개당 유닛 1개 고정" + "BIG 개수만큼 BIG 분배" 정책 구현
        // - 같은 색 유닛들이 매 발사마다 BIG을 서로 바꿔잡는 문제(타겟 왔다갔다) 방지
        // -------------------------
        const unitsByColor = new Map(); // colorId -> shooting slot indices
        for (let i = 0; i < 5; i++) {
            const placeBase = this._placesS[i];
            if (!placeBase || !placeBase.isValid || !placeBase.activeInHierarchy)
                continue;
            const slot = this._slotS[i];
            if (!slot || !slot.node?.isValid)
                continue;
            if (slot.moving)
                continue;
            const d = slot.data;
            if (!d)
                continue;
            const ammoLeft = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
            if (ammoLeft <= 0)
                continue;
            const c = (d.colorId | 0);
            let arr = unitsByColor.get(c);
            if (!arr) {
                arr = [];
                unitsByColor.set(c, arr);
            }
            arr.push(i);
        }
        const getBigAssign = (colorId) => {
            const k = colorId | 0;
            let a = this._bigAssignByColor.get(k);
            if (!a) {
                a = { unitToEnt: new Map(), entToUnit: new Map() };
                this._bigAssignByColor.set(k, a);
            }
            return a;
        };
	    // Update assignment per color (Deterministic)
	    // 규칙:
	    // - BIG: 항상 좌→우 우선
	    // - 유닛: 장착 순서(hintStep) 우선, 동률이면 슬롯 인덱스
	    // - 매 프레임 현재 상태로 매칭을 재구성(유닛 제거/추가 시 즉시 재배치)
	    for (const [colorId, unitIdxsRaw] of unitsByColor) {
	        const a = getBigAssign(colorId);
	        a.unitToEnt.clear();
	        a.entToUnit.clear();
	        // shootable BIGs for this color (좌→우)
	        const bigs = b.listRow0BigEnts ? b.listRow0BigEnts(colorId, 'LEFT') : (b.listShootableBigEnts ? b.listShootableBigEnts(colorId, 'LEFT') : []);
	        if (!unitIdxsRaw || unitIdxsRaw.length <= 0 || !bigs || bigs.length <= 0)
	            continue;
	        const unitIdxs = unitIdxsRaw.slice();
	        unitIdxs.sort((aIdx, bIdx) => {
	            const aS = this._slotS[aIdx];
	            const bS = this._slotS[bIdx];
	            const ae = (aS?.data?.hintStep | 0) || 0;
	            const be = (bS?.data?.hintStep | 0) || 0;
	            return ae - be || (aIdx | 0) - (bIdx | 0);
	        });
	        const budget = Math.min(unitIdxs.length, bigs.length);
	        for (let i = 0; i < budget; i++) {
	            const u = unitIdxs[i] | 0;
	            const entId = (bigs[i]?.entId | 0);
	            if (!entId)
	                continue;
	            a.unitToEnt.set(u, entId);
	            a.entToUnit.set(entId, u);
	        }
	    }
        const planByColor = new Map();
        const getPlan = (colorId) => {
            const k = colorId | 0;
            let p = planByColor.get(k);
            if (!p) {
                // BIG budget는 해당 colorId에서 지금(row0) 쏠 수 있는 BIG 개수만큼
                // ✅ 타겟 우선순위는 항상 좌→우
                const bb = b.countRow0Big ? b.countRow0Big(k, 'LEFT') : (b.countShootableBig ? b.countShootableBig(k, 'LEFT') : 0);
                // ✅ 엔티티 고정 매칭이 이미 잡아둔 BIG은 이번 프레임 계획에서 "이미 사용" 처리
                // - 다른 유닛이 그 BIG을 뺏어가는 것을 방지
                const assign = getBigAssign(k);
                const usedEnt = new Set();
                const usedBig = new Set();
                for (const entId of assign.unitToEnt.values()) {
                    usedEnt.add(entId | 0);
                    usedBig.add(entId | 0);
                }
                p = { ent: usedEnt, bigBudget: bb | 0, bigEnt: usedBig };
                planByColor.set(k, p);
            }
            return p;
        };
        for (let i = 0; i < 5; i++) {
            // ✅ 유효 슬롯 판단은 Place(바닥) 기준
            const placeBase = this._placesS[i];
            if (!placeBase || !placeBase.isValid || !placeBase.activeInHierarchy)
                continue;
            const slot = this._slotS[i];
            if (!slot || !slot.node?.isValid)
                continue;
            if (slot.moving)
                continue;
            const d = slot.data;
            if (!d)
                continue;
            // 예약 듀얼 2번째 발 카운트다운
            if (slot.pendingDual && slot.pendingT > 0)
                slot.pendingT = Math.max(0, slot.pendingT - dt);
            let ammoLeft = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
            if (ammoLeft <= 0) {
                this._recycleAmmoEmpty(slot);
                continue;
            }
            if (slot.targetHoldT > 0)
                slot.targetHoldT = Math.max(0, slot.targetHoldT - dt);
            if (slot.targetStickyT > 0)
                slot.targetStickyT = Math.max(0, slot.targetStickyT - dt);
            if (slot.reacquireDelayT > 0)
                slot.reacquireDelayT = Math.max(0, slot.reacquireDelayT - dt);
            if (slot.postEquipDelayT > 0)
                slot.postEquipDelayT = Math.max(0, slot.postEquipDelayT - dt);
            // -------------------------
            // 에임 락 타이머(발사 중 본 흔들림 방지)
            // -------------------------
            if (slot.aimLockT > 0)
                slot.aimLockT = Math.max(0, slot.aimLockT - dt);
            // -------------------------
            // 타겟 갱신(주기)
            // -------------------------
            slot.aimRefreshCd -= dt;
            if (slot.aimRefreshCd <= 0) {
                slot.aimRefreshCd = refreshSec;
                // ✅ 발사 중에는 에임 타겟을 재계산하지 않습니다(본이 좌우로 튀는 현상 방지)
                if (slot.aimLockT <= 0) {
                    const colorId = d.colorId | 0;
                    const mode = this._getMode(slot.data);
                    const wantShots = mode === 2 ? Math.min(2, ammoLeft) : 1;
                    // ✅ 낙하/정렬 중 타겟은 우선 제외
                    const plan = getPlan(colorId);
                    const targets = this._pickTargetsSkippingMoving(b, colorId, wantShots, slot, plan);
                    slot.canShootNow = targets.length > 0;
                    if (targets.length > 0) {
                        // aim target: 2발이면 중간점, 1발이면 그대로
                        if (mode === 2 && targets.length >= 2) {
                            this._tmpAimWorld.x = (targets[0].world.x + targets[1].world.x) * 0.5;
                            this._tmpAimWorld.y = (targets[0].world.y + targets[1].world.y) * 0.5;
                            this._tmpAimWorld.z = (targets[0].world.z + targets[1].world.z) * 0.5;
                        }
                        else {
                            this._tmpAimWorld.set(targets[0].world);
                        }
                        const ok = this._computeIkLocalFromWorld(slot, this._tmpAimWorld);
                        if (ok) {
                            if (!slot.aimHasTarget)
                                slot.reacquireDelayT = reacqSec;
                            slot.aimHasTarget = true;
                            slot.targetHoldT = holdSec;
                            slot.aimDesX = this._tmpSkelLocal.x;
                            slot.aimDesY = this._tmpSkelLocal.y;
                        }
                    }
                    else {
                        if (slot.targetHoldT <= 0)
                            slot.aimHasTarget = false;
                    }
                }
            }
            if (slot.aimHasTarget && slot.targetHoldT <= 0)
                slot.aimHasTarget = false;
            // 애니 전환
            if (slot.aimHasTarget && (slot.canShootNow || slot.targetHoldT > 0))
                this._ensureAnim(slot, 'Attack');
            else
                this._ensureAnim(slot, 'Idle');
            // 조준 스무딩
            if (smoothSpeed > 0 || returnSpeed > 0) {
                const has = slot.aimHasTarget;
                // ✅ 역할: 타겟이 없을 때도 '중앙(Idle 포즈의 IK 기준점)'으로 자연스럽게 복귀
                // - 리그마다 중앙 좌표가 (0,0)이 아닐 수 있으므로 slot.aimHomeX/Y 사용
                // - ShootingLine(S)은 aimReturnSpeed가 0이어도 중앙 복귀를 강제(대기 시 정면 유지)
                const shouldReturnToHome = !has && slot.line === 'S';
                let speed = has ? smoothSpeed : returnSpeed;
                if (shouldReturnToHome && speed <= 0)
                    speed = smoothSpeed > 0 ? smoothSpeed : 12;
                if (speed > 0) {
                    const alpha = 1 - Math.exp(-dt * speed);
                    const homeX = slot.aimHomeInited ? slot.aimHomeX : 0;
                    const homeY = slot.aimHomeInited ? slot.aimHomeY : 0;
                    const tx = has ? slot.aimDesX : shouldReturnToHome || returnSpeed > 0 ? homeX : slot.aimCurX;
                    const ty = has ? slot.aimDesY : shouldReturnToHome || returnSpeed > 0 ? homeY : slot.aimCurY;
                    if (!slot.aimInited) {
                        slot.aimCurX = tx;
                        slot.aimCurY = ty;
                        slot.aimInited = true;
                        this._applyIkLocal(slot, slot.aimCurX, slot.aimCurY);
                    }
                    else {
                        let nx = slot.aimCurX + (tx - slot.aimCurX) * alpha;
                        let ny = slot.aimCurY + (ty - slot.aimCurY) * alpha;
                        if (maxStep > 0) {
                            const dx = nx - slot.aimCurX;
                            const dy = ny - slot.aimCurY;
                            const len = Math.sqrt(dx * dx + dy * dy);
                            if (len > maxStep) {
                                const inv = maxStep / len;
                                nx = slot.aimCurX + dx * inv;
                                ny = slot.aimCurY + dy * inv;
                            }
                        }
                        if (Math.abs(nx - slot.aimCurX) > 0.05 || Math.abs(ny - slot.aimCurY) > 0.05) {
                            slot.aimCurX = nx;
                            slot.aimCurY = ny;
                            this._applyIkLocal(slot, nx, ny);
                        }
                    }
                }
            }
            // 발사 조건
            if (!slot.aimHasTarget || !slot.canShootNow || slot.postEquipDelayT > 0 || slot.reacquireDelayT > 0) {
                this._cooldownsS[i] = Math.max(0, (this._cooldownsS[i] ?? 0) - dt);
                continue;
            }
            let cd = (this._cooldownsS[i] ?? 0) - dt;
            let attempts = 0;
            while (cd <= 0 && attempts++ < (this.maxAttemptsPerTick | 0)) {
                ammoLeft = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
                if (ammoLeft <= 0) {
                    this._recycleAmmoEmpty(slot);
                    break;
                }
                const colorId = d.colorId | 0;
                const mode = this._getMode(slot.data);
                const wantShots = mode === 2 ? Math.min(2, ammoLeft) : 1;
                let fired = 0;
                let usedBig = false;
                // ✅ 1) 듀얼 2번째 발 예약이 있고 시간이 됐다면, 그 발부터 처리(동시발사 방지)
                if (mode === 2 && slot.pendingDual && slot.pendingT <= 0 && ammoLeft > 0) {
                    const m = slot.pendingMuzzle;
                    if (!this._getMuzzleWorld(slot, m, this._tmpMuzzleW0)) {
                        if (!this._getMuzzleWorld(slot, 'C', this._tmpMuzzleW0))
                            slot.node.getWorldPosition(this._tmpMuzzleW0);
                    }
                    const okP = b.tryShootAtColumn(this._tmpMuzzleW0, slot.pendingColorId, slot.pendingCol);
                    if (okP) {
                        this._playMuzzleFx(slot, m, slot.pendingColorId);
                        slot.aimLockT = Math.max(slot.aimLockT, 0.06);
                        ammoLeft = this._consumeAmmo(slot, 1);
                        fired = 1;
                        usedBig = !!slot.pendingIsBig;
                        // extend sticky on successful hit
                        try {
                            const e = b.entAt?.(0, slot.pendingCol);
                            if (e) {
                                slot.targetEntId = e.id | 0;
                                slot.targetCol = slot.pendingCol | 0;
                                slot.targetStickyT = Math.max(slot.targetStickyT, 0.7);
                            }
                        }
                        catch { }
                        // 성공했을 때만 flip 진행
                        slot.dualFlip = slot.dualFlip === 0 ? 1 : 0;
                        // 예약 해제
                        slot.pendingDual = false;
                        slot.pendingT = 0;
                        if (ammoLeft <= 0) {
                            this._recycleAmmoEmpty(slot);
                            cd = this.fireIntervalSec;
                            break;
                        }
                    }
                    else {
                        // 타겟이 변했거나 예약 컬럼이 막혔으면 예약은 버리고 다음 로직에서 재획득
                        slot.pendingDual = false;
                        slot.pendingT = 0;
                    }
                }
                // ✅ 2) 예약 발을 못 쐈다면, 일반 발사 처리
                if (fired === 0) {
                    const plan = getPlan(colorId);
                    const targets = this._pickTargetsSkippingMoving(b, colorId, wantShots, slot, plan);
                    if (targets.length <= 0) {
                        cd += this.retryIntervalSec;
                        // ✅ 타겟이 사라졌을 때(예: BIG 파괴 직후): 다음 틱에 즉시 재탐색하도록 강제
                        // - aimLockT가 남아 있으면 조준 갱신이 막혀 "멈춘" 것처럼 보일 수 있음
                        slot.canShootNow = false;
                        slot.aimLockT = 0;
                        slot.aimRefreshCd = 0;
                        break;
                    }
                    if (mode === 1) {
                        // 단일포
                        if (!this._getMuzzleWorld(slot, 'C', this._tmpMuzzleW0))
                            slot.node.getWorldPosition(this._tmpMuzzleW0);
                        const ok = b.tryShootAtColumn(this._tmpMuzzleW0, colorId, targets[0].col);
                        if (ok) {
                            this._playMuzzleFx(slot, 'C', colorId);
                            // ✅ 발사 중 에임 고정(본 흔들림 방지)
                            slot.aimLockT = Math.max(slot.aimLockT, 0.06);
                            ammoLeft = this._consumeAmmo(slot, 1);
                            fired = 1;
                            usedBig = !!targets[0]?.isBig;
                            // extend sticky on successful hit
                            slot.targetEntId = targets[0].entId | 0;
                            slot.targetCol = targets[0].col | 0;
                            slot.targetStickyT = Math.max(slot.targetStickyT, 0.7);
                            if (ammoLeft <= 0) {
                                this._recycleAmmoEmpty(slot);
                                cd = this.fireIntervalSec;
                                break;
                            }
                        }
                    }
                    else {
                        // ✅ 듀얼포: 1발만 즉시 발사 + 2번째 발은 예약(딜레이)
                        const t0 = targets[0];
                        const t1 = targets.length > 1 ? targets[1] : targets[0];
                        const first = slot.dualFlip === 0 ? 'L' : 'R';
                        const second = first === 'L' ? 'R' : 'L';
                        if (!this._getMuzzleWorld(slot, first, this._tmpMuzzleW0)) {
                            if (!this._getMuzzleWorld(slot, 'C', this._tmpMuzzleW0))
                                slot.node.getWorldPosition(this._tmpMuzzleW0);
                        }
                        // 1) 첫 발
                        const ok0 = b.tryShootAtColumn(this._tmpMuzzleW0, colorId, t0.col);
                        if (ok0) {
                            this._playMuzzleFx(slot, first, colorId);
                            // ✅ 발사 중 에임 고정(본 흔들림 방지)
                            slot.aimLockT = Math.max(slot.aimLockT, 0.06);
                            ammoLeft = this._consumeAmmo(slot, 1);
                            fired = 1;
                            usedBig = !!t0?.isBig;
                            // extend sticky on successful hit
                            slot.targetEntId = (t0.entId | 0);
                            slot.targetCol = (t0.col | 0);
                            slot.targetStickyT = Math.max(slot.targetStickyT, 0.7);
                            // 성공했을 때만 flip 진행
                            slot.dualFlip = slot.dualFlip === 0 ? 1 : 0;
                            if (ammoLeft <= 0) {
                                this._recycleAmmoEmpty(slot);
                                cd = this.fireIntervalSec;
                                break;
                            }
                            // 2) 두 번째 발 예약(동시발사 방지)
                            if (wantShots >= 2 && t1) {
                                const sameEnt = (t1.entId | 0) === (t0.entId | 0);
                                const isBigSingle = !!t0?.isBig && sameEnt;
                                const delay = isBigSingle
                                    ? Math.max(0, this.dualSecondShotDelayBigSec)
                                    : Math.max(0, this.dualSecondShotDelaySec);
                                slot.pendingDual = true;
                                slot.aimLockT = Math.max(slot.aimLockT, delay + 0.06);
                                slot.pendingT = delay;
                                slot.pendingCol = t1.col | 0;
                                slot.pendingColorId = colorId | 0;
                                slot.pendingMuzzle = second;
                                slot.pendingIsBig = isBigSingle;
                            }
                        }
                    }
                }
                // ✅ 발사 템포는 거리/타겟 크기와 무관하게 항상 동일
                cd += fired > 0 ? this.fireIntervalSec : this.retryIntervalSec;
                if (fired === 0)
                    break;
            }
            this._cooldownsS[i] = cd;
        }
        // ✅ 2단계 Lock: overflow 유지(아이템/외부 로직으로 대기라인에 구멍이 생겨도 자동으로 복구)
        // - 너무 자주 돌면 연출과 충돌할 수 있어 0.08초 간격으로만 점검합니다.
        this._overflowMaintainCd -= dt;
        if (this._overflowMaintainCd <= 0) {
            this._overflowMaintainCd = 0.08;
            this._maintainWaitingOverflow();
        }
    }
    // -----------------------------
    // ✅ 타겟 디테일: "내려오는(이동 중) 엔티티"는 우선 제외
    // -----------------------------
    _pickTargetsSkippingMoving(b, colorId, wantShots, slot, plan) {
        // ✅ 항상 좌→우(왼쪽 우선)
        // - 사용자 요구: 왼쪽부터 오른쪽으로 갈수록 우선순위가 낮아짐
        const pref = 'LEFT';
        const applySticky = (picked) => {
            if (picked && picked.length > 0) {
                slot.targetEntId = picked[0].entId | 0;
                slot.targetCol = picked[0].col | 0;
                // keep sticky at least a bit to avoid flicker; will auto-invalidate when target disappears.
                slot.targetStickyT = Math.max(slot.targetStickyT, 0.5);
            }
            return picked;
        };
        // ✅ BIG 고정 매칭 우선 적용
        // - 같은 색 유닛이 BIG 여러 개를 "서로 바꿔쏘는" 문제를 차단
        // - 매칭된 BIG이 shootable이면 무조건 그 BIG을 1타겟으로 사용
        const assigned = this._bigAssignByColor.get(colorId | 0);
        const assignedEntId = (assigned?.unitToEnt.get(slot.index | 0) ?? 0) | 0;
        const hasAssignedBig = assignedEntId > 0;
        if (hasAssignedBig && b.isShootableEnt) {
            const okA = b.isShootableEnt(colorId, assignedEntId);
            if (okA && okA.ok) {
                const colA = (okA.col | 0);
                const eA = b.entAt?.(0, colA);
                const t0 = {
                    col: colA,
                    entId: assignedEntId,
                    world: b.cellWorldPos?.(0, colA),
                    isBig: true,
                    hp: eA?.view?.getHp?.() ?? 0,
                };
                // mark used for same-color planning
                plan.ent.add(assignedEntId);
                plan.bigEnt.add(assignedEntId);
                // set sticky to the assigned BIG (prevents swap)
                slot.targetEntId = assignedEntId;
                slot.targetCol = colA;
                slot.targetStickyT = Math.max(slot.targetStickyT, 0.8);
                if (wantShots <= 1)
                    return applySticky([t0]);
                // second shot: never pick another BIG if this unit already owns a BIG
                const more = b.pickShootTargets(colorId, wantShots - 1, pref, plan.ent, false);
                return applySticky([t0, ...more].slice(0, wantShots));
            }
        }
        // 0) Sticky target: keep current target if still shootable.
        // - prevents per-shot retarget jitter (IK 왔다갔다)
        // - allows other same-color units to pick different targets via `plan`.
        if ((slot.targetEntId | 0) > 0) {
            const okSticky = b.isShootableEnt
                ? b.isShootableEnt(colorId, slot.targetEntId | 0)
                : { ok: false, col: -1 };
            if (okSticky && okSticky.ok) {
                // Mark current target into plan so other same-color units won't pick it.
                plan.ent.add(slot.targetEntId | 0);
                const stickyCol = (okSticky.col | 0);
                slot.targetCol = stickyCol;
                const e = b.entAt?.(0, stickyCol);
                const isBig = !!(e && (e.w > 1 || e.h > 1));
                if (isBig)
                    plan.bigEnt.add(slot.targetEntId | 0);
                const t0 = {
                    col: stickyCol,
                    entId: slot.targetEntId | 0,
                    world: b.cellWorldPos?.(0, slot.targetCol | 0),
                    isBig,
                    hp: isBig ? (e?.view?.getHp?.() ?? 0) : 0,
                };
                if (wantShots <= 1)
                    return applySticky([t0]);
                // For dual-shot, try to find a second distinct target (same color) if available.
                // If not, caller will just shoot once.
                // For second shot: BIG은 "BIG 개수만큼 분배" 정책을 지키기 위해
                // - 이미 BIG이 충분히 배정되었다면 BIG을 허용하지 않고 SMALL로만 채웁니다.
                // second shot: if this unit has an assigned BIG, do NOT steal another BIG
                const allowBig2 = !hasAssignedBig && plan.bigEnt.size < Math.max(0, plan.bigBudget | 0);
                const more = b.pickShootTargets(colorId, wantShots - 1, pref, plan.ent, allowBig2);
                return applySticky([t0, ...more].slice(0, wantShots));
            }
            else {
                // Invalidate sticky if not shootable anymore.
                slot.targetEntId = 0;
                slot.targetCol = -1;
                slot.targetStickyT = 0;
            }
        }
        // 1) Fresh pick (with plan excludes)
        // ✅ BIG 분배 정책:
        // - 같은 색 유닛이 여러 개일 때, BIG은 "BIG 개수만큼"만 분배(엔티티 중복 금지)
        // - BIG이 이미 모두 배정되었다면, 이후 유닛/샷 슬롯은 SMALL에서 "엔티티"만 중복되지 않게 선택
        // if this unit already has an assigned BIG (even if temporarily not shootable), do NOT pick other BIGs.
        const allowBig = !hasAssignedBig && plan.bigEnt.size < Math.max(0, plan.bigBudget | 0);
        const targets = b.pickShootTargets(colorId, wantShots, pref, plan.ent, allowBig);
        if (targets.length > 0 && !!targets[0]?.isBig) {
            plan.bigEnt.add(targets[0].entId | 0);
        }
        // board가 moving 판별 API가 없으면 그대로 사용
        const isMovingFn = b.isEntMoving;
        if (typeof isMovingFn !== 'function')
            return applySticky(targets);
        // 1) moving 아닌 것만 먼저
        const stable = [];
        for (let i = 0; i < targets.length; i++) {
            const t = targets[i];
            if (!t)
                continue;
            if (!isMovingFn.call(b, t.entId))
                stable.push(t);
        }
        if (stable.length > 0) {
            // 듀얼이면 2개까지
            if (stable.length >= wantShots)
                return applySticky(stable.slice(0, wantShots));
            // 부족하면 나머지로 채우기(그래도 없으면 moving 허용)
            const out = stable.slice();
            for (let i = 0; i < targets.length && out.length < wantShots; i++) {
                const t = targets[i];
                if (!t)
                    continue;
                if (out.indexOf(t) >= 0)
                    continue;
                out.push(t);
            }
            return applySticky(out);
        }
        // 2) stable이 하나도 없으면 원래 targets로(다른 타겟이 없으니 어쩔 수 없음)
        return applySticky(targets);
    }
    // -----------------------------
    // Public API
    // -----------------------------
    /**
     * ✅ 클리어 실패 판정(요구사항)
     * - 슈팅라인 슬롯이 모두 찼고
     * - 장착된 유닛 전체가 "쏠 타겟이 없음"이면 true
     */
    isStuckNoShootTargets(board) {
        const b = board;
        if (!b || !b.isValid)
            return false;
        // 현재 활성 슈팅 슬롯 수(Place가 활성화된 개수)
        let capacity = 0;
        let filled = 0;
        for (let i = 0; i < 5; i++) {
            const place = this._placesS?.[i];
            if (!place || !place.isValid || !place.activeInHierarchy)
                continue;
            capacity++;
            if (this._slotS[i])
                filled++;
        }
        if (capacity <= 0)
            return false;
        if (filled < capacity)
            return false; // 슬롯이 덜 찼으면 실패 아님
        // 슬롯이 꽉 찼다: 모든 유닛이 타겟이 0인지 확인
        for (let i = 0; i < 5; i++) {
            const slot = this._slotS[i];
            if (!slot || !slot.data)
                continue;
            const colorId = slot.data.colorId | 0;
            const shots = Math.max(1, slot.data.shotCount ? (slot.data.shotCount | 0) : 1);
            // 정의상 "한 명이라도 쏠 타겟이 있으면" 실패 아님
            // (엔티티 중복/분산 제약은 고려하지 않음)
            try {
                const ts = b.pickShootTargets?.(colorId, shots, 'LEFT', new Set(), true);
                if (Array.isArray(ts) && ts.length > 0)
                    return false;
            }
            catch {
                // pickShootTargets 실패 시 보수적으로 '쏠 수 없음'으로 간주
            }
        }
        return true;
    }
    /**
     * ✅ 스턱 디버그 스냅샷(콘솔 로그용)
     * - 실패조건: 슬롯 full & 전원 타겟 0
     * - 현재 슬롯 구성/각 슬롯의 타겟 개수/row0 요약을 반환
     */
    buildStuckSnapshot(board) {
        const b = board;
        const snap = {
            capacity: 0,
            filled: 0,
            slots: [],
            row0: [],
        };
        // capacity/filled + slot data
        for (let i = 0; i < 5; i++) {
            const place = this._placesS?.[i];
            if (!place || !place.isValid || !place.activeInHierarchy)
                continue;
            snap.capacity++;
            const slot = this._slotS[i];
            if (!slot || !slot.data) {
                snap.slots.push({ idx: i, empty: true });
                continue;
            }
            snap.filled++;
            const d = slot.data;
            const colorId = d.colorId | 0;
            const shots = Math.max(1, d.shotCount ? (d.shotCount | 0) : 1);
            const ammo = d.ammo | 0;
            const step = (d.hintStep ?? 0) | 0;
            let targets = [];
            try {
                targets = b.pickShootTargets?.(colorId, shots, 'LEFT', new Set(), true) ?? [];
            }
            catch {
                targets = [];
            }
            snap.slots.push({
                idx: i,
                colorId,
                token: Types_1.COLOR_TOKEN_ORDER[colorId] ?? 'R',
                shots,
                ammo,
                hintStep: step,
                targetsLen: Array.isArray(targets) ? targets.length : 0,
                targetCols: Array.isArray(targets) ? targets.map((t) => (t?.col ?? -1)) : [],
            });
        }
        // row0 summary (best-effort)
        try {
            const cols = b.cols ?? 10;
            for (let c = 0; c < cols; c++) {
                const e = b.entAt?.(0, c);
                if (!e) {
                    snap.row0.push(null);
                    continue;
                }
                // NOTE: BlockEnt 자체에는 colorId가 없고, TileView가 색/스택을 가집니다.
                const cid = (e.view?.colorId ?? -1) | 0;
                const isBig = !!(e.w > 1 || e.h > 1);
                snap.row0.push({
                    c,
                    token: Types_1.COLOR_TOKEN_ORDER[cid] ?? '?',
                    colorId: cid,
                    isBig,
                    hp: e.view?.getHp?.() ?? 1,
                    hidden: !!(e.view?.isHidden?.() ?? e.hidden),
                });
            }
        }
        catch {
            // ignore
        }
        return snap;
    }
    rebuild(slotCount, pickerCols, waitLineCount) {
        const shootCols = Math.max(0, Math.min(5, slotCount | 0));
        const pickCols = Math.max(0, Math.min(5, pickerCols | 0));
        const waitN = Math.max(1, Math.min(3, waitLineCount | 0));
        const w1Node = this.waitingLine01;
        const w2Node = this.waitingLine02;
        const w3Node = this.waitingLine03;
        if (w1Node && w1Node.isValid)
            w1Node.active = waitN >= 1;
        if (w2Node && w2Node.isValid)
            w2Node.active = waitN >= 2;
        if (w3Node && w3Node.isValid)
            w3Node.active = waitN >= 3;
        const shootMask = this._mask5FromCount(shootCols);
        const pickMask = this._mask5FromCount(pickCols);
        // ✅ Shooting: Place와 UnitPlace를 같이 on/off
        for (let i = 0; i < 5; i++) {
            const base = this._placesS[i];
            if (base && base.isValid)
                base.active = !!shootMask[i];
            const up = this._unitPlacesS[i];
            if (up && up.isValid)
                up.active = !!shootMask[i];
            if (!shootMask[i])
                this._returnSlotNode(this._slotS[i], true);
        }
        const w1On = !!w1Node?.active;
        const w2On = !!w2Node?.active;
        const w3On = !!w3Node?.active;
        for (let i = 0; i < 5; i++) {
            const p1 = this._placesW1[i];
            const p2 = this._placesW2[i];
            const p3 = this._placesW3[i];
            const on = !!pickMask[i];
            if (p1 && p1.isValid)
                p1.active = w1On && on;
            if (p2 && p2.isValid)
                p2.active = w2On && on;
            if (p3 && p3.isValid)
                p3.active = w3On && on;
            if (!w1On || !on)
                this._returnSlotNode(this._slotW1[i], true);
            if (!w2On || !on)
                this._returnSlotNode(this._slotW2[i], true);
            if (!w3On || !on)
                this._returnSlotNode(this._slotW3[i], true);
            if (!shootMask[i])
                this._cooldownsS[i] = 0;
        }
    }
    resetAllAimAndPose() {
        // 역할:
        // - 스테이지 전환/재시작 시 '총 쏘던 방향/IK 잔상'을 확실히 제거하기 위한 하드 리셋
        // - 오브젝트 풀/노드 재사용은 유지하고, 조준/IK/예약/애니메이션 상태만 초기화
        for (let i = 0; i < 5; i++) {
            const s0 = this._slotS[i];
            if (s0)
                this._resetSlotAimAndPose(s0);
            const w1 = this._slotW1[i];
            if (w1)
                this._resetSlotAimAndPose(w1);
            const w2 = this._slotW2[i];
            if (w2)
                this._resetSlotAimAndPose(w2);
            const w3 = this._slotW3[i];
            if (w3)
                this._resetSlotAimAndPose(w3);
        }
    }
    _resetSlotAimAndPose(s) {
        // 역할:
        // - 단일 슬롯의 조준/IK/발사 예약/애니메이션 상태를 즉시(보간 없이) 홈 포즈로 되돌림
        // - 전환 순간의 잔상/뒤틀림을 방지하기 위해 tween을 사용하지 않음
        // 이동/도착 후 장착 예약도 제거 (전환 중 입력 잔상 방지)
        s.moving = false;
        s.equipQueued = false;
        // 발사/예약 상태 초기화
        s.canShootNow = false;
        s.pendingDual = false;
        s.pendingT = 0;
        s.pendingCol = -1;
        s.pendingColorId = -1;
        s.pendingMuzzle = 'L';
        s.pendingIsBig = false;
        // aim 상태 초기화
        s.aimHasTarget = false;
        s.aimInited = false;
        s.aimRefreshCd = 0;
        s.targetHoldT = 0;
        s.reacquireDelayT = 0;
        s.postEquipDelayT = 0;
        // IK 타겟을 홈으로 강제 복귀 (0으로 보내면 반전/오차가 생길 수 있어 홈 좌표 사용)
        if (s.aimHomeInited) {
            s.aimCurX = s.aimHomeX;
            s.aimCurY = s.aimHomeY;
            s.aimDesX = s.aimHomeX;
            s.aimDesY = s.aimHomeY;
            if (s.ikTarget) {
                // Bone(World/Local) 타입이 프로젝트마다 달라 any로 처리됨
                try {
                    if (typeof s.ikTarget.setPosition === 'function') {
                        s.ikTarget.setPosition(s.aimHomeX, s.aimHomeY);
                    }
                    else {
                        s.ikTarget.x = s.aimHomeX;
                        s.ikTarget.y = s.aimHomeY;
                    }
                }
                catch { }
            }
        }
        else {
            // 홈 좌표가 없으면 안전한 기본값
            s.aimCurX = 0;
            s.aimCurY = 0;
            s.aimDesX = 0;
            s.aimDesY = 0;
        }
        // 듀얼 플립 초기화
        s.dualFlip = 0;
        // Skeleton 포즈/트랙 리셋 (IK 잔상 핵심)
        if (s.skel) {
            try {
                s.skel.clearTracks();
                s.skel.setToSetupPose();
                const idle = s.aimHomeAnim && s.aimHomeAnim.length > 0 ? s.aimHomeAnim : 'Idle';
                s.skel.setAnimation(0, idle, true);
                s.lastAnim = idle;
            }
            catch { }
        }
        // 시각적 잔상 제거
        if (s.opacity) {
            s.opacity.opacity = 255;
        }
    }
    setWaitingUnits(units) {
        // // 역할: 대기라인(W1~W3) 초기 배치 + 초과분은 컬럼별 오버플로 큐에 저장(가상 WaitingLine04+)
        for (let i = 0; i < 5; i++) {
            this._returnSlotNode(this._slotW1[i], true);
            this._returnSlotNode(this._slotW2[i], true);
            this._returnSlotNode(this._slotW3[i], true);
            this._overflowByCol[i].length = 0;
            this._overflowHeadByCol[i] = 0;
        }
        const list = Array.isArray(units) ? units : [];
        const w1On = !!this.waitingLine01?.active;
        const w2On = !!this.waitingLine02?.active;
        const w3On = !!this.waitingLine03?.active;
        const activeCols = [];
        for (let i = 0; i < 5; i++) {
            const p = this._placesW1[i];
            if (p && p.isValid && p.active)
                activeCols.push(i);
        }
        const cols = activeCols.length;
        if (cols <= 0)
            return;
        const waitN = (w1On ? 1 : 0) + (w2On ? 1 : 0) + (w3On ? 1 : 0);
        const cap = Math.max(0, Math.min(15, waitN * cols));
        const count = Math.min(cap, list.length);
        // (A) W1~W3 채우기
        for (let k = 0; k < count; k++) {
            const lineIdx = (k / cols) | 0;
            const colIdx = activeCols[k % cols];
            let line = 'W1';
            if (lineIdx === 0)
                line = 'W1';
            else if (lineIdx === 1)
                line = 'W2';
            else
                line = 'W3';
            if (line === 'W2' && !w2On)
                break;
            if (line === 'W3' && !w3On)
                break;
            this._spawnTo(line, colIdx, list[k]);
        }
        // (B) 초과분은 "가상 라인(W4+)"로 간주하여 컬럼별 큐에 저장
        for (let k = count; k < list.length; k++) {
            const colIdx = activeCols[k % cols];
            this._overflowByCol[colIdx].push(list[k]);
        }
    }
    clearAll(clearShooting) {
        for (let i = 0; i < 5; i++) {
            this._returnSlotNode(this._slotW1[i], true);
            this._returnSlotNode(this._slotW2[i], true);
            this._returnSlotNode(this._slotW3[i], true);
            if (clearShooting)
                this._returnSlotNode(this._slotS[i], true);
            this._cooldownsS[i] = 0;
        }
    }
    // -----------------------------
    // Click / Equip
    // -----------------------------
    beginItemSelectUnitToShoot() {
        // // 역할: 유닛 선택 아이템 사용 시작(다음 탭을 슈팅라인 배치로 처리)
        this._itemSelectUnitActive = true;
    }
    isItemSelectUnitToShootActive() {
        // // 역할: 아이템1(유닛 선택 → 슈팅라인 배치) 모드가 활성인지 외부에서 확인
        // // - BottomItemBar의 오버레이 종료 타이밍(선택 완료 시 자동 닫기)에 사용
        return !!this._itemSelectUnitActive;
    }
    cancelItemSelectUnitToShoot() {
        // // 역할: 유닛 선택 모드 강제 종료
        this._itemSelectUnitActive = false;
    }
    useItemShuffleUnits() {
        // // 역할: 대기라인 유닛 중 '섞기 가능(NORMAL)'만 랜덤 재배치(체인/락/생성기 제외)
        this._tmpShuffleSlots.length = 0;
        this._tmpShuffleData.length = 0;
        const collect = (arr) => {
            if (!arr)
                return;
            for (let i = 0; i < arr.length; i++) {
                const s = arr[i];
                if (!s || !s.node?.isValid)
                    continue;
                if (s.moving)
                    continue;
                if (!s.data)
                    continue;
                const k = s.data.kind;
                if (k === 'CHAIN' || k === 'LOCK' || k === 'SPAWNER')
                    continue;
                this._tmpShuffleSlots.push(s);
                this._tmpShuffleData.push(s.data);
            }
        };
        collect(this._slotW1);
        collect(this._slotW2);
        collect(this._slotW3);
        const n = this._tmpShuffleData.length;
        if (n <= 1)
            return false;
        // Fisher–Yates(in-place) : 추가 배열 생성 없이 셔플
        for (let i = n - 1; i > 0; i--) {
            const j = (Math.random() * (i + 1)) | 0;
            const tmp = this._tmpShuffleData[i];
            this._tmpShuffleData[i] = this._tmpShuffleData[j];
            this._tmpShuffleData[j] = tmp;
        }
        // 데이터만 교체(노드 이동 없음) → 가장 가볍고 빠름
        for (let i = 0; i < n; i++) {
            const s = this._tmpShuffleSlots[i];
            const d = this._tmpShuffleData[i];
            s.data = d;
            // ✅ 데이터가 바뀌었으니 유닛 고유 슈팅 SFX 캐시도 갱신
            s.shotSfxIdx = this._ensureShotSfxIdx(d);
            // // 역할: 섞인 결과를 즉시 시각 반영
            this._applySkinByColor(s);
            this._applyAmmoLabelVisual(s);
            this._ensureAnim(s, 'Idle');
            // // 역할: 대기 중 조준 상태/예약 샷 리셋
            s.aimRefreshCd = 0;
            s.pendingDual = false;
            s.pendingT = 0;
        }
        return true;
    }
    _equipFromWaiting01(index) {
        // // 역할: 기존 기능 유지(W1 → S 장착)
        this._equipFromWaiting('W1', index);
    }
    _equipFromWaiting(line, index) {
        // // 역할: 대기라인(W1/W2/W3) 선택 유닛을 슈팅라인(S) 빈 슬롯에 배치
        const fromIdx = index | 0;
        const fromPlace = this._placeOf(line, fromIdx);
        if (!fromPlace || !fromPlace.isValid || !fromPlace.activeInHierarchy)
            return false;
        const fromArr = line === 'W1' ? this._slotW1 : line === 'W2' ? this._slotW2 : this._slotW3;
        const from = fromArr[fromIdx];
        if (!from || !from.node?.isValid)
            return false;
        if (from.moving)
            return false;
        from.equipQueued = false; // ✅ 장착 시작 시 예약 상태 제거
        const toIdx = this._findFirstEmptyShooting();
        if (toIdx < 0)
            return false;
        const toBase = this._placesS[toIdx];
        if (!toBase || !toBase.isValid || !toBase.activeInHierarchy)
            return false;
        this._moveSlotNode(from, 'S', toIdx, this.equipMoveSec, this.equipJumpY, () => {
            from.postEquipDelayT = Math.max(0, this.postEquipDelaySec);
            from.reacquireDelayT = Math.max(0, this.reacquireDelaySec);
            // // 역할: 장착 직후 듀얼 예약/조준 상태 초기화(오동작 방지)
            from.pendingDual = false;
            from.pendingT = 0;
            this._cooldownsS[toIdx] = 0;
            // // 역할: 대기라인 구멍 메우기
            this._shiftColumn(fromIdx);
        });
        return true;
    }
    _consumeQueuedEquipInColumn(col) {
        // ✅ 역할: W2→W1 이동(당김) 중 탭된 유닛을 '도착 후' 안전하게 장착합니다.
        // 설명:
        // - 컬럼 이동/보충(shift/refill)이 모두 끝난 뒤에만 실행되어 순간이동/연출 충돌을 방지합니다.
        const i = col | 0;
        if (i < 0 || i >= 5)
            return;
        const s = this._slotW1[i];
        if (!s || !s.node?.isValid)
            return;
        if (s.moving)
            return;
        if (!s.equipQueued)
            return;
        s.equipQueued = false; // ✅ 1회 소비(중복클릭 방지)
        // 빈 슈팅 슬롯이 있을 때만 시도
        if (this._findFirstEmptyShooting() < 0)
            return;
        // W1 → S 장착 실행(기존 규칙 그대로)
        this._equipFromWaiting('W1', i);
    }
    _shiftColumn(index) {
        // // 역할: 특정 컬럼에서 W1/W2/W3 빈칸을 당겨 메우고,
        // //      W3가 비면 오버플로(가상 W4+)에서 1개를 보충합니다.
        const i = index | 0;
        if (i < 0 || i >= 5)
            return;
        const w1On = !!this.waitingLine01?.active;
        const w2On = !!this.waitingLine02?.active;
        const w3On = !!this.waitingLine03?.active;
        if (!w1On)
            return;
        const tryRefill = () => {
            // NOTE(StageTool/headless): overflow refill must work even when waitLineCount < 3.
            // The refill target is decided inside `_refillFromOverflow` based on which waiting lines are active.
            this._refillFromOverflow(i);
            // ✅ 컬럼 이동/보충이 끝나는 타이밍에 '도착 후 장착' 예약을 처리
            this._consumeQueuedEquipInColumn(i);
        };
        // (1) W1이 비었으면 W2 또는 W3를 W1으로 당김
        if (!this._slotW1[i]) {
            const s2 = w2On ? this._slotW2[i] : null;
            const s3 = w3On ? this._slotW3[i] : null;
            if (s2) {
                this._moveSlotNode(s2, 'W1', i, this.shiftMoveSec, 0, () => {
                    // W2가 비었으면 W3 -> W2
                    if (w3On && !this._slotW2[i]) {
                        const s3b = this._slotW3[i];
                        if (s3b) {
                            this._moveSlotNode(s3b, 'W2', i, this.shiftMoveSec, 0, () => tryRefill());
                            return;
                        }
                    }
                    tryRefill();
                });
                return;
            }
            if (s3) {
                this._moveSlotNode(s3, 'W1', i, this.shiftMoveSec, 0, () => tryRefill());
                return;
            }
            tryRefill();
            return;
        }
        // (2) W1은 차있고 W2가 비었으면 W3를 W2로 당김
        if (w2On && w3On && !this._slotW2[i] && this._slotW3[i]) {
            this._moveSlotNode(this._slotW3[i], 'W2', i, this.shiftMoveSec, 0, () => tryRefill());
            return;
        }
        // (3) 이동이 없어도 W3가 비었으면 보충
        tryRefill();
    }
    _maintainWaitingOverflow() {
        // // 역할: 2단계 Lock
        // // - 대기라인 cap(3줄*pickerCols) 밖의 카드는 overflow로 유지
        // // - 아이템/외부 로직으로 W1~W3에 구멍이 생겼을 때도 자동으로 당겨 채움
        const w1On = !!this.waitingLine01?.active;
        if (!w1On)
            return;
        const w2On = !!this.waitingLine02?.active;
        const w3On = !!this.waitingLine03?.active;
        for (let i = 0; i < 5; i++) {
            const p = this._placesW1[i];
            if (!p || !p.isValid || !p.activeInHierarchy)
                continue;
            // 컬럼 이동 중이면 스킵(연출 충돌 방지)
            const s1 = this._slotW1[i];
            const s2 = w2On ? this._slotW2[i] : null;
            const s3 = w3On ? this._slotW3[i] : null;
            if ((s1 && s1.moving) || (s2 && s2.moving) || (s3 && s3.moving))
                continue;
            // (1) 위쪽에 뭐라도 있거나 overflow가 있으면 컬럼 시프트로 복구
            const hasOverflow = (this._overflowByCol[i]?.length ?? 0) > (this._overflowHeadByCol[i] | 0);
            const needsShift = !s1 && (s2 || s3 || hasOverflow);
            const needsShift2 = !!s1 && w2On && !s2 && !!s3; // W2 hole
            if (needsShift || needsShift2) {
                this._shiftColumn(i);
                continue;
            }
            // (2) overflow가 있으면(그리고 채울 자리가 있으면) 보충
            if (hasOverflow) {
                this._refillFromOverflow(i);
            }
        }
    }
    _refillFromOverflow(col) {
        // // 역할: 가상 WaitingLine04+(오버플로)에서 1개를 꺼내
        // //      "현재 활성화된 마지막 대기라인"(W3/W2/W1)에 보충 + 이동 연출
        const c = col | 0;
        if (c < 0 || c >= 5)
            return;
        const w1On = !!this.waitingLine01?.active;
        const w2On = !!this.waitingLine02?.active;
        const w3On = !!this.waitingLine03?.active;
        if (!w1On)
            return;
        const targetLine = w3On ? 'W3' : w2On ? 'W2' : 'W1';
        const occupied = targetLine === 'W3' ? !!this._slotW3[c] : targetLine === 'W2' ? !!this._slotW2[c] : !!this._slotW1[c];
        if (occupied)
            return;
        const q = this._overflowByCol[c];
        if (!q || q.length <= 0)
            return;
        const head = this._overflowHeadByCol[c] | 0;
        if (head >= q.length) {
            q.length = 0;
            this._overflowHeadByCol[c] = 0;
            return;
        }
        const data = q[head];
        this._overflowHeadByCol[c] = head + 1;
        // 다 썼으면 큐 정리
        if (this._overflowHeadByCol[c] >= q.length) {
            q.length = 0;
            this._overflowHeadByCol[c] = 0;
        }
        this._spawnTo(targetLine, c, data);
        const slot = targetLine === 'W3' ? this._slotW3[c] : targetLine === 'W2' ? this._slotW2[c] : this._slotW1[c];
        if (!slot || !slot.node || !slot.node.isValid)
            return;
        slot.moving = true;
        slot.node.setPosition(0, -180, 0);
        // ✅ StageTool headless simulation: Tween 없이 즉시 이동
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            try {
                slot.node.setPosition(this._vZero);
            }
            catch { }
            slot.moving = false;
        }
        else {
            (0, cc_1.tween)(slot.node)
                .to(this.shiftMoveSec, { position: this._vZero })
                .call(() => (slot.moving = false))
                .start();
        }
    }
    // -----------------------------
    // Spawn / Socket / Label
    // -----------------------------
    _spawnTo(line, index, data) {
        const p = this._placeOf(line, index);
        if (!p || !p.isValid)
            return;
        const nd = this._pool.size() > 0 ? this._pool.get() : this.unitPrefab ? (0, cc_1.instantiate)(this.unitPrefab) : null;
        if (!nd)
            return;
        nd.active = true;
        nd.setParent(p);
        nd.setPosition(0, 0, 0);
        const s = this._scaleOf(line);
        nd.setScale(s, s, 1);
        nd.setRotationFromEuler(0, 0, 0);
        const op = nd.getComponent(cc_1.UIOpacity) || nd.addComponent(cc_1.UIOpacity);
        op.opacity = 255;
        nd.off(cc_1.Node.EventType.TOUCH_END, this._onUnitTouchEnd, this);
        nd.on(cc_1.Node.EventType.TOUCH_END, this._onUnitTouchEnd, this);
        let skel = nd.getComponent(cc_1.sp.Skeleton);
        if (!skel)
            skel = nd.getComponentInChildren(cc_1.sp.Skeleton);
        // ✅ Label_Num은 최초 스폰에서 Skeleton 아래로 옮겨질 수 있어(풀링 재사용 시)
        // 루트 직속 탐색만 하면 일부 카드가 라벨 갱신이 안 되는 문제가 생깁니다.
        let labelNode = nd.getChildByName('Label_Num');
        if (!labelNode && skel && skel.node && skel.node.isValid) {
            labelNode = skel.node.getChildByName('Label_Num');
        }
        if (!labelNode) {
            labelNode = this._findNodeByNameDFS(nd, 'Label_Num');
        }
        let ammoLabel = null;
        if (labelNode && labelNode.isValid && skel && skel.isValid) {
            const host = skel.node;
            if (labelNode.parent !== host)
                this._reparentKeepWorldPos(labelNode, host);
            ammoLabel = labelNode.getComponent(cc_1.Label);
        }
        else if (labelNode && labelNode.isValid) {
            ammoLabel = labelNode.getComponent(cc_1.Label);
        }
        let muzzleCenter = null;
        let muzzleLeft = null;
        let muzzleRight = null;
        let boneCenter = null;
        let boneLeft = null;
        let boneRight = null;
        let ikTarget = null;
        if (skel && skel.isValid) {
            const host = skel.node;
            muzzleCenter = host.getChildByName('Muzzle_Center');
            if (!muzzleCenter) {
                muzzleCenter = new cc_1.Node('Muzzle_Center');
                muzzleCenter.setParent(host);
            }
            muzzleLeft = host.getChildByName('Muzzle_Left');
            if (!muzzleLeft) {
                muzzleLeft = new cc_1.Node('Muzzle_Left');
                muzzleLeft.setParent(host);
            }
            muzzleRight = host.getChildByName('Muzzle_Right');
            if (!muzzleRight) {
                muzzleRight = new cc_1.Node('Muzzle_Right');
                muzzleRight.setParent(host);
            }
            this._mergeSocketsKeepOthers(skel, muzzleCenter, muzzleLeft, muzzleRight, labelNode);
            // ✅ 잔여 발사 FX 제거(스테이지 전환/풀링 재사용 시 유닛 등장과 동시에 FX가 보이는 문제 방지)
            this._despawnMuzzleFxUnder(muzzleCenter);
            this._despawnMuzzleFxUnder(muzzleLeft);
            this._despawnMuzzleFxUnder(muzzleRight);
            // ✅ 역할: 풀링 재사용 시 이전 프레임의 소켓 노드 로컬 변형(위치/회전/스케일)이 남아
            //           머즐/라벨이 틀어져 보이는 문제를 방지합니다.
            // 설명: SpineSocket은 Bone에 의해 월드 변환이 적용되지만, 노드의 로컬 값이 비정상이면
            //       setup/idle 복귀 직후에도 잠깐 "비뚤어짐"이 보일 수 있어 기본값으로 정리합니다.
            muzzleCenter.setPosition(0, 0, 0);
            muzzleCenter.setRotationFromEuler(0, 0, 0);
            muzzleCenter.setScale(1, 1, 1);
            muzzleLeft.setPosition(0, 0, 0);
            muzzleLeft.setRotationFromEuler(0, 0, 0);
            muzzleLeft.setScale(1, 1, 1);
            muzzleRight.setPosition(0, 0, 0);
            muzzleRight.setRotationFromEuler(0, 0, 0);
            muzzleRight.setScale(1, 1, 1);
            if (labelNode && labelNode.isValid) {
                labelNode.setPosition(0, 0, 0);
                labelNode.setRotationFromEuler(0, 0, 0);
                labelNode.setScale(1, 1, 1);
            }
            try {
                const spskel = skel._skeleton;
                if (spskel?.findBone) {
                    boneCenter = spskel.findBone(UnitLineRack_1.BONE_CENTER) || null;
                    boneLeft = spskel.findBone(UnitLineRack_1.BONE_LEFT) || null;
                    boneRight = spskel.findBone(UnitLineRack_1.BONE_RIGHT) || null;
                    ikTarget = spskel.findBone(UnitLineRack_1.IK_TARGET_BONE) || null;
                }
            }
            catch { }
        }
        const slot = {
            node: nd,
            data,
            line,
            index: index | 0,
            moving: false,
            equipQueued: false,
            moveParam: null,
            moveDoneCb: null,
            skel,
            ammoLabel,
            opacity: op,
            muzzleCenter,
            muzzleLeft,
            muzzleRight,
            boneCenter,
            boneLeft,
            boneRight,
            ikTarget,
            aimHasTarget: false,
            aimCurX: 0,
            aimCurY: 0,
            aimDesX: 0,
            aimDesY: 0,
            aimInited: false,
            aimRefreshCd: 0,
            aimLockT: 0,
            targetEntId: 0,
            targetCol: -1,
            targetStickyT: 0,
            aimHomeX: 0,
            aimHomeY: 0,
            aimHomeInited: false,
            aimHomeAnim: '',
            targetHoldT: 0,
            reacquireDelayT: 0,
            postEquipDelayT: 0,
            canShootNow: false,
            dualFlip: 0,
            pendingDual: false,
            pendingT: 0,
            pendingCol: -1,
            pendingColorId: 0,
            pendingMuzzle: 'L',
            pendingIsBig: false,
            lastAnim: '',
            // ✅ 유닛 고유 슈팅 SFX 고정값(0~2)
            shotSfxIdx: this._ensureShotSfxIdx(data),
        };
        this._slotByNode.set(nd, slot);
        this._setSlot(line, index, slot);
        this._applySkinByColor(slot);
        this._applyAmmoLabelVisual(slot);
        this._ensureAnim(slot, 'Idle');
        // ✅ 풀링 재사용/스테이지 전환 시 자세(조준/IK) 초기화
        this._resetUnitPose(slot);
        if (line === 'S')
            this._cooldownsS[index | 0] = 0;
    }
    _mergeSocketsKeepOthers(skel, c, l, r, labelNode) {
        const cur = Array.isArray(skel.sockets) ? skel.sockets : [];
        const next = [];
        for (let i = 0; i < cur.length; i++) {
            const s = cur[i];
            const p = s?.path;
            if (p === UnitLineRack_1.PATH_CENTER ||
                p === UnitLineRack_1.PATH_LEFT ||
                p === UnitLineRack_1.PATH_RIGHT ||
                p === UnitLineRack_1.PATH_LABEL) {
                continue;
            }
            next.push(s);
        }
        next.push(new cc_1.sp.SpineSocket(UnitLineRack_1.PATH_CENTER, c));
        next.push(new cc_1.sp.SpineSocket(UnitLineRack_1.PATH_LEFT, l));
        next.push(new cc_1.sp.SpineSocket(UnitLineRack_1.PATH_RIGHT, r));
        if (labelNode && labelNode.isValid)
            next.push(new cc_1.sp.SpineSocket(UnitLineRack_1.PATH_LABEL, labelNode));
        skel.sockets = next;
    }
    /**
     * 역할: 풀링 재사용 시 Label_Num 등 특정 노드가 루트 직속이 아닌 곳(예: Skeleton 아래)으로 이동해도 안정적으로 찾습니다.
     * 설명: 재귀 대신 재사용 스택(배열)로 DFS 탐색하여 GC/스택오버플로우를 피합니다.
     */
    _findNodeByNameDFS(root, name) {
        if (!root || !root.isValid)
            return null;
        const st = this._tmpNodeStack;
        st.length = 0;
        st.push(root);
        while (st.length > 0) {
            const n = st.pop();
            if (!n || !n.isValid)
                continue;
            if (n.name === name)
                return n;
            const ch = n.children;
            // children는 배열이므로 역순 push로 원래 순서에 가깝게 탐색
            for (let i = ch.length - 1; i >= 0; i--)
                st.push(ch[i]);
        }
        return null;
    }
    _reparentKeepWorldPos(child, newParent) {
        child.getWorldPosition(this._tmpReparentW);
        child.setParent(newParent);
        const tr = newParent.getComponent(cc_1.UITransform);
        if (tr) {
            tr.convertToNodeSpaceAR(this._tmpReparentW, this._tmpReparentL);
            child.setPosition(this._tmpReparentL);
        }
        else {
            child.setWorldPosition(this._tmpReparentW);
        }
    }
    // -----------------------------
    // ✅ Muzzle FX leak/ghost 방지
    // -----------------------------
    /**
     * 역할: 유닛(또는 소켓) 아래에 남아있는 발사 FX를 즉시 회수합니다.
     * 설명: 스테이지 전환/라인 재구성 중에 FX 수명이 끝나기 전에 유닛이 풀로 들어가면,
     *       다음 스폰에서 FX가 그대로 따라와 "유닛이 나오자마자 발사"처럼 보일 수 있습니다.
     */
    _despawnMuzzleFxUnder(host) {
        if (!host || !host.isValid)
            return;
        const ch = host.children;
        for (let i = ch.length - 1; i >= 0; i--) {
            const n = ch[i];
            if (!n || !n.isValid)
                continue;
            if (!n[MUZZLE_FX_TAG])
                continue;
            // active 리스트에서 제거
            const list = this._fxActive;
            for (let k = list.length - 1; k >= 0; k--) {
                if (list[k].node === n) {
                    list.splice(k, 1);
                    break;
                }
            }
            // 파티클 정지
            try {
                const ps3 = n.getComponent(cc_1.ParticleSystem);
                ps3?.stop?.();
            }
            catch { }
            try {
                const ps2 = n.getComponent(cc_1.ParticleSystem2D);
                ps2?.stopSystem?.();
            }
            catch { }
            n.active = false;
            n.removeFromParent();
            this._muzzleFxPool.put(n);
        }
    }
    /**
     * 역할: 슬롯을 모르는 회수 경로에서도(예: 임시 노드 회수) 트리 전체에서 FX를 제거합니다.
     * 설명: 재귀 대신 스택 DFS로 GC/스택오버플로우를 피합니다.
     */
    _despawnMuzzleFxInTree(root) {
        if (!root || !root.isValid)
            return;
        const st = this._tmpNodeStack;
        st.length = 0;
        st.push(root);
        while (st.length > 0) {
            const n = st.pop();
            if (!n || !n.isValid)
                continue;
            if (n[MUZZLE_FX_TAG]) {
                // active 리스트에서 제거
                const list = this._fxActive;
                for (let k = list.length - 1; k >= 0; k--) {
                    if (list[k].node === n) {
                        list.splice(k, 1);
                        break;
                    }
                }
                try {
                    const ps3 = n.getComponent(cc_1.ParticleSystem);
                    ps3?.stop?.();
                }
                catch { }
                try {
                    const ps2 = n.getComponent(cc_1.ParticleSystem2D);
                    ps2?.stopSystem?.();
                }
                catch { }
                n.active = false;
                n.removeFromParent();
                this._muzzleFxPool.put(n);
                continue;
            }
            const ch = n.children;
            for (let i = ch.length - 1; i >= 0; i--)
                st.push(ch[i]);
        }
    }
    // -----------------------------
    // ✅ Muzzle FX (Prefab + Pool)
    // -----------------------------
    _prewarmMuzzleFx() {
        const pf = this.muzzleFxPrefab;
        if (!pf)
            return;
        const n = Math.max(0, Math.min(100, this.muzzleFxWarmup | 0));
        for (let i = 0; i < n; i++) {
            const nd = (0, cc_1.instantiate)(pf);
            nd.active = false;
            nd.removeFromParent();
            this._muzzleFxPool.put(nd);
        }
    }
    _tickFxRecycle(dt) {
        const list = this._fxActive;
        for (let i = list.length - 1; i >= 0; i--) {
            const it = list[i];
            it.t -= dt;
            if (it.t > 0)
                continue;
            const nd = it.node;
            list.splice(i, 1);
            if (!nd || !nd.isValid)
                continue;
            nd.active = false;
            nd.removeFromParent();
            this._muzzleFxPool.put(nd);
        }
    }
    _colorIdToFrameIdx0(colorId) {
        // ✅ 유닛 라벨 값 기준: colorId가 0~11 이든 1~12 이든 “결국 0~11”로 맞춘다
        const c = colorId | 0;
        if (c >= 0 && c <= 11)
            return c;
        if (c >= 1 && c <= 12)
            return c - 1;
        return ((c % 12) + 12) % 12;
        // 결과: 0..11
    }
    _frameIdxToHex(frameIdx0) {
        const i = (((frameIdx0 | 0) % 12) + 12) % 12;
        return MUZZLE_COLOR_HEX[i] ?? '??????';
    }
    // ✅ 요청하신 원본 형태 유지(로그 포함)
    _playMuzzleFx(slot, muzzle, colorId) {
        // Headless validator: FX/SFX are irrelevant and can spam logs / throw due to missing assets.
        if (globalThis.__HEADLESS__)
            return;
        const pf = this.muzzleFxPrefab;
        if (!pf)
            return;
        let host = null;
        if (muzzle === 'C')
            host = slot.muzzleCenter;
        else if (muzzle === 'L')
            host = slot.muzzleLeft;
        else
            host = slot.muzzleRight;
        if (!host || !host.isValid)
            host = slot.node;
        if (!host || !host.isValid)
            return;
        const nd = this._muzzleFxPool.size() > 0 ? this._muzzleFxPool.get() : (0, cc_1.instantiate)(pf);
        if (!nd)
            return;
        // ✅ 태그: 유닛 풀링 회수/스테이지 전환 시 잔여 FX를 찾아 즉시 회수하기 위함
        nd[MUZZLE_FX_TAG] = 1;
        nd.active = true;
        nd.setParent(host);
        nd.setPosition(0, 0, 0);
        nd.setRotationFromEuler(0, 0, 0);
        nd.setScale(1, 1, 1);
        const frameIdx0 = this._colorIdToFrameIdx0(colorId);
        const hex = this._frameIdxToHex(frameIdx0);
        // ✅ ParticleSystem(3D) 기준: textureAnimationModule.startFrame(Constant=0..11)
        const ps3 = nd.getComponent(cc_1.ParticleSystem);
        if (ps3) {
            const mod = ps3.textureAnimationModule;
            const sf = mod?.startFrame;
            if (sf) {
                try {
                    sf.mode = cc_1.CurveRange.Mode.Constant;
                    sf.constant = frameIdx0;
                    console.log(`[MuzzleFX] startFrame set: colorId=${colorId} frameIdx0=${frameIdx0} hex=#${hex} muzzle=${muzzle} host=${host.name} nd=${nd.name}`);
                }
                catch (e) {
                    console.warn('[MuzzleFX] failed to set startFrame:', e);
                }
            }
            else {
                console.warn(`[MuzzleFX] textureAnimationModule.startFrame not found. colorId=${colorId} muzzle=${muzzle} nd=${nd.name}`);
            }
            // ✅ 즉시 반영(연사 중에도 바뀌게): stop/play
            try {
                ps3.stop?.();
                ps3.play?.();
                // ✅ 유닛 고유 슈팅 SFX(0~2): 유닛당 1개로 고정
                AudioManager_1.AudioManager.I?.playSfxByIndex(slot.shotSfxIdx, { volume: 1.0, minIntervalMs: 15 });
            }
            catch { }
        }
        else {
            const ps2 = nd.getComponent(cc_1.ParticleSystem2D);
            if (ps2) {
                console.warn(`[MuzzleFX] ParticleSystem2D detected(3D가 아님). startFrame 제어가 다를 수 있음. colorId=${colorId} frameIdx0=${frameIdx0} hex=#${hex} muzzle=${muzzle} nd=${nd.name}`);
                try {
                    ps2.resetSystem();
                }
                catch { }
            }
        }
        const life = this.muzzleFxRecycleSec > 0 ? this.muzzleFxRecycleSec : 0.35;
        this._fxActive.push({ node: nd, t: life });
    }
    // -----------------------------
    // Muzzle / IK helpers
    // -----------------------------
    _getMuzzleWorld(slot, type, out) {
        let n = null;
        if (type === 'C')
            n = slot.muzzleCenter;
        else if (type === 'L')
            n = slot.muzzleLeft;
        else
            n = slot.muzzleRight;
        if (n && n.isValid) {
            n.getWorldPosition(out);
            return true;
        }
        const skel = slot.skel;
        if (!skel || !skel.node?.isValid)
            return false;
        let bone = null;
        if (type === 'C')
            bone = slot.boneCenter;
        else if (type === 'L')
            bone = slot.boneLeft;
        else
            bone = slot.boneRight;
        if (!bone)
            return false;
        out.set(bone.worldX || 0, bone.worldY || 0, 0);
        skel.node.getWorldMatrix(this._tmpMat);
        cc_1.Vec3.transformMat4(out, out, this._tmpMat);
        return true;
    }
    _computeIkLocalFromWorld(slot, targetWorld) {
        const skel = slot.skel;
        const tgt = slot.ikTarget;
        if (!skel || !skel.node?.isValid || !tgt)
            return false;
        skel.node.getWorldMatrix(this._tmpMat);
        cc_1.Mat4.invert(this._tmpMatInv, this._tmpMat);
        this._tmpSkelLocal.set(targetWorld);
        cc_1.Vec3.transformMat4(this._tmpSkelLocal, this._tmpSkelLocal, this._tmpMatInv);
        let lx = this._tmpSkelLocal.x;
        let ly = this._tmpSkelLocal.y;
        const parent = tgt.parent;
        if (parent) {
            const rx = lx - (parent.worldX || 0);
            const ry = ly - (parent.worldY || 0);
            const a = parent.a ?? 1;
            const b = parent.b ?? 0;
            const c = parent.c ?? 0;
            const d = parent.d ?? 1;
            const det = a * d - b * c;
            if (det !== 0) {
                const invDet = 1 / det;
                lx = (rx * d - ry * b) * invDet;
                ly = (ry * a - rx * c) * invDet;
            }
            else {
                lx = rx;
                ly = ry;
            }
        }
        this._tmpSkelLocal.x = lx;
        this._tmpSkelLocal.y = ly;
        return true;
    }
    _applyIkLocal(slot, lx, ly) {
        const skel = slot.skel;
        const tgt = slot.ikTarget;
        if (!skel || !skel.node?.isValid || !tgt)
            return;
        try {
            tgt.x = lx;
            tgt.y = ly;
            skel.updateWorldTransform?.();
        }
        catch { }
    }
    // -----------------------------
    // Visual helpers
    // -----------------------------
    _applySkinByColor(slot) {
        const skel = slot.skel;
        const data = slot.data;
        if (!skel || !data)
            return;
        const c = (data.colorId ?? 0) | 0;
        let idx;
        if (c >= 0 && c <= 11)
            idx = c + 1;
        else if (c >= 1 && c <= 12)
            idx = c;
        else
            idx = (((c % 12) + 12) % 12) + 1;
        const skinName = `Unit_${String(idx).padStart(2, '0')}`;
        try {
            skel.setSkin?.(skinName);
            skel.skinName = skinName;
            skel.setSlotsToSetupPose?.();
            skel.updateWorldTransform?.();
        }
        catch { }
    }
    _applyAmmoLabelVisual(slot) {
        // ✅ 풀링/재부모화 타이밍에 따라 ammoLabel 캐시가 비어있을 수 있어, 필요 시 재탐색합니다.
        let lb = slot.ammoLabel;
        const d = slot.data;
        if (!d)
            return;
        if (!lb && slot.node && slot.node.isValid) {
            const skel = slot.skel;
            let labelNode = slot.node.getChildByName('Label_Num');
            if (!labelNode && skel && skel.node && skel.node.isValid)
                labelNode = skel.node.getChildByName('Label_Num');
            if (!labelNode)
                labelNode = this._findNodeByNameDFS(slot.node, 'Label_Num');
            lb = labelNode && labelNode.isValid ? labelNode.getComponent(cc_1.Label) : null;
            slot.ammoLabel = lb;
        }
        if (!lb)
            return;
        const ammo = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
        // ✅ 라벨 표시: "총알수,equipOrder,순번" (예: "30,R2,1")
        // - equipOrder 표기 = <ColorToken><shotCount>
        // - 순번(hintStep)은 stage.equipOrder(또는 시뮬 기반)로부터 StageCompiler가 부여
        const step = (d.hintStep ?? 0) | 0;
        const colorId = (d.colorId | 0) < 0 ? 0 : d.colorId | 0;
        const tok = Types_1.COLOR_TOKEN_ORDER[colorId] ?? 'R';
        const mode = this._getMode(d);
        const base = `${ammo},${tok}${mode}`;
        lb.string = step > 0 ? `${base},${step}` : base;
        // ✅ 라벨 표시/색상 적용
        if (lb.node)
            lb.node.active = true;
        lb.color = ColorPalette_1.LabelPalette.get(d.colorId | 0, 12);
    }
    _consumeAmmo(slot, n) {
        const d = slot.data;
        if (!d)
            return 0;
        const dec = Math.max(0, n | 0);
        const cur = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
        const next = Math.max(0, cur - dec);
        if (next === cur)
            return next;
        d.ammo = next;
        const lb = slot.ammoLabel;
        if (lb) {
            const colorId = (d.colorId | 0) < 0 ? 0 : d.colorId | 0;
            const tok = Types_1.COLOR_TOKEN_ORDER[colorId] ?? 'R';
            const mode = this._getMode(d);
            const step = (d.hintStep ?? 0) | 0;
            const base = `${next},${tok}${mode}`;
            lb.string = step > 0 ? `${base},${step}` : base;
        }
        return next;
    }
    _getMode(data) {
        if (!data)
            return 1;
        const d = data;
        const sc = d.shotCount | 0;
        if (sc === 2)
            return 2;
        if (sc === 1)
            return 1;
        const v = (d.barrelMode ?? d.attackMode ?? d.ammoMode ?? d.mode ?? 1) | 0;
        return v === 2 ? 2 : 1;
    }
    _animName(base, mode) {
        return `${base}_${mode}`;
    }
    _playAnim(slot, base, loop) {
        const skel = slot.skel;
        if (!skel)
            return;
        const mode = this._getMode(slot.data);
        const name = this._animName(base, mode);
        if (slot.lastAnim === name)
            return;
        slot.lastAnim = name;
        try {
            skel.setAnimation(0, name, loop);
        }
        catch { }
    }
    _captureAimHome(slot, animName) {
        // ✅ 역할: '대기(Idle)' 애니메이션에서 IK 타겟의 기본(중앙) 좌표를 저장
        // - 리그에 따라 중앙이 (0,0)이 아닐 수 있어, 0으로 복귀하면 좌/우 반전/오프셋이 생길 수 있음
        // - 따라서 idle/setup 포즈에서의 ikTarget.x/y를 기준으로 복귀 좌표를 잡습니다.
        const tgt = slot.ikTarget;
        if (!tgt)
            return;
        // 같은 idle 애니에서 매번 갱신하지 않도록 가드
        if (slot.aimHomeInited && slot.aimHomeAnim === animName)
            return;
        try {
            slot.aimHomeX = (tgt.x ?? 0);
            slot.aimHomeY = (tgt.y ?? 0);
            slot.aimHomeInited = true;
            slot.aimHomeAnim = animName;
        }
        catch { }
    }
    _ensureAnim(slot, base) {
        // ✅ 역할: 타겟 유무에 따라 유닛의 기본 루프 애니메이션을 유지/전환
        // - 기존: 타겟 없으면 Idle_1 / Idle_2
        // - 변경: ShootingLine(S)에서 타겟 없을 때는 Attack_1_Idle / Attack_2_Idle 사용(공격 자세 유지)
        const skel = slot.skel;
        if (!skel)
            return;
        const mode = this._getMode(slot.data);
        // ShootingLine에서 타겟 없음(Idle)인 경우: Attack_<mode>_Idle
        const name = base === 'Idle' && slot.line === 'S' ? `Attack_${mode}_Idle` : `${base}_${mode}`;
        if (slot.lastAnim === name)
            return;
        slot.lastAnim = name;
        try {
            skel.setAnimation(0, name, true);
            // ✅ Idle 애니메이션 진입 시 '중앙 복귀' 기준 좌표를 저장
            if (base === 'Idle')
                this._captureAimHome(slot, name);
        }
        catch { }
    }
    // -----------------------------
    // ✅ Stage 전환/풀링 재사용 시 "자세(조준/IK)" 초기화
    // -----------------------------
    /**
     * 역할: 풀에서 재사용되는 유닛이 이전 스테이지/이전 타겟을 바라보는 문제를 방지합니다.
     * 설명:
     * - Skeleton을 setup pose로 한번 리셋하고(가능한 API만 호출)
     * - Idle 애니 진입 후 캡처한 aimHomeX/Y(기본 자세)로 IK 타겟을 되돌립니다.
     * - aim/예약발/딜레이 상태도 초기화합니다.
     */
    _resetAllExistingUnitPoses() {
        // ✅ 역할: 스테이지 전환 시 현재 배치된 모든 유닛의 자세/조준 상태를 초기화합니다.
        const apply = (arr) => {
            if (!arr)
                return;
            for (let i = 0; i < arr.length; i++) {
                const s = arr[i];
                if (!s || !s.node?.isValid)
                    continue;
                s.equipQueued = false;
                this._ensureAnim(s, 'Idle');
                this._resetUnitPose(s);
            }
        };
        apply(this._slotS);
        apply(this._slotW1);
        apply(this._slotW2);
        apply(this._slotW3);
    }
    _resetUnitPose(slot) {
        if (!slot || !slot.node || !slot.node.isValid)
            return;
        const skel = slot.skel;
        if (skel && skel.isValid) {
            // ✅ 역할: 풀링 재사용/스테이지 전환 시 이전 애니 트랙/IK가 남아 "본이 틀어져" 보이는 현상을 방지
            // 설명:
            // - IK 타겟은 매 프레임 bone(x/y)을 직접 수정하므로, 트랙이 살아있으면 setupPose 호출 직후에도
            //   다음 update에서 이전 상태가 다시 적용될 수 있습니다.
            // - 따라서 clearTracks로 트랙을 정리한 뒤 setupPose로 되돌리고, Idle 루프를 다시 건 뒤
            //   홈 좌표로 IK 타겟을 복귀시킵니다.
            try {
                skel.clearTracks?.();
            }
            catch { }
            try {
                skel.setToSetupPose?.(); // 일부 버전에 존재
            }
            catch { }
            try {
                skel.setBonesToSetupPose?.();
            }
            catch { }
            try {
                skel.setSlotsToSetupPose?.();
            }
            catch { }
            try {
                skel.updateWorldTransform?.();
            }
            catch { }
            // setupPose만으로 부족한 버전(3.8.x 포함)에서 "이전 애니 진행 중 포즈"가 다시 튀는 것을 방지
            // - 현재 라인 기준 Idle(또는 Attack_<mode>_Idle)로 트랙0를 재지정
            try {
                const mode = this._getMode(slot.data);
                const idleName = slot.line === 'S' ? `Attack_${mode}_Idle` : `Idle_${mode}`;
                skel.setAnimation?.(0, idleName, true);
                slot.lastAnim = idleName;
                // Idle 진입 시 홈 좌표 캡처(리그별 중앙 오프셋 대응)
                this._captureAimHome(slot, idleName);
            }
            catch { }
        }
        // ✅ 기본 자세(Idle) 기준 좌표로 복귀
        const hx = slot.aimHomeInited ? slot.aimHomeX : 0;
        const hy = slot.aimHomeInited ? slot.aimHomeY : 0;
        slot.aimHasTarget = false;
        slot.canShootNow = false;
        slot.aimCurX = hx;
        slot.aimCurY = hy;
        slot.aimDesX = hx;
        slot.aimDesY = hy;
        slot.aimInited = true;
        slot.aimRefreshCd = 0;
        slot.targetEntId = 0;
        slot.targetCol = -1;
        slot.targetStickyT = 0;
        slot.targetHoldT = 0;
        slot.reacquireDelayT = 0;
        slot.postEquipDelayT = 0;
        slot.pendingDual = false;
        slot.pendingT = 0;
        slot.pendingCol = -1;
        slot.pendingColorId = 0;
        slot.dualFlip = 0;
        // IK 적용(가능한 경우)
        this._applyIkLocal(slot, hx, hy);
    }
    // -----------------------------
    // Move / Recycle
    // -----------------------------
    _moveSlotNode(slot, toLine, toIndex, sec, arcHeight, onDone) {
        if (!slot.node || !slot.node.isValid)
            return;
        const fromLine = slot.line;
        const fromIdx = slot.index;
        const fromPlace = this._placeOf(fromLine, fromIdx);
        const toPlace = this._placeOf(toLine, toIndex);
        if (!fromPlace || !toPlace)
            return;
        const isEquipMove = fromLine !== 'S' && toLine === 'S';
        // // 역할: W2/W3 → S 이동도 '장착 이동'으로 동일 처리
        const isWaitingMove = fromLine !== 'S' && toLine !== 'S';
        if (isEquipMove)
            this._playAnim(slot, 'Jump', true);
        else if (isWaitingMove)
            this._playAnim(slot, 'Move', true);
        this._setSlot(fromLine, fromIdx, null);
        slot.line = toLine;
        slot.index = toIndex | 0;
        this._setSlot(toLine, toIndex, slot);
        slot.moving = true;
        const ui = this._uiTr;
        if (!ui)
            return;
        fromPlace.getWorldPosition(this._tmpW0);
        toPlace.getWorldPosition(this._tmpW1);
        ui.convertToNodeSpaceAR(this._tmpW0, this._tmpL0);
        ui.convertToNodeSpaceAR(this._tmpW1, this._tmpL1);
        const nd = slot.node;
        cc_1.Tween.stopAllByTarget(nd);
        if (slot.opacity)
            cc_1.Tween.stopAllByTarget(slot.opacity);
        nd.setRotationFromEuler(0, 0, 0);
        if (slot.opacity)
            slot.opacity.opacity = 255;
        nd.setParent(this.node);
        nd.setPosition(this._tmpL0);
        const s0 = nd.scale.x;
        const s1 = this._scaleOf(toLine);
        // ✅ StageTool headless simulation: Tween 없이 즉시 스냅(대량 리플레이/검증 속도 개선)
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            // 진행 중 tween 정리
            if (slot.moveParam) {
                try {
                    cc_1.Tween.stopAllByTarget(slot.moveParam);
                }
                catch { }
                this._putTParam(slot.moveParam);
                slot.moveParam = null;
            }
            slot.moveDoneCb = null;
            try {
                nd.setParent(toPlace);
                nd.setRotationFromEuler(0, 0, 0);
                if (slot.opacity)
                    slot.opacity.opacity = 255;
                nd.setScale(s1, s1, 1);
                nd.setPosition(this._vZero);
            }
            catch { }
            this._ensureAnim(slot, 'Idle');
            this._resetUnitPose(slot);
            this._applyAmmoLabelVisual(slot);
            slot.moving = false;
            onDone?.();
            return;
        }
        nd.setScale(s0, s0, 1);
        const duration = Math.max(0.001, sec);
        const x0 = this._tmpL0.x, y0 = this._tmpL0.y, z0 = this._tmpL0.z;
        const x1 = this._tmpL1.x, y1 = this._tmpL1.y, z1 = this._tmpL1.z;
        const p = this._getTParam();
        p.t = 0;
        // ✅ 이동 tween(TParam) 보관: 이동 중 즉시 장착 시 tween을 중지하기 위함
        if (slot.moveParam) {
            try {
                cc_1.Tween.stopAllByTarget(slot.moveParam);
            }
            catch { }
            this._putTParam(slot.moveParam);
        }
        slot.moveParam = p;
        slot.moveDoneCb = onDone ?? null;
        const landSec = 0.08;
        (0, cc_1.tween)(p)
            .to(duration, { t: 1 }, {
            easing: isEquipMove ? 'sineOut' : 'quadOut',
            onUpdate: () => {
                if (!nd.isValid)
                    return;
                const t = p.t;
                const x = x0 + (x1 - x0) * t;
                const z = z0 + (z1 - z0) * t;
                const baseY = y0 + (y1 - y0) * t;
                const arc = isEquipMove && arcHeight > 0 ? arcHeight * (4 * t * (1 - t)) : 0;
                const y = baseY + arc;
                nd.setPosition(x, y, z);
                const s = s0 + (s1 - s0) * t;
                nd.setScale(s, s, 1);
            },
        })
            .call(() => {
            if (!nd.isValid) {
                // ✅ 이동 상태 해제
                if (slot.moveParam === p) {
                    slot.moveParam = null;
                    slot.moveDoneCb = null;
                }
                this._putTParam(p);
                return;
            }
            nd.setParent(toPlace);
            nd.setScale(s1, s1, 1);
            if (isEquipMove) {
                this._ensureAnim(slot, 'Idle');
                this._resetUnitPose(slot);
                this._applyAmmoLabelVisual(slot);
                slot.aimRefreshCd = 0;
                slot.targetHoldT = 0;
                slot.aimHasTarget = false;
                slot.canShootNow = false;
                slot.pendingDual = false;
                slot.pendingT = 0;
                slot.postEquipDelayT = Math.max(0, this.postEquipDelaySec);
                slot.reacquireDelayT = Math.max(0, this.reacquireDelaySec);
                nd.setPosition(this._vLandUp);
                (0, cc_1.tween)(nd)
                    .to(landSec, { position: this._vZero }, { easing: 'quadOut' })
                    .call(() => {
                    slot.moving = false;
                    // ✅ 이동 상태 해제(강제 종료/재진입 안정화)
                    if (slot.moveParam === p) {
                        slot.moveParam = null;
                        slot.moveDoneCb = null;
                    }
                    this._putTParam(p);
                    onDone?.();
                })
                    .start();
            }
            else {
                this._ensureAnim(slot, 'Idle');
                this._resetUnitPose(slot);
                this._applyAmmoLabelVisual(slot);
                slot.aimRefreshCd = 0;
                nd.setPosition(this._vZero);
                slot.moving = false;
                // ✅ 이동 상태 해제(강제 종료/재진입 안정화)
                if (slot.moveParam === p) {
                    slot.moveParam = null;
                    slot.moveDoneCb = null;
                }
                this._putTParam(p);
                onDone?.();
            }
        })
            .start();
    }
    _forceFinishMove(slot) {
        // // 역할: 슬롯이 이동 중일 때 tween을 강제로 종료하고, 현재 목적지 Place에 "정상 착지"시킵니다.
        // // 설명:
        // // - W2→W1 당김 이동 중 탭 즉시 장착을 구현하기 위해 사용
        // // - tween 대상(TParam)을 중지하지 않으면 onUpdate가 계속 좌표를 덮어써서 '사라짐/튐'이 발생할 수 있음
        if (!slot || !slot.node || !slot.node.isValid)
            return;
        // 이동 tween(TParam) 정지/회수
        if (slot.moveParam) {
            try {
                cc_1.Tween.stopAllByTarget(slot.moveParam);
            }
            catch { }
            this._putTParam(slot.moveParam);
            slot.moveParam = null;
        }
        slot.moveDoneCb = null;
        const toPlace = this._placeOf(slot.line, slot.index);
        if (!toPlace || !toPlace.isValid) {
            // 목적지 place를 못 찾으면 이동만 해제
            slot.moving = false;
            return;
        }
        // 노드 tween/페이드 tween 정지
        const nd = slot.node;
        try {
            cc_1.Tween.stopAllByTarget(nd);
        }
        catch { }
        if (slot.opacity) {
            try {
                cc_1.Tween.stopAllByTarget(slot.opacity);
            }
            catch { }
            slot.opacity.opacity = 255;
        }
        // 목적지 place에 스냅
        const s1 = this._scaleOf(slot.line);
        nd.setParent(toPlace);
        nd.setRotationFromEuler(0, 0, 0);
        nd.setScale(s1, s1, 1);
        nd.setPosition(this._vZero);
        // 포즈/라벨 보정(이동 중 뒤틀림 방지)
        this._ensureAnim(slot, 'Idle');
        this._resetUnitPose(slot);
        this._applyAmmoLabelVisual(slot);
        slot.moving = false;
    }
    _recycleAmmoEmpty(slot) {
        if (!slot || !slot.node || !slot.node.isValid)
            return;
        if (slot.moving)
            return;
        const nd = slot.node;
        // 예약 발 정리
        slot.pendingDual = false;
        slot.pendingT = 0;
        if (slot.line === 'S') {
            const idx = slot.index | 0;
            if (idx >= 0 && idx < 5 && this._slotS[idx] === slot)
                this._slotS[idx] = null;
            if (idx >= 0 && idx < 5)
                this._cooldownsS[idx] = 0;
        }
        else {
            this._setSlot(slot.line, slot.index, null);
        }
        this._slotByNode.delete(nd);
        nd.off(cc_1.Node.EventType.TOUCH_END, this._onUnitTouchEnd, this);
        slot.data = null;
        this._recycleUnitNode(nd, slot.opacity);
    }
    // -----------------------------
    // Internal: cache / pool / slots
    // -----------------------------
    _cachePlaces() {
        this._placesS = this._readPlaces(this.shootingLine);
        this._unitPlacesS = this._readUnitPlacesOrNull(this.shootingLine);
        this._placesW1 = this._readPlaces(this.waitingLine01);
        this._placesW2 = this._readPlaces(this.waitingLine02);
        this._placesW3 = this._readPlaces(this.waitingLine03);
    }
    _readPlaces(line) {
        if (!line || !line.isValid)
            return [];
        const out = new Array(5);
        for (let i = 0; i < 5; i++)
            out[i] = line.getChildByName(`Place0${i + 1}`);
        return out;
    }
    _readUnitPlacesOrNull(line) {
        const out = new Array(5);
        for (let i = 0; i < 5; i++)
            out[i] = null;
        if (!line || !line.isValid)
            return out;
        for (let i = 0; i < 5; i++) {
            const n = line.getChildByName(`UnitPlace0${i + 1}`);
            out[i] = n && n.isValid ? n : null;
        }
        return out;
    }
    _prewarmPool() {
        if (!this.unitPrefab)
            return;
        const n = Math.max(0, Math.min(50, this.poolWarmup | 0));
        for (let i = 0; i < n; i++) {
            const nd = (0, cc_1.instantiate)(this.unitPrefab);
            const op = nd.getComponent(cc_1.UIOpacity) || nd.addComponent(cc_1.UIOpacity);
            op.opacity = 255;
            nd.setRotationFromEuler(0, 0, 0);
            nd.active = false;
            this._pool.put(nd);
        }
    }
    _scaleOf(line) {
        switch (line) {
            case 'S':
                return this.scaleShooting;
            case 'W1':
                return this.scaleWaiting01;
            case 'W2':
                return this.scaleWaiting02;
            case 'W3':
                return this.scaleWaiting03;
        }
    }
    _placeOf(line, index) {
        const i = index | 0;
        if (i < 0 || i >= 5)
            return null;
        switch (line) {
            case 'S': {
                // ✅ 유닛은 UnitPlace 우선 (없으면 Place fallback)
                const up = this._unitPlacesS[i];
                if (up && up.isValid)
                    return up;
                return this._placesS[i] ?? null;
            }
            case 'W1':
                return this._placesW1[i] ?? null;
            case 'W2':
                return this._placesW2[i] ?? null;
            case 'W3':
                return this._placesW3[i] ?? null;
        }
    }
    _setSlot(line, index, slot) {
        const i = index | 0;
        if (i < 0 || i >= 5)
            return;
        switch (line) {
            case 'S':
                this._slotS[i] = slot;
                break;
            case 'W1':
                this._slotW1[i] = slot;
                break;
            case 'W2':
                this._slotW2[i] = slot;
                break;
            case 'W3':
                this._slotW3[i] = slot;
                break;
        }
    }
    _findFirstEmptyShooting() {
        for (let i = 0; i < 5; i++) {
            const base = this._placesS[i];
            if (!base || !base.isValid || !base.activeInHierarchy)
                continue;
            if (!this._slotS[i])
                return i;
        }
        return -1;
    }
    _returnSlotNode(slot, clearRef) {
        if (!slot)
            return;
        // 예약 정리
        slot.pendingDual = false;
        slot.pendingT = 0;
        const nd = slot.node;
        if (nd && nd.isValid) {
            cc_1.Tween.stopAllByTarget(nd);
            if (slot.opacity)
                cc_1.Tween.stopAllByTarget(slot.opacity);
            nd.off(cc_1.Node.EventType.TOUCH_END, this._onUnitTouchEnd, this);
            // ✅ 역할: 아직 살아있는 발사 FX가 유닛에 붙은 채로 풀에 들어가는 것을 방지
            // 설명: FX 수명 타이머(_fxActive)보다 먼저 유닛이 회수되면, 다음 스폰에서 FX가 같이 나타날 수 있습니다.
            this._despawnMuzzleFxUnder(slot.muzzleCenter);
            this._despawnMuzzleFxUnder(slot.muzzleLeft);
            this._despawnMuzzleFxUnder(slot.muzzleRight);
            // 안전망: 소켓이 누락된 구조에서도 트리 전체에서 태그 FX를 제거
            this._despawnMuzzleFxInTree(nd);
            // ✅ 역할: 풀에 넣기 전에 Spine 트랙/포즈를 정리해, 다음 재사용 시 본/IK 잔상이 남지 않도록 합니다.
            // 설명: spawn 시에도 리셋하지만, 일부 버전에서는 비활성화 직전 포즈가 저장되어 "첫 프레임"에
            //       튀어 보일 수 있어, 회수 시점에도 한번 더 정리합니다.
            const skel = slot.skel;
            if (skel && skel.isValid) {
                try {
                    skel.clearTracks?.();
                }
                catch { }
                try {
                    skel.setToSetupPose?.();
                }
                catch { }
            }
            if (slot.opacity)
                slot.opacity.opacity = 255;
            nd.setPosition(0, 0, 0);
            nd.setRotationFromEuler(0, 0, 0);
            nd.active = false;
            nd.removeFromParent();
            this._pool.put(nd);
        }
        if (clearRef) {
            this._setSlot(slot.line, slot.index, null);
            this._slotByNode.delete(nd);
            if (slot.line === 'S')
                this._cooldownsS[slot.index] = 0;
        }
    }
    _recycleUnitNode(nd, op) {
        if (!nd || !nd.isValid)
            return;
        cc_1.Tween.stopAllByTarget(nd);
        if (op) {
            cc_1.Tween.stopAllByTarget(op);
            op.opacity = 255;
        }
        // ✅ 역할: 슬롯을 모르는 회수 경로에서도 잔여 발사 FX를 제거(유닛 스폰 시 유령 FX 방지)
        this._despawnMuzzleFxInTree(nd);
        // ✅ 역할: 비정상 포즈(조준/IK)가 남은 채로 풀에 들어가는 것을 방지
        // 설명: Slot을 모르는 경로(예: 임시 노드 회수)에서도 스켈레톤 트랙을 정리합니다.
        const skel = nd.getComponent(cc_1.sp.Skeleton) || nd.getComponentInChildren(cc_1.sp.Skeleton);
        if (skel && skel.isValid) {
            try {
                skel.clearTracks?.();
            }
            catch { }
            try {
                skel.setToSetupPose?.();
            }
            catch { }
        }
        nd.setPosition(0, 0, 0);
        nd.setRotationFromEuler(0, 0, 0);
        nd.active = false;
        nd.removeFromParent();
        this._pool.put(nd);
    }
    _getTParam() {
        return this._tParamPool.length > 0 ? this._tParamPool.pop() : { t: 0 };
    }
    _putTParam(p) {
        p.t = 0;
        this._tParamPool.push(p);
    }
    // -----------------------------
    // ✅ Place 활성 마스크(중앙정렬)
    // -----------------------------
    _mask5FromCount(count) {
        const c = Math.max(0, Math.min(5, count | 0));
        switch (c) {
            case 1:
                return [false, false, true, false, false];
            case 2:
                return [false, true, false, true, false];
            case 3:
                return [false, true, true, true, false];
            case 4:
                return [true, true, true, true, false];
            case 5:
                return [true, true, true, true, true];
            default:
                return [false, false, false, false, false];
        }
    }
};
exports.UnitLineRack = UnitLineRack;
UnitLineRack.BONE_CENTER = 'Cannon_Attack_Center_Muzzle';
UnitLineRack.BONE_LEFT = 'Cannon_Attack_Left_Muzzle';
UnitLineRack.BONE_RIGHT = 'Cannon_Attack_Right_Muzzle';
UnitLineRack.IK_TARGET_BONE = 'Cannon_Target';
UnitLineRack.PATH_CENTER = 'root/Cannon_Attack/Connon_Attack_1/Cannon_Attack_Center_Muzzle';
UnitLineRack.PATH_LEFT = 'root/Cannon_Attack/Cannon_Attack_2/Cannon_Attack_Left/Cannon_Attack_Left_Muzzle';
UnitLineRack.PATH_RIGHT = 'root/Cannon_Attack/Cannon_Attack_2/Cannon_Attack_Right/Cannon_Attack_Right_Muzzle';
UnitLineRack.PATH_LABEL = 'root/Unit/Body/Cannon_Target_Mirror/Label_Num';
__decorate([
    property({ type: cc_1.Node, tooltip: 'Shootingline 노드(자식 Place01~05 / UnitPlace01~05)' })
], UnitLineRack.prototype, "shootingLine", void 0);
__decorate([
    property({ type: cc_1.Node, tooltip: 'WaitingLine01 노드(자식 Place01~05)' })
], UnitLineRack.prototype, "waitingLine01", void 0);
__decorate([
    property({ type: cc_1.Node, tooltip: 'WaitingLine02 노드(자식 Place01~05)' })
], UnitLineRack.prototype, "waitingLine02", void 0);
__decorate([
    property({ type: cc_1.Node, tooltip: 'WaitingLine03 노드(자식 Place01~05)' })
], UnitLineRack.prototype, "waitingLine03", void 0);
__decorate([
    property({ type: cc_1.Prefab, tooltip: '유닛 프리팹(Pre_Unit)' })
], UnitLineRack.prototype, "unitPrefab", void 0);
__decorate([
    property({ type: cc_1.Prefab, tooltip: '머즐 파티클 프리펩(생성형). 발사 순간 머즐 위치에 재생' })
], UnitLineRack.prototype, "muzzleFxPrefab", void 0);
__decorate([
    property({ tooltip: '머즐 파티클 회수 시간(초). 0이면 대략값(0.35s) 사용' })
], UnitLineRack.prototype, "muzzleFxRecycleSec", void 0);
__decorate([
    property({ tooltip: '머즐 파티클 풀 예열 개수' })
], UnitLineRack.prototype, "muzzleFxWarmup", void 0);
__decorate([
    property({ type: Board_1.Board, tooltip: '발사 대상 Board(씬에서 드래그)' })
], UnitLineRack.prototype, "board", void 0);
__decorate([
    property({ tooltip: 'Shootingline 발사 우선순위: LEFT(좌측), CENTER(중앙)' })
], UnitLineRack.prototype, "targetPref", void 0);
__decorate([
    property({ tooltip: '발사 성공 시 다음 시도 간격(초)' })
], UnitLineRack.prototype, "fireIntervalSec", void 0);
__decorate([
    property({
        tooltip: '✅ 큰블럭(2x2, HP) 타겟일 때 연사 간격(초). 기본보다 더 빠르게 해서 "쏘고-대기" 느낌을 줄입니다.',
    })
], UnitLineRack.prototype, "bigTargetFireIntervalSec", void 0);
__decorate([
    property({
        tooltip: '쌍포(shotCount=2) 2번째 발 지연(초). 스몰 블럭 다수 타겟에서 "동시 발사"처럼 보이는 현상을 줄입니다.',
    })
], UnitLineRack.prototype, "dualSecondShotDelaySec", void 0);
__decorate([
    property({
        tooltip: '✅ 큰블럭(2x2) 단일 타겟일 때 2번째 발 지연(초). 0이면 거의 동시에(동일 프레임 가능) 쏩니다.',
    })
], UnitLineRack.prototype, "dualSecondShotDelayBigSec", void 0);
__decorate([
    property({ tooltip: '발사 실패 시 다음 시도 간격(초)' })
], UnitLineRack.prototype, "retryIntervalSec", void 0);
__decorate([
    property({ tooltip: '한 프레임 내 과발사 방지(시도 횟수 제한)' })
], UnitLineRack.prototype, "maxAttemptsPerTick", void 0);
__decorate([
    property({ tooltip: '슈팅 라인(가장 작은) 스케일' })
], UnitLineRack.prototype, "scaleShooting", void 0);
__decorate([
    property({ tooltip: 'WaitingLine01 스케일' })
], UnitLineRack.prototype, "scaleWaiting01", void 0);
__decorate([
    property({ tooltip: 'WaitingLine02 스케일' })
], UnitLineRack.prototype, "scaleWaiting02", void 0);
__decorate([
    property({ tooltip: 'WaitingLine03(가장 큰) 스케일' })
], UnitLineRack.prototype, "scaleWaiting03", void 0);
__decorate([
    property({ tooltip: '장착 이동 시간(초)' })
], UnitLineRack.prototype, "equipMoveSec", void 0);
__decorate([
    property({ tooltip: '장착 이동 시 비행 높이(로컬 y)' })
], UnitLineRack.prototype, "equipJumpY", void 0);
__decorate([
    property({ tooltip: '줄 당김 이동 시간(초)' })
], UnitLineRack.prototype, "shiftMoveSec", void 0);
__decorate([
    property({ tooltip: '풀 프리웜 개수' })
], UnitLineRack.prototype, "poolWarmup", void 0);
__decorate([
    property({ tooltip: '조준 스무딩 속도(권장 10~18)' })
], UnitLineRack.prototype, "aimSmoothSpeed", void 0);
__decorate([
    property({ tooltip: '조준 목표 갱신 주기(초). 권장 0.05~0.12' })
], UnitLineRack.prototype, "aimRefreshSec", void 0);
__decorate([
    property({ tooltip: '타겟 홀드 시간(초)' })
], UnitLineRack.prototype, "targetHoldSec", void 0);
__decorate([
    property({ tooltip: '타겟 재획득 직후 발사 지연(초)' })
], UnitLineRack.prototype, "reacquireDelaySec", void 0);
__decorate([
    property({ tooltip: '장착 직후 발사 지연(초)' })
], UnitLineRack.prototype, "postEquipDelaySec", void 0);
__decorate([
    property({ tooltip: '조준 프레임당 최대 이동량(로컬)' })
], UnitLineRack.prototype, "aimMaxStepPerFrame", void 0);
__decorate([
    property({ tooltip: '타겟 없을 때 원점 복귀(0이면 유지)' })
], UnitLineRack.prototype, "aimReturnSpeed", void 0);
exports.UnitLineRack = UnitLineRack = UnitLineRack_1 = __decorate([
    ccclass('UnitLineRack')
], UnitLineRack);
