// 역할: UnitLineRack BIG(2x2) 타겟 고정 매칭(색상 단위) 로직 분리
// - UnitLineRack.ts update() 비대화를 줄이고, BIG 매칭 규칙을 한 곳에서 유지합니다.

// 정책
// - 같은 색 유닛 여러 개 + BIG 여러 개일 때, "유닛 1개당 BIG 1개"를 고정으로 매칭
// - BIG이 사라지거나 유닛이 사라지면 매칭을 정리(prune)
// - 남는 BIG이 있으면 좌→우 순서로 아직 매칭 없는 유닛에 배정

export function updateBigAssign(r: any, b: any) {
    // colorId -> shooting slot indices(좌측 슬롯부터)
    const byColor: number[][] = r._tmpUnitIdxByColor;
    for (let c = 0; c < byColor.length; c++) byColor[c].length = 0;

    for (let i = 0; i < 5; i++) {
        const placeBase = r._placesS[i];
        if (!placeBase || !placeBase.isValid || !placeBase.activeInHierarchy) continue;
        const slot = r._slotS[i];
        if (!slot || !slot.node?.isValid) continue;
        if (slot.moving) continue;

        const d: any = slot.data;
        if (!d) continue;
        const ammoLeft = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
        if (ammoLeft <= 0) continue;

        const c = (d.colorId | 0) as number;
        if (c < 0 || c >= byColor.length) continue;
        byColor[c].push(i);
    }

    // ✅ 같은 색 유닛들의 BIG 고정 매칭 우선순위:
    // - "장착 순서"(equipSeq) → 슬롯 인덱스(좌→우)
    // - 먼저 장착된 유닛이 BIG 타겟을 먼저 배정받습니다.
    for (let c = 0; c < byColor.length; c++) {
        const arr = byColor[c];
        if (!arr || arr.length <= 1) continue;
        arr.sort((ia, ib) => {
            const sa = r._slotS?.[ia];
            const sb = r._slotS?.[ib];
            const ea = ((sa as any)?.equipSeq ?? 0) | 0;
            const eb = ((sb as any)?.equipSeq ?? 0) | 0;
            if (ea !== eb) return ea - eb;
            return (ia | 0) - (ib | 0);
        });
    }

    const getAssign = (colorId: number) => {
        const k = colorId | 0;
        let a = r._bigAssignByColor.get(k);
        if (!a) {
            a = { unitToEnt: new Map<number, number>(), entToUnit: new Map<number, number>() };
            r._bigAssignByColor.set(k, a);
        }
        return a;
    };

    // update assignment per color
    for (let colorId = 0; colorId < byColor.length; colorId++) {
        const unitIdxs = byColor[colorId];
        if (!unitIdxs || unitIdxs.length <= 0) continue;

        const a = getAssign(colorId);

        // shootable BIGs for this color (좌→우)
        const bigs: any[] = b.listRow0BigEntsInto
            ? b.listRow0BigEntsInto(colorId, r._tmpRow0Bigs, 'LEFT')
            : b.listRow0BigEnts
              ? b.listRow0BigEnts(colorId, 'LEFT')
              : b.listShootableBigEnts
                ? b.listShootableBigEnts(colorId, 'LEFT')
                : [];

        // BIG entId 목록(최대 5개 수준)
        const bigEntIds: number[] = r._tmpBigEntIds;
        bigEntIds.length = 0;
        for (let bi = 0; bi < bigs.length; bi++) {
            const entId = (bigs[bi]?.entId | 0) as number;
            if (entId) bigEntIds.push(entId);
        }

        const hasBig = (entId: number) => {
            const e = entId | 0;
            for (let i = 0; i < bigEntIds.length; i++) {
                if ((bigEntIds[i] | 0) === e) return true;
            }
            return false;
        };

        // (1) prune: dead units or dead BIGs
        const delU: number[] = r._tmpDelU;
        delU.length = 0;
        for (const [u, ent] of a.unitToEnt) {
            if (unitIdxs.indexOf(u) < 0 || !hasBig(ent | 0)) delU.push(u);
        }
        for (let i = 0; i < delU.length; i++) {
            const u = delU[i] | 0;
            const ent = a.unitToEnt.get(u);
            if (ent === undefined) continue;
            a.unitToEnt.delete(u);
            a.entToUnit.delete(ent);
        }

        // ensure entToUnit is consistent
        const delEnt: number[] = r._tmpDelEnt;
        delEnt.length = 0;
        for (const [ent, u] of a.entToUnit) {
            const cur = a.unitToEnt.get(u);
            if (cur === undefined || (cur | 0) !== (ent | 0)) delEnt.push(ent);
        }
        for (let i = 0; i < delEnt.length; i++) a.entToUnit.delete(delEnt[i]);

        // (2) fill: unassigned units with remaining BIGs
        const budget = Math.min(unitIdxs.length, bigs.length);

        const freeUnits: number[] = r._tmpFreeUnits;
        freeUnits.length = 0;
        for (let ui = 0; ui < unitIdxs.length; ui++) {
            const u = unitIdxs[ui] | 0;
            if (!a.unitToEnt.has(u)) freeUnits.push(u);
        }

        let fu = 0;
        for (let bi = 0; bi < bigs.length && a.entToUnit.size < budget && fu < freeUnits.length; bi++) {
            const entId = (bigs[bi]?.entId | 0) as number;
            if (!entId) continue;
            if (a.entToUnit.has(entId)) continue;
            const u = freeUnits[fu++] | 0;
            a.unitToEnt.set(u, entId);
            a.entToUnit.set(entId, u);
        }
    }
}
