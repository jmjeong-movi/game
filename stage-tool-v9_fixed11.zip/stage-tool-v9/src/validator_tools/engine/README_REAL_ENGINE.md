# Real Engine Bridge

To run validation in trusted mode (`isRealEngine=true`), provide an external module and set:

```bash
export REAL_GAME_VALIDATOR_MODULE=path/to/real_game_validator.js
```

Required module contract:

```js
module.exports = {
  isRealEngine: true,
  async validateStageEquivalent(stage, opts) {
    return {
      status: 'SOLVED' | 'UNSOLVED',
      reason: '...',
      failStep: -1,
      opsUsed: ['deck_reorder', 'ammo_redistribute'],
    };
  },
};
```

Without this module, validator stays fail-safe and blocks export.
