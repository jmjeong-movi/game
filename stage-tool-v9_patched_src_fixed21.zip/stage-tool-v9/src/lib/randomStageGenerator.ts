import type { BoardObject, Color12, StageV2 } from './schema';
import { COLOR12 } from './schema';
import { uid } from './ids';
import { calcInitialBlocks } from './board';
import type { PatternKey } from './patterns10x10';
import { isPatternCell } from './patterns10x10';

export type RandomStageGenCfg = {
  // 목표 meta.blockCount
  blockCount: number;
  // 1..10
  difficulty: number;
  pattern: PatternKey;
  // true면 10x10 전체를 채우고(패턴은 색/특수로 표현), false면 패턴 셀만 채움
  fillBackground: boolean;
  // 랜덤 스테이지 대칭(초기 보드 기준)
  // - NONE: 대칭 없음
  // - VERTICAL: 좌우(세로축) 대칭
  // - HORIZONTAL: 상하(가로축) 대칭
  // - RANDOM: 생성 시마다 VERTICAL/HORIZONTAL 중 랜덤 선택
  symmetry: 'NONE' | 'VERTICAL' | 'HORIZONTAL' | 'RANDOM';
  includeChain: boolean;
  includeHidden: boolean;
  includeLarge: boolean;
  includeLargeHidden: boolean;
  includeSpawner: boolean;
  includeKeyLock: boolean;
};

type XY = { x: number; y: number };

function clampInt(n: number, lo: number, hi: number): number {
  const v = Math.floor(Number.isFinite(n) ? n : 0);
  return Math.max(lo, Math.min(hi, v));
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffleInPlace<T>(arr: T[], rng: () => number) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const t = arr[i];
    arr[i] = arr[j];
    arr[j] = t;
  }
}

function pick<T>(arr: T[], rng: () => number): T {
  return arr[Math.max(0, Math.min(arr.length - 1, Math.floor(rng() * arr.length)))]!;
}

function roundUpTo10(n: number): number {
  const v = Math.max(0, Math.floor(n));
  return Math.ceil(v / 10) * 10;
}

function makeAllCells(): XY[] {
  const out: XY[] = [];
  for (let y = 0; y < 10; y++) for (let x = 0; x < 10; x++) out.push({ x, y });
  return out;
}

function canPlace2x2(occ: boolean[][], x: number, y: number): boolean {
  if (x < 0 || y < 0 || x + 1 >= 10 || y + 1 >= 10) return false;
  for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) if (occ[y + dy][x + dx]) return false;
  return true;
}

function mark2x2(occ: boolean[][], x: number, y: number) {
  for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) occ[y + dy][x + dx] = true;
}

function canPlace2x1(occ: boolean[][], x: number, y: number): boolean {
  if (x < 0 || y < 0 || x + 1 >= 10 || y >= 10) return false;
  return !occ[y][x] && !occ[y][x + 1];
}

function mark2x1(occ: boolean[][], x: number, y: number) {
  occ[y][x] = true;
  occ[y][x + 1] = true;
}

function difficultyToColorCount(d: number): number {
  // 1~10 → 2~6색
  const dd = clampInt(d, 1, 10);
  return clampInt(2 + Math.floor((dd - 1) / 2), 2, 6);
}

type SymMode = RandomStageGenCfg['symmetry'];

function resolveSymmetry(mode: SymMode | undefined, rng: () => number): Exclude<SymMode, 'RANDOM'> {
  const m: SymMode = mode ?? 'NONE';
  if (m === 'RANDOM') return rng() < 0.5 ? 'VERTICAL' : 'HORIZONTAL';
  return m;
}

function mirrorPoint(mode: Exclude<SymMode, 'RANDOM'>, x: number, y: number): XY {
  if (mode === 'VERTICAL') return { x: 9 - x, y };
  if (mode === 'HORIZONTAL') return { x, y: 9 - y };
  return { x, y };
}

function mirrorRect(mode: Exclude<SymMode, 'RANDOM'>, x: number, y: number, w: number, h: number): XY {
  if (mode === 'VERTICAL') return { x: 10 - w - x, y };
  if (mode === 'HORIZONTAL') return { x, y: 10 - h - y };
  return { x, y };
}

export function generateRandomStage(base: StageV2, cfg: RandomStageGenCfg, seed: number): StageV2 {
  const rng = mulberry32(seed);

  // ✅ 요청: 랜덤 스테이지가 "약간 대칭" 되도록 옵션 제공
  // - 패턴/일반 블럭 채움은 symmetry를 최대한 지키되,
  //   특정 오브젝트(키/락 등) 때문에 완전 대칭이 깨질 수는 있습니다.
  const symMode = resolveSymmetry(cfg.symmetry, rng);

  const difficulty = clampInt(cfg.difficulty, 1, 10);
  const colorCount = difficultyToColorCount(difficulty);
  const colors = COLOR12.slice(0, colorCount) as Color12[];
  const fg: Color12 = colors[0] ?? 'R';
  const bg: Color12 = colors[1] ?? colors[0] ?? 'B';

  // --- 1) 초기 보드 생성 ---
  const occ: boolean[][] = Array.from({ length: 10 }, () => Array.from({ length: 10 }, () => false));
  const objects: BoardObject[] = [] as any;
  const layer = 0;

  // large
  const wantLarge = !!cfg.includeLarge;
  const wantLargeHidden = !!cfg.includeLargeHidden;
  const largeCount = wantLarge ? clampInt(Math.floor(difficulty / 3), 0, 4) : 0;
  const largeHp = clampInt(20 + difficulty * 10, 20, 200);
  const anchors2x2: XY[] = [];
  for (let y = 0; y <= 8; y++) for (let x = 0; x <= 8; x++) anchors2x2.push({ x, y });
  shuffleInPlace(anchors2x2, rng);
  for (let i = 0; i < largeCount && anchors2x2.length > 0; i++) {
    let placed = false;
    while (anchors2x2.length > 0 && !placed) {
      const a = anchors2x2.pop()!;

      // symmetry: 가능한 경우 미러까지 같이 배치(=대칭 유지)
      const m = symMode;
      const a2 = mirrorRect(m, a.x, a.y, 2, 2);

      if (!canPlace2x2(occ, a.x, a.y)) continue;
      if (m !== 'NONE' && !(a2.x === a.x && a2.y === a.y) && !canPlace2x2(occ, a2.x, a2.y)) continue;

      const t = wantLargeHidden && rng() < 0.35 ? 'BLOCK_LARGE_HIDDEN' : 'BLOCK_LARGE';
      const color = pick(colors, rng);

      // place original
      mark2x2(occ, a.x, a.y);
      objects.push({
        uid: uid(),
        type: t as any,
        x: a.x,
        y: a.y,
        w: 2,
        h: 2,
        color,
        hp: largeHp,
        ...(t === 'BLOCK_LARGE_HIDDEN' ? { revealRule: 'REACH_BOTTOM' } : {}),
        layer,
      } as any);

      // place mirror (if different)
      if (m !== 'NONE' && !(a2.x === a.x && a2.y === a.y)) {
        mark2x2(occ, a2.x, a2.y);
        objects.push({
          uid: uid(),
          type: t as any,
          x: a2.x,
          y: a2.y,
          w: 2,
          h: 2,
          color,
          hp: largeHp,
          ...(t === 'BLOCK_LARGE_HIDDEN' ? { revealRule: 'REACH_BOTTOM' } : {}),
          layer,
        } as any);
      }

      placed = true;
    }
  }

  // spawner
  const wantSpawner = !!cfg.includeSpawner;
  const spawnerCount = wantSpawner ? clampInt(Math.floor((difficulty + 2) / 5), 0, 2) : 0;
  // ✅ 신규 생성박스: hp = 생성할 블럭 수(=queue 길이)
  // - 이전 규칙(1회=2개) 대비 체감량을 비슷하게 하려면 대략 2배 정도가 적당합니다.
  const spawnerBlocks = wantSpawner ? clampInt(4 * difficulty, 2, 60) : 0;
  const anchorsSpawner2x2: XY[] = [];
  for (let y = 0; y <= 8; y++) for (let x = 0; x <= 8; x++) anchorsSpawner2x2.push({ x, y });
  shuffleInPlace(anchorsSpawner2x2, rng);
  for (let i = 0; i < spawnerCount && anchorsSpawner2x2.length > 0; i++) {
    let placed = false;
    while (anchorsSpawner2x2.length > 0 && !placed) {
      const a = anchorsSpawner2x2.pop()!;

      const m = symMode;
      const a2 = mirrorRect(m, a.x, a.y, 2, 2);

      if (!canPlace2x2(occ, a.x, a.y)) continue;
      if (m !== 'NONE' && !(a2.x === a.x && a2.y === a.y) && !canPlace2x2(occ, a2.x, a2.y)) continue;

      const pool2 = (colors.length >= 2 ? colors.slice(0, 2) : [colors[0], colors[0]]) as any;

      // place original
      mark2x2(occ, a.x, a.y);
      objects.push({
        uid: uid(),
        type: 'SPAWNER_BOX',
        x: a.x,
        y: a.y,
        w: 2,
        h: 2,
        hp: spawnerBlocks,
        spawn: { poolColors: pool2 },
        layer,
      } as any);

      // place mirror (if different)
      if (m !== 'NONE' && !(a2.x === a.x && a2.y === a.y)) {
        mark2x2(occ, a2.x, a2.y);
        objects.push({
          uid: uid(),
          type: 'SPAWNER_BOX',
          x: a2.x,
          y: a2.y,
          w: 2,
          h: 2,
          hp: spawnerBlocks,
          spawn: { poolColors: pool2 },
          layer,
        } as any);
      }

      placed = true;
    }
  }

  // key/lock (간단 1쌍)
  const wantKeyLock = !!cfg.includeKeyLock;
  const freeCells: XY[] = makeAllCells().filter((c) => !occ[c.y][c.x]);
  shuffleInPlace(freeCells, rng);
  if (wantKeyLock && freeCells.length >= 2) {
    const k = freeCells.pop()!;
    const l = freeCells.pop()!;
    occ[k.y][k.x] = true;
    occ[l.y][l.x] = true;
    objects.push({ uid: uid(), type: 'KEY', x: k.x, y: k.y, keyId: 'A', layer } as any);
    objects.push({ uid: uid(), type: 'LOCK', x: l.x, y: l.y, lockId: 'A', layer } as any);
  }

  // --- fill normal cells ---
  const wantChain = !!cfg.includeChain;
  const wantHidden = !!cfg.includeHidden;
  const chainRate = wantChain ? Math.min(0.02 + difficulty * 0.01, 0.18) : 0;
  const hiddenRate = wantHidden ? Math.min(0.04 + difficulty * 0.02, 0.35) : 0;

  const pushCell = (x: number, y: number, type: any, color: Color12) => {
    if (occ[y][x]) return;
    if (type === 'BLOCK_HIDDEN') {
      objects.push({ uid: uid(), type, x, y, color, revealRule: 'REACH_BOTTOM', layer } as any);
    } else {
      objects.push({ uid: uid(), type, x, y, color, layer } as any);
    }
    occ[y][x] = true;
  };

  const inPatternAt = (x: number, y: number) => (cfg.pattern !== 'NONE' ? isPatternCell(cfg.pattern, x, y) : true);

  const fillPair = (x: number, y: number, x2: number, y2: number) => {
    const occ1 = occ[y][x];
    const occ2 = occ[y2][x2];
    if (occ1 && occ2) return;

    // symmetry 시에는 패턴을 "대칭 합집합"으로 취급해서 (패턴이 비대칭이어도) 결과를 대칭으로 만듭니다.
    const inPatternPair = cfg.pattern !== 'NONE' ? inPatternAt(x, y) || inPatternAt(x2, y2) : true;
    const shouldFill = cfg.fillBackground ? true : inPatternPair;
    if (!shouldFill) return;

    // 패턴은 fg / 배경은 bg (또는 랜덤)
    let color: Color12;
    if (cfg.pattern !== 'NONE' && cfg.fillBackground) {
      color = inPatternPair ? fg : (rng() < 0.7 ? bg : pick(colors, rng));
    } else if (cfg.pattern !== 'NONE') {
      color = fg;
    } else {
      color = pick(colors, rng);
    }

    let type: any = 'BLOCK_NORMAL';
    if (wantChain && rng() < chainRate) type = 'CHAIN_BARRIER';
    else if (wantHidden && rng() < hiddenRate) type = 'BLOCK_HIDDEN';

    if (!occ1) pushCell(x, y, type, color);
    if (!occ2) pushCell(x2, y2, type, color);
  };

  if (symMode === 'VERTICAL') {
    for (let y = 0; y < 10; y++) {
      for (let x = 0; x < 5; x++) {
        const m = mirrorPoint(symMode, x, y);
        fillPair(x, y, m.x, m.y);
      }
    }
  } else if (symMode === 'HORIZONTAL') {
    for (let y = 0; y < 5; y++) {
      for (let x = 0; x < 10; x++) {
        const m = mirrorPoint(symMode, x, y);
        fillPair(x, y, m.x, m.y);
      }
    }
  } else {
    // 기존(대칭 없음) 로직
    for (let y = 0; y < 10; y++) {
      for (let x = 0; x < 10; x++) {
        if (occ[y][x]) continue;

        const inPattern = cfg.pattern !== 'NONE' ? isPatternCell(cfg.pattern, x, y) : true;
        const shouldFill = cfg.fillBackground ? true : inPattern;
        if (!shouldFill) continue;

        // 패턴은 fg / 배경은 bg (또는 랜덤)
        let color: Color12;
        if (cfg.pattern !== 'NONE' && cfg.fillBackground) {
          color = inPattern ? fg : (rng() < 0.7 ? bg : pick(colors, rng));
        } else if (cfg.pattern !== 'NONE') {
          color = fg;
        } else {
          color = pick(colors, rng);
        }

        let type: any = 'BLOCK_NORMAL';
        if (wantChain && rng() < chainRate) type = 'CHAIN_BARRIER';
        else if (wantHidden && rng() < hiddenRate) type = 'BLOCK_HIDDEN';

        pushCell(x, y, type, color);
      }
    }
  }

  // --- 2) supply 생성 ---
  const initialHits = calcInitialBlocks(objects as any, 10, 10);
  let targetBlockCount = roundUpTo10(cfg.blockCount);
  if (targetBlockCount < initialHits) targetBlockCount = roundUpTo10(initialHits);

  let remainSupplyHits = Math.max(0, targetBlockCount - initialHits);

  // 공급은 기본적으로 NORMAL(1hit)로 채우되, 너무 커지면 LARGE로 압축
  const supplyPages: Array<{ objects: BoardObject[] }> = [];
  const supplyHiddenRate = wantHidden ? Math.min(hiddenRate * 0.5, 0.2) : 0;
  const supplyUseLarge = cfg.includeLarge && remainSupplyHits > 5000;
  const supplyLargeHp = clampInt(40 + difficulty * 10, 40, 400);

  const fillOrder: XY[] = [];
  for (let yy = 0; yy < 10; yy++) for (let xx = 0; xx < 10; xx++) fillOrder.push({ x: xx, y: yy });

  while (remainSupplyHits > 0) {
    const pageOcc: boolean[][] = Array.from({ length: 10 }, () => Array.from({ length: 10 }, () => false));
    const pageObjs: BoardObject[] = [] as any;
    let pageCapacityHits = 0;

    // 1) (옵션) LARGE로 먼저 채워 히트를 크게 올림
    if (supplyUseLarge) {
      const anchors: XY[] = [];
      for (let y = 0; y <= 8; y++) for (let x = 0; x <= 8; x++) anchors.push({ x, y });
      shuffleInPlace(anchors, rng);
      while (remainSupplyHits >= supplyLargeHp && anchors.length > 0) {
        const a = anchors.pop()!;
        if (!canPlace2x2(pageOcc, a.x, a.y)) continue;
        mark2x2(pageOcc, a.x, a.y);
        const hp = Math.min(supplyLargeHp, remainSupplyHits);
        pageObjs.push({
          uid: uid(),
          type: 'BLOCK_LARGE',
          x: a.x,
          y: a.y,
          w: 2,
          h: 2,
          color: pick(colors, rng),
          hp,
          layer: 0,
        } as any);
        remainSupplyHits -= hp;
        pageCapacityHits += hp;
        // 한 페이지가 너무 거대해지는 건 피함
        if (pageCapacityHits >= 2000) break;
      }
    }

    // 2) 남은 히트는 1hit 블럭으로 채움(최대 100)
    // - supply는 layer 의미가 없으므로 0 고정
    shuffleInPlace(fillOrder, rng);
    for (const c of fillOrder) {
      if (remainSupplyHits <= 0) break;
      if (pageOcc[c.y][c.x]) continue;
      // 1hit
      const color = pick(colors, rng);
      const t = wantHidden && rng() < supplyHiddenRate ? 'BLOCK_HIDDEN' : 'BLOCK_NORMAL';
      if (t === 'BLOCK_HIDDEN') {
        pageObjs.push({ uid: uid(), type: t, x: c.x, y: c.y, color, revealRule: 'REACH_BOTTOM', layer: 0 } as any);
      } else {
        pageObjs.push({ uid: uid(), type: t, x: c.x, y: c.y, color, layer: 0 } as any);
      }
      pageOcc[c.y][c.x] = true;
      remainSupplyHits -= 1;
      pageCapacityHits += 1;
      if (pageObjs.length >= 100) break;
    }

    // 안전장치: 더 이상 채울 수 없으면 탈출
    if (pageObjs.length === 0) break;

    supplyPages.push({ objects: pageObjs });
  }

  // --- 3) stage 조립 ---
  const out: StageV2 = {
    ...base,
    meta: {
      ...base.meta,
      seed,
      colorCount,
      blockCount: targetBlockCount,
    } as any,
    board: { ...base.board, w: 10, h: 10, objects },
    supply: {
      ...(base.supply as any),
      mode: 'PATTERN',
      pages: supplyPages,
    } as any,
    // 덱은 export/repairStagePack이 실제 로직 기준으로 채웁니다.
    cards: {
      mode: 'GENERATE',
      rules: { ammoStep: 10, totalAmmoEquals: 'BOARD_BLOCKS' },
    } as any,
  };

  return out;
}
