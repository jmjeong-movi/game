import { _decorator, Component, Node, SafeArea, UITransform, Widget, screen, view, ResolutionPolicy, Vec3 } from 'cc';

const { ccclass, property } = _decorator;

@ccclass('UIAllDeviceAdapter')
export class UIAllDeviceAdapter extends Component {
    @property({ type: Node, tooltip: 'SafeArea 컴포넌트가 붙은 루트 노드' })
    public safeAreaRoot: Node | null = null;

    @property({ type: Node, tooltip: '상단 UI(Top_Menu) 노드' })
    public topMenu: Node | null = null;

    @property({ type: Node, tooltip: '하단 UI(Bottom_Menu) 노드' })
    public bottomMenu: Node | null = null;

    @property({
        type: Node,
        tooltip:
            'Top/Bottom 사이 남은 영역 컨테이너(예: Unit_Position). SafeAreaRoot 기준으로 상/하 패딩을 자동 반영합니다.',
    })
    public centerArea: Node | null = null;

    @property({ tooltip: '디자인 해상도 Width (기본 720)' })
    public designWidth = 720;

    @property({ tooltip: '디자인 해상도 Height (기본 1280)' })
    public designHeight = 1280;

    @property({ tooltip: '기기 비율에 따라 FIXED_WIDTH / FIXED_HEIGHT 자동 선택' })
    public autoResolutionPolicy = true;

    private _safeArea: SafeArea | null = null;
    private _centerWidget: Widget | null = null;

    // 캐시(불필요한 set/update 방지)
    private _lastPolicy: number = -1;
    private _lastTop = -999999;
    private _lastBottom = -999999;

    // 성능: Vec3 재사용(매번 new 방지)
    private _tmpV1: Vec3 = new Vec3();
    private _tmpV2: Vec3 = new Vec3();

    protected onLoad(): void {
        this._safeArea = this.safeAreaRoot?.getComponent(SafeArea) ?? null;

        if (this.centerArea) {
            this._centerWidget = this.centerArea.getComponent(Widget);
            if (!this._centerWidget) this._centerWidget = this.centerArea.addComponent(Widget);

            // 역할: centerArea를 SafeAreaRoot 기준으로 상/하/좌/우 스트레치 정렬
            // 설명: centerArea가 SafeAreaRoot 자식이 아니어도 target 지정으로 안전하게 동작
            this._centerWidget.target = this.safeAreaRoot; // ✅ 기준을 SafeAreaRoot로 고정
            this._centerWidget.isAlignLeft = true;
            this._centerWidget.isAlignRight = true;
            this._centerWidget.isAlignTop = true;
            this._centerWidget.isAlignBottom = true;
            this._centerWidget.left = 0;
            this._centerWidget.right = 0;
        }
    }

    protected onEnable(): void {
        this.applyAll();

        // 성능: 매 프레임 갱신 금지. 리사이즈/회전 시에만 재계산
        screen.on('window-resize', this.applyAll, this);
        screen.on('orientation-change', this.applyAll, this);

        // 일부 버전에서만 존재할 수 있어 optional로 처리
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (view as any).on?.('design-resolution-changed', this.applyAll, this);
    }

    protected onDisable(): void {
        screen.off('window-resize', this.applyAll, this);
        screen.off('orientation-change', this.applyAll, this);

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (view as any).off?.('design-resolution-changed', this.applyAll, this);
    }

    public applyAll(): void {
        if (this.autoResolutionPolicy) this._applyResolutionPolicyAuto();

        // 역할: 노치/홈바 영역 반영
        this._safeArea?.updateArea();

        // 역할: Top/Bottom 메뉴 실제 시각 영역 기준으로 CenterArea 안전영역 계산
        this._applyCenterAreaByVisualBounds();
    }

    private _applyResolutionPolicyAuto(): void {
        // 역할: "현재 프레임(실제 화면)" 기준으로 정책 선택
        const frame = view.getFrameSize();
        const frameW = Math.max(1, frame.width);
        const frameH = Math.max(1, frame.height);

        const designW = Math.max(1, this.designWidth);
        const designH = Math.max(1, this.designHeight);

        const designRatio = designW / designH;
        const frameRatio = frameW / frameH;

        // frame이 더 넓으면(태블릿/가로형) 높이 고정, 더 길면(롱스크린) 너비 고정
        const nextPolicy = frameRatio > designRatio ? ResolutionPolicy.FIXED_HEIGHT : ResolutionPolicy.FIXED_WIDTH;

        if (this._lastPolicy === nextPolicy) return;
        this._lastPolicy = nextPolicy;

        view.setDesignResolutionSize(designW, designH, nextPolicy);
    }

    private _applyCenterAreaByVisualBounds(): void {
        if (!this._centerWidget || !this.safeAreaRoot) return;

        const safeTr = this.safeAreaRoot.getComponent(UITransform);
        if (!safeTr) return;

        const safeH = safeTr.height;
        const safeTopEdge = safeH * 0.5;
        const safeBottomEdge = -safeH * 0.5;

        // Top_Menu의 "아래쪽 경계(minY)"를 SafeAreaRoot 로컬 기준으로 구함
        const topBounds = this._getNodeBoundsInLocal(this.topMenu, this.safeAreaRoot);
        const topPadding = topBounds ? safeTopEdge - topBounds.minY : 0;

        // Bottom_Menu의 "위쪽 경계(maxY)"를 SafeAreaRoot 로컬 기준으로 구함
        const bottomBounds = this._getNodeBoundsInLocal(this.bottomMenu, this.safeAreaRoot);
        const bottomPadding = bottomBounds ? bottomBounds.maxY - safeBottomEdge : 0;

        // 캐시로 불필요 업데이트 방지
        if (topPadding === this._lastTop && bottomPadding === this._lastBottom) return;
        this._lastTop = topPadding;
        this._lastBottom = bottomPadding;

        this._centerWidget.top = Math.max(0, topPadding);
        this._centerWidget.bottom = Math.max(0, bottomPadding);
        this._centerWidget.updateAlignment();
    }

    private _getNodeBoundsInLocal(node: Node | null, relativeTo: Node): { minY: number; maxY: number } | null {
        if (!node) return null;

        const tr = node.getComponent(UITransform);
        const relTr = relativeTo.getComponent(UITransform);
        if (!tr || !relTr) return null;

        const bb = tr.getBoundingBoxToWorld();

        this._tmpV1.set(bb.xMin, bb.yMin, 0);
        this._tmpV2.set(bb.xMax, bb.yMax, 0);

        const pMin = relTr.convertToNodeSpaceAR(this._tmpV1);
        const pMax = relTr.convertToNodeSpaceAR(this._tmpV2);

        return { minY: Math.min(pMin.y, pMax.y), maxY: Math.max(pMin.y, pMax.y) };
    }
}
