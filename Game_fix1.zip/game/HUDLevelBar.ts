import {
    _decorator,
    Component,
    Label,
    ProgressBar,
    ParticleSystem,
    CurveRange,
    find,
    Node,
    instantiate,
    math,
} from 'cc';

const { ccclass, property } = _decorator;

@ccclass('HUDLevelBar')
export class HUDLevelBar extends Component {
    @property({ type: Label, tooltip: 'LEVEL 표시용 라벨' })
    levelLabel: Label | null = null;

    @property({ type: ProgressBar, tooltip: '진행도 프로그래스바(비어있으면 경로로 자동 탐색)' })
    progressBar: ProgressBar | null = null;

    @property({ tooltip: '진행도 채움 부드러움(초). 값이 작을수록 빨리 따라갑니다.' })
    progressSmoothTime = 0.22;

    @property({ tooltip: 'Spark 풀 사이즈(2~4 추천). 재생 중 연속 호출 시 겹쳐서 재생됩니다.' })
    sparkPoolSize = 3;

    private _progressTarget = 0;
    private _progressShown = 0;

    private _tipPS: ParticleSystem | null = null;
    private _glowPS: ParticleSystem | null = null;

    private _sparkTemplateNode: Node | null = null;
    private _sparkPoolNodes: Node[] = [];
    private _sparkPoolPS: ParticleSystem[] = [];
    private _sparkRR = 0;

    // 현재 스테이지 id를 표시합니다.
    setStageId(id: number) {
        // // 역할: 현재 스테이지 id 표시(레퍼런스가 비어있으면 1회 자동 탐색)
        this._bindIfNeeded();
        if (this.levelLabel && this.levelLabel.isValid) this.levelLabel.string = `LEVEL ${id}`;
    }

    // 진행도 목표값(0~1)을 설정합니다. 실제 바는 update에서 부드럽게 따라갑니다.
    setProgress01(v01: number) {
        this._bindIfNeeded();

        const p = Math.max(0, Math.min(1, v01));
        this._progressTarget = p;

        // 초기/리셋 직후는 즉시 반영(바가 0에서 멈춰 보이는 현상 방지)
        if (!this.progressBar || !this.progressBar.isValid) return;
        if (this._progressShown <= 0.0001 && p <= 0.0001) {
            this._progressShown = 0;
            this.progressBar.progress = 0;
        }

        // Tip/Glow는 항상 루프
        this._ensureLoopFx();
    }

    // 블럭이 완전히 제거될 때 1회 스파크를 재생합니다.
    // - 재생 중 다시 호출되면 풀에서 다음 인스턴스를 꺼내 "겹쳐서" 재생됩니다.
    playSparkOnce() {
        this._bindIfNeeded();
        this._ensureLoopFx();
        this._ensureSparkPool();

        if (this._sparkPoolNodes.length <= 0 || this._sparkPoolPS.length <= 0) return;

        const idx = (this._sparkRR++ % this._sparkPoolNodes.length) | 0;
        const n = this._sparkPoolNodes[idx];
        const ps = this._sparkPoolPS[idx];

        if (!n || !n.isValid || !ps || !ps.node || !ps.node.isValid) return;

        n.active = true;

        try {
            ps.playOnAwake = false;
            ps.loop = false;
        } catch {}

        try {
            ps.stop();
            ps.clear();
            ps.play();
        } catch {}

        const offDelay = this._estimateParticleTotalTime(ps);

        const anyN = n as any;
        const tok = (anyN.__sparkTok = ((anyN.__sparkTok | 0) + 1) | 0) as number;

        this.scheduleOnce(() => {
            if (!n.isValid) return;
            if (((n as any).__sparkTok | 0) !== tok) return;

            try {
                ps.stop();
                ps.clear();
            } catch {}

            n.active = false;
        }, offDelay);
    }

    onEnable() {
        this._bindIfNeeded();
        this._ensureLoopFx();
        this._ensureSparkPool();

        // 현재 값 반영(처음 켜질 때 점프 방지)
        if (this.progressBar && this.progressBar.isValid) {
            const p = Math.max(0, Math.min(1, this._progressTarget));
            this._progressShown = p;
            this.progressBar.progress = p;
        }
    }

    onDisable() {
        for (let i = 0; i < this._sparkPoolNodes.length; i++) {
            const n = this._sparkPoolNodes[i];
            if (n && n.isValid) n.active = false;
        }
    }

    update(dt: number) {
        if (!this.progressBar || !this.progressBar.isValid) return;

        const target = this._progressTarget;
        let shown = this._progressShown;

        if (Math.abs(target - shown) <= 0.0005) return;

        // moveTowards 형태(오버슈트 없음)
        const t = Math.max(0.01, this.progressSmoothTime);
        const step = dt / t;
        shown = math.lerp(shown, target, Math.min(1, step));

        // 수렴 안정화
        if (Math.abs(target - shown) <= 0.0008) shown = target;

        this._progressShown = shown;
        this.progressBar.progress = shown;
    }

    // ProgressBar/Particles를 씬 경로로 1회만 찾아서 캐시합니다.
    private _bindIfNeeded() {
        if (!this.progressBar || !this.progressBar.isValid) {
            const n = find('Canvas/UI/Root/BGRoot/Window/ProgressBar') || find('UI/Root/BGRoot/Window/ProgressBar');
            if (n && n.isValid) this.progressBar = n.getComponent(ProgressBar);
        }

        if (!this._tipPS || !this._tipPS.node || !this._tipPS.node.isValid) {
            const n =
                find('Canvas/UI/Root/BGRoot/Window/ProgressBar/Bar/Particle_Tip') ||
                find('UI/Root/BGRoot/Window/ProgressBar/Bar/Particle_Tip');
            this._tipPS = this._getPS(n);
        }

        if (!this._glowPS || !this._glowPS.node || !this._glowPS.node.isValid) {
            const n =
                find('Canvas/UI/Root/BGRoot/Window/ProgressBar/Bar/Particle_Tip/Particle_Glow') ||
                find('UI/Root/BGRoot/Window/ProgressBar/Bar/Particle_Tip/Particle_Glow');
            this._glowPS = this._getPS(n);
        }

        if (!this._sparkTemplateNode || !this._sparkTemplateNode.isValid) {
            const n =
                find('Canvas/UI/Root/BGRoot/Window/ProgressBar/Bar/Particle_Spark') ||
                find('UI/Root/BGRoot/Window/ProgressBar/Bar/Particle_Spark');
            this._sparkTemplateNode = n && n.isValid ? n : null;
        }
    }

    // Tip/Glow는 루프 재생을 보장합니다.
    private _ensureLoopFx() {
        this._playLoop(this._tipPS);
        this._playLoop(this._glowPS);
    }

    private _playLoop(ps: ParticleSystem | null) {
        if (!ps || !ps.node || !ps.node.isValid) return;

        ps.node.active = true;

        try {
            ps.playOnAwake = false;
            ps.loop = true;
        } catch {}

        try {
            ps.play();
        } catch {}
    }

    // Spark 풀을 준비합니다(한 번만).
    private _ensureSparkPool() {
        const tpl = this._sparkTemplateNode;
        if (!tpl || !tpl.isValid) return;

        const want = Math.max(1, Math.min(8, this.sparkPoolSize | 0));
        if (this._sparkPoolNodes.length >= want) return;

        // 0번은 템플릿을 그대로 사용(추가 instantiate 최소화)
        if (this._sparkPoolNodes.length === 0) {
            const ps0 = this._getPS(tpl);
            if (!ps0) return;

            tpl.active = false;

            this._sparkPoolNodes.push(tpl);
            this._sparkPoolPS.push(ps0);
        }

        const parent = tpl.parent;
        if (!parent || !parent.isValid) return;

        while (this._sparkPoolNodes.length < want) {
            const n = instantiate(tpl);
            if (!n) break;

            n.setParent(parent);
            n.active = false;

            const ps = this._getPS(n);
            if (!ps) {
                n.destroy();
                break;
            }

            this._sparkPoolNodes.push(n);
            this._sparkPoolPS.push(ps);
        }
    }

    // Node에서 ParticleSystem을 찾아서 반환합니다. (자식에 붙어있어도 찾음)
    private _getPS(n: Node | null): ParticleSystem | null {
        if (!n || !n.isValid) return null;

        const ps = n.getComponent(ParticleSystem);
        if (ps) return ps;

        const anyN = n as any;
        if (typeof anyN.getComponentInChildren === 'function') {
            return anyN.getComponentInChildren(ParticleSystem) as ParticleSystem | null;
        }

        return null;
    }

    // 파티클 1회 재생이 대략 끝나는 시간을 계산합니다.
    private _estimateParticleTotalTime(ps: ParticleSystem): number {
        const delay = this._curveMax(ps.startDelay);
        const duration = Math.max(0, ps.duration);
        const life = this._curveMax(ps.startLifetime);

        const t = delay + duration + life + 0.05;
        return Math.max(0.05, Math.min(5.0, t));
    }

    // CurveRange에서 최대치 추정(상수 기반). 커브는 안전값으로 추정합니다.
    private _curveMax(cr: CurveRange): number {
        if (!cr) return 0;

        const mode = cr.mode;
        const mult = (cr as any).multiplier ?? 1;

        if (mode === CurveRange.Mode.Constant) {
            return Math.max(0, (cr as any).constant ?? 0) * mult;
        }
        if (mode === CurveRange.Mode.TwoConstants) {
            const a = Math.max(0, (cr as any).constantMin ?? 0);
            const b = Math.max(0, (cr as any).constantMax ?? 0);
            return Math.max(a, b) * mult;
        }

        return 1.0 * mult;
    }
}
