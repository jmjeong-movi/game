// 역할: UnitLineRack 스턱(클리어 실패) 판정/스냅샷 로직 분리
// - UnitLineRack.ts 비대화를 줄이고, 실패 판정 규칙을 한 곳에서 유지합니다.

import { COLOR_TOKEN_ORDER } from '../Types';

// ✅ 클리어 실패 판정(요구사항)
// - 슈팅라인 슬롯이 모두 찼고
// - 장착된 유닛 전체가 "쏠 타겟이 없음"이면 true
export function isStuckNoShootTargets(r: any, board: any): boolean {
    const b: any = board;
    if (!b || !b.isValid) return false;

    // 활성 슈팅 슬롯 수(Place가 활성화된 개수)
    let cap = 0;
    let filled = 0;
    for (let i = 0; i < 5; i++) {
        const place = r._placesS?.[i];
        if (!place || !place.isValid || !place.activeInHierarchy) continue;
        cap++;
        if (r._slotS[i]) filled++;
    }
    if (cap <= 0) return false;
    if (filled < cap) return false;

    // 슬롯이 꽉 찼다: 모든 유닛이 타겟 0인지 확인
    for (let i = 0; i < 5; i++) {
        const slot: any = r._slotS[i];
        if (!slot || !slot.data) continue;

        const colorId = slot.data.colorId | 0;
        const shots = Math.max(1, slot.data.shotCount ? (slot.data.shotCount | 0) : 1);

        try {
            const ex = r._tmpEmptyExcludeEnt;
            ex.clear();
            const ts = b.pickShootTargets?.(colorId, shots, 'LEFT', ex, true);
            ex.clear();
            if (Array.isArray(ts) && ts.length > 0) return false;
        } catch {
            // pickShootTargets 실패 시 보수적으로 '쏠 수 없음'으로 간주
        }
    }

    return true;
}

// ✅ 스턱 디버그 스냅샷(콘솔 로그용)
export function buildStuckSnapshot(r: any, board: any): any {
    const b: any = board;

    const snap: any = {
        capacity: 0,
        filled: 0,
        slots: [] as any[],
        row0: [] as any[],
    };

    // capacity/filled + slot data
    for (let i = 0; i < 5; i++) {
        const place = r._placesS?.[i];
        if (!place || !place.isValid || !place.activeInHierarchy) continue;
        snap.capacity++;

        const slot: any = r._slotS[i];
        if (!slot || !slot.data) {
            snap.slots.push({ idx: i, empty: true });
            continue;
        }

        snap.filled++;
        const d: any = slot.data;
        const colorId = d.colorId | 0;
        const shots = Math.max(1, d.shotCount ? (d.shotCount | 0) : 1);
        const ammo = d.ammo | 0;
        const step = (d.hintStep ?? 0) | 0;

        let targets: any[] = [];
        try {
            const ex = r._tmpEmptyExcludeEnt;
            ex.clear();
            targets = b.pickShootTargets?.(colorId, shots, 'LEFT', ex, true) ?? [];
            ex.clear();
        } catch {
            targets = [];
        }

        snap.slots.push({
            idx: i,
            colorId,
            token: COLOR_TOKEN_ORDER[colorId] ?? 'R',
            shots,
            ammo,
            hintStep: step,
            targetsLen: Array.isArray(targets) ? targets.length : 0,
            targetCols: Array.isArray(targets) ? targets.map((t: any) => (t?.col ?? -1)) : [],
        });
    }

    // row0 summary(best-effort)
    try {
        const cols = b.cols ?? 10;
        for (let c = 0; c < cols; c++) {
            const e = b.entAt?.(0, c);
            if (!e) {
                snap.row0.push(null);
                continue;
            }
            const cid = (e.view?.colorId ?? -1) | 0;
            const isBig = !!(e.w > 1 || e.h > 1);
            snap.row0.push({
                c,
                token: COLOR_TOKEN_ORDER[cid] ?? '?',
                colorId: cid,
                isBig,
                hp: e.view?.getHp?.() ?? 1,
                hidden: !!(e.view?.isHidden?.() ?? (e as any).hidden),
            });
        }
    } catch {
        // ignore
    }

    return snap;
}
