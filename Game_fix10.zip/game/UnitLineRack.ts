import {
    _decorator,
    Component,
    Node,
    Prefab,
    NodePool,
    instantiate,
    UITransform,
    Vec3,
    Mat4,
    director,
    Director,
    EventTouch,
    Tween,
    sp,
    Label,
    UIOpacity,
} from 'cc';

import type { CardData } from './Types';
import { COLOR_TOKEN_ORDER } from './Types';
import { ColorPalette, LabelPalette } from './ColorPalette';
import { Board, type ShootAttemptOut } from './Board';
import { AudioManager } from '../core/AudioManager';
import { pickTargetsSkippingMoving as _pickTargetsSkippingMoving } from './unit/targeting';
import {
    isStuckNoShootTargets as _isStuckNoShootTargets,
    buildStuckSnapshot as _buildStuckSnapshot,
} from './unit/stuck';
import {
    resetAllAimAndPose as _resetAllAimAndPose,
    resetSlotAimAndPose as _resetSlotAimAndPose,
    resetAllExistingUnitPoses as _resetAllExistingUnitPoses,
    resetUnitPose as _resetUnitPose,
} from './unit/pose';
import {
    consumeQueuedEquipInColumn as _consumeQueuedEquipInColumn,
    shiftColumn as _shiftColumn,
    maintainWaitingOverflow as _maintainWaitingOverflow,
    refillFromOverflow as _refillFromOverflow,
} from './unit/waiting';
import { BONE_CENTER, BONE_LEFT, BONE_RIGHT, BONE_IK } from './unit/rackConst';
import {
    despawnMuzzleFxUnder as _despawnMuzzleFxUnder,
    despawnMuzzleFxInTree as _despawnMuzzleFxInTree,
    prewarmMuzzleFx as _prewarmMuzzleFx,
    tickFxRecycle as _tickFxRecycle,
    playMuzzleFx as _playMuzzleFx,
} from './unit/muzzleFx';

import { spawnTo as _spawnTo, findNodeByNameDFS as _findNodeByNameDFS } from './unit/spawn';
import { moveSlotNode as _moveSlotNode, forceFinishMove as _forceFinishMove } from './unit/move';
import { updateBigAssign as _updateBigAssign } from './unit/bigAssign';

const { ccclass, property } = _decorator;

type ShootTargetPref = 'LEFT' | 'CENTER';
type LineKind = 'S' | 'W1' | 'W2' | 'W3';

type Slot = {
    node: Node;
    data: CardData | null;
    line: LineKind;
    index: number; // Place index(0~4)

    // ✅ 같은 색 유닛 타겟 우선권(=장착 순서)
    equipSeq: number;
    moving: boolean;

    // ✅ 이동(특히 W2→W1 당김) 중 탭 시 '도착 후 장착' 예약 플래그
    equipQueued: boolean;

    // ✅ 이동 tween 타겟(TParam) 보관: 이동 중 즉시 장착 시 tween 중지/회수에 사용
    moveParam: TParam | null;

    // ✅ 오버플로우→W3 리필(등장) tween 타겟
    // - 역할: 이동(move)과 별개로 슬롯 등장 애니메이션이 중단되어도 moving 고착이 없게 관리
    appearParam: TParam | null;

    // ✅ 이동 완료 콜백 보관: 강제 종료 시에도 후처리(shift/refill) 트리거를 유지
    moveDoneCb: (() => void) | null;

    skel: sp.Skeleton | null;

    ammoLabel: Label | null;
    opacity: UIOpacity | null;

    muzzleCenter: Node | null;
    muzzleLeft: Node | null;
    muzzleRight: Node | null;

    boneCenter: any | null;
    boneLeft: any | null;
    boneRight: any | null;

    ikTarget: any | null;

    // aim state
    aimHasTarget: boolean;
    aimCurX: number;
    aimCurY: number;
    aimDesX: number;
    aimDesY: number;
    aimInited: boolean;
    aimRefreshCd: number;

    // ✅ 발사 중 에임(본) 고정: 타겟이 여러 개여도 발사 사이클 동안 IK 타겟이 흔들리지 않게 합니다.
    aimLockT: number;

    // ✅ 타겟 고정(엔티티 단위): 한 발 쏘고 다른 타겟으로 튀는 현상( IK 왔다갔다 ) 방지
    targetEntId: number;
    targetCol: number;
    targetStickyT: number;

    // ✅ aim home(대기 시 중앙) - IK 타겟의 '기본 자세' 좌표를 저장해서 0으로 돌아가는 오차/반전 방지
    aimHomeX: number;
    aimHomeY: number;
    aimHomeInited: boolean;
    aimHomeAnim: string;

    targetHoldT: number;
    reacquireDelayT: number;
    postEquipDelayT: number;

    canShootNow: boolean;
    dualFlip: 0 | 1;

    // ✅ 듀얼 2번째 발 예약(동시발사 방지)
    pendingDual: boolean;
    pendingT: number;
    pendingCol: number;
    pendingColorId: number;
    pendingMuzzle: 'L' | 'R';
    pendingIsBig: boolean;

    lastAnim: string;

    // ✅ 유닛 고유 슈팅 SFX(0~2) - CardData에 저장된 값을 캐시
    shotSfxIdx: 0 | 1 | 2;
};

type TParam = { t: number };

type FxActive = {
    node: Node;
    t: number;
};

// ✅ 같은 색 유닛끼리 타겟이 겹치지 않게 하는 1프레임 플랜
// - 역할: 한 프레임 동안 같은 색상(colorId) 유닛들이 서로 다른 엔티티를 우선 선택하도록 제외 목록을 공유합니다.
// - bigBudget/bigEnt: BIG(2x2) 타겟은 “개수만큼만” 분배하고, 중복/스위칭을 막습니다.
type ColorPlan = {
    ent: Set<number>;
    bigBudget: number;
    bigEnt: Set<number>;
    // stamp: update() 호출마다 증가하는 토큰(초기화/재사용 제어)
    stamp: number;
};

@ccclass('UnitLineRack')
export class UnitLineRack extends Component {
    @property({ type: Node, tooltip: 'Shootingline 노드(자식 Place01~05 / UnitPlace01~05)' })
    shootingLine: Node | null = null;

    @property({ type: Node, tooltip: 'WaitingLine01 노드(자식 Place01~05)' })
    waitingLine01: Node | null = null;

    @property({ type: Node, tooltip: 'WaitingLine02 노드(자식 Place01~05)' })
    waitingLine02: Node | null = null;

    @property({ type: Node, tooltip: 'WaitingLine03 노드(자식 Place01~05)' })
    waitingLine03: Node | null = null;

    @property({ type: Prefab, tooltip: '유닛 프리팹(Pre_Unit)' })
    unitPrefab: Prefab | null = null;

    @property({ type: Prefab, tooltip: '머즐 파티클 프리펩(생성형). 발사 순간 머즐 위치에 재생' })
    muzzleFxPrefab: Prefab | null = null;

    @property({ tooltip: '머즐 파티클 회수 시간(초). 0이면 대략값(0.35s) 사용' })
    muzzleFxRecycleSec = 0.35;

    @property({ tooltip: '머즐 파티클 풀 예열 개수' })
    muzzleFxWarmup = 24;

    @property({ type: Board, tooltip: '발사 대상 Board(씬에서 드래그)' })
    board: Board | null = null;

    @property({ tooltip: 'Shootingline 발사 우선순위: LEFT(좌측), CENTER(중앙)' })
    targetPref: ShootTargetPref = 'LEFT';

    @property({
        tooltip:
            '✅ 발사 간격(초). 단일/듀얼 공통으로 "한 발"마다 이 간격으로 다음 발사를 시도합니다. (값이 작을수록 빨라짐)\n' +
            '- 듀얼(shotCount=2)은 좌/우 머즐을 번갈아가며 1발씩 발사합니다(동시발사/버스트 없음).',
    })
    fireIntervalSec = 0.01;

    // ✅ 발사 템포 단순화
    // - 과거(버스트/2번째 발 딜레이/빅 전용 템포 등) 파라미터는 직렬화 호환을 위해 필드는 유지하되,
    //   인스펙터에는 노출하지 않고 실제 로직에서도 사용하지 않습니다.
    @property({ tooltip: '[Deprecated] not used', visible: false })
    bigTargetFireIntervalSec = 0.01;

    @property({ tooltip: '[Deprecated] not used', visible: false })
    dualSecondShotDelaySec = 0.016;

    @property({ tooltip: '[Deprecated] not used', visible: false })
    dualSecondShotDelayBigSec = 0.0;

    @property({ tooltip: '[Deprecated] not used', visible: false })
    retryIntervalSec = 0.03;

    @property({ tooltip: '[Deprecated] not used', visible: false })
    maxAttemptsPerTick = 2;

    @property({ tooltip: '슈팅 라인(가장 작은) 스케일' })
    scaleShooting = 0.72;

    @property({ tooltip: 'WaitingLine01 스케일' })
    scaleWaiting01 = 0.82;

    @property({ tooltip: 'WaitingLine02 스케일' })
    scaleWaiting02 = 0.92;

    @property({ tooltip: 'WaitingLine03(가장 큰) 스케일' })
    scaleWaiting03 = 1.0;

    @property({ tooltip: '장착 이동 시간(초)' })
    equipMoveSec = 0.22;

    @property({ tooltip: '장착 이동 시 비행 높이(로컬 y)' })
    equipJumpY = 70;

    @property({ tooltip: '줄 당김 이동 시간(초)' })
    shiftMoveSec = 0.12;

    @property({ tooltip: '풀 프리웜 개수' })
    poolWarmup = 20;

    @property({ tooltip: '조준 스무딩 속도(권장 10~18)' })
    aimSmoothSpeed = 14;

    @property({ tooltip: '조준 목표 갱신 주기(초). 권장 0.05~0.12' })
    aimRefreshSec = 0.07;

    @property({ tooltip: '타겟 홀드 시간(초)' })
    targetHoldSec = 0.18;

    @property({ tooltip: '타겟 재획득 직후 발사 지연(초)' })
    reacquireDelaySec = 0.07;

    @property({ tooltip: '장착 직후 발사 지연(초)' })
    postEquipDelaySec = 0.1;

    @property({ tooltip: '조준 프레임당 최대 이동량(로컬)' })
    aimMaxStepPerFrame = 45;

    @property({ tooltip: '타겟 없을 때 원점 복귀(0이면 유지)' })
    aimReturnSpeed = 0;

    private _pool = new NodePool('UnitLineRackPool');

    private _muzzleFxPool = new NodePool('UnitLineRackMuzzleFxPool');
    private _fxActive: FxActive[] = [];

    private _uiTr: UITransform | null = null;

    // ✅ 재사용 스택(DFS 탐색용)
    // 풀링 재사용 시 Label_Num이 Skeleton 아래로 재부모화되는 케이스가 있어도 안정적으로 찾기 위함
    private _tmpNodeStack: Node[] = [];

    // Place(바닥) - 활성/비활성/슬롯 유효성 판단은 이걸로
    private _placesS: Node[] = [];
    // UnitPlace(유닛 레이어) - 유닛은 여기에 배치(없으면 Place로 fallback)
    private _unitPlacesS: (Node | null)[] = [];

    private _placesW1: Node[] = [];
    private _placesW2: Node[] = [];
    private _placesW3: Node[] = [];

    private _slotS: (Slot | null)[] = [null, null, null, null, null];

    // ✅ Stage 전환 감지용 토큰(보드의 stageId/stageIndex 등을 읽어 변화 시 유닛 포즈를 1회 리셋)
    private _lastStageToken: any = undefined;

    // ✅ 색상별 BIG(2x2) 고정 매칭(유닛 슬롯 -> BIG entId)
    // - 같은 색 유닛 여러 개 + BIG 여러 개일 때, 각 유닛이 "자기 BIG"을 깨질 때까지 고정으로 쏘도록 합니다.
    // - 매 프레임 즉흥 선택으로 BIG을 서로 바꿔잡는(왔다갔다) 문제를 근본적으로 차단합니다.
    private _bigAssignByColor = new Map<number, { unitToEnt: Map<number, number>; entToUnit: Map<number, number> }>();

    // ✅ update()에서 GC를 유발하는 Map/Set/Array 생성 방지용 재사용 버퍼
    // - 역할: 매 프레임 new Map/new Set/new Array를 줄여 CPU/GPU 프레임 드랍을 완화
    private _tmpUnitIdxByColor: number[][] = Array.from({ length: 12 }, () => []);
    private _planStamp = 0;
    private _planByColor: ColorPlan[] = Array.from({ length: 12 }, () => ({
        ent: new Set<number>(),
        bigEnt: new Set<number>(),
        bigBudget: 0,
        stamp: 0,
    }));

    // ✅ BIG 매칭/플랜 갱신 중 삭제/임시 목록(재사용)
    private _tmpDelU: number[] = [];
    private _tmpDelEnt: number[] = [];
    private _tmpFreeUnits: number[] = [];
    private _tmpBigEntIds: number[] = [];
    private _tmpRow0Bigs: any[] = [];

    // ✅ 빈 exclude Set 재사용(스턱 체크 등에서 new Set() 제거)
    private _tmpEmptyExcludeEnt: Set<number> = new Set();

    // ✅ 타겟 1:1 정책 보조용(프레임 단위)
    // - 요구사항: "타겟도 한개의 유닛만 지정"(1 타겟 = 1 유닛)
    // - update() 1회 동안 entId -> shooting slot index(owner)를 기록해 중복 타겟을 방지/정리합니다.
    private _frameEntOwner: Map<number, number> = new Map();

    // ✅ 조준(aim) 타겟 선택용 exclude Set(색상별)
    // - 요구사항: 같은 색 유닛이 서로 같은 타겟을 바라보며 총구가 흔들리지 않게(=중복 타겟 방지)
    // - Board.pickShootTargets는 excludeEnt(Set)에 선택된 entId를 추가(side-effect)하므로,
    //   "발사용 plan.ent"와 분리해 조준 단계에서만 사용합니다.
    private _aimExcludeByColor: Set<number>[] = Array.from({ length: 12 }, () => new Set<number>());

    private _slotW1: (Slot | null)[] = [null, null, null, null, null];
    private _slotW2: (Slot | null)[] = [null, null, null, null, null];
    private _slotW3: (Slot | null)[] = [null, null, null, null, null];

    private _slotByNode = new WeakMap<Node, Slot>();

    // ✅ 아이템: 유닛 선택 모드(대기라인 유닛 탭 → 슈팅라인 배치)
    private _itemSelectUnitActive = false;

    // ✅ 섞기용 버퍼(재사용 → GC 최소화)
    private _tmpShuffleSlots: Slot[] = [];
    private _tmpShuffleData: (CardData | null)[] = [];
    private _overflowByCol: CardData[][] = Array.from({ length: 5 }, () => []); // ✅ 대기라인 초과분(가상 WaitingLine04+)
    private _overflowHeadByCol: number[] = [0, 0, 0, 0, 0]; // ✅ shift() 비용 제거(컬럼별 head)

    private _tmpW0 = new Vec3();
    private _tmpW1 = new Vec3();
    private _tmpL0 = new Vec3();
    private _tmpL1 = new Vec3();

    private _tmpMuzzleW0 = new Vec3();
    private _tmpMuzzleW1 = new Vec3();

    private _tmpMat = new Mat4();
    private _tmpMatInv = new Mat4();

    private _tmpSkelLocal = new Vec3();
    private _tmpAimWorld = new Vec3();

    private _tmpReparentW = new Vec3();
    private _tmpReparentL = new Vec3();

    private _vLandUp = new Vec3(0, 8, 0);
    private _vZero = new Vec3(0, 0, 0);

    private _tParamPool: TParam[] = [];

    private _cooldownsS: number[] = [0, 0, 0, 0, 0];

    // ✅ 같은 색 유닛의 "타겟 우선권"을 슬롯 인덱스가 아니라 "장착 순서"로 맞추기 위한 시퀀스
    // - S 라인으로 장착될 때(대기라인 → 슈팅라인) 증가값이 할당됩니다.
    private _equipSeqCounter = 0;

    // ✅ update() 루프에서 같은색 유닛만 장착순으로 재정렬하기 위한 인덱스 버퍼(재사용)
    private _tmpShootOrder: number[] = [];

    // ✅ LOCK 유닛(잠금 유닛) 1개씩 해제(키 1개당 1개)
    // - 키가 바닥에 닿아 수집되면(또는 KEY를 맞추면) "가장 앞 순서"의 LOCK 유닛 1개가 해제됩니다.
    // - Stage 카드 순서(cards 배열 순서)를 "우선순위"로 사용합니다.
    private _lockQueue: CardData[] = [];
    private _lockQueueCursor = 0;
    private _pendingLockKeys = 0;
    private _lockQueueReady = false;

    // ✅ 런타임 발사 할당 제거: tryShootAtColumnEx(out 재사용)
    private _tmpShootOut: ShootAttemptOut = { entId: 0, col0: -1, col1: -1, isBig: false };

    // ✅ 유닛별 슈팅 SFX(0~2) 고정 배정용 시리얼
    private _shotSfxSerial = 0;

    // ✅ 역할: 유닛(CardData)마다 슈팅 사운드(0~2)를 "한 번만" 정해서 고정 저장
    // - data.shotSfxIdx가 이미 있으면 그대로 사용(0~2 clamp)
    // - 없으면 serial + colorId를 섞어서 0..2를 부여 후 data에 저장
    // - 셔플/이동/재배치가 되어도 CardData에 저장되어 유지
    private _ensureShotSfxIdx(data: any): 0 | 1 | 2 {
        if (!data) return 0;

        let v = (data as any).shotSfxIdx;
        if (typeof v === 'number') {
            v = v | 0;
            if (v < 0) v = 0;
            if (v > 2) v = 2;
            (data as any).shotSfxIdx = v;
            return v as 0 | 1 | 2;
        }

        const cid = ((data as any).colorId | 0) * 7;
        const idx = ((this._shotSfxSerial++ + cid) % 3) | 0;

        (data as any).shotSfxIdx = idx;
        return idx as 0 | 1 | 2;
    }

    // ✅ 2단계 Lock: overflow(대기라인 초과분) 보충 유지용 틱(아이템/외부 로직으로 구멍이 생겨도 자동 복구)
    private _overflowMaintainCd: number = 0;

    onLoad() {
        this._uiTr = this.getComponent(UITransform) || this.addComponent(UITransform);

        // ✅ Spine IK(총구 조준) 보정: Skeleton update가 늦게 적용되면 update()에서 넣은 IK 타겟이 덮일 수 있습니다.
        // - 렌더 직전(Director.EVENT_BEFORE_DRAW)에도 한 번 더 적용해서 '정면 고정'을 방지합니다.
        director.on(Director.EVENT_BEFORE_DRAW, this._onBeforeDraw, this);
        console.log('[UnitLineRack] IK patch active (v4): resolve IK target from constraint / Cannon_Target');
        this._cachePlaces();
        this._prewarmPool();
        this._prewarmMuzzleFx();
    }

    onDestroy() {
        director.off(Director.EVENT_BEFORE_DRAW, this._onBeforeDraw, this);
        this.clearAll(true);
        this._pool.clear();
        this._muzzleFxPool.clear();
        this._tParamPool.length = 0;
        this._fxActive.length = 0;
    }

    update(dt: number) {
        const b = this.board;
        if (!b || !b.isValid) return;

        // 파티클 회수
        this._tickFxRecycle(dt);

        // ✅ Stage 전환 시(보드의 stageId/stageIndex 등이 바뀌는 경우) 유닛 포즈(조준/IK)를 1회 초기화
        // - 보드 구현이 다를 수 있어, 존재하는 필드만 안전하게 탐색합니다.
        const token =
            (b as any).stageId ??
            (b as any).stageIndex ??
            (b as any).stageNo ??
            (b as any).runtimeId ??
            (b as any)._stageId ??
            (b as any)._stageIndex;

        if (token !== undefined && token !== this._lastStageToken) {
            this._lastStageToken = token;
            this._resetAllExistingUnitPoses();
            // ✅ 스테이지가 바뀌면 BIG 고정 매칭도 초기화
            this._bigAssignByColor.clear();

            // ✅ 스테이지 전환 시 이전 보드의 entId가 남아있지 않도록 타겟을 초기화
            // - entId는 스테이지 로드 시 1부터 재사용될 수 있어, 남아있으면 잘못된 exclude/조준이 발생할 수 있습니다.
            for (let si = 0; si < 5; si++) {
                const s = this._slotS[si];
                if (!s) continue;
                s.targetEntId = 0;
                s.targetCol = -1;
                s.targetStickyT = 0;
                s.targetHoldT = 0;
                s.aimHasTarget = false;
                s.canShootNow = false;
                s.aimLockT = 0;
                s.aimRefreshCd = 0;
            }
        }

        // ✅ LOCK 유닛 해제는 Board의 KEY 수집 콜백에서 즉시 처리합니다.

        const smoothSpeed = Math.max(0, this.aimSmoothSpeed);
        const returnSpeed = Math.max(0, this.aimReturnSpeed);
        const refreshSec = Math.max(0.02, this.aimRefreshSec);

        const holdSec = Math.max(0, this.targetHoldSec);
        const reacqSec = Math.max(0, this.reacquireDelaySec);
        const maxStep = Math.max(0, this.aimMaxStepPerFrame);

        // ✅ 공중 체인 타겟이 "바닥에 기둥 제외 타겟이 없을 때만" 유효하도록 보조 체크
        // - sticky로 잡힌 공중 체인이 이후 상황 변화로 더 이상 허용되지 않을 경우(바닥에 일반 타겟 등장),
        //   해당 공중 체인 타겟을 해제하고 바닥 타겟을 다시 잡을 수 있도록 합니다.
        const hasRow0ShootableNonPillar = (() => {
            const cols = ((b as any).cols ?? 10) | 0;
            const entAt = (b as any).entAt;
            if (typeof entAt !== 'function') return false;
            for (let c = 0; c < cols; c++) {
                const e = entAt.call(b, 0, c);
                if (!e) continue;
                const depth = (e.view?.depth ?? 1) | 0;
                const sp = depth <= 1 ? e.view?.getSpecial?.() ?? null : null;
                if (sp?.t === 'PILLAR') continue;
                if (sp?.t === 'SPAWNER_BOX') continue;
                if (sp?.t === 'LOCK' && !(b as any).unlockedLocks?.has?.(sp.id)) continue;
                return true;
            }
            return false;
        })();

        // -------------------------
        // ✅ BIG(2x2) 고정 매칭(색 그룹 단위)
        // - "BIG 1개당 유닛 1개 고정" + "BIG 개수만큼 BIG 분배" 정책 구현
        // - update()는 매 프레임 호출되므로, 여기서는 new Map/new Set/new Array를 만들지 않고
        //   클래스 필드 버퍼를 재사용합니다(GC/스파이크 방지).
        // -------------------------
        const getBigAssign = (colorId: number) => {
            const k = colorId | 0;
            let a = this._bigAssignByColor.get(k);
            if (!a) {
                a = { unitToEnt: new Map<number, number>(), entToUnit: new Map<number, number>() };
                this._bigAssignByColor.set(k, a);
            }
            return a;
        };

        // ✅ BIG(2x2) 고정 매칭(색 그룹 단위) 갱신
        _updateBigAssign(this as any, b as any);

        // ✅ 같은 색 유닛끼리 타겟이 겹쳐서 하나는 BIG, 하나는 SMALL을 못 잡는 문제 방지
        // - 한 프레임(=이번 update) 동안 이미 할당된 엔티티를 기록해 뒤 슬롯이 다른 타겟을 잡게 합니다.
        const stamp = ++this._planStamp;
        const getPlan = (colorId: number): ColorPlan => {
            const k0 = colorId | 0;
            const k = k0 >= 0 && k0 < this._planByColor.length ? k0 : 0;

            const p = this._planByColor[k];
            if (p.stamp !== stamp) {
                p.stamp = stamp;
                p.ent.clear();
                p.bigEnt.clear();

                // BIG budget는 해당 colorId에서 지금(row0) 쏠 수 있는 BIG 개수만큼
                // ✅ 타겟 우선순위는 항상 좌→우
                const bb = (b as any).countRow0Big
                    ? (b as any).countRow0Big(k, 'LEFT')
                    : (b as any).countShootableBig
                      ? (b as any).countShootableBig(k, 'LEFT')
                      : 0;
                p.bigBudget = bb | 0;

                // NOTE:
                // - "타겟은 제거되기 전까지 유지" 규칙과 결합될 때, BIG을 '미리 예약'하면
                //   (해당 유닛이 이미 다른 타겟을 붙잡고 있는 경우) BIG이 비어있어도 다른 유닛이 못 쏘는 문제가 생깁니다.
                // - 따라서 plan 초기화에서는 BIG을 선점하지 않고,
                //   실제로 각 유닛이 현재 붙잡고 있는 타겟/이번 프레임에 새로 획득한 타겟만 p.ent에 기록합니다.
            }
            return p;
        };

        // ✅ 같은 색 유닛끼리 "장착 순서"(equipSeq) 우선으로 타겟을 잡도록
        //    S 라인 처리 순서를 재정렬합니다.
        // - 기본은 슬롯 인덱스(좌→우)
        // - 같은 색끼리만 equipSeq 오름차순(=먼저 장착된 유닛 먼저)
        const order = this._tmpShootOrder;
        order.length = 0;
        for (let i = 0; i < 5; i++) {
            const placeBase = this._placesS[i];
            if (!placeBase || !placeBase.isValid || !placeBase.activeInHierarchy) continue;
            const slot = this._slotS[i];
            if (!slot || !slot.node?.isValid) continue;
            if (slot.moving) continue;
            order.push(i);
        }

        // ✅ equipSeq 동기화(슬롯 ↔ 데이터)
        // - 일부 경로에서 data.equipSeq만 있거나 slot.equipSeq만 있는 경우가 있어 정렬 키가 흔들릴 수 있습니다.
        for (let k = 0; k < order.length; k++) {
            const idx = order[k];
            const s = this._slotS[idx] as any;
            if (!s) continue;

            const deq = (s.data as any)?.equipSeq;
            const seq = s.equipSeq;

            if (Number.isFinite(deq) && (deq | 0) > 0) {
                if ((seq | 0) !== (deq | 0)) s.equipSeq = deq | 0;
            } else if (Number.isFinite(seq) && (seq | 0) > 0) {
                try {
                    if (s.data) (s.data as any).equipSeq = seq | 0;
                } catch {}
            }
        }

        order.sort((a, bIdx) => {
            const sa = this._slotS[a];
            const sb = this._slotS[bIdx];

            // ✅ 발사/타겟 우선순위: "장착 순서"(equipSeq) → 슬롯 인덱스(좌→우)
            // - equipSeq가 낮을수록(=먼저 장착된 유닛) 먼저 처리되어 총알이 먼저 소비됩니다.
            const ea = ((sa as any)?.data?.equipSeq ?? (sa as any)?.equipSeq ?? 0) | 0;
            const eb = ((sb as any)?.data?.equipSeq ?? (sb as any)?.equipSeq ?? 0) | 0;
            if (ea !== eb) return ea - eb;

            return (a | 0) - (bIdx | 0);
        });

        // ✅ 프레임 단위 중복 타겟 방지 준비
        this._frameEntOwner.clear();

        // ✅ 조준 단계 exclude Set(색상별) 준비 + ✅ "1 타겟 = 1 유닛" 선점(쿨다운 무관)
        //
        // 문제:
        // - 기존 구현은 '발사 루프(쿨다운 통과)'에서만 plan/owner를 등록합니다.
        // - 따라서 우선권 유닛이 쿨다운/딜레이로 스킵되는 프레임에는
        //   다른 유닛이 동일 타겟(BIG 1개 등)을 새로 잡아 "여러 유닛이 한 타겟을 번갈아/동시에 쏘는" 현상이 생길 수 있습니다.
        //
        // 해결:
        // - 프레임 시작 시점에, 이미 잡고 있는(sticky) targetEntId를 우선순위(order)대로 1개만 인정하고
        //   (중복은 즉시 해제)
        // - 그 타겟을 plan.ent/plan.bigEnt + aimExclude에 선등록합니다(쿨다운과 무관).
        //   => 다른 유닛이 같은 타겟을 새로 잡을 수 없음.
        const aimEx = this._aimExcludeByColor;
        for (let c = 0; c < aimEx.length; c++) aimEx[c].clear();

        const entsMap: any = (b as any).ents;
        for (let oi = 0; oi < order.length; oi++) {
            const idx = order[oi] | 0;
            const s = this._slotS[idx];
            if (!s || !s.node?.isValid) continue;

            const d: any = s.data;
            if (!d) {
                // data가 없으면 타겟 유지 의미가 없으므로 정리
                if ((s.targetEntId | 0) > 0) {
                    s.targetEntId = 0;
                    s.targetCol = -1;
                    s.targetStickyT = 0;
                }
                continue;
            }

            // ✅ LOCK 유닛은 타겟/발사 대상이 아니므로 선점하지 않음
            if (d.kind === 'LOCK') {
                if ((s.targetEntId | 0) > 0) {
                    s.targetEntId = 0;
                    s.targetCol = -1;
                    s.targetStickyT = 0;
                }
                continue;
            }

            // ✅ 탄이 없으면 선점 의미가 없음(다른 유닛이 쏘게 두는 편이 자연스럽습니다)
            // - 또한 빈 탄 유닛이 타겟을 붙잡고 있으면 조준/배타 정책이 꼬일 수 있으므로 타겟도 정리합니다.
            const ammoLeft0 = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
            if (ammoLeft0 <= 0) {
                if ((s.targetEntId | 0) > 0) {
                    s.targetEntId = 0;
                    s.targetCol = -1;
                    s.targetStickyT = 0;
                }
                continue;
            }

            const entId = (s.targetEntId | 0) as number;
            if (entId <= 0) continue;

            const colorId = (d.colorId | 0) as number;
            const k = colorId >= 0 && colorId < aimEx.length ? colorId : 0;

            // ✅ 타겟 유효성 검사(존재/색상 불일치 시 즉시 해제)
            let ee: any = null;
            try {
                ee = entsMap && typeof entsMap.get === 'function' ? entsMap.get(entId | 0) : null;
            } catch {
                ee = null;
            }
            if (!ee || (((ee.view?.colorId ?? -999) | 0) !== (colorId | 0))) {
                s.targetEntId = 0;
                s.targetCol = -1;
                s.targetStickyT = 0;
                continue;
            }

            // ✅ 1 타겟 = 1 유닛: 이미 다른(우선순위 높은) 유닛이 소유 중이면 해제
            const owner = this._frameEntOwner.get(entId | 0);
            if (owner !== undefined && (owner | 0) !== (idx | 0)) {
                s.targetEntId = 0;
                s.targetCol = -1;
                s.targetStickyT = 0;
                continue;
            }

            // 소유 등록(쿨다운 무관)
            this._frameEntOwner.set(entId | 0, idx | 0);

            // aimExclude 선등록(같은 색 다른 유닛이 조준/획득 못 하게)
            aimEx[k].add(entId | 0);

            // ✅ 발사용 plan에도 선등록(쿨다운 스킵 프레임에서도 중복 타겟 획득 방지)
            const plan0 = getPlan(colorId | 0);
            plan0.ent.add(entId | 0);
            if ((ee.w > 1 || ee.h > 1) && plan0.bigEnt) plan0.bigEnt.add(entId | 0);
        }

        for (let oi = 0; oi < order.length; oi++) {
            const i = order[oi] | 0;

            // ✅ 유효 슬롯 판단은 Place(바닥) 기준
            const placeBase = this._placesS[i];
            if (!placeBase || !placeBase.isValid || !placeBase.activeInHierarchy) continue;

            const slot = this._slotS[i];
            if (!slot || !slot.node?.isValid) continue;
            if (slot.moving) continue;

            const d: any = slot.data;
            if (!d) continue;

            // ✅ LOCK 유닛: 키(열쇠)로 잠금 해제되기 전까지는 타겟/발사 불가
            // - 정책: 키 1개당 LOCK 유닛 1개씩 해제(가장 앞 순서)
            // - 해제되면 data.kind가 제거되어 NORMAL처럼 동작합니다.
            if (d.kind === 'LOCK') {
                slot.canShootNow = false;
                continue;
            }

            // (Deprecated) 듀얼 2번째 발 예약 시스템은 제거되었습니다.

            let ammoLeft = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
            if (ammoLeft <= 0) {
                this._recycleAmmoEmpty(slot);
                continue;
            }

            if (slot.targetHoldT > 0) slot.targetHoldT = Math.max(0, slot.targetHoldT - dt);
            if (slot.targetStickyT > 0) slot.targetStickyT = Math.max(0, slot.targetStickyT - dt);
            if (slot.reacquireDelayT > 0) slot.reacquireDelayT = Math.max(0, slot.reacquireDelayT - dt);
            if (slot.postEquipDelayT > 0) slot.postEquipDelayT = Math.max(0, slot.postEquipDelayT - dt);

            // -------------------------
            // 에임 락 타이머(발사 중 본 흔들림 방지)
            // -------------------------
            if (slot.aimLockT > 0) slot.aimLockT = Math.max(0, slot.aimLockT - dt);

            // -------------------------
            // 타겟 갱신(주기)
            // -------------------------
            slot.aimRefreshCd -= dt;
            if (slot.aimRefreshCd <= 0) {
                slot.aimRefreshCd = refreshSec;

                // ✅ 총구(에임) 업데이트는 "타겟 선택"과 "타겟 좌표 추적"을 분리합니다.
                // - 이전 구현은 발사 중(aimLockT>0)에 에임 갱신 자체를 막아,
                //   fireIntervalSec이 짧으면 aimLockT가 매 발사마다 갱신되어 에임이 영구적으로 갱신되지 않고
                //   총구가 "고정"되는 현상이 발생할 수 있었습니다.
                // - 해결: 발사 중에도 현재 타겟의 월드 좌표를 계속 추적해 aimDes를 갱신합니다.
                //   타겟 변경(새 타겟 획득)만 sticky 규칙으로 제어합니다.

                const colorId = d.colorId | 0;
                const mode = this._getMode(slot.data);
                const wantShots = mode === 2 ? Math.min(2, ammoLeft) : 1;

                let aimed = false;

                // 1) 이미 지정된 타겟(entId)이 있으면: 타겟은 바꾸지 말고 "좌표만" 계속 업데이트
                if ((slot.targetEntId | 0) > 0) {
                    try {
                        let found: any = null;
                        let foundCol = (slot.targetCol ?? -1) | 0;
                        const entsMap: any = (b as any).ents;
                        const entAtFn = (b as any).entAt;

                        // entId로 직접 조회(공중 체인 포함)
                        if (entsMap && typeof entsMap.get === 'function') {
                            const ee = entsMap.get(slot.targetEntId | 0);
                            if (ee && ((ee.id | 0) === (slot.targetEntId | 0))) {
                                found = ee;
                                foundCol = (ee.col ?? foundCol) | 0;
                            }
                        }

                        // 보조: row0에서 찾기
                        if (!found && typeof entAtFn === 'function') {
                            if (foundCol >= 0) {
                                const ee = entAtFn.call(b, 0, foundCol);
                                if (ee && ((ee.id | 0) === (slot.targetEntId | 0))) found = ee;
                            }
                            if (!found) {
                                const colsN = (b as any).cols | 0;
                                for (let cc = 0; cc < colsN; cc++) {
                                    const ee = entAtFn.call(b, 0, cc);
                                    if (ee && ((ee.id | 0) === (slot.targetEntId | 0))) {
                                        found = ee;
                                        foundCol = cc;
                                        break;
                                    }
                                }
                            }
                        }

                        if (found && ((found.view?.colorId ?? -999) | 0) === (colorId | 0)) {
                            slot.targetCol = foundCol;
                            try {
                                slot.canShootNow = b.isShootableEnt
                                    ? (b.isShootableEnt(colorId, slot.targetEntId | 0).ok ? true : false)
                                    : true;
                            } catch {
                                slot.canShootNow = true;
                            }

                            try {
                                found.view?.node?.getWorldPosition(this._tmpAimWorld);
                            } catch {}

                            const ok = this._computeIkLocalFromWorld(slot, this._tmpAimWorld);
                            if (!slot.aimHasTarget) slot.reacquireDelayT = reacqSec;
                            slot.aimHasTarget = true;
                            slot.targetHoldT = holdSec;
                            slot.targetStickyT = Math.max(slot.targetStickyT || 0, holdSec);

                            if (ok) {
                                slot.aimDesX = Math.round(this._tmpSkelLocal.x);
                                slot.aimDesY = Math.round(this._tmpSkelLocal.y);
                            }
                            aimed = true;
                        } else {
                            slot.targetEntId = 0;
                            slot.targetCol = -1;
                            slot.targetStickyT = 0;
                        }
                    } catch {
                        // ignore
                    }
                }

                // 2) 지정 타겟이 없으면 새로 획득
                if (!aimed) {
                    const exSet = colorId >= 0 && colorId < aimEx.length ? aimEx[colorId] : (aimEx[0] as Set<number>);
                    const targets = (b as any).pickShootTargets
                        ? (b as any).pickShootTargets(colorId, wantShots, 'LEFT', exSet, true)
                        : [];
                    slot.canShootNow = (targets?.length ?? 0) > 0;

                    if (targets.length > 0) {
                        const t0 = targets[0];
                        this._tmpAimWorld.set(t0.world);
                        if (slot.targetStickyT <= 0) slot.targetStickyT = Math.max(0, holdSec);
                        slot.targetEntId = ((t0 as any).entId ?? 0) | 0;
                        slot.targetCol = ((t0 as any).col ?? -1) | 0;

                        const ok = this._computeIkLocalFromWorld(slot, this._tmpAimWorld);
                        if (!slot.aimHasTarget) slot.reacquireDelayT = reacqSec;
                        slot.aimHasTarget = true;
                        slot.targetHoldT = holdSec;

                        if (ok) {
                            slot.aimDesX = Math.round(this._tmpSkelLocal.x);
                            slot.aimDesY = Math.round(this._tmpSkelLocal.y);
                        }
                    } else {
                        slot.targetStickyT = 0;
                        slot.targetEntId = 0;
                        slot.targetCol = -1;
                        slot.targetHoldT = 0;
                        slot.aimHasTarget = false;
                    }
                }
            }

            // ✅ 총구 고정 방지: sticky 타겟이 있는 동안은 매 프레임 타겟의 "현재" 월드 좌표를 따라가며 aimDes를 갱신
            // - aimRefreshSec은 "타겟 선택"(새 타겟 획득) 빈도만 제한하는 용도로 두고,
            //   실제 조준 좌표(본/IK)는 타겟 이동(낙하/슬라이드 등)을 부드럽게 따라가도록 합니다.
            // - 이 로직은 targetEntId가 유지되는 동안만 동작하므로, 다중 타겟 흔들림과는 무관합니다.
            if ((slot.targetEntId | 0) > 0) {
                try {
                    const colorId = (d.colorId | 0) as number;
                    const ee = (b as any).ents?.get?.(slot.targetEntId | 0) ?? null;
                    if (ee && (((ee.view?.colorId ?? -999) | 0) === (colorId | 0))) {
                        // sticky 타겟이 존재하면 aimHasTarget/hold를 유지해서
                        // aimReturn(정면 복귀) 로직 때문에 갑자기 총구가 "고정"(정면)되는 현상을 막습니다.
                        slot.aimHasTarget = true;
                        slot.targetHoldT = holdSec;
                        try {
                            ee.view?.node?.getWorldPosition(this._tmpAimWorld);
                        } catch {}
                        const ok = this._computeIkLocalFromWorld(slot, this._tmpAimWorld);
                        if (ok) {
                            slot.aimDesX = Math.round(this._tmpSkelLocal.x);
                            slot.aimDesY = Math.round(this._tmpSkelLocal.y);
                        }
                    }
                } catch {
                    // ignore
                }
            }

            // ✅ sticky 타겟이 있으면(=targetEntId>0) aimHasTarget을 자동 해제하지 않습니다.
            // - 타겟이 살아있는데도 hold 타이머 때문에 aimHasTarget이 꺼지면
            //   aimReturn(정면 복귀)로 튀면서 "총구가 고정"된 것처럼 보일 수 있습니다.
            if ((slot.targetEntId | 0) <= 0 && slot.aimHasTarget && slot.targetHoldT <= 0) slot.aimHasTarget = false;

            // 애니 전환
            if (slot.aimHasTarget && (slot.canShootNow || slot.targetHoldT > 0)) this._ensureAnim(slot, 'Attack');
            else this._ensureAnim(slot, 'Idle');

            // 조준 스무딩
            if (smoothSpeed > 0 || returnSpeed > 0) {
                const has = slot.aimHasTarget;

                // ✅ 역할: 타겟이 없을 때도 '중앙(Idle 포즈의 IK 기준점)'으로 자연스럽게 복귀
                // - 리그마다 중앙 좌표가 (0,0)이 아닐 수 있으므로 slot.aimHomeX/Y 사용
                // - ShootingLine(S)은 aimReturnSpeed가 0이어도 중앙 복귀를 강제(대기 시 정면 유지)
                const shouldReturnToHome = !has;
                let speed = has ? smoothSpeed : returnSpeed;
                if (shouldReturnToHome && speed <= 0) speed = smoothSpeed > 0 ? smoothSpeed : 12;

                if (speed > 0) {
                    const alpha = 1 - Math.exp(-dt * speed);

                    const homeX = slot.aimHomeInited ? slot.aimHomeX : 0;
                    const homeY = slot.aimHomeInited ? slot.aimHomeY : 0;

                    const tx = has ? slot.aimDesX : shouldReturnToHome || returnSpeed > 0 ? homeX : slot.aimCurX;
                    const ty = has ? slot.aimDesY : shouldReturnToHome || returnSpeed > 0 ? homeY : slot.aimCurY;

                    if (!slot.aimInited) {
                        slot.aimCurX = tx;
                        slot.aimCurY = ty;
                        slot.aimInited = true;
                        this._applyIkLocal(slot, slot.aimCurX, slot.aimCurY);
                    } else {
                        let nx = slot.aimCurX + (tx - slot.aimCurX) * alpha;
                        let ny = slot.aimCurY + (ty - slot.aimCurY) * alpha;

                        if (maxStep > 0) {
                            const dx = nx - slot.aimCurX;
                            const dy = ny - slot.aimCurY;
                            const len = Math.sqrt(dx * dx + dy * dy);
                            if (len > maxStep) {
                                const inv = maxStep / len;
                                nx = slot.aimCurX + dx * inv;
                                ny = slot.aimCurY + dy * inv;
                            }
                        }

                        if (Math.abs(nx - slot.aimCurX) > 0.05 || Math.abs(ny - slot.aimCurY) > 0.05) {
                            slot.aimCurX = nx;
                            slot.aimCurY = ny;
                            this._applyIkLocal(slot, nx, ny);
                        }
                    }
                }
            }

            // -------------------------
            // ✅ 발사(템포 단순화)
            // - 타겟이 있는 동안 "끊김 없이" 연사
            // - 프레임당 최대 1발(과발사/동시발사 방지)
            // - 듀얼(shotCount=2)은 좌/우를 번갈아 1발씩(버스트/2연발 예약 로직 제거)
            // -------------------------
            if (slot.postEquipDelayT > 0) {
                this._cooldownsS[i] = Math.max(0, (this._cooldownsS[i] ?? 0) - dt);
                continue;
            }

            const interval = Math.max(0.001, this.fireIntervalSec);
            let cd = (this._cooldownsS[i] ?? 0) - dt;
            if (cd > 0) {
                this._cooldownsS[i] = cd;
                continue;
            }

            ammoLeft = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
            if (ammoLeft <= 0) {
                this._recycleAmmoEmpty(slot);
                this._cooldownsS[i] = 0;
                continue;
            }

            const colorId = d.colorId | 0;
            const mode = this._getMode(slot.data);

            // ✅ 같은 색 유닛끼리 타겟 중복 방지용 계획(프레임 단위)
            // - 기존 타겟을 유지하더라도(쏠 수 없더라도) 계획에 등록해
            //   다른 유닛이 같은 타겟을 새로 잡지 못하게 합니다.
            const plan = getPlan(colorId);

            // 1) 가능한 한 기존 "고정 타겟"을 유지(조준 흔들림/타겟 스위칭 최소화)
            let col = -1;
            let entId = 0;
            if ((slot.targetEntId | 0) > 0) {
                const cur = (slot.targetEntId | 0) as number;
                const ee = (b as any).ents?.get?.(cur) ?? null;

                // (A) 타겟이 실제로 제거되었거나 색이 다르면 해제
                if (!ee || (((ee.view?.colorId ?? -999) | 0) !== (colorId | 0))) {
                    slot.targetEntId = 0;
                    slot.targetCol = -1;
                    slot.targetStickyT = 0;
                } else {
                    // (B) 1 타겟 = 1 유닛(장착 순서 우선). 이미 다른 유닛이 소유한 타겟이면 해제
                    const owner = this._frameEntOwner.get(cur);
                    if (owner !== undefined && (owner | 0) !== (i | 0)) {
                        slot.targetEntId = 0;
                        slot.targetCol = -1;
                        slot.targetStickyT = 0;
                    } else {
                        // (C) 소유/계획 등록(쏠 수 없더라도 유지)
                        this._frameEntOwner.set(cur, i | 0);
                        plan.ent.add(cur);
                        if ((ee.w > 1 || ee.h > 1) && plan.bigEnt) plan.bigEnt.add(cur);

                        entId = cur;
                        try {
                            const chk = (b as any).isShootableEnt ? (b as any).isShootableEnt(colorId, cur) : null;
                            if (chk?.ok) col = (chk.col ?? -1) | 0;
                        } catch {
                            // ignore
                        }

                        // ✅ 타겟이 존재하는 동안은 '쏠 수 없더라도' 타겟을 바꾸지 않음
                        // - 예약/스폰락/이동 등으로 잠깐 못 쏘는 구간에서 재획득으로 튀는 현상 방지
                        if (col < 0) {
                            // 단, "공중 체인"은 바닥에 (기둥 제외) 타겟이 생기면 더 이상 허용되지 않으므로 해제
                            const spCur =
                                ((ee.view?.depth ?? 1) | 0) <= 1 ? (ee.view?.getSpecial?.() ?? null) : null;
                            if (spCur?.t === 'CHAIN_SEG' && (((ee.row ?? 0) | 0) > 0) && hasRow0ShootableNonPillar) {
                                const cur = (slot.targetEntId | 0) as number;
                                slot.targetEntId = 0;
                                slot.targetCol = -1;
                                slot.targetStickyT = 0;
                                if (this._frameEntOwner.get(cur) === (i | 0)) this._frameEntOwner.delete(cur);
                                // fallthrough -> 새 타겟 획득
                            } else {
                                // ✅ 개선: 1-hit 스몰 타겟은 제거/낙하 애니메이션을 기다리지 않고
                                // 다른 컬럼의 타겟으로 재획득할 수 있게 합니다.
                                // - 원인: colReserved/colBusy로 잠깐 shootable=false가 되면 기존 규칙(타겟 유지) 때문에
                                //   "내려오면 쏘고"(stop-start) 패턴이 생김.
                                // - 해결: 1-hit 타겟(대부분 SMALL)은 shootable이 아니면 즉시 타겟 해제 후 새 타겟 탐색.
                                const oneHit = this._isOneHitLikeTarget(ee);
                                if (oneHit) {
                                    const curId = (slot.targetEntId | 0) as number;
                                    slot.targetEntId = 0;
                                    slot.targetCol = -1;
                                    slot.targetStickyT = 0;
                                    if (this._frameEntOwner.get(curId) === (i | 0)) this._frameEntOwner.delete(curId);
                                    // fallthrough -> 새 타겟 획득
                                } else {
                                    slot.canShootNow = false;
                                    cd = Math.min(0.02, interval);
                                    this._cooldownsS[i] = cd;
                                    continue;
                                }
                            }
                        }
                    }
                }
            }

            // 2) 새 타겟 획득
            if (col < 0) {
                const targets = this._pickTargetsSkippingMoving(b, colorId, 1, slot, plan);
                if (!targets || targets.length <= 0) {
                    // 타겟이 없으면 다음 프레임에 빠르게 재시도(끊김 최소화)
                    slot.canShootNow = false;
                    slot.aimLockT = 0;
                    slot.aimRefreshCd = 0;
                    cd = Math.min(0.02, interval);
                    this._cooldownsS[i] = cd;
                    continue;
                }

                const t0: any = targets[0];
                col = (t0.col ?? -1) | 0;
                entId = (t0.entId ?? 0) | 0;

                // ✅ 총구(조준) 고정 방지: 이번에 선택된 타겟으로 즉시 IK 목표 갱신
                // - aimRefreshSec/aimLockT와 무관하게 발사 루프에서 동기화합니다.
                try {
                    if (t0?.world) {
                        this._tmpAimWorld.set(t0.world);
                        this._syncAimToWorld(slot, this._tmpAimWorld, holdSec);
                    } else {
                        // fallback: entId 기반
                        this._syncAimToEnt(slot, b as any, entId, col, holdSec);
                    }
                } catch {
                    // ignore
                }

                slot.canShootNow = true;
                slot.targetEntId = entId;
                slot.targetCol = col;
                slot.targetStickyT = Math.max(slot.targetStickyT, 0.2);

                // ✅ 소유/계획 등록(1 타겟 = 1 유닛)
                this._frameEntOwner.set(entId | 0, i | 0);
                plan.ent.add(entId | 0);
            }

            // 3) 발사(1발)
            const muzzle: 'C' | 'L' | 'R' = mode === 2 ? (slot.dualFlip === 0 ? 'L' : 'R') : 'C';

            if (!this._getMuzzleWorld(slot, muzzle, this._tmpMuzzleW0)) {
                if (!this._getMuzzleWorld(slot, 'C', this._tmpMuzzleW0)) slot.node.getWorldPosition(this._tmpMuzzleW0);
            }

            const ok = (b as any).tryShootAtColumnEx
                ? (b as any).tryShootAtColumnEx(this._tmpMuzzleW0, colorId, col, this._tmpShootOut)
                : b.tryShootAtColumn(this._tmpMuzzleW0, colorId, col);

            if (ok) {
                this._playMuzzleFx(slot, muzzle, colorId);

                // ✅ 발사 중 에임 고정(본 흔들림 방지)
                slot.aimLockT = Math.max(slot.aimLockT, 0.06);

                ammoLeft = this._consumeAmmo(slot, 1);

                // ✅ 성공 시에만 타겟 고정/스티키 갱신
                // - tryShootAtColumnEx는 CHAIN_SEG를 tail로 정규화할 수 있으므로 out 값을 우선 사용
                const realEnt = ((this._tmpShootOut?.entId ?? entId) | 0) as number;
                const realCol = ((this._tmpShootOut?.col0 ?? col) | 0) as number;
                slot.targetEntId = realEnt;
                slot.targetCol = realCol;
                slot.targetStickyT = Math.max(slot.targetStickyT, 0.7);

                // ✅ 정규화된 실제 타겟(예: CHAIN 꼬리) 기준으로 조준을 다시 한 번 맞춥니다.
                // - fireIntervalSec가 매우 빠른 경우에도 총구가 첫 타겟에 고정되는 문제 방지
                this._syncAimToEnt(slot, b as any, realEnt, realCol, holdSec);

                // ✅ 소유 갱신(정규화로 entId가 바뀐 경우 대비)
                if ((entId | 0) !== (realEnt | 0)) {
                    if (this._frameEntOwner.get(entId | 0) === (i | 0)) this._frameEntOwner.delete(entId | 0);
                }
                this._frameEntOwner.set(realEnt | 0, i | 0);

                // ✅ 핵심: 1-hit(대부분 SMALL) 타겟은 "쏜 즉시" 다음 타겟을 잡을 수 있게 해제
                // - 제거/낙하 애니메이션 동안 targetEntId를 붙잡고 있으면 stop-start 발사(끊김/느림) 체감이 큼
                // - BIG/스택/CHAIN(hp형)은 여러 발이 필요하므로 유지
                try {
                    const eeReal = (b as any).ents?.get?.(realEnt | 0) ?? null;
                    if (this._isOneHitLikeTarget(eeReal)) {
                        slot.targetEntId = 0;
                        slot.targetCol = -1;
                        slot.targetStickyT = 0;
                    }
                } catch {
                    // ignore
                }

                // ✅ 듀얼: 좌/우 번갈아
                if (mode === 2) slot.dualFlip = slot.dualFlip === 0 ? 1 : 0;

                if (ammoLeft <= 0) this._recycleAmmoEmpty(slot);

                cd = interval;
            } else {
                // 실패(예약/락/타겟 변화 등): 타겟은 유지하고 '빠르게 재시도'
                // - 요구사항: "타겟이 있는 한 발사는 끊기지 않고" / "타겟 제거 전까지 타겟 변경 금지"
                slot.canShootNow = false;
                slot.aimLockT = 0;
                slot.aimRefreshCd = 0;

                // 타겟이 실제로 사라진 경우에만 해제
                const cur = (slot.targetEntId | 0) as number;
                const ee = (b as any).ents?.get?.(cur) ?? null;
                if (!ee || (((ee.view?.colorId ?? -999) | 0) !== (colorId | 0))) {
                    slot.targetEntId = 0;
                    slot.targetCol = -1;
                    slot.targetStickyT = 0;
                    if (this._frameEntOwner.get(cur) === (i | 0)) this._frameEntOwner.delete(cur);
                }

                cd = Math.min(0.02, interval);
            }

            this._cooldownsS[i] = cd;
        }

        // ✅ 2단계 Lock: overflow 유지(아이템/외부 로직으로 대기라인에 구멍이 생겨도 자동으로 복구)
        // - 너무 자주 돌면 연출과 충돌할 수 있어 0.08초 간격으로만 점검합니다.
        this._overflowMaintainCd -= dt;
        if (this._overflowMaintainCd <= 0) {
            this._overflowMaintainCd = 0.08;
            this._maintainWaitingOverflow();
        }
    }

    // -----------------------------
    // ✅ 타겟 디테일: "내려오는(이동 중) 엔티티"는 우선 제외
    // -----------------------------
    private _pickTargetsSkippingMoving(b: Board, colorId: number, wantShots: number, slot: Slot, plan: ColorPlan) {
        // 내부 구현은 unit/targeting.ts로 분리
        return _pickTargetsSkippingMoving(this as any, b as any, colorId, wantShots, slot as any, plan as any);
    }

    // -----------------------------
    // ✅ 1-hit(=한 발로 제거되는) 타겟 판정
    //
    // 문제/요구사항:
    // - 스몰 블럭(대부분 1hit 제거)을 쐈을 때, 제거/낙하 애니메이션이 끝날 때까지
    //   "타겟 고정" 때문에 다음 타겟을 못 잡아 발사 템포가 끊기는 느낌이 발생.
    //
    // 정책:
    // - BIG(2x2) / 스택(depth>1) / CHAIN(hp형) 은 여러 발이 필요하므로 기존처럼 타겟 유지.
    // - 그 외 SMALL(1x1) & depth==1 타겟은 "쏘는 순간" 이미 처리 대상이므로
    //   애니메이션/낙하 완료를 기다리지 않고 다음 타겟을 잡을 수 있게 합니다.
    // -----------------------------
    private _isOneHitLikeTarget(e: any): boolean {
        if (!e || !e.view) return false;
        const w = (e.w ?? 1) | 0;
        const h = (e.h ?? 1) | 0;
        if (w > 1 || h > 1) return false; // BIG 제외

        const depth = ((e.view?.depth ?? 1) | 0) as number;
        if (depth > 1) return false; // 스택은 여러 발 필요

        const sp = depth <= 1 ? (e.view?.getSpecial?.() ?? null) : null;
        // hp형 CHAIN은 여러 발 필요
        if (sp?.t === 'CHAIN') return false;

        // 타겟 불가 오브젝트는 애초에 이 함수 의미가 없지만, 방어적으로 제외
        if (sp?.t === 'PILLAR') return false;
        if (sp?.t === 'SPAWNER_BOX') return false;
        if (sp?.t === 'LOCK') return false;

        return true;
    }

    // -----------------------------
    // ✅ 조준 동기화: "이번에 실제로 쏠 타겟"을 기준으로 총구(IK)를 즉시 갱신
    //
    // 문제:
    // - fireIntervalSec가 aimRefreshSec보다 훨씬 빠르거나(예: 0.01s vs 0.07s)
    // - aimLockT로 aimRefresh가 막힌 상태에서
    //   스몰(1-hit) 타겟을 연속으로 갈아타면,
    //   "발사는 계속 되는데 총구(조준)는 첫 타겟에 고정"되는 체감이 발생합니다.
    //
    // 해결:
    // - 발사 루프에서 타겟(col/entId)을 확정하는 순간에,
    //   해당 타겟의 월드 좌표로 IK 목표를 바로 갱신해서 '조준 고정'을 방지합니다.
    // - IK가 없거나 계산이 실패하면(리그 불일치 등) 발사 진행은 그대로 유지합니다.
    // -----------------------------
    private _syncAimToWorld(slot: Slot, world: Vec3, holdSec: number): void {
        try {
            // IK local 계산 실패는 연출만 실패로 취급
            const ok = this._computeIkLocalFromWorld(slot, world);
            if (!ok) return;

            slot.aimDesX = Math.round(this._tmpSkelLocal.x);
            slot.aimDesY = Math.round(this._tmpSkelLocal.y);

            // ✅ 조준 유지(스무딩 대상)
            slot.aimHasTarget = true;
            slot.targetHoldT = Math.max(slot.targetHoldT || 0, holdSec);

            // ✅ 첫 프레임 고정 방지: aimInited 이전이면 즉시 적용
            if (!slot.aimInited) {
                slot.aimCurX = slot.aimDesX;
                slot.aimCurY = slot.aimDesY;
                slot.aimInited = true;
                this._applyIkLocal(slot, slot.aimCurX, slot.aimCurY);
            }
        } catch {
            // ignore
        }
    }

    private _syncAimToEnt(slot: Slot, b: any, entId: number, colHint: number, holdSec: number): void {
        if ((entId | 0) <= 0) return;
        try {
            const ee = b?.ents?.get ? b.ents.get(entId | 0) : null;
            if (ee?.view?.node?.isValid) {
                ee.view.node.getWorldPosition(this._tmpAimWorld);
                this._syncAimToWorld(slot, this._tmpAimWorld, holdSec);
                return;
            }

            // fallback: 셀 중심 월드 좌표(뷰 노드가 아직 없을 수 있음)
            const row = ((ee?.row ?? 0) | 0) as number;
            const col = (((ee?.col ?? colHint) ?? colHint) | 0) as number;

            if (typeof b?.cellWorldPosInto === 'function') {
                b.cellWorldPosInto(row, col, this._tmpAimWorld);
                this._syncAimToWorld(slot, this._tmpAimWorld, holdSec);
                return;
            }
            if (typeof b?.cellWorldPos === 'function') {
                const w = b.cellWorldPos(row, col);
                if (w) {
                    this._tmpAimWorld.set(w);
                    this._syncAimToWorld(slot, this._tmpAimWorld, holdSec);
                }
            }
        } catch {
            // ignore
        }
    }

    // -----------------------------
    // Public API
    // -----------------------------

    // ✅ 클리어 실패 판정(요구사항)
    // - 슈팅라인 슬롯이 모두 찼고
    // - 장착된 유닛 전체가 "쏠 타겟이 없음"이면 true
    public isStuckNoShootTargets(board: any): boolean {
        return _isStuckNoShootTargets(this as any, board);
    }

    // ✅ 스턱 디버그 스냅샷(콘솔 로그용)
    // - 실패조건: 슬롯 full & 전원 타겟 0
    // - 현재 슬롯 구성/각 슬롯의 타겟 개수/row0 요약을 반환
    public buildStuckSnapshot(board: any): any {
        return _buildStuckSnapshot(this as any, board);
    }

    rebuild(slotCount: number, pickerCols: number, waitLineCount: number) {
        const shootCols = Math.max(0, Math.min(5, slotCount | 0));
        const pickCols = Math.max(0, Math.min(5, pickerCols | 0));
        const waitN = Math.max(1, Math.min(3, waitLineCount | 0));

        const w1Node = this.waitingLine01;
        const w2Node = this.waitingLine02;
        const w3Node = this.waitingLine03;

        if (w1Node && w1Node.isValid) w1Node.active = waitN >= 1;
        if (w2Node && w2Node.isValid) w2Node.active = waitN >= 2;
        if (w3Node && w3Node.isValid) w3Node.active = waitN >= 3;

        const shootMask = this._mask5FromCount(shootCols);
        const pickMask = this._mask5FromCount(pickCols);

        // ✅ Shooting: Place와 UnitPlace를 같이 on/off
        for (let i = 0; i < 5; i++) {
            const base = this._placesS[i];
            if (base && base.isValid) base.active = !!shootMask[i];

            const up = this._unitPlacesS[i];
            if (up && up.isValid) up.active = !!shootMask[i];

            if (!shootMask[i]) this._returnSlotNode(this._slotS[i], true);
        }

        const w1On = !!w1Node?.active;
        const w2On = !!w2Node?.active;
        const w3On = !!w3Node?.active;

        for (let i = 0; i < 5; i++) {
            const p1 = this._placesW1[i];
            const p2 = this._placesW2[i];
            const p3 = this._placesW3[i];

            const on = !!pickMask[i];

            if (p1 && p1.isValid) p1.active = w1On && on;
            if (p2 && p2.isValid) p2.active = w2On && on;
            if (p3 && p3.isValid) p3.active = w3On && on;

            if (!w1On || !on) this._returnSlotNode(this._slotW1[i], true);
            if (!w2On || !on) this._returnSlotNode(this._slotW2[i], true);
            if (!w3On || !on) this._returnSlotNode(this._slotW3[i], true);

            if (!shootMask[i]) this._cooldownsS[i] = 0;
        }
    }
    public resetAllAimAndPose(): void {
        _resetAllAimAndPose(this as any);
    }

    private _resetSlotAimAndPose(s: Slot): void {
        _resetSlotAimAndPose(this as any, s as any);
    }

    setWaitingUnits(units: CardData[]) {
        // ✅ LOCK 유닛 해제(키 1개당 1개)용 큐 재구성
        // - 주의: Board.load() 중에 KEY가 먼저 수집될 수 있으므로(pending)
        //   pending 키 개수는 유지하고, 카드 배치가 끝난 뒤에 적용합니다.
        this._lockQueue.length = 0;
        this._lockQueueCursor = 0;
        this._lockQueueReady = false;

        // // 역할: 대기라인(W1~W3) 초기 배치 + 초과분은 컬럼별 오버플로 큐에 저장(가상 WaitingLine04+)
        for (let i = 0; i < 5; i++) {
            this._returnSlotNode(this._slotW1[i], true);
            this._returnSlotNode(this._slotW2[i], true);
            this._returnSlotNode(this._slotW3[i], true);
            this._overflowByCol[i].length = 0;
            this._overflowHeadByCol[i] = 0;
        }

        const list = Array.isArray(units) ? units : [];

        // ✅ "가장 앞 순서"를 카드 배열 순서로 고정
        // - kind==='LOCK' 카드만 별도 큐에 기록해 두고, 키를 얻을 때마다 앞에서부터 1개씩 해제합니다.
        for (let i = 0; i < list.length; i++) {
            const d: any = list[i] as any;
            if (!d) continue;
            (d as any).__deckIdx = i | 0;
            if ((d as any).kind === 'LOCK') this._lockQueue.push(d as CardData);
        }

        const w1On = !!this.waitingLine01?.active;
        const w2On = !!this.waitingLine02?.active;
        const w3On = !!this.waitingLine03?.active;

        const activeCols: number[] = [];
        for (let i = 0; i < 5; i++) {
            const p = this._placesW1[i];
            if (p && p.isValid && p.active) activeCols.push(i);
        }

        const cols = activeCols.length;
        if (cols <= 0) return;

        const waitN = (w1On ? 1 : 0) + (w2On ? 1 : 0) + (w3On ? 1 : 0);
        const cap = Math.max(0, Math.min(15, waitN * cols));
        const count = Math.min(cap, list.length);

        // (A) W1~W3 채우기
        for (let k = 0; k < count; k++) {
            const lineIdx = (k / cols) | 0;
            const colIdx = activeCols[k % cols];

            let line: LineKind = 'W1';
            if (lineIdx === 0) line = 'W1';
            else if (lineIdx === 1) line = 'W2';
            else line = 'W3';

            if (line === 'W2' && !w2On) break;
            if (line === 'W3' && !w3On) break;

            this._spawnTo(line, colIdx, list[k]);
        }

        // (B) 초과분은 "가상 라인(W4+)"로 간주하여 컬럼별 큐에 저장
        for (let k = count; k < list.length; k++) {
            const colIdx = activeCols[k % cols];
            this._overflowByCol[colIdx].push(list[k]);
        }

        // ✅ 카드 배치가 끝난 뒤에 pending 키를 적용(가능한 만큼)
        this._lockQueueReady = true;
        if ((this._pendingLockKeys | 0) > 0 && this._lockQueue.length > 0) {
            let unlockedAny = false;
            while ((this._pendingLockKeys | 0) > 0) {
                if (!this._unlockNextLockUnitNoRefresh()) break;
                this._pendingLockKeys = Math.max(0, (this._pendingLockKeys | 0) - 1);
                unlockedAny = true;
            }
            if (unlockedAny) this._refreshAllUnitSkinsAndLabels();
        }
    }

    // -----------------------------
    // ✅ KEY → LOCK 유닛 해제
    // -----------------------------

    // ✅ Stage 시작 전 상태 초기화
    // - GameFlow.loadStage에서 Board.load() 전에 호출해
    //   보드 로딩 중 발생하는 KEY 수집 이벤트를 pending으로 누적할 수 있게 합니다.
    public resetKeyUnlockState(): void {
        this._lockQueue.length = 0;
        this._lockQueueCursor = 0;
        this._pendingLockKeys = 0;
        this._lockQueueReady = false;
    }

    // ✅ Board.collectKey 콜백에서 호출
    // - 키 1개당 LOCK 유닛 1개(가장 앞 순서) 해제
    public onKeyCollected(_keyId: string): void {
        // keyId 자체는 보드의 LOCK(셀) 해제에 사용되며,
        // 잠금 유닛 해제는 "키 획득 1회"를 토큰으로 사용합니다.
        this._pendingLockKeys = (this._pendingLockKeys | 0) + 1;

        if (!this._lockQueueReady || this._lockQueue.length <= 0) return;

        const ok = this._unlockNextLockUnitNoRefresh();
        if (ok) {
            this._pendingLockKeys = Math.max(0, (this._pendingLockKeys | 0) - 1);
            this._refreshAllUnitSkinsAndLabels();
        }
    }

    // ✅ 잠금 유닛 1개를 실제로 해제(kind 제거)
    private _unlockNextLockUnitNoRefresh(): boolean {
        const q = this._lockQueue;
        let i = this._lockQueueCursor | 0;
        if (i < 0) i = 0;

        for (; i < q.length; i++) {
            const d: any = q[i] as any;
            if (!d) continue;
            if ((d as any).kind !== 'LOCK') continue; // 이미 해제됨

            // ✅ 해제: kind를 제거/무효화하여 모든 로직에서 NORMAL처럼 취급되게 함
            try {
                (d as any).kind = undefined;
                try {
                    delete (d as any).kind;
                } catch {}
            } catch {
                // ignore
            }

            this._lockQueueCursor = (i + 1) | 0;
            return true;
        }

        this._lockQueueCursor = q.length | 0;
        return false;
    }

    clearAll(clearShooting: boolean) {
        for (let i = 0; i < 5; i++) {
            this._returnSlotNode(this._slotW1[i], true);
            this._returnSlotNode(this._slotW2[i], true);
            this._returnSlotNode(this._slotW3[i], true);
            if (clearShooting) this._returnSlotNode(this._slotS[i], true);
            this._cooldownsS[i] = 0;
        }
    }

    // -----------------------------
    // Click / Equip
    // -----------------------------

    public beginItemSelectUnitToShoot() {
        // // 역할: 유닛 선택 아이템 사용 시작(다음 탭을 슈팅라인 배치로 처리)
        this._itemSelectUnitActive = true;
    }

    public isItemSelectUnitToShootActive(): boolean {
        // // 역할: 아이템1(유닛 선택 → 슈팅라인 배치) 모드가 활성인지 외부에서 확인
        // // - BottomItemBar의 오버레이 종료 타이밍(선택 완료 시 자동 닫기)에 사용
        return !!this._itemSelectUnitActive;
    }

    public cancelItemSelectUnitToShoot() {
        // // 역할: 유닛 선택 모드 강제 종료
        this._itemSelectUnitActive = false;
    }

    public useItemShuffleUnits(): boolean {
        // // 역할: 대기라인 유닛 중 '섞기 가능(NORMAL)'만 랜덤 재배치(체인/락/생성기 제외)
        this._tmpShuffleSlots.length = 0;
        this._tmpShuffleData.length = 0;

        const collect = (arr: (Slot | null)[] | null) => {
            if (!arr) return;
            for (let i = 0; i < arr.length; i++) {
                const s = arr[i];
                if (!s || !s.node?.isValid) continue;
                if (s.moving) continue;
                if (!s.data) continue;

                const k = (s.data as any).kind as any;
                if (k === 'CHAIN' || k === 'LOCK' || k === 'SPAWNER') continue;

                this._tmpShuffleSlots.push(s);
                this._tmpShuffleData.push(s.data);
            }
        };

        collect(this._slotW1);
        collect(this._slotW2);
        collect(this._slotW3);

        const n = this._tmpShuffleData.length;
        if (n <= 1) return false;

        // Fisher–Yates(in-place) : 추가 배열 생성 없이 셔플
        for (let i = n - 1; i > 0; i--) {
            const j = (Math.random() * (i + 1)) | 0;
            const tmp = this._tmpShuffleData[i];
            this._tmpShuffleData[i] = this._tmpShuffleData[j];
            this._tmpShuffleData[j] = tmp;
        }

        // 데이터만 교체(노드 이동 없음) → 가장 가볍고 빠름
        for (let i = 0; i < n; i++) {
            const s = this._tmpShuffleSlots[i];
            const d = this._tmpShuffleData[i] as CardData;
            s.data = d;
            // ✅ 데이터가 바뀌었으니 유닛 고유 슈팅 SFX 캐시도 갱신
            (s as any).shotSfxIdx = this._ensureShotSfxIdx(d);

            // // 역할: 섞인 결과를 즉시 시각 반영
            this._applySkinByColor(s);
            this._applyAmmoLabelVisual(s);
            this._ensureAnim(s, 'Idle');

            // // 역할: 대기 중 조준 상태/예약 샷 리셋
            s.aimRefreshCd = 0;
            s.pendingDual = false;
            s.pendingT = 0;
        }

        return true;
    }

    private _onUnitTouchEnd = (ev: EventTouch) => {
        const n = ev?.target as Node | null;
        if (!n || !n.isValid) return;
        const slot = this._slotByNode.get(n);
        if (!slot) return;

        // ✅ 이동 중(W2→W1 당김 포함) 탭 처리:
        // - 순간이동/중복 이동은 금지
        // - ✅ 단, 'W2→W1 당김 이동' 중 탭하면 **즉시 슈팅라인 장착**(예약 아님)
        //   - UX: 빠른 연속 탭에서도 "이동 중이라도 바로 장착" 동작
        //   - 안정성: 이동 tween(TParam)을 강제 종료해 '사라짐/튀김'을 방지
        if (slot.moving) {
            if (!this._itemSelectUnitActive && slot.line === 'W1') {
                // 빈 슈팅 슬롯이 있을 때만 즉시 장착
                if (this._findFirstEmptyShooting() >= 0) {
                    slot.equipQueued = false;
                    this._forceFinishMove(slot); // ✅ 이동 강제 종료(부모/좌표/스케일 정리)
                    this._equipFromWaiting('W1', slot.index | 0);
                } else {
                    // 슈팅라인이 가득 찼으면 아무것도 하지 않음(예약도 하지 않음)
                    slot.equipQueued = false;
                }
            }
            return;
        }

        // ✅ 아이템 모드: W1/W2/W3 모두 선택 가능
        if (this._itemSelectUnitActive) {
            if (slot.line === 'W1' || slot.line === 'W2' || slot.line === 'W3') {
                const ok = this._equipFromWaiting(slot.line, slot.index);
                if (ok) this._itemSelectUnitActive = false; // 1회 소모
            }
            return;
        }

        // 기본 모드: 기존 룰 유지(W1만 탭 장착)
        if (slot.line !== 'W1') return;
        this._equipFromWaiting01(slot.index);
    };
    private _equipFromWaiting01(index: number) {
        // // 역할: 기존 기능 유지(W1 → S 장착)
        this._equipFromWaiting('W1', index);
    }

    private _equipFromWaiting(line: LineKind, index: number): boolean {
        // // 역할: 대기라인(W1/W2/W3) 선택 유닛을 슈팅라인(S) 빈 슬롯에 배치
        const fromIdx = index | 0;

        const fromPlace = this._placeOf(line, fromIdx);
        if (!fromPlace || !fromPlace.isValid || !fromPlace.activeInHierarchy) return false;

        const fromArr = line === 'W1' ? this._slotW1 : line === 'W2' ? this._slotW2 : this._slotW3;
        const from = fromArr[fromIdx];
        if (!from || !from.node?.isValid) return false;
        if (from.moving) return false;
        // ✅ LOCK 유닛은 key 해제 전까지 모든 장착 경로에서 비상호작용
        if ((from as any)?.data?.kind === 'LOCK') return false;
        from.equipQueued = false; // ✅ 장착 시작 시 예약 상태 제거

        const toIdx = this._findFirstEmptyShooting();
        if (toIdx < 0) return false;

        const toBase = this._placesS[toIdx];
        if (!toBase || !toBase.isValid || !toBase.activeInHierarchy) return false;
        // ✅ 장착 순서 시퀀스: "장착 시작" 시점에 확정(트윈 중단/스킵되어도 순서 보장)
        (from as any).equipSeq = ++this._equipSeqCounter;
        // equipSeq는 '유닛(데이터)'에도 같이 저장 → 슬롯 이동/데이터 스왑에도 순서 유지
        try {
            if (from?.data) (from.data as any).equipSeq = (from as any).equipSeq;
        } catch {}

        this._moveSlotNode(from, 'S', toIdx, this.equipMoveSec, this.equipJumpY, () => {
            // ✅ 장착 직후 상태/쿨다운 초기화

            from.postEquipDelayT = Math.max(0, this.postEquipDelaySec);
            from.reacquireDelayT = Math.max(0, this.reacquireDelaySec);

            // // 역할: 장착 직후 듀얼 예약/조준 상태 초기화(오동작 방지)
            from.pendingDual = false;
            from.pendingT = 0;

            this._cooldownsS[toIdx] = 0;

            // // 역할: 대기라인 구멍 메우기
            this._shiftColumn(fromIdx);
        });

        return true;
    }

    private _consumeQueuedEquipInColumn(col: number) {
        _consumeQueuedEquipInColumn(this as any, col);
    }

    private _shiftColumn(index: number) {
        _shiftColumn(this as any, index);
    }

    private _maintainWaitingOverflow() {
        _maintainWaitingOverflow(this as any);
    }

    private _refillFromOverflow(col: number) {
        _refillFromOverflow(this as any, col);
    }

    // -----------------------------
    // Spawn / Socket / Label
    // -----------------------------

    private _spawnTo(line: LineKind, index: number, data: CardData) {
        _spawnTo(this as any, line as any, index | 0, data);
    }

    // -----------------------------
    // ✅ Muzzle FX leak/ghost 방지
    // -----------------------------

    // 역할: 유닛(또는 소켓) 아래에 남아있는 발사 FX를 즉시 회수
    // - 스테이지 전환/라인 재구성 중 FX 수명이 끝나기 전에 유닛이 풀로 들어가면,
    //   다음 스폰에서 FX가 그대로 따라와 "유닛이 나오자마자 발사"처럼 보일 수 있음
    private _despawnMuzzleFxUnder(host: Node | null) {
        _despawnMuzzleFxUnder(this, host);
    }

    // 역할: 슬롯을 모르는 회수 경로에서도(예: 임시 노드 회수) 트리 전체에서 FX 제거
    // - 재귀 대신 스택 DFS로 GC/스택오버플로우 방지
    private _despawnMuzzleFxInTree(root: Node | null) {
        _despawnMuzzleFxInTree(this, root);
    }

    // -----------------------------
    // ✅ Muzzle FX (Prefab + Pool)
    // -----------------------------

    private _prewarmMuzzleFx() {
        _prewarmMuzzleFx(this);
    }

    private _tickFxRecycle(dt: number) {
        _tickFxRecycle(this, dt);
    }

    // ✅ 요청하신 원본 형태 유지(로그 포함)
    private _playMuzzleFx(slot: Slot, muzzle: 'C' | 'L' | 'R', colorId: number) {
        _playMuzzleFx(this, slot, muzzle, colorId);
    }

    private _onBeforeDraw() {
        // ✅ 최종 렌더 직전 IK 타겟을 다시 한 번 적용 (Spine 애니메이션이 update 단계에서 본을 덮는 케이스 방지)
        // - aimInited가 아니면(초기화 전) 건드리지 않습니다.
        const apply = (s: any | null) => {
            if (!s || !s.node || !s.node.isValid) return;
            if (!s.aimInited) return;
            // 타겟이 없더라도 "정면 복귀"가 aimCur에 반영되어 있으므로 그대로 적용합니다.
            this._applyIkLocal(s as any, s.aimCurX, s.aimCurY);
        };

        for (let i = 0; i < this._slotS.length; i++) apply(this._slotS[i] as any);
        for (let i = 0; i < this._slotW1.length; i++) apply(this._slotW1[i] as any);
        for (let i = 0; i < this._slotW2.length; i++) apply(this._slotW2[i] as any);
        for (let i = 0; i < this._slotW3.length; i++) apply(this._slotW3[i] as any);
    }

    // -----------------------------
    // Muzzle / IK helpers
    // -----------------------------

    private _ensureSpineRefs(slot: Slot) {
        // Spine runtime may not be ready on the same frame the unit is spawned.
        // Lazily resolve muzzle/IK bones on demand to avoid a permanently-null cache.

        // ✅ IK 타겟은 반드시 IK constraint가 바라보는 본(보통 Cannon_Target)이어야 합니다.
        // - Cannon_Target_Mirror는 Label_Num 등에 쓰이는 Transform-constraint용 본이라,
        //   이것을 ikTarget으로 쓰면 총구가 정면 고정처럼 보일 수 있습니다.
        const curName: any = (slot.ikTarget as any)?.data?.name ?? (slot.ikTarget as any)?.name ?? '';
        const hasAll = !!slot.boneCenter && !!slot.boneLeft && !!slot.boneRight;

        // ✅ IK 타겟이 "Cannon_Target(BONE_IK)"로 확정되어 있고 muzzle 본도 모두 있으면 더 볼 필요 없음
        if (hasAll && curName === BONE_IK) return;

        const skel: any = slot.skel as any;
        if (!skel || !skel.isValid) return;

        const spskel: any = (skel as any)._skeleton;

        // ✅ Spine 본 참조는 내부 runtime bone(spine.Bone)를 우선 사용합니다.
        const findBone = (name: string): any | null => {
            if (spskel?.findBone) return (spskel.findBone(name) as any) || null;
            return ((skel as any).findBone?.(name) as any) ?? null;
        };

        if (!slot.boneCenter) slot.boneCenter = findBone(BONE_CENTER);
        if (!slot.boneLeft) slot.boneLeft = findBone(BONE_LEFT);
        if (!slot.boneRight) slot.boneRight = findBone(BONE_RIGHT);

        // ✅ IK target bone은 'Connon_Target' IK constraint의 target을 우선 사용 (리그가 바뀌어도 안전)
        const resolveIkTarget = (): any | null => {
            const arr: any = spskel?.ikConstraints;
            if (Array.isArray(arr) && arr.length > 0) {
                const c =
                    arr.find((x: any) => (x?.data?.name ?? x?.name) === 'Connon_Target') ||
                    arr.find((x: any) => (x?.data?.name ?? x?.name) === 'Cannon_Target') ||
                    arr[0];
                const t = c?.target;
                if (t) return t;
            }
            // fallback: 이름으로 직접 찾기
            return findBone(BONE_IK);
        };

        const want = resolveIkTarget();
        if (want) {
            const prev = slot.ikTarget as any;
            if (prev !== want) {
                const prevName: any = prev?.data?.name ?? prev?.name ?? '';
                const wantName: any = (want as any)?.data?.name ?? (want as any)?.name ?? '';
                slot.ikTarget = want;

                // ✅ 디버그(1회): IK 타겟이 잘못 캐시되던 문제 확인용
                if (!(slot as any)._ikResolvedLogged) {
                    console.log(`[UnitLineRack] IK target resolved: ${prevName || '(null)'} -> ${wantName}`);
                    (slot as any)._ikResolvedLogged = true;
                }
            }
        }
    }

    private _getMuzzleWorld(slot: Slot, type: 'C' | 'L' | 'R', out: Vec3): boolean {
        this._ensureSpineRefs(slot);
        let n: Node | null = null;
        if (type === 'C') n = slot.muzzleCenter;
        else if (type === 'L') n = slot.muzzleLeft;
        else n = slot.muzzleRight;

        if (n && n.isValid) {
            n.getWorldPosition(out);
            return true;
        }

        const skel = slot.skel as any;
        if (!skel || !skel.node?.isValid) return false;

        let bone: any | null = null;
        if (type === 'C') bone = slot.boneCenter;
        else if (type === 'L') bone = slot.boneLeft;
        else bone = slot.boneRight;

        if (!bone) return false;

        out.set(bone.worldX || 0, bone.worldY || 0, 0);
        skel.node.getWorldMatrix(this._tmpMat);
        Vec3.transformMat4(out, out, this._tmpMat);
        return true;
    }

    private _computeIkLocalFromWorld(slot: Slot, targetWorld: Vec3): boolean {
        const skel = slot.skel as any;
        this._ensureSpineRefs(slot);
        const tgt = slot.ikTarget;
        if (!skel || !skel.node?.isValid || !tgt) return false;

        skel.node.getWorldMatrix(this._tmpMat);
        Mat4.invert(this._tmpMatInv, this._tmpMat);

        this._tmpSkelLocal.set(targetWorld);
        Vec3.transformMat4(this._tmpSkelLocal, this._tmpSkelLocal, this._tmpMatInv);

        let lx = this._tmpSkelLocal.x;
        let ly = this._tmpSkelLocal.y;

        const parent: any = tgt.parent;
        if (parent) {
            const rx = lx - (parent.worldX || 0);
            const ry = ly - (parent.worldY || 0);

            const a = parent.a ?? 1;
            const b = parent.b ?? 0;
            const c = parent.c ?? 0;
            const d = parent.d ?? 1;

            const det = a * d - b * c;
            if (det !== 0) {
                const invDet = 1 / det;
                lx = (rx * d - ry * b) * invDet;
                ly = (ry * a - rx * c) * invDet;
            } else {
                lx = rx;
                ly = ry;
            }
        }

        this._tmpSkelLocal.x = lx;
        this._tmpSkelLocal.y = ly;
        return true;
    }

    private _applyIkLocal(slot: Slot, lx: number, ly: number) {
        this._ensureSpineRefs(slot);
        const skel = slot.skel as any;
        const tgt = slot.ikTarget;
        if (!skel || !skel.node?.isValid || !tgt) return;

        try {
            tgt.x = lx;
            tgt.y = ly;

            // ✅ Cocos의 sp.Skeleton.updateWorldTransform()는 Skeleton + Socket 갱신까지 포함합니다.
            // - 내부 _skeleton.updateWorldTransform()만 호출하면 Socket/표시가 갱신되지 않는 버전이 있어,
            //   컴포넌트 API를 우선 사용합니다.
            const uwt: any = (skel as any).updateWorldTransform;
            if (typeof uwt === 'function') uwt.call(skel);
            else (skel as any)._skeleton?.updateWorldTransform?.();
        } catch {}
    }

    // -----------------------------
    // Visual helpers
    // -----------------------------

    private _applySkinByColor(slot: Slot) {
        const skel = slot.skel;
        const data: any = slot.data;
        if (!skel || !data) return;

        // ✅ LOCK 유닛은 잠금 해제 전까지 Unit_Lock 스킨
        // - 잠금 해제 시 data.kind가 제거되므로, 여기서는 kind만 체크하면 됩니다.
        const lockedNow = data.kind === 'LOCK';
        if (lockedNow) {
            const skinName = `Unit_Lock`;
            try {
                (skel as any).setSkin?.(skinName);
                (skel as any).skinName = skinName;
                (skel as any).setSlotsToSetupPose?.();
                (skel as any).updateWorldTransform?.();
            } catch {}
            return;
        }

        const c = (data.colorId ?? 0) | 0;
        let idx: number;

        if (c >= 0 && c <= 11) idx = c + 1;
        else if (c >= 1 && c <= 12) idx = c;
        else idx = (((c % 12) + 12) % 12) + 1;

        const skinName = `Unit_${String(idx).padStart(2, '0')}`;

        try {
            (skel as any).setSkin?.(skinName);
            (skel as any).skinName = skinName;
            (skel as any).setSlotsToSetupPose?.();
            (skel as any).updateWorldTransform?.();
        } catch {}
    }

    private _applyAmmoLabelVisual(slot: Slot) {
        // ✅ 풀링/재부모화 타이밍에 따라 ammoLabel 캐시가 비어있을 수 있어, 필요 시 재탐색합니다.
        let lb = slot.ammoLabel;
        const d: any = slot.data;
        if (!d) return;

        if (!lb && slot.node && slot.node.isValid) {
            const skel = slot.skel;
            let labelNode: Node | null = slot.node.getChildByName('Label_Num');
            if (!labelNode && skel && skel.node && skel.node.isValid) labelNode = skel.node.getChildByName('Label_Num');
            if (!labelNode) labelNode = _findNodeByNameDFS(this as any, slot.node, 'Label_Num');
            lb = labelNode && labelNode.isValid ? labelNode.getComponent(Label) : null;
            slot.ammoLabel = lb;
        }

        if (!lb) return;

        // ✅ LOCK 유닛은 잠금 해제 전까지 Label_Num 비활성
        const lockedNow = d.kind === 'LOCK';
        if (lockedNow) {
            if (lb.node) lb.node.active = false;
            return;
        }

        const ammo = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;

        // ✅ 라벨 표시: "총알수,equipOrder,순번" (예: "30,R2,1")
        // - equipOrder 표기 = <ColorToken><shotCount>
        // - 순번(hintStep)은 stage.equipOrder(또는 시뮬 기반)로부터 StageCompiler가 부여
        const step = (d.hintStep ?? 0) | 0;

        const colorId = (d.colorId | 0) < 0 ? 0 : d.colorId | 0;
        const tok = COLOR_TOKEN_ORDER[colorId] ?? 'R';
        const mode = this._getMode(d);
        const base = `${ammo},${tok}${mode}`;
        lb.string = step > 0 ? `${base},${step}` : base;

        // ✅ 라벨 표시/색상 적용
        if (lb.node) lb.node.active = true;
        lb.color = LabelPalette.get(d.colorId | 0, 12);
    }

    // ✅ 키(열쇠)로 잠금 해제 등 "상태 변화" 발생 시, 화면상의 스킨/라벨을 한 번에 갱신
    private _refreshAllUnitSkinsAndLabels() {
        // S 라인
        for (let i = 0; i < this._slotS.length; i++) {
            const s = this._slotS[i];
            if (!s || !s.data) continue;
            this._applySkinByColor(s);
            this._applyAmmoLabelVisual(s);
        }

        // W 라인
        for (const row of [this._slotW1, this._slotW2, this._slotW3]) {
            if (!row) continue;
            for (let ci = 0; ci < row.length; ci++) {
                const s = row[ci];
                if (!s || !s.data) continue;
                this._applySkinByColor(s);
                this._applyAmmoLabelVisual(s);
            }
        }
    }

    private _consumeAmmo(slot: Slot, n: number): number {
        const d: any = slot.data;
        if (!d) return 0;

        const dec = Math.max(0, n | 0);
        const cur = (d.ammo | 0) < 0 ? 0 : d.ammo | 0;
        const next = Math.max(0, cur - dec);
        if (next === cur) return next;

        d.ammo = next;

        const lb = slot.ammoLabel;
        if (lb) {
            const colorId = (d.colorId | 0) < 0 ? 0 : d.colorId | 0;
            const tok = COLOR_TOKEN_ORDER[colorId] ?? 'R';
            const mode = this._getMode(d);

            const step = (d.hintStep ?? 0) | 0;

            const base = `${next},${tok}${mode}`;
            lb.string = step > 0 ? `${base},${step}` : base;
        }

        return next;
    }

    private _getMode(data: CardData | null): 1 | 2 {
        if (!data) return 1;
        const d: any = data;

        const sc = d.shotCount | 0;
        if (sc === 2) return 2;
        if (sc === 1) return 1;

        const v = (d.barrelMode ?? d.attackMode ?? d.ammoMode ?? d.mode ?? 1) | 0;
        return v === 2 ? 2 : 1;
    }

    private _animName(base: string, mode: 1 | 2): string {
        return `${base}_${mode}`;
    }

    private _playAnim(slot: Slot, base: string, loop: boolean) {
        const skel = slot.skel;
        if (!skel) return;

        const mode = this._getMode(slot.data);
        const name = this._animName(base, mode);

        if (slot.lastAnim === name) return;
        slot.lastAnim = name;

        try {
            skel.setAnimation(0, name, loop);
        } catch {}
    }

    private _captureAimHome(slot: Slot, animName: string) {
        // ✅ 역할: '대기(Idle)' 애니메이션에서 IK 타겟의 기본(중앙) 좌표를 저장
        // - 리그에 따라 중앙이 (0,0)이 아닐 수 있어, 0으로 복귀하면 좌/우 반전/오프셋이 생길 수 있음
        // - 따라서 idle/setup 포즈에서의 ikTarget.x/y를 기준으로 복귀 좌표를 잡습니다.
        const tgt: any = slot.ikTarget;
        if (!tgt) return;

        // 같은 idle 애니에서 매번 갱신하지 않도록 가드
        if (slot.aimHomeInited && slot.aimHomeAnim === animName) return;

        try {
            slot.aimHomeX = (tgt.x ?? 0) as number;
            slot.aimHomeY = (tgt.y ?? 0) as number;
            slot.aimHomeInited = true;
            slot.aimHomeAnim = animName;
        } catch {}
    }

    private _ensureAnim(slot: Slot, base: 'Attack' | 'Idle') {
        // ✅ 역할: 타겟 유무에 따라 유닛의 기본 루프 애니메이션을 유지/전환
        // - 기존: 타겟 없으면 Idle_1 / Idle_2
        // - 변경: ShootingLine(S)에서 타겟 없을 때는 Attack_1_Idle / Attack_2_Idle 사용(공격 자세 유지)

        const skel = slot.skel;
        if (!skel) return;

        const mode = this._getMode(slot.data);

        // ShootingLine에서 타겟 없음(Idle)인 경우: Attack_<mode>_Idle
        const name = base === 'Idle' && slot.line === 'S' ? `Attack_${mode}_Idle` : `${base}_${mode}`;

        if (slot.lastAnim === name) return;

        try {
            skel.setAnimation(0, name, true);
            slot.lastAnim = name; // ✅ 변경: setAnimation 성공 후에만 lastAnim 갱신
            // ✅ Idle 애니메이션 진입 시 '중앙 복귀' 기준 좌표를 저장
            if (base === 'Idle') this._captureAimHome(slot, name);
        } catch {
            // ✅ 변경: 실패 시 lastAnim을 갱신하지 않아 다음 프레임에 재시도 가능
        }
    }

    // -----------------------------
    // ✅ Stage 전환/풀링 재사용 시 "자세(조준/IK)" 초기화
    // -----------------------------

    // 역할: 풀에서 재사용되는 유닛이 이전 스테이지/이전 타겟을 바라보는 문제 방지
    // - Skeleton을 setup pose로 1회 리셋(가능한 API만 호출)
    // - Idle 애니 진입 후 캡처한 aimHomeX/Y(기본 자세)로 IK 타겟을 되돌림
    // - aim/예약발/딜레이 상태도 초기화
    private _resetAllExistingUnitPoses() {
        _resetAllExistingUnitPoses(this as any);
    }

    private _resetUnitPose(slot: Slot) {
        _resetUnitPose(this as any, slot as any);
    }

    // -----------------------------
    // Move / Recycle
    // -----------------------------

    private _moveSlotNode(
        slot: Slot,
        toLine: LineKind,
        toIndex: number,
        sec: number,
        arcHeight: number,
        onDone?: () => void,
    ) {
        _moveSlotNode(this as any, slot as any, toLine as any, toIndex | 0, sec, arcHeight, onDone);
    }

    private _forceFinishMove(slot: Slot) {
        _forceFinishMove(this as any, slot as any);
    }

    private _recycleAmmoEmpty(slot: Slot) {
        if (!slot || !slot.node || !slot.node.isValid) return;
        if (slot.moving) return;

        const nd = slot.node;

        // 예약 발 정리
        slot.pendingDual = false;
        slot.pendingT = 0;

        if (slot.line === 'S') {
            const idx = slot.index | 0;
            if (idx >= 0 && idx < 5 && this._slotS[idx] === slot) this._slotS[idx] = null;
            if (idx >= 0 && idx < 5) this._cooldownsS[idx] = 0;
        } else {
            this._setSlot(slot.line, slot.index, null);
        }

        this._slotByNode.delete(nd);
        nd.off(Node.EventType.TOUCH_END, this._onUnitTouchEnd, this);

        slot.data = null;

        this._recycleUnitNode(nd, slot.opacity);
    }

    // -----------------------------
    // Internal: cache / pool / slots
    // -----------------------------

    private _cachePlaces() {
        this._placesS = this._readPlaces(this.shootingLine);
        this._unitPlacesS = this._readUnitPlacesOrNull(this.shootingLine);

        this._placesW1 = this._readPlaces(this.waitingLine01);
        this._placesW2 = this._readPlaces(this.waitingLine02);
        this._placesW3 = this._readPlaces(this.waitingLine03);
    }

    private _readPlaces(line: Node | null): Node[] {
        if (!line || !line.isValid) return [];
        const out: Node[] = new Array(5);
        for (let i = 0; i < 5; i++) out[i] = line.getChildByName(`Place0${i + 1}`) as any;
        return out;
    }

    private _readUnitPlacesOrNull(line: Node | null): (Node | null)[] {
        const out: (Node | null)[] = new Array(5);
        for (let i = 0; i < 5; i++) out[i] = null;

        if (!line || !line.isValid) return out;

        for (let i = 0; i < 5; i++) {
            const n = line.getChildByName(`UnitPlace0${i + 1}`);
            out[i] = n && n.isValid ? n : null;
        }
        return out;
    }

    private _prewarmPool() {
        if (!this.unitPrefab) return;
        const n = Math.max(0, Math.min(50, this.poolWarmup | 0));
        for (let i = 0; i < n; i++) {
            const nd = instantiate(this.unitPrefab);
            const op = nd.getComponent(UIOpacity) || nd.addComponent(UIOpacity);
            op.opacity = 255;
            nd.setRotationFromEuler(0, 0, 0);
            nd.active = false;
            this._pool.put(nd);
        }
    }

    private _scaleOf(line: LineKind): number {
        switch (line) {
            case 'S':
                return this.scaleShooting;
            case 'W1':
                return this.scaleWaiting01;
            case 'W2':
                return this.scaleWaiting02;
            case 'W3':
                return this.scaleWaiting03;
        }
    }

    private _placeOf(line: LineKind, index: number): Node | null {
        const i = index | 0;
        if (i < 0 || i >= 5) return null;
        switch (line) {
            case 'S': {
                // ✅ 유닛은 UnitPlace 우선 (없으면 Place fallback)
                const up = this._unitPlacesS[i];
                if (up && up.isValid) return up;
                return this._placesS[i] ?? null;
            }
            case 'W1':
                return this._placesW1[i] ?? null;
            case 'W2':
                return this._placesW2[i] ?? null;
            case 'W3':
                return this._placesW3[i] ?? null;
        }
    }

    private _setSlot(line: LineKind, index: number, slot: Slot | null) {
        const i = index | 0;
        if (i < 0 || i >= 5) return;
        switch (line) {
            case 'S':
                this._slotS[i] = slot;
                break;
            case 'W1':
                this._slotW1[i] = slot;
                break;
            case 'W2':
                this._slotW2[i] = slot;
                break;
            case 'W3':
                this._slotW3[i] = slot;
                break;
        }
    }

    private _findFirstEmptyShooting(): number {
        for (let i = 0; i < 5; i++) {
            const base = this._placesS[i];
            if (!base || !base.isValid || !base.activeInHierarchy) continue;
            if (!this._slotS[i]) return i;
        }
        return -1;
    }

    private _returnSlotNode(slot: Slot | null, clearRef: boolean) {
        if (!slot) return;

        // 예약 정리
        slot.pendingDual = false;
        slot.pendingT = 0;

        // ✅ 역할: node tween만 정지하면(moveParam/appearParam의 TParam tween은) 계속 돌 수 있음
        // - 스테이지 전환/리셋 중 이동이 남아있으면 onUpdate에서 풀 노드를 만지며 오류/잔상이 생길 수 있어
        //   TParam tween도 함께 중지/회수합니다.
        if (slot.moveParam) {
            try {
                Tween.stopAllByTarget(slot.moveParam);
            } catch {}
            this._putTParam(slot.moveParam);
            slot.moveParam = null;
        }
        if (slot.appearParam) {
            try {
                Tween.stopAllByTarget(slot.appearParam);
            } catch {}
            this._putTParam(slot.appearParam);
            slot.appearParam = null;
        }
        slot.moveDoneCb = null;
        slot.moving = false;

        const nd = slot.node;
        if (nd && nd.isValid) {
            Tween.stopAllByTarget(nd);
            if (slot.opacity) Tween.stopAllByTarget(slot.opacity);

            nd.off(Node.EventType.TOUCH_END, this._onUnitTouchEnd, this);

            // ✅ 역할: 아직 살아있는 발사 FX가 유닛에 붙은 채로 풀에 들어가는 것을 방지
            // 설명: FX 수명 타이머(_fxActive)보다 먼저 유닛이 회수되면, 다음 스폰에서 FX가 같이 나타날 수 있습니다.
            this._despawnMuzzleFxUnder(slot.muzzleCenter);
            this._despawnMuzzleFxUnder(slot.muzzleLeft);
            this._despawnMuzzleFxUnder(slot.muzzleRight);
            // 안전망: 소켓이 누락된 구조에서도 트리 전체에서 태그 FX를 제거
            this._despawnMuzzleFxInTree(nd);

            // ✅ 역할: 풀에 넣기 전에 Spine 트랙/포즈를 정리해, 다음 재사용 시 본/IK 잔상이 남지 않도록 합니다.
            // 설명: spawn 시에도 리셋하지만, 일부 버전에서는 비활성화 직전 포즈가 저장되어 "첫 프레임"에
            //       튀어 보일 수 있어, 회수 시점에도 한번 더 정리합니다.
            const skel: any = slot.skel;
            if (skel && skel.isValid) {
                try {
                    skel.clearTracks?.();
                } catch {}
                try {
                    skel.setToSetupPose?.();
                } catch {}
            }

            if (slot.opacity) slot.opacity.opacity = 255;
            nd.setPosition(0, 0, 0);
            nd.setRotationFromEuler(0, 0, 0);

            nd.active = false;
            nd.removeFromParent();
            this._pool.put(nd);
        }

        if (clearRef) {
            this._setSlot(slot.line, slot.index, null);
            this._slotByNode.delete(nd);
            if (slot.line === 'S') this._cooldownsS[slot.index] = 0;
        }
    }

    private _recycleUnitNode(nd: Node, op: UIOpacity | null) {
        if (!nd || !nd.isValid) return;

        Tween.stopAllByTarget(nd);
        if (op) {
            Tween.stopAllByTarget(op);
            op.opacity = 255;
        }

        // ✅ 역할: 슬롯을 모르는 회수 경로에서도 잔여 발사 FX를 제거(유닛 스폰 시 유령 FX 방지)
        this._despawnMuzzleFxInTree(nd);

        // ✅ 역할: 비정상 포즈(조준/IK)가 남은 채로 풀에 들어가는 것을 방지
        // 설명: Slot을 모르는 경로(예: 임시 노드 회수)에서도 스켈레톤 트랙을 정리합니다.
        const skel: any = nd.getComponent(sp.Skeleton) || nd.getComponentInChildren(sp.Skeleton);
        if (skel && skel.isValid) {
            try {
                skel.clearTracks?.();
            } catch {}
            try {
                skel.setToSetupPose?.();
            } catch {}
        }

        nd.setPosition(0, 0, 0);
        nd.setRotationFromEuler(0, 0, 0);

        nd.active = false;
        nd.removeFromParent();
        this._pool.put(nd);
    }

    private _getTParam(): TParam {
        return this._tParamPool.length > 0 ? this._tParamPool.pop()! : { t: 0 };
    }

    private _putTParam(p: TParam) {
        p.t = 0;
        this._tParamPool.push(p);
    }

    // -----------------------------
    // ✅ Place 활성 마스크(중앙정렬)
    // -----------------------------

    private _mask5FromCount(count: number): boolean[] {
        const c = Math.max(0, Math.min(5, count | 0));
        switch (c) {
            case 1:
                return [false, false, true, false, false];
            case 2:
                return [false, true, false, true, false];
            case 3:
                return [false, true, true, true, false];
            case 4:
                return [true, true, true, true, false];
            case 5:
                return [true, true, true, true, true];
            default:
                return [false, false, false, false, false];
        }
    }
}