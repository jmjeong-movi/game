#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(git rev-parse --show-toplevel)"
GAME_SRC="$REPO_ROOT/work_game/game/stage/compileRuntimeFromV2.ts"
TOOL_DST="$REPO_ROOT/work_stage/stage-tool-v9/src/lib/runtime/stage/compileRuntimeFromV2.ts"
[[ -f "$GAME_SRC" ]] || { echo "missing game compiler: $GAME_SRC"; exit 2; }
cp "$GAME_SRC" "$TOOL_DST"
GH=$(sha256sum "$GAME_SRC" | awk '{print $1}')
TH=$(sha256sum "$TOOL_DST" | awk '{print $1}')
[[ "$GH" == "$TH" ]] || { echo "compiler hash mismatch"; exit 3; }
echo "[sync] runtime compiler synced hash=$TH"
