/* eslint-disable no-console */

const path = require('path');

function toFail(stageId, reason, extra = {}) {
  return {
    stageId,
    status: 'UNSOLVED',
    reason,
    failStep: extra.failStep ?? -1,
    opsUsed: Array.isArray(extra.opsUsed) ? extra.opsUsed : [],
  };
}

async function repairStagePack(pack, opts = {}) {
  const stages = Array.isArray(pack?.stages) ? pack.stages : [];

  // 단일 경로 강제: 실검증 엔진이 없으면 절대 SOLVED를 리턴하지 않음.
  // (기존 PLACEHOLDER false-positive 방지)
  let engine = null;
  try {
    const enginePath = path.resolve(__dirname, '..', 'engine', 'sim_equivalent.js');
    // eslint-disable-next-line import/no-dynamic-require, global-require
    engine = require(enginePath);
  } catch {
    engine = null;
  }

  const results = [];
  for (const st of stages) {
    const id = st?.id ?? -1;
    if (!engine || typeof engine.validateStageEquivalent !== 'function') {
      results.push(toFail(id, 'VALIDATOR_ENGINE_MISSING'));
      continue;
    }
    try {
      const r = await engine.validateStageEquivalent(st, opts);
      results.push({
        stageId: id,
        status: r?.status === 'SOLVED' ? 'SOLVED' : 'UNSOLVED',
        reason: String(r?.reason ?? (r?.status === 'SOLVED' ? 'OK' : 'UNKNOWN')),
        failStep: Number.isFinite(r?.failStep) ? (r.failStep | 0) : -1,
        opsUsed: Array.isArray(r?.opsUsed) ? r.opsUsed : [],
      });
    } catch (e) {
      results.push(toFail(id, `VALIDATION_EXCEPTION:${e?.message ?? e}`));
    }
  }

  const solved = results.filter((r) => r.status === 'SOLVED').length;
  return {
    pack,
    report: {
      validationMode: 'SIM_EQUIVALENT_SINGLE_PATH',
      results,
      summary: { total: results.length, solved, unsolved: results.length - solved },
    },
  };
}

module.exports = { repairStagePack };
