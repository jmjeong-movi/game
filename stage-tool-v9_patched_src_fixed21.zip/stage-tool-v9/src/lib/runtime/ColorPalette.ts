// Runtime color palette used by both game and stage-tool.
// Keep this file tiny to avoid pulling UI/editor dependencies into runtime simulation.

// 12-color default palette matching COLOR_TOKEN_ORDER: R,O,Y,G,B,P,M,C,S,L,K,W
export const DEFAULT_PALETTE_HEX_12: readonly string[] = [
  '#ff3b30', // R
  '#ff9f0a', // O
  '#ffd60a', // Y
  '#34c759', // G
  '#0a84ff', // B
  '#bf5af2', // P
  '#ff2d55', // M
  '#64d2ff', // C
  '#30d158', // S
  '#ac8e68', // L
  '#1c1c1e', // K
  '#ffffff', // W
] as const;
