"use strict";
// Headless stubs for the Cocos Creator 'cc' module.
// These are intentionally minimal: they exist to let game logic TS execute in Node.
Object.defineProperty(exports, "__esModule", { value: true });
exports.director = exports.resources = exports.sp = exports.UIOpacity = exports.Label = exports.SpriteFrame = exports.SpriteAtlas = exports.Color = exports.EventTouch = exports.CurveRange = exports.GradientRange = exports.ParticleSystem2D = exports.ParticleSystem = exports.Tween = exports.NodePool = exports.math = exports.UITransform = exports.Prefab = exports.Node = exports.Mat4 = exports.Vec3 = exports.Component = exports.JsonAsset = exports.TextAsset = exports.Asset = exports._decorator = void 0;
exports.instantiate = instantiate;
exports.tween = tween;
// Global marker so game code can silence FX/UI logs and skip presentation-only work.
globalThis.__HEADLESS__ = true;
exports._decorator = {
    ccclass: (_name) => (cls) => cls,
    property: (_opts) => (_target, _key) => { },
};
// Asset/Resource stubs (headless)
class Asset {
}
exports.Asset = Asset;
class TextAsset extends Asset {
    constructor(text = '') {
        super();
        this.text = text;
    }
}
exports.TextAsset = TextAsset;
class JsonAsset extends Asset {
    constructor(json = null) {
        super();
        this.json = json;
    }
}
exports.JsonAsset = JsonAsset;
class Component {
    constructor() {
        this.isValid = true;
        this.enabled = true;
    }
    getComponent(_cls) { return null; }
    addComponent(cls) {
        // In Cocos, components are attached to a node; in headless we just instantiate.
        const inst = new cls();
        inst.node = this.node;
        inst.isValid = true;
        return inst;
    }
    scheduleOnce(fn, _delay = 0) { try {
        fn();
    }
    catch { } }
}
exports.Component = Component;
class Vec3 {
    constructor(x = 0, y = 0, z = 0) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    set(x, y, z) {
        if (x instanceof Vec3) {
            this.x = x.x;
            this.y = x.y;
            this.z = x.z;
            return this;
        }
        this.x = x;
        this.y = y ?? 0;
        this.z = z ?? 0;
        return this;
    }
    clone() { return new Vec3(this.x, this.y, this.z); }
    static distance(a, b) {
        const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
    static transformMat4(out, a, _m) {
        // Headless: ignore matrix and just copy.
        out.set(a);
        return out;
    }
}
exports.Vec3 = Vec3;
class Mat4 {
    static invert(out, _a) { return out; }
}
exports.Mat4 = Mat4;
class Node {
    constructor(name = '') {
        this.name = name;
        this.active = true;
        this.isValid = true;
        this._parent = null;
        this._pos = new Vec3();
        this._scale = new Vec3(1, 1, 1);
        this._rotEuler = new Vec3(0, 0, 0);
        this._components = new Map();
        this.children = [];
    }

    // Cocos-compatible: derived flag that reflects `active` plus ancestor activity.
    // StageTool headless validation toggles `node.active`; logic depends on this being correct.
    get activeInHierarchy() {
        return !!this.active && (!this._parent || this._parent.activeInHierarchy);
    }
    setParent(p) {
        // detach
        if (this._parent) {
            const idx = this._parent.children.indexOf(this);
            if (idx >= 0)
                this._parent.children.splice(idx, 1);
        }
        this._parent = p;
        if (p)
            p.children.push(this);
    }
    get parent() { return this._parent; }
    set parent(p) { this.setParent(p); }
    get position() { return this._pos; }
    set position(v) { this._pos.set(v.x, v.y, v.z); }
    get worldPosition() { return this._pos.clone(); }
    setWorldPosition(v) { this._pos.set(v.x, v.y, v.z); }
    setPosition(v, y, z) {
        if (v instanceof Vec3)
            this._pos.set(v.x, v.y, v.z);
        else
            this._pos.set(v, y ?? 0, z ?? 0);
    }
    getWorldPosition(out) {
        const o = out ?? new Vec3();
        o.set(this._pos.x, this._pos.y, this._pos.z);
        return o;
    }
    // Cocos API compatibility: fill out world matrix.
    // In headless mode we treat the world matrix as identity.
    getWorldMatrix(out) {
        return out;
    }
    setScale(x, y, z) {
        if (x instanceof Vec3)
            this._scale.set(x.x, x.y, x.z);
        else
            this._scale.set(x, y ?? x, z ?? x);
    }
    get scale() { return this._scale; }
    setRotationFromEuler(_x, _y, _z) { }
    addComponent(cls) {
        const inst = new cls();
        if (inst && typeof inst === 'object') {
            inst.node = this;
            inst.isValid = true;
        }
        this._components.set(cls, inst);
        return inst;
    }
    getComponent(cls) {
        if (this._components.has(cls))
            return this._components.get(cls);
        // If asked for a Component-like class, create lazily.
        try {
            return this.addComponent(cls);
        }
        catch {
            return null;
        }
    }
    removeAllChildren() { }
    destroy() { this.isValid = false; }
    removeFromParent() { this.setParent(null); }
    getChildByName(name) { return this.children.find(c => c.name === name) ?? null; }
    getChildByPath(path) {
        const parts = (path ?? '').split('/').filter(Boolean);
        let cur = this;
        for (const p of parts) {
            if (!cur)
                return null;
            cur = cur.getChildByName(p);
        }
        return cur;
    }
    on(_evt, _handler, _ctx) { }
    off(_evt, _handler, _ctx) { }
    getComponentsInChildren(_cls) { return []; }
    getComponentInChildren(_cls) { return null; }
}
exports.Node = Node;
Node.EventType = { TOUCH_END: 'touch-end' };
class Prefab {
}
exports.Prefab = Prefab;
class UITransform {
    constructor(node = new Node()) {
        this.node = node;
        this.width = 0;
        this.height = 0;
    }
    convertToNodeSpaceAR(v, out) { const o = out ?? new Vec3(); o.set(v); return o; }
    convertToWorldSpaceAR(v, out) { const o = out ?? new Vec3(); o.set(v); return o; }
}
exports.UITransform = UITransform;
function instantiate(_prefab) {
    // In headless mode, instantiate returns a plain Node.
    return new Node('inst');
}
exports.math = {
    clamp: (v, min, max) => Math.max(min, Math.min(max, v)),
    randomRangeInt: (min, max) => {
        const a = Math.ceil(min);
        const b = Math.floor(max);
        if (b <= a)
            return a;
        return a + Math.floor(Math.random() * (b - a));
    },
};
class NodePool {
    constructor(_name) {
        this.items = [];
    }
    size() { return this.items.length; }
    get() { return this.items.pop() ?? null; }
    put(n) { this.items.push(n); }
    clear() { this.items.length = 0; }
}
exports.NodePool = NodePool;
class Tween {
    static stopAllByTarget(_target) { }
    stop() { return this; }
}
exports.Tween = Tween;
function tween(_target) {
    // Minimal chainable tween builder; executes instantly.
    const api = {
        to: (_d, props, opts) => {
            try {
                if (props && typeof props === 'object') {
                    Object.assign(_target, props);
                }
                opts?.onUpdate?.(_target, 1);
                opts?.onComplete?.();
            }
            catch { }
            return api;
        },
        by: (_d, props, opts) => {
            try {
                if (props && typeof props === 'object') {
                    for (const k of Object.keys(props)) {
                        const dv = props[k];
                        const cur = _target[k];
                        if (typeof cur === 'number' && typeof dv === 'number')
                            _target[k] = cur + dv;
                    }
                }
                opts?.onUpdate?.(_target, 1);
                opts?.onComplete?.();
            }
            catch { }
            return api;
        },
        delay: (_d) => api,
        call: (fn) => { try {
            fn();
        }
        catch { } return api; },
        union: () => api,
        parallel: () => api,
        start: () => api,
    };
    return api;
}
class ParticleSystem {
    constructor() {
        this.startDelay = { getMax: () => 0 };
        this.startLifetime = { getMax: () => 0 };
        this.duration = 0;
    }
    getComponent(_cls) { return null; }
}
exports.ParticleSystem = ParticleSystem;
class ParticleSystem2D {
}
exports.ParticleSystem2D = ParticleSystem2D;
class GradientRange {
}
exports.GradientRange = GradientRange;
GradientRange.Mode = { Color: 0 };
class CurveRange {
}
exports.CurveRange = CurveRange;
(function (CurveRange) {
    CurveRange.Mode = { Constant: 0 };
})(CurveRange || (exports.CurveRange = CurveRange = {}));
class EventTouch {
}
exports.EventTouch = EventTouch;
class Color {
    constructor(r = 255, g = 255, b = 255, a = 255) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }
}
exports.Color = Color;
Color.WHITE = new Color(255, 255, 255, 255);
class SpriteAtlas {
    getSpriteFrame(_name) { return null; }
}
exports.SpriteAtlas = SpriteAtlas;
class SpriteFrame {
}
exports.SpriteFrame = SpriteFrame;
class Label {
    constructor() {
        this.string = '';
        this.node = null;
        this.color = null;
    }
}
exports.Label = Label;
class UIOpacity {
    constructor() {
        this.opacity = 255;
    }
}
exports.UIOpacity = UIOpacity;
var sp;
(function (sp) {
    class SpineSocket {
        constructor(path, target) {
            this.path = path;
            this.target = target;
        }
    }
    sp.SpineSocket = SpineSocket;
    class Skeleton {
        constructor() {
            this.isValid = true;
            this.node = null;
            this.sockets = [];
            // Minimal Spine runtime surface used by UnitLineRack:
            // - skeleton._skeleton.findBone(name)
            // UnitLineRack uses this to obtain muzzle/IK bones.
            this.__bones = new Map();
            this._skeleton = {
                findBone: (name) => {
                    const key = String(name ?? '');
                    if (!key)
                        return null;
                    if (this.__bones.has(key))
                        return this.__bones.get(key);
                    const bone = {
                        name: key,
                        x: 0,
                        y: 0,
                        worldX: 0,
                        worldY: 0,
                        a: 1,
                        b: 0,
                        c: 0,
                        d: 1,
                        parent: null,
                    };
                    this.__bones.set(key, bone);
                    return bone;
                },
            };
        }
        clearTracks() { }
        setToSetupPose() { }
        setAnimation(_track, _name, _loop) { }
        updateWorldTransform() { }
    }
    sp.Skeleton = Skeleton;
})(sp || (exports.sp = sp = {}));
// Resource/directory stubs
exports.resources = {
    load: (_path, _type, cb) => cb(null, null),
    loadDir: (_path, _type, cb) => cb(null, []),
};
const _sceneRoot = new Node('Scene');
exports.director = {
    getScene: () => _sceneRoot,
};
