#!/usr/bin/env node
/* eslint-disable no-console */
const fs = require('fs');
const path = require('path');

function arg(name, dflt = '') {
  const i = process.argv.indexOf(name);
  if (i < 0 || i + 1 >= process.argv.length) return dflt;
  return process.argv[i + 1];
}


function hasFlag(name) {
  return process.argv.includes(name);
}

async function main() {
  const cmd = process.argv[2] || 'repair';
  const input = arg('--input');
  const output = arg('--output', 'stagepack_v2_solver_only.json');
  const report = arg('--report', 'report_stagepack_v2_solver_only.json');
  const failDump = arg('--fail-dump', 'validation_failed_stages.json');
  const emitFailDump = hasFlag('--emit-fail-dump');
  if (!input) throw new Error('missing --input');

  const stageCompilerPath = path.resolve(__dirname, 'game', 'StageCompiler.js');
  if (!fs.existsSync(stageCompilerPath)) {
    throw new Error(`validator contract failed: missing ${stageCompilerPath}`);
  }
  const mod = require(stageCompilerPath);
  if (typeof mod.repairStagePack !== 'function') {
    throw new Error('validator contract failed: repairStagePack export missing');
  }

  const pack = JSON.parse(fs.readFileSync(input, 'utf8'));
  const res = await mod.repairStagePack(pack, {
    solverPolicy: 'STRICT_DECK_AND_AMMO_ONLY',
    validationMode: 'SIM_EQUIVALENT_SINGLE_PATH',
  });

  const rows = Array.isArray(res?.report?.results) ? res.report.results : [];
  const unsolved = rows.filter((r) => String(r?.status) !== 'SOLVED');

  // 하드락: UNSOLVED가 있으면 output은 저장하지 않음
  if (unsolved.length === 0) {
    fs.writeFileSync(output, JSON.stringify(res.pack ?? pack, null, 2));
  }
  fs.writeFileSync(report, JSON.stringify(res.report ?? { results: [] }, null, 2));

  if (emitFailDump && unsolved.length > 0) {
    const byId = new Map((pack.stages || []).map((s) => [s.id, s]));
    fs.writeFileSync(
      failDump,
      JSON.stringify(
        {
          summary: { total: rows.length, unsolved: unsolved.length },
          failed: unsolved.map((u) => ({
            stageId: u.stageId,
            status: u.status,
            reason: u.reason,
            failStep: u.failStep,
            opsUsed: u.opsUsed || [],
            stage: byId.get(u.stageId) || null,
          })),
        },
        null,
        2,
      ),
    );
  }

  if (cmd === 'repair' && unsolved.length > 0) process.exit(3);
}

main().catch((e) => {
  console.error('[validator_tools/cli] ERROR:', e?.message || e);
  process.exit(1);
});
