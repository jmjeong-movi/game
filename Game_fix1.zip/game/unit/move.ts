// 역할: UnitLineRack 슬롯 이동(장착/당김) + 강제 착지 로직 분리
// - UnitLineRack.ts 비대화를 줄이고, 이동 tween 규칙을 한 곳에서 유지합니다.

import { tween, Tween } from 'cc';
import type { TweenEasing } from 'cc';

type LineKind = 'S' | 'W1' | 'W2' | 'W3';

export function moveSlotNode(
    r: any,
    slot: any,
    toLine: LineKind,
    toIndex: number,
    sec: number,
    arcHeight: number,
    onDone?: () => void,
) {
    if (!slot?.node || !slot.node.isValid) return;

    const fromLine: LineKind = slot.line;
    const fromIdx = slot.index | 0;

    const fromPlace = r._placeOf(fromLine, fromIdx);
    const toPlace = r._placeOf(toLine, toIndex);
    if (!fromPlace || !toPlace) return;

    const isEquipMove = fromLine !== 'S' && toLine === 'S';
    const isWaitingMove = fromLine !== 'S' && toLine !== 'S';

    if (isEquipMove) r._playAnim(slot, 'Jump', true);
    else if (isWaitingMove) r._playAnim(slot, 'Move', true);

    r._setSlot(fromLine, fromIdx, null);
    slot.line = toLine;
    slot.index = toIndex | 0;
    r._setSlot(toLine, toIndex, slot);

    slot.moving = true;

    const ui = r._uiTr;
    if (!ui) return;

    fromPlace.getWorldPosition(r._tmpW0);
    toPlace.getWorldPosition(r._tmpW1);
    ui.convertToNodeSpaceAR(r._tmpW0, r._tmpL0);
    ui.convertToNodeSpaceAR(r._tmpW1, r._tmpL1);

    const nd = slot.node;

    Tween.stopAllByTarget(nd);
    if (slot.opacity) Tween.stopAllByTarget(slot.opacity);

    nd.setRotationFromEuler(0, 0, 0);
    if (slot.opacity) slot.opacity.opacity = 255;

    nd.setParent(r.node);
    nd.setPosition(r._tmpL0);

    const s0 = nd.scale.x;
    const s1 = r._scaleOf(toLine);
    nd.setScale(s0, s0, 1);

    const duration = Math.max(0.001, sec);

    const x0 = r._tmpL0.x,
        y0 = r._tmpL0.y,
        z0 = r._tmpL0.z;
    const x1 = r._tmpL1.x,
        y1 = r._tmpL1.y,
        z1 = r._tmpL1.z;

    const p = r._getTParam();
    p.t = 0;

    // 이동 중 즉시 장착 시 tween 중지/회수
    if (slot.moveParam) {
        try {
            Tween.stopAllByTarget(slot.moveParam);
        } catch {}
        r._putTParam(slot.moveParam);
    }

    // ✅ 오버플로우→W3 리필(등장) tween이 남아있으면 먼저 중지/회수
    if (slot.appearParam) {
        try {
            Tween.stopAllByTarget(slot.appearParam);
        } catch {}
        r._putTParam(slot.appearParam);
        slot.appearParam = null;
    }
    slot.moveParam = p;
    slot.moveDoneCb = onDone ?? null;

    const landSec = 0.08;

    tween(p)
        .to(
            duration,
            { t: 1 },
            {
                easing: (isEquipMove ? 'sineOut' : 'quadOut') as TweenEasing,
                onUpdate: () => {
                    if (!nd.isValid) return;

                    const t = p.t;

                    const x = x0 + (x1 - x0) * t;
                    const z = z0 + (z1 - z0) * t;
                    const baseY = y0 + (y1 - y0) * t;

                    const arc = isEquipMove && arcHeight > 0 ? arcHeight * (4 * t * (1 - t)) : 0;
                    const y = baseY + arc;

                    nd.setPosition(x, y, z);

                    const s = s0 + (s1 - s0) * t;
                    nd.setScale(s, s, 1);
                },
            },
        )
        .call(() => {
            if (!nd.isValid) {
                if (slot.moveParam === p) {
                    slot.moveParam = null;
                    slot.moveDoneCb = null;
                }
                r._putTParam(p);
                return;
            }

            nd.setParent(toPlace);
            nd.setScale(s1, s1, 1);

            if (isEquipMove) {
                r._ensureAnim(slot, 'Idle');
                r._resetUnitPose(slot);
                r._applyAmmoLabelVisual(slot);

                slot.aimRefreshCd = 0;
                slot.targetHoldT = 0;
                slot.aimHasTarget = false;
                slot.canShootNow = false;

                slot.pendingDual = false;
                slot.pendingT = 0;

                slot.postEquipDelayT = Math.max(0, r.postEquipDelaySec);
                slot.reacquireDelayT = Math.max(0, r.reacquireDelaySec);

                nd.setPosition(r._vLandUp);
                tween(nd)
                    .to(landSec, { position: r._vZero }, { easing: 'backOut' as TweenEasing })
                    .call(() => {
                        slot.moving = false;

                        if (slot.moveParam === p) {
                            slot.moveParam = null;
                            slot.moveDoneCb = null;
                        }
                        r._putTParam(p);
                        onDone?.();
                    })
                    .start();
            } else {
                r._ensureAnim(slot, 'Idle');
                r._resetUnitPose(slot);
                r._applyAmmoLabelVisual(slot);
                slot.aimRefreshCd = 0;

                nd.setPosition(r._vZero);
                slot.moving = false;

                if (slot.moveParam === p) {
                    slot.moveParam = null;
                    slot.moveDoneCb = null;
                }
                r._putTParam(p);
                onDone?.();
            }
        })
        .start();
}

export function forceFinishMove(r: any, slot: any) {
    if (!slot || !slot.node || !slot.node.isValid) return;

    // 이동 tween(TParam) 정지/회수
    if (slot.moveParam) {
        try {
            Tween.stopAllByTarget(slot.moveParam);
        } catch {}
        r._putTParam(slot.moveParam);
        slot.moveParam = null;
    }

    // ✅ 등장 tween(TParam)도 정지/회수
    if (slot.appearParam) {
        try {
            Tween.stopAllByTarget(slot.appearParam);
        } catch {}
        r._putTParam(slot.appearParam);
        slot.appearParam = null;
    }
    slot.moveDoneCb = null;

    const toPlace = r._placeOf(slot.line, slot.index);
    if (!toPlace || !toPlace.isValid) {
        slot.moving = false;
        return;
    }

    const nd = slot.node;
    try {
        Tween.stopAllByTarget(nd);
    } catch {}
    if (slot.opacity) {
        try {
            Tween.stopAllByTarget(slot.opacity);
        } catch {}
        slot.opacity.opacity = 255;
    }

    const s1 = r._scaleOf(slot.line);
    nd.setParent(toPlace);
    nd.setRotationFromEuler(0, 0, 0);
    nd.setScale(s1, s1, 1);
    nd.setPosition(r._vZero);

    r._ensureAnim(slot, 'Idle');
    r._resetUnitPose(slot);
    r._applyAmmoLabelVisual(slot);

    slot.moving = false;
}
