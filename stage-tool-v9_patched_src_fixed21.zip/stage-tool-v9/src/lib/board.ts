import type { BoardObject } from './schema';

export type Cell = { x: number; y: number };

export function cellsOf(obj: BoardObject): Cell[] {
  const { x, y } = obj;
  switch (obj.type) {
    case 'BLOCK_NORMAL':
    case 'BLOCK_HIDDEN':
    case 'CHAIN_BARRIER':
    case 'KEY':
    case 'LOCK':
      return [{ x, y }];
    case 'SPAWNER_BOX': {
      // ✅ 생성박스: 2x2 영역(편집/충돌 방지)
      // - (x,y)는 2x2 영역의 하단-좌측(spawn row)
      // - 구버전 호환: h===1이면 2x1로 취급
      const w = 2;
      const hRaw = Math.floor((((obj as any).h ?? 2) as any) ?? 2);
      const h = hRaw === 1 ? 1 : 2;
      const out: Cell[] = [];
      for (let dy = 0; dy < h; dy++) {
        for (let dx = 0; dx < w; dx++) out.push({ x: x + dx, y: y + dy });
      }
      return out;
    }
    case 'BLOCK_LARGE':
    case 'BLOCK_LARGE_HIDDEN': {
      const out: Cell[] = [];
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) out.push({ x: x + dx, y: y + dy });
      return out;
    }
    case 'PILLAR': {
      const out: Cell[] = [];
      for (let dy = 0; dy < Math.max(1, Math.floor(obj.h)); dy++) out.push({ x, y: y + dy });
      return out;
    }
  }
}

export function inBounds(cell: Cell, w = 10, h = 10): boolean {
  return cell.x >= 0 && cell.x < w && cell.y >= 0 && cell.y < h;
}

export type OccMap = Map<string, string>; // key "layer:x,y" -> uid
export function cellKey(layer: number, x: number, y: number) {
  return `${layer}:${x},${y}`;
}

export function objLayer(obj: BoardObject): number {
  const l = (obj as any).layer;
  return Number.isFinite(l) ? Math.max(0, Math.min(4, Math.floor(l))) : 0;
}

export function buildOcc(objects: BoardObject[], w = 10, h = 10): {
  occ: OccMap;
  collisions: Array<{ cell: Cell; a: string; b: string; layer: number }>;
  outOfBounds: Array<{ cell: Cell; uid: string; layer: number }>;
} {
  const occ: OccMap = new Map();
  const collisions: Array<{ cell: Cell; a: string; b: string; layer: number }> = [];
  const outOfBounds: Array<{ cell: Cell; uid: string; layer: number }> = [];

  for (const obj of objects) {
    const layer = objLayer(obj);
    for (const c of cellsOf(obj)) {
      if (!inBounds(c, w, h)) {
        outOfBounds.push({ cell: c, uid: obj.uid, layer });
        continue;
      }
      const k = cellKey(layer, c.x, c.y);
      const prev = occ.get(k);
      if (prev && prev !== obj.uid) collisions.push({ cell: c, a: prev, b: obj.uid, layer });
      occ.set(k, obj.uid);
    }
  }

  return { occ, collisions, outOfBounds };
}

export function countsAsBlock(obj: BoardObject): boolean {
  // blockCount(총 블럭 수) = "타격/히트로 소모되는 수량"만 포함합니다.
  // - KEY: 바닥 열 도달 시 자동 소멸(블럭 카운트 제외)
  // - PILLAR: 고정 오브젝트(타격/파괴 불가)
  // - LOCK: 블럭이 아닌 잠금 토큰(블럭 카운트 제외)
  // - SPAWNER_BOX: 박스 몸통은 타격 대상이 아니며, hp(생성물 수량)만 별도 카운트
  if (obj.type === 'KEY') return false;
  if (obj.type === 'PILLAR') return false;
  if (obj.type === 'LOCK') return false;
  if (obj.type === 'SPAWNER_BOX') return false;
  return true;
}

export function calcInitialBlocks(objects: BoardObject[], w = 10, h = 10): number {
  // blockCount 개념은 “깨져서 사라져야 하는 총 블록 수 목표치”입니다.
  // ✅ Normal/Hidden/Chain = 1
  // ✅ Large(2x2) = hp (예: hp=80이면 라지 1개가 블록 80개)
  // ✅ Spawner(생성박스) = hp (hp20이면 생성물 20개 = 블록 20개)
  // ❌ KEY / PILLAR / LOCK / SPAWNER_BOX(몸통) 은 블럭 카운트에서 제외
  let sum = 0;

  for (const obj of objects) {
    const cells = cellsOf(obj);
    // 부분 OOB는 스테이지가 잘못된 상태이므로 카운트에서 제외(validator가 경고/에러로 잡아줌)
    if (cells.some((c) => !inBounds(c, w, h))) continue;

    // ✅ 생성박스는 "생성물 수량"만 카운트합니다.
    if (obj.type === 'SPAWNER_BOX') {
      const hp = Math.max(0, Math.floor((obj as any).hp ?? 0));
      sum += hp;
      continue;
    }

    if (!countsAsBlock(obj)) continue;

    if (obj.type === 'BLOCK_LARGE' || obj.type === 'BLOCK_LARGE_HIDDEN') {
      const hp = Math.max(1, Math.floor((obj as any).hp ?? 80));
      sum += hp;
    } else {
      sum += 1;
    }
  }

  return sum;
}

export function uidAt(occ: OccMap, layer: number, x: number, y: number): string | null {
  return occ.get(cellKey(layer, x, y)) ?? null;
}

export function buildStackCount(objects: BoardObject[], w = 10, h = 10): Map<string, number> {
  // key "x,y" -> stack count across layers (blocks only)
  const m = new Map<string, number>();
  for (const obj of objects) {
    if (!countsAsBlock(obj)) continue;
    for (const c of cellsOf(obj)) {
      if (!inBounds(c, w, h)) continue;
      const k = `${c.x},${c.y}`;
      m.set(k, (m.get(k) ?? 0) + 1);
    }
  }
  return m;
}
