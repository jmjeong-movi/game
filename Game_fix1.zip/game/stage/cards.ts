import type { CardData } from '../Types';
import { clamp, mulberry32, rngInt, roundDownToStep, roundUpToStep } from './util';

// 배열을 제자리에서 셔플합니다.
export function shuffleInPlace<T>(arr: T[], rng: () => number) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = rngInt(rng, 0, i + 1);
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
}

// total을 [min,max] + step 단위로 정확히 분배
export function splitTotalBoundedStep(
    total: number,
    count: number,
    min: number,
    max: number,
    step: number,
    rng: () => number,
): number[] {
    const t = total / step;
    const mn = min / step;
    const mx = max / step;

    const minSum = count * mn;
    const maxSum = count * mx;
    if (t < minSum || t > maxSum)
        throw new Error(`split impossible total=${total} count=${count} min=${min} max=${max}`);

    const parts = new Array(count).fill(mn);
    let remain = t - minSum;

    let guard = 200000;
    while (remain > 0 && guard-- > 0) {
        const i = rngInt(rng, 0, count);
        if (parts[i] >= mx) continue;
        parts[i]++;
        remain--;
    }
    if (remain !== 0) throw new Error(`split failed remain=${remain}`);
    return parts.map((x) => x * step);
}

// “최대한” min/max를 지키되, 불가능하면 안전하게 1장으로 몰아줌(런타임상 문제 없음)
export function splitTotalAuto(total: number, min: number, max: number, step: number, rng: () => number): number[] {
    if (total <= 0) return [];
    const T = roundUpToStep(total, step);
    const mn = Math.max(step, roundUpToStep(min, step));
    const mx = Math.max(mn, roundUpToStep(max, step));

    const minCards = Math.ceil(T / mx);
    const maxCards = Math.floor(T / mn);

    if (maxCards < minCards) {
        // bounds가 너무 빡빡하면 1장으로 (ammoMax 초과해도 런타임은 정상 동작)
        return [T];
    }

    const avg = (mn + mx) / 2;
    let count = Math.round(T / avg);
    count = clamp(count, minCards, maxCards);

    try {
        return splitTotalBoundedStep(T, count, mn, mx, step, rng);
    } catch {
        return [T];
    }
}

// 카드판(cols/rows)을 자동 계산합니다.
export function decidePickerGrid(cardCount: number, forcedCols?: number) {
    if (forcedCols && forcedCols > 0) {
        // pickerCols(meta.pickerCols)는 절대 무시하지 않습니다.
        // 런타임 Place01~05 존재 제약 때문에 cols는 1~5로 클램프합니다.
        const cols = clamp(Math.max(1, forcedCols | 0), 1, 5);
        const rows = Math.ceil(cardCount / cols);
        return { cols, rows };
    }
    let cols = Math.ceil(Math.sqrt(cardCount));
    cols = clamp(cols, 3, 8);
    const rows = Math.ceil(cardCount / cols);
    return { cols, rows };
}

// 같은 색 연속을 줄이면서 버킷을 번갈아 배치(제자리 재배열)
export function arrangeCardsNoAdjacentInPlace(cards: CardData[], colorCount: number, seed: number) {
    const n = cards.length;
    if (n <= 2 || colorCount <= 1) return;

    // 색상별 버킷(참조만 모음)
    const buckets: CardData[][] = new Array(colorCount);
    for (let c = 0; c < colorCount; c++) buckets[c] = [];

    for (let i = 0; i < n; i++) {
        const cd = cards[i];
        const cid = (cd.colorId | 0) % colorCount;
        buckets[cid].push(cd);
    }

    // 버킷 내부는 “가벼운” 시드 셔플(한 색에 큰 탄만 몰리지 않도록)
    for (let c = 0; c < colorCount; c++) {
        const b = buckets[c];
        if (b.length > 1) shuffleInPlace(b, mulberry32(seed + 911 + c));
    }

    const idx = new Int32Array(colorCount);
    const remain = new Int32Array(colorCount);
    for (let c = 0; c < colorCount; c++) remain[c] = buckets[c].length;

    const rngPick = mulberry32(seed + 777);

    // 결과는 한 번만 버퍼에 담아 cards를 덮어씀(할당 1회)
    const out: CardData[] = new Array(n);

    let prev = -1;
    for (let k = 0; k < n; k++) {
        // 1) prev를 제외한 후보 중 remain 최대 찾기
        let maxRemain = -1;
        for (let c = 0; c < colorCount; c++) {
            const r = remain[c];
            if (r <= 0) continue;
            if (c === prev) continue;
            if (r > maxRemain) maxRemain = r;
        }

        // 2) 후보가 없으면(남은 게 prev 뿐) prev 포함해서 찾기
        let allowPrev = false;
        if (maxRemain < 0) {
            allowPrev = true;
            for (let c = 0; c < colorCount; c++) {
                const r = remain[c];
                if (r <= 0) continue;
                if (r > maxRemain) maxRemain = r;
            }
        }

        // 3) maxRemain 동률은 reservoir sampling으로 시드 기반 랜덤 선택(추가 배열 할당 없음)
        let pick = -1;
        let seen = 0;
        for (let c = 0; c < colorCount; c++) {
            const r = remain[c];
            if (r !== maxRemain) continue;
            if (!allowPrev && c === prev) continue;
            if (r <= 0) continue;

            seen++;
            if (rngPick() < 1 / seen) pick = c;
        }

        // 안전장치: 그래도 pick 실패면 남은 아무거나
        if (pick < 0) {
            for (let c = 0; c < colorCount; c++) {
                if (remain[c] > 0) {
                    pick = c;
                    break;
                }
            }
            if (pick < 0) break;
        }

        const b = buckets[pick];
        const j = idx[pick];
        out[k] = b[j];
        idx[pick] = j + 1;
        remain[pick]--;
        prev = pick;
    }

    for (let i = 0; i < n; i++) cards[i] = out[i];
}

// 카드 수가 너무 적으면 가장 큰 카드부터 쪼개서 보충(soft)
export function ensureMinCardCountSoft(cards: CardData[], minCount: number, step: number, hardMax: number) {
    // 역할: 슈팅라인(slotCount) 최소 장수 확보
    // - ammoMin/ammoMax는 '선호(soft)'이므로 여기서는 강제하지 않습니다
    // - 대신 1) 정확합계 유지, 2) 1장당 하드 상한(hardMax=50)만 지킵니다.
    if (!Array.isArray(cards) || cards.length >= minCount) return;

    // 큰 것부터 분할(할당 최소화)
    cards.sort((a, b) => (b.ammo | 0) - (a.ammo | 0));

    let guard = 512;
    while (cards.length < minCount && guard-- > 0) {
        let idx = -1;
        for (let i = 0; i < cards.length; i++) {
            const t = cards[i].ammo | 0;
            if (t > 1) {
                idx = i;
                break;
            }
        }
        if (idx < 0) break;

        const src = cards.splice(idx, 1)[0];
        const total = Math.max(1, src.ammo | 0);

        const s = step > 1 ? step : 1;
        let a = roundDownToStep(Math.floor(total * 0.5), s);
        if (a <= 0) a = 1;
        let b = total - a;
        if (b <= 0) {
            cards.push(src);
            break;
        }

        // 하드 상한(50) 적용
        if (a > hardMax) {
            a = hardMax;
            b = total - a;
        }
        if (b > hardMax) {
            b = hardMax;
            a = total - b;
        }
        if (a <= 0 || b <= 0 || a + b !== total) {
            cards.push(src);
            break;
        }

        cards.push({ colorId: src.colorId, ammo: a, shotCount: (src as any).shotCount, kind: (src as any).kind });
        cards.push({ colorId: src.colorId, ammo: b, shotCount: (src as any).shotCount, kind: (src as any).kind });
        cards.sort((x, y) => (y.ammo | 0) - (x.ammo | 0));
    }
}

// "필수 색" 카드들을 cards 배열 앞쪽으로 당깁니다.
export function promoteColorsToFrontInPlace(cards: CardData[], colors: number[], perColor = 1) {
    if (!Array.isArray(cards) || cards.length <= 1 || !Array.isArray(colors) || colors.length <= 0) return;

    let write = 0;
    const picked = new Int32Array(12);
    const want = Math.max(1, perColor | 0);

    for (let k = 0; k < colors.length; k++) {
        const c = colors[k] | 0;
        if (c < 0 || c >= 12) continue;
        if (picked[c] >= want) continue;

        for (let i = write; i < cards.length; i++) {
            if ((cards[i].colorId | 0) !== c) continue;
            const tmp = cards[write];
            cards[write] = cards[i];
            cards[i] = tmp;
            picked[c]++;
            write++;
            break;
        }
    }
}

// 특정 색 카드 1장을 '초기 슈터(slotCount)' 범위로 당김
export function promoteColorIntoShootersInPlace(cards: CardData[], desiredColor: number, slotCount: number): boolean {
    if (!Array.isArray(cards) || cards.length <= 0) return false;
    const dc = desiredColor | 0;
    if (dc < 0) return false;

    const sc = Math.max(1, slotCount | 0);
    const lim = Math.min(sc, cards.length);

    // 이미 shooter 범위에 있으면 OK
    for (let i = 0; i < lim; i++) if ((cards[i].colorId | 0) === dc) return true;

    // shooter 밖에서 찾기
    let src = -1;
    for (let i = lim; i < cards.length; i++) {
        if ((cards[i].colorId | 0) === dc) {
            src = i;
            break;
        }
    }
    if (src < 0) return false;

    // victim: shooter 중 ammo가 가장 큰 카드
    let victim = 0;
    let bestAmmo = -1;
    for (let i = 0; i < lim; i++) {
        const a = cards[i].ammo | 0;
        if (a > bestAmmo) {
            bestAmmo = a;
            victim = i;
        }
    }

    const tmp = cards[victim];
    cards[victim] = cards[src];
    cards[src] = tmp;
    return true;
}

// ammoMax 초과 카드 보정(20/30 우선 분할)
export function splitOversizedCardsPrefer2030InPlace(cards: CardData[], ammoMin: number, ammoMax: number, step: number) {
    if (!Array.isArray(cards) || cards.length === 0) return;

    const out: CardData[] = [];
    for (let i = 0; i < cards.length; i++) {
        const cd = cards[i];
        const total = cd.ammo | 0;
        if (total <= ammoMax) {
            out.push(cd);
            continue;
        }

        let remain = total;
        while (remain > 0) {
            let take = 0;

            // 1) 20 우선
            if (remain >= 20 && (remain - 20 === 0 || remain - 20 >= ammoMin)) take = 20;
            // 2) 그다음 30
            else if (remain >= 30 && (remain - 30 === 0 || remain - 30 >= ammoMin)) take = 30;
            // 3) 마지막은 ammoMax 이하로
            else take = Math.min(ammoMax, remain);

            // step 정렬
            take = roundDownToStep(take, step);
            if (take <= 0) take = Math.min(ammoMax, remain);

            // 남은 게 너무 작아져서 ammoMin을 못 지키면 이전 조각에 합치기
            if (remain - take > 0 && remain - take < ammoMin) {
                if (out.length > 0 && out[out.length - 1].colorId === cd.colorId) {
                    out[out.length - 1].ammo += remain;
                    remain = 0;
                    break;
                }
                // 합칠 곳이 없으면 그냥 마지막에 더 크게 가져가서 끝
                take = remain;
            }

            out.push({ colorId: cd.colorId, ammo: take });
            remain -= take;
        }
    }

    cards.length = 0;
    cards.push(...out);
}

// 랜덤 + 막힘 완화로 카드 색 분산
export function arrangeCardsRandomButClear(cards: CardData[], colorCount: number, rng: () => number, gapLimit = 15) {
    const n = cards.length | 0;
    if (n <= 1 || colorCount <= 1) return;

    const gap = clamp(gapLimit | 0, 3, Math.max(3, n));

    // 색상별 버킷(참조만 이동)
    const buckets: CardData[][] = Array.from({ length: colorCount }, () => []);
    for (let i = 0; i < n; i++) {
        const c = cards[i].colorId | 0;
        buckets[c >= 0 && c < colorCount ? c : 0].push(cards[i]);
    }

    // 버킷 내부도 seed 기반 셔플로 패턴 고정 방지
    for (let c = 0; c < colorCount; c++) {
        const b = buckets[c];
        if (b.length > 1) shuffleInPlace(b, rng);
    }

    // out 버퍼(1회 할당)
    const out: CardData[] = new Array(n);

    // 마지막 등장 위치(-1: 아직 등장 안 함)
    const lastPos = new Int32Array(colorCount);
    for (let c = 0; c < colorCount; c++) lastPos[c] = -1;

    let prevColor = -1;
    let cursor = rngInt(rng, 0, Math.max(1, colorCount));

    // 초반에 모든 색이 1번은 나오도록(가능한 경우) 데드라인 설정
    const firstDeadline = Math.min(n - 1, gap - 1);

    // 루프당 new 방지(임시 리스트 재사용)
    const mand: number[] = [];
    const cand: number[] = [];

    for (let pos = 0; pos < n; pos++) {
        mand.length = 0;
        cand.length = 0;

        // (A) 강제 후보: 더 미루면 gap 초과
        for (let t = 0; t < colorCount; t++) {
            const c = (cursor + t) % colorCount;
            const b = buckets[c];
            if (!b || b.length <= 0) continue;

            const lp = lastPos[c];
            if (lp < 0) {
                if (pos >= firstDeadline) mand.push(c);
            } else {
                if (pos - lp >= gap) mand.push(c);
            }
        }

        let pick = -1;

        if (mand.length > 0) {
            pick = weightedPickColor(mand, buckets, rng);
        } else {
            // (B) 가능하면 직전 색을 피해서 후보 구성
            for (let t = 0; t < colorCount; t++) {
                const c = (cursor + t) % colorCount;
                const b = buckets[c];
                if (!b || b.length <= 0) continue;
                if (c !== prevColor) cand.push(c);
            }

            if (cand.length > 0) pick = weightedPickColor(cand, buckets, rng);
            else {
                // (C) 남은 색이 1종뿐이면 허용
                for (let t = 0; t < colorCount; t++) {
                    const c = (cursor + t) % colorCount;
                    const b = buckets[c];
                    if (b && b.length > 0) {
                        pick = c;
                        break;
                    }
                }
            }
        }

        if (pick < 0) break; // 방어

        out[pos] = buckets[pick].pop()!;
        lastPos[pick] = pos;
        prevColor = pick;
        cursor = (pick + 1) % colorCount;
    }

    // in-place 덮어쓰기
    for (let i = 0; i < n; i++) cards[i] = out[i];
}

// 후보 색 목록에서 남은 카드 수 비율로 가중 랜덤 선택
export function weightedPickColor(list: number[], buckets: CardData[][], rng: () => number): number {
    let sum = 0;
    for (let i = 0; i < list.length; i++) sum += buckets[list[i]]?.length ?? 0;
    if (sum <= 0) return list[rngInt(rng, 0, list.length)];

    let r = rng() * sum;
    for (let i = 0; i < list.length; i++) {
        const c = list[i];
        r -= buckets[c]?.length ?? 0;
        if (r <= 0) return c;
    }
    return list[list.length - 1];
}
