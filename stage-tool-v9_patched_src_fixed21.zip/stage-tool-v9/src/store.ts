import { create } from 'zustand';
import { COLOR12 } from './lib/schema';
import type { BoardObject, BoardObjectType, Color12, StagePackV2, StageV2 } from './lib/schema';
import { makeDefaultPack, makeEmptyStage } from './lib/defaultPack';
import { uid } from './lib/ids';
import { buildOcc, calcInitialBlocks, uidAt, cellsOf } from './lib/board';
import { packToJson, parsePack, packToJsonClearGuaranteedAsync } from './lib/codec';

export type ToolMode = 'PAINT' | 'ERASE' | 'SELECT';

type State = {
  pack: StagePackV2;
  currentStageId: number;

  // ✅ 편집 대상: 초기 보드 / 공급(Supply) 페이지
  editTarget: { kind: 'INITIAL' | 'SUPPLY'; index: number };

  // ✅ PILLAR 선그리기(1번째 클릭 시작점, 2번째 클릭 종료점)
  pillarLineStart: { x: number; y: number } | null;

  // ✅ CHAIN_BARRIER 선그리기(1번째 클릭 시작점, 2번째 클릭 종료점)
  // - 체인은 항상 1행(가로)만 차지합니다.
  // - 길이: 2~10칸
  chainLineStart: { x: number; y: number } | null;

  // 현재 편집 레이어(0..4). stage.meta.layerCount 기준으로 clamp
  currentLayer: number;

  toolMode: ToolMode;
  brush: BoardObjectType;
  color: Color12;

  // ✅ 브러시(특수 오브젝트) 기본 파라미터
  // - 역할: 배치 시 모달에서 입력한 값을 기억했다가 다음 배치에도 그대로 사용합니다.
  // - 주의: 스테이지 데이터에 저장되지 않는 "툴 UI 상태"입니다.
  brushConfig: {
    largeHp: number;
    largeHiddenHp: number;
    spawnerHp: number;
    spawnerLeft: Color12;
    spawnerRight: Color12;
    chainHead: Color12;
    chainTail: Color12;
    // ✅ 체인 머리 방향(라인 배치 시 chainOrder 방향)
    // - LEFT: x 증가 방향으로 chainOrder 0..len-1
    // - RIGHT: x 감소 방향으로 chainOrder 0..len-1 (머리가 오른쪽)
    chainHeadSide: 'LEFT' | 'RIGHT';
  };
  setBrushConfig: (patch: Partial<State['brushConfig']>) => void;

  selectedUid: string | null;

  // derived-ish (for UI)
  lastSavedAt: number | null;

  // ✅ Undo/Redo (pack snapshot 기반, CAP 적용)
  undoDepth: number;
  redoDepth: number;


  // ✅ 숫자 입력 Draft(빈 값 허용)
  // 역할: 입력 도중(빈 문자열 포함)을 보관해서 '강제 1자리' 현상을 제거합니다.
  numDraft: Record<string, string>;
  setNumDraft: (key: string, value: string) => void;
  clearNumDraft: (key: string) => void;

  // actions
  loadFromText: (jsonText: string) => void;
  resetToDefault: () => void;

  selectStage: (id: number) => void;
  addStageAfter: () => void;
  duplicateStage: () => void;
  deleteStage: () => void;

  // ✅ 현재 스테이지를 통째로 교체(리플레이 리페어 결과 적용 등)
  replaceCurrentStage: (stage: StageV2) => void;

  setToolMode: (m: ToolMode) => void;
  setBrush: (b: BoardObjectType) => void;
  setColor: (c: Color12) => void;

  setCurrentLayer: (layer: number) => void;

  setEditTarget: (t: { kind: 'INITIAL' | 'SUPPLY'; index?: number }) => void;

  setMeta: (patch: Partial<StageV2['meta']>) => void;
  addSupplyPage: () => void;
  removeSupplyPage: (pageIndex: number) => void;

  fillLayerWithColor: (mode: 'EMPTY_ONLY' | 'OVERWRITE') => void;

  // ✅ 빠른 정리
  clearCurrentLayer: () => void;
  clearCurrentPage: () => void;

  // ✅ 랜덤 꾸미기(현재 보고 있는 페이지의 현재 레이어만)
  randomDecorateCurrentLayer: (cfg: {
    clearExisting: boolean;
    fillPercent: number; // 0~100
    chainPercent: number; // 0~100
    includeNormal: boolean;
    includeLarge: boolean;
    largeCount: number;
    largeHp: number;
    includeChain: boolean;
    includePillar: boolean;
    pillarLines: number;
    includeKey: boolean;
    keyCount: number;
    includeSpawner: boolean;
    spawnerCount: number;
    colors: Color12[];
  }) => void;

  clickCell: (x: number, y: number, opts?: { forceErase?: boolean }) => void;
  // ✅ 다중 셀 적용(Shift 드래그 사각형 등): Undo 1회로 묶어서 처리
  applyCells: (cells: Array<{ x: number; y: number }>, opts?: { forceErase?: boolean; mode?: 'PAINT' | 'ERASE' }) => void;

  // ✅ 선택영역 복사/붙여넣기
  // - relObjects: {x,y}가 (0,0) 기준인 상대좌표 오브젝트 배열
  // - anchor: 붙여넣을 좌하단 기준 좌표
  pasteObjects: (anchor: { x: number; y: number }, relObjects: BoardObject[]) => void;
  setSelectedUid: (uid: string | null) => void;
  updateSelectedObject: (patch: Partial<BoardObject>) => void;

  // ✅ 다중 선택(사각형/복수) 오브젝트 일괄 수정
  // - 1번의 Undo로 묶어서 적용합니다.
  bulkUpdateObjects: (uids: string[], patch: Partial<BoardObject>) => void;

  // ✅ 에러 자동 수정(공급/블록 카운트 불일치 등)
  autoFix: () => void;

  // ✅ Undo/Redo
  undo: () => void;
  redo: () => void;

  getPackJson: () => string;
  markSaved: (t: number) => void;

  // ✅ 체인 라인 배치(1클릭 시작) 취소
  cancelChainLine: () => void;
};

function clampInt(n: number, lo: number, hi: number): number {
  const v = Math.floor(Number.isFinite(n) ? n : 0);
  return Math.max(lo, Math.min(hi, v));
}

const AMMO_STEP = 10;
// ✅ 카드 1장의 탄약 상한(런타임 요구사항)
const HARD_AMMO_MAX = 50;
function roundUpStep(n: number, step: number) {
  if (step <= 1) return Math.ceil(n);
  return Math.ceil(n / step) * step;
}
function roundDownStep(n: number, step: number) {
  if (step <= 1) return Math.floor(n);
  return Math.floor(n / step) * step;
}

/**
 * 블록 수/색상 수에 따라 추천 탄약 범위를 자동 계산합니다.
 * - perColor(블록/색상) 값이 클수록 카드 1장의 ammo도 커지도록.
 * - 너무 작은/큰 값은 clamp.
 */
function recommendAmmoRange(blockCount: number, colorCount: number) {
  const bc = Math.max(1, Math.floor(blockCount));
  const cc = Math.max(1, Math.min(COLOR12.length, Math.floor(colorCount)));
  const per = bc / cc;

  // ✅ perColor를 기준으로 추천하되, 카드 1장 최대 탄약(HARD_AMMO_MAX)을 절대 넘기지 않음
  // - per가 크면 max는 HARD_AMMO_MAX로 포화
  // - per가 작으면 10~50 사이에서 자연스럽게 추천
  let max = roundUpStep(Math.max(20, Math.min(HARD_AMMO_MAX, per * 1.2)), AMMO_STEP);
  let min = roundDownStep(Math.max(AMMO_STEP, Math.min(max, per * 0.8)), AMMO_STEP);

  // 최종 안전 클램프
  max = Math.max(AMMO_STEP, Math.min(HARD_AMMO_MAX, max));
  min = Math.max(AMMO_STEP, Math.min(max, min));

  return { ammoMin: min, ammoMax: max };
}

function deepCopyStage(stage: StageV2): StageV2 {
  return {
    ...stage,
    meta: { ...stage.meta },
    board: { ...stage.board, objects: stage.board.objects.map((o) => ({ ...(o as any) })) as any },
    // ✅ supply는 "공급 패턴 페이지"만 저장합니다.
    // - pages 내부도 깊은 복사 (Undo/Redo 안정성)
    supply: {
      mode: 'PATTERN',
      pages: (stage.supply?.pages ?? []).map((p) => ({ objects: (p.objects ?? []).map((o) => ({ ...(o as any) })) as any })),
    },
    cards: {
      ...stage.cards,
      rules: stage.cards.rules ? { ...stage.cards.rules } : undefined,
      authored: stage.cards.authored ? stage.cards.authored.map((a) => ({ ...a })) : undefined,
    },
    shooters: { ...stage.shooters, slots: stage.shooters.slots.map((s) => ({ ...s })) },
  };
}


/**
 * Supply 페이지 접근 규칙(B안)
 * - stage.supply.pages 배열은 "사용자가 실체화(materialize)해서 편집한 공급 페이지"만 저장합니다.
 * - 해석(resolved)은 [초기, 공급1, 공급2, ...] 순서로 순차 반복(라운드 로빈)합니다.
 * - 자동 복제(페이지 폭증)를 막기 위해, "필요할 때만" materialize로 생성합니다.
 */
const SUPPLY_PAGE_CAP = 50;

function resolveSupplyPageObjects(stage: StageV2, pageIndex: number): BoardObject[] {
  // ✅ 역할: “실체화된 supply 페이지”의 오브젝트를 반환합니다. (편집용)
  // 규칙:
  // - supply.pages가 0장이라면: 편집 대상 공급 패턴이 없으므로 빈 배열 반환(초기와 섞이지 않게)
  // - pageIndex가 범위를 넘으면: 마지막 실체화 페이지로 클램프(방어)
  const pages = stage.supply?.pages ?? [];
  if (pages.length <= 0) return [];
  const i = Math.max(0, Math.min(pages.length - 1, Math.floor(pageIndex)));
  return ((pages[i]?.objects ?? []) as any).slice();
}

function resolveSupplyTimelineObjects(stage: StageV2, supplyPageIndex: number): BoardObject[] {
  // ✅ 역할: “공급 타임라인 페이지”의 패턴을 반환합니다. (해석/검증/프리뷰용)
  // 규칙:
  // - supply.pages가 0장이라면: 초기(Initial) 1페이지 패턴을 계속 반복
  // - supply.pages가 1장 이상이라면: [초기, 공급1, 공급2, ...] 순서로 순차 반복(라운드 로빈)
  // - ✅ 추가 규칙: supply.pages[k].objects가 비어있으면 "직전 패턴 상속(inherit)"로 해석합니다.
  const pages = stage.supply?.pages ?? [];
  const seqLen = 1 + pages.length; // 0: initial, 1..: supply pages
  const i = Math.max(0, Math.floor(supplyPageIndex));
  const k = seqLen <= 0 ? 0 : (i % seqLen);

  // 초기 패턴(비어있을 수도 있음)
  const initial = ((stage.board.objects ?? []) as any).slice();

  // supply가 없으면 초기 반복
  if (pages.length <= 0) return initial;

  // 0: initial, 1..: supply pages
  // ✅ 상속 규칙: 비어있는 supply page는 직전(가장 최근의 non-empty) 패턴을 사용
  let lastNonEmpty = initial;

  // k까지의 "해석된" 패턴을 순차적으로 따라가며 lastNonEmpty를 갱신한다.
  // (k가 크지 않아서 매번 계산해도 충분히 가볍습니다.)
  for (let idx = 1; idx <= k; idx++) {
    const objs = ((pages[idx - 1]?.objects ?? []) as any).slice();
    if (objs.length > 0) lastNonEmpty = objs;
  }

  // k==0이면 initial
  if (k === 0) return initial;

  // k>0이면 k번째 supply page를 해석(비어있으면 lastNonEmpty)
  const cur = ((pages[k - 1]?.objects ?? []) as any).slice();
  return cur.length > 0 ? cur : lastNonEmpty;
}
function materializeSupplyPage(stage: StageV2, pageIndex: number) {
  const pi = clampInt(pageIndex, 0, SUPPLY_PAGE_CAP - 1);
  const sp = stage.supply ?? { mode: 'PATTERN' as const, pages: [] as any[] };
  let pages = (sp.pages ?? []).slice();

  // ✅ B안: 공급 페이지는 '공급 추가'로 실체화될 때도 기본은 빈 페이지입니다.
  // 역할: 공급을 추가하지 않으면(=supplyPages가 비어있으면) 초기 1페이지 패턴이 자동 반복되고,
  //       사용자가 공급 페이지를 꾸미기로 결정했을 때만 빈 페이지를 생성해서 꾸미도록 합니다.
  const makeEmptyPage = () => ({ objects: [] as any[] });

  // 필요한 인덱스까지는 빈 페이지로만 실체화(자동 채움/복제 금지)
  while (pages.length <= pi) {
    pages.push(makeEmptyPage());
  }

  stage.supply = { ...(stage.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
  return pi;
}

function calcSupplyNeededPages(stage: StageV2): { supplyBudget: number; neededPages: number; sum: number; lastPageBlocks: number } {
  // ✅ 역할: 공급 목표(supplyBudget)를 채우기 위해 “공급 타임라인 페이지”가 몇 장 필요한지 계산합니다.
  // 규칙:
  // - supplyBudget = max(0, blockCount - initialBlocks)
  // - supplyPages가 0장: 초기 패턴만 반복
  // - supplyPages가 1장 이상: [초기, 공급1, 공급2, ...] 순서로 반복(라운드 로빈)
  const CAP = SUPPLY_PAGE_CAP;

  const initialBlocks = calcInitialBlocks(stage.board.objects ?? [], 10, 10);
  const bc = Math.max(0, Math.floor((stage.meta as any)?.blockCount ?? 0));
  const supplyBudget = Math.max(0, bc - initialBlocks);

  if (supplyBudget <= 0) return { supplyBudget, neededPages: 0, sum: 0, lastPageBlocks: 0 };

  const pages = stage.supply?.pages ?? [];
  const pageBlocks = pages.map((p) => calcInitialBlocks((p?.objects ?? []) as any, 10, 10));

  const seqBlocks = pages.length > 0 ? [initialBlocks, ...pageBlocks] : [initialBlocks];
  const seqLen = Math.max(1, seqBlocks.length);

  // 패턴이 전부 0이면 공급 불가
  const canProgress = seqBlocks.some((v) => (v || 0) > 0);
  if (!canProgress) return { supplyBudget, neededPages: 0, sum: 0, lastPageBlocks: 0 };

  let sum = 0;
  let neededPages = 0;
  let lastPageBlocks = 0;

  for (let i = 0; i < CAP && sum < supplyBudget; i++) {
    const b = Math.max(0, Math.floor(seqBlocks[i % seqLen] ?? 0));
    if (b <= 0) continue; // 0블록 페이지는 스킵(무한루프 방지)
    sum += b;
    neededPages++;
    lastPageBlocks = b;
  }

  return { supplyBudget, neededPages, sum, lastPageBlocks };
}


function stageIndex(pack: StagePackV2, id: number): number {
  return pack.stages.findIndex((s) => s.id === id);
}

function getNextStageId(existingIds: number[]): number {
  const used = new Set(existingIds.filter((n) => Number.isFinite(n) && n > 0).map((n) => Math.floor(n)));
  let id = 1;
  while (used.has(id)) id++;
  return id;
}

function pickNextSelectedId(sortedIds: number[], deletedId: number): number {
  for (const id of sortedIds) if (id > deletedId) return id;
  return sortedIds.length ? sortedIds[sortedIds.length - 1] : 1;
}

function recalcSupply(stage: StageV2): StageV2 {
  const BOARD_UNIT = 100; // 10x10 = 100 (시각화 단위)
  const MAX_SUPPLY_PAGES = 50;

  const cloneObjectsWithNewUid = (objs: any[]) => (objs ?? []).map((o) => ({ ...o, uid: uid() }));

  const calcPageBlocks = (objs: any[]) => calcInitialBlocks(objs ?? [], 10, 10);

  // ---- meta 정규화(안전 장치) ----
  const meta = { ...(stage.meta as any) } as any;
  meta.layerCount = clampInt(meta.layerCount ?? 1, 1, 5);
  meta.slotCount = clampInt(meta.slotCount ?? 3, 3, 5);
  meta.blockCount = Math.max(0, Math.floor(meta.blockCount ?? 0));
  meta.waitLineCount = clampInt(meta.waitLineCount ?? 3, 3, 5);
  meta.pickerCols = clampInt(meta.pickerCols ?? 2, 1, 10);
  // pickerMaxCards는 (대기라인 x 피커 열수)로 자동 계산
  meta.pickerMaxCards = clampInt(meta.pickerCols * meta.waitLineCount, 1, 50);

  // ✅ ammoMax는 자동이 아니라 사용자가 직접 설정(런타임 상한 50 유지)
  // 역할: 카드 1장 탄약의 최대값을 사용자가 고정/조정할 수 있게 합니다.
  meta.ammoMax = clampInt(meta.ammoMax ?? 50, AMMO_STEP, HARD_AMMO_MAX);


// ✅ colorCount 자동 계산
// 역할: 초기/공급(실체화)에서 실제로 사용된 색상 개수를 meta.colorCount로 갱신합니다.
//       (숨김 블록도 color를 가질 수 있으므로 포함)
const usedColors = new Set<string>();
const scanColors = (objs: any[]) => {
  for (const o of objs ?? []) {
    const anyO: any = o as any;
    if (!anyO) continue;

    // 일반/빅 블록/특수(색 기반) 오브젝트
    if (anyO.color !== undefined && anyO.color !== null) {
      usedColors.add(String(anyO.color));
    }

    // 스포너 박스: poolColors에 색이 들어갈 수 있음
        // ✅ 스포너/생성박스는 spawn.poolColors에 색상 풀이 있음
        const pool = anyO.spawn?.poolColors ?? anyO.poolColors ?? anyO.colors ?? anyO.palette;
    if (Array.isArray(pool)) {
      for (const c of pool) {
        if (c === undefined || c === null) continue;
        usedColors.add(String(c));
      }
    }
  }
};
  scanColors((stage.board.objects ?? []) as any);
  for (const p of stage.supply?.pages ?? []) scanColors((p as any).objects ?? []);
  meta.colorCount = clampInt(Math.max(1, usedColors.size), 1, COLOR12.length);

  // ✅ cards 정규화
  // 역할:
  // - 구버전 JSON(또는 과거 코드)에서 cards가 배열([])로 들어오는 경우가 있었음
  // - 현재 스키마는 cards가 객체({mode,rules,authored})이므로 여기서 안전하게 변환
  const rawCards: any = (stage as any).cards;
  const normCards: any = (() => {
    // 최신 포맷(객체)
    if (rawCards && typeof rawCards === 'object' && !Array.isArray(rawCards)) {
      const mode = rawCards.mode === 'AUTHORED' ? 'AUTHORED' : 'GENERATE';
      const rules = rawCards.rules ?? { ammoStep: 10, totalAmmoEquals: 'BOARD_BLOCKS' };
      const authored = Array.isArray(rawCards.authored) ? rawCards.authored : undefined;
      return { mode, rules, authored };
    }
    // 구버전(배열/없음) -> 기본 생성 모드
    return { mode: 'GENERATE', rules: { ammoStep: 10, totalAmmoEquals: 'BOARD_BLOCKS' } };
  })();

  // ✅ blockCount는 "사용자가 설정한 목표값"을 유지
  // 역할: 보드에 블록을 찍거나 지워도 meta.blockCount(목표)가 자동으로 바뀌지 않게 합니다.
  //       supply 목표는 "목표(blockCount) - 현재 초기 블록"으로 계산합니다.
  // 자물쇠(LOCK)는 사용하지 않음: 로드/정규화 단계에서 제거
  const stripLock = (objs: any[]) => (objs ?? []).filter((o) => o?.type !== 'LOCK');

  const boardObjects = stripLock(stage.board.objects ?? []);
  const initial = calcInitialBlocks(boardObjects, 10, 10);

  const desiredTotal = Math.max(0, Math.floor(meta.blockCount ?? 0));
  const supplyTotal = Math.max(0, desiredTotal - initial);

  // ✅ blockCount(목표) 기준 supply 합계(=supplyTotal)는 “페이지 자동 복제”로 채우지 않습니다.
  // - supplyPages.pages는 “사용자가 실체화(materialize)해서 편집한 페이지”만 저장합니다.
  // - 공급 해석은 [초기, 공급1, 공급2, ...] 순서로 순차 반복(라운드 로빈)합니다.
  // - 부족/초과 보정은 Validate/AutoFix에서 명시적으로 처리합니다.
  // supplyPages.pages는 “사용자가 실체화(materialize)해서 편집한 페이지”만 저장합니다.
  // ⚠️ 목표 공급량이 0이 되어도 사용자가 만든 supply 페이지를 강제로 삭제하지 않습니다.
  let supplyPages = (stage.supply?.pages ? stage.supply.pages : []).map((p) => ({ ...p, objects: stripLock((p as any).objects ?? []) }));

  // ✅ lockShooterCount 자동 계산 (KEY 블럭 기반)
  // - 기획: KEY 블럭 1개가 생성되면(=스테이지에 존재하면) "자물쇠 유닛"이 1개 필요합니다.
  // - 따라서 lockShooterCount는 KEY 블럭 개수(초기 + 공급 페이지)에 맞춰 자동 갱신합니다.
  // - (구버전 호환) LOCK 오브젝트는 stripLock에서 제거되므로 여기서는 KEY만 계산합니다.
  {
    const countKeys = (objs: any[]) => (objs ?? []).reduce((a, o) => a + (o?.type === 'KEY' ? 1 : 0), 0);
    const keyCount = countKeys(boardObjects as any) + supplyPages.reduce((a, p) => a + countKeys((p as any)?.objects ?? []), 0);
    meta.lockShooterCount = clampInt(keyCount, 0, 999);
  }

  // ✅ ammoMin 자동 계산 (최소 탄약)
  // 역할:
  // - 보드/공급 패턴에 찍힌 블록들 중, "가장 적게 등장한 색상"의 블록 수를 ammoMin으로 사용합니다.
  // - 히든 스몰/히든 라지도 color를 가지므로 동일하게 집계합니다.
  // - 라지(2x2)는 hp(=블록 수)로 집계합니다.
  const calcAmmoMinFromMinColor = () => {
    const counts = new Map<string, number>();

    const add = (c: any, w: number) => {
      const key = String(c ?? '');
      if (!key) return;
      counts.set(key, (counts.get(key) ?? 0) + Math.max(1, Math.floor(w)));
    };

    // 역할:
    // - (히든 포함) 보드에 찍힌 스몰/빅 블럭 중, "가장 적게 찍힌 색상"의 블록 수를 ammoMin으로 사용합니다.
    // - 빅(2x2)은 hp(=깨야 하는 블록 수/타격 수) 기준으로 집계합니다.
    const scanBoardOnly = (objs: any[]) => {
      for (const o of objs ?? []) {
        if (!o) continue;
        const t = String((o as any).type ?? '');
        if (t === 'BLOCK_NORMAL' || t === 'BLOCK_HIDDEN') {
          add((o as any).color, 1);
        } else if (t === 'BLOCK_LARGE' || t === 'BLOCK_LARGE_HIDDEN') {
          add((o as any).color, Math.max(1, Math.floor((o as any).hp ?? 80)));
        }
      }
    };

    scanBoardOnly(boardObjects as any);

    if (counts.size === 0) return 0;

    let min = Infinity;
    for (const v of counts.values()) min = Math.min(min, v);
    return Number.isFinite(min) ? Math.max(0, Math.floor(min)) : 0;
  };

  // ✅ ammoMin 자동 계산(추천값)
  // 기존: “가장 적게 등장한 색상의 블록 수”를 ammoMin으로 사용했는데,
  //       라지 hp/공급량이 큰 스테이지에서는 ammoMin이 50을 넘어가면서
  //       (ammoMin > ammoMax) 상태가 쉽게 발생했습니다.
  //       ammoMin은 ‘카드 1장당 최소 탄약’ 의미이므로, 툴에서는 10~ammoMax(<=50) 범위로 유지합니다.
  //       추천값은 blockCount/colorCount 기반의 recommendAmmoRange를 사용합니다.
  {
    const rec = recommendAmmoRange(meta.blockCount ?? 1, meta.colorCount ?? 1);
    const suggestedMin = rec.ammoMin;
    meta.ammoMin = clampInt(suggestedMin, AMMO_STEP, meta.ammoMax);
  }

  // ✅ 공급 페이지 자동 생성은 하지 않습니다.
  // 역할:
  // - 사용자가 supply.pages를 추가하지 않은 상태라도, 런타임 해석 규칙에 의해
  //   '초기 패턴 반복(또는 [초기→공급..] 순차 반복)'으로 공급이 동작할 수 있습니다.
  // - 툴은 데이터를 임의로 실체화(materialize)해서 pages를 늘리지 않습니다.

  // shooters 슬롯 수를 meta.slotCount에 맞춰 자동 정렬/보정
  const wantedSlots = Math.max(1, Math.floor(meta.slotCount ?? 3));
  const srcSlots = Array.isArray(stage?.shooters?.slots) ? stage.shooters.slots : [];
  const nextSlots: any[] = [];
  for (let i = 0; i < wantedSlots; i++) {
    const ex = srcSlots.find((s: any) => s?.slot === i) ?? srcSlots[i];
    nextSlots.push({ slot: i, type: ex?.type ?? 'SHOOTER_NORMAL', lockId: ex?.lockId });
  }

  return {
    ...stage,
    board: { ...stage.board, objects: boardObjects },
    meta,
    cards: normCards,
    // ✅ 공급 패턴은 supply.pages로만 저장합니다.
    supply: { mode: 'PATTERN', pages: supplyPages },
    shooters: { ...stage.shooters, slots: nextSlots },
  };
}

function makeStageFromTemplate(template: StageV2, id: number, kind: 'empty' | 'duplicate'): StageV2 {
  if (kind === 'empty') {
    const base = makeEmptyStage(id);
    // meta는 템플릿에서 가져오되, blockCount는 그대로, seed만 갱신
    base.meta = { ...template.meta, seed: (template.meta.seed ?? 1000) + 1, blockCount: template.meta.blockCount };
    base.shooters = { ...template.shooters, slots: template.shooters.slots.map((s) => ({ ...s })) };
    base.meta.pickerMaxCards = template.meta.pickerMaxCards;
    base.meta.pickerCols = template.meta.pickerCols;
    base.meta.colorCount = template.meta.colorCount;
    base.meta.slotCount = template.meta.slotCount;
    base.meta.ammoMin = template.meta.ammoMin;
    base.meta.ammoMax = template.meta.ammoMax;
    return recalcSupply(base);
  }

  const dup = deepCopyStage(template);
  dup.id = id;
  dup.meta = { ...dup.meta, seed: (dup.meta.seed ?? 1000) + 1 };
  // uid 재생성(겹침 방지)
  dup.board.objects = dup.board.objects.map((o) => ({ ...(o as any), uid: uid() })) as any;
  return recalcSupply(dup);
}

export const useStageTool = create<State>((set, get) => {
  const initialPack = makeDefaultPack();
  const initialStageId = initialPack.stages[0]?.id ?? 1;
  const _undo: string[] = [];
  const _redo: string[] = [];
  const HISTORY_CAP = 100;

  const pushUndo = () => {
    try {
      const cur = get().getPackJson();
      _undo.push(cur);
      if (_undo.length > HISTORY_CAP) _undo.shift();
      _redo.length = 0;
      set({ undoDepth: _undo.length, redoDepth: _redo.length });
    } catch {}
  };

  const applySnapshot = (jsonText: string) => {
    try {
      const pack = parsePack(jsonText);
      const stages = pack.stages.map((s) => recalcSupply(s));
      const sorted = stages.slice().sort((a, b) => a.id - b.id);
      const curId = sorted[0]?.id ?? 1;
      console.log('[StageTool] applySnapshot ok:', { stages: sorted.length, curId });
      set({ pack: { schemaVersion: 2, stages: sorted }, currentStageId: curId, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null, numDraft: {} });
    } catch (e) {
      console.error('[StageTool] applySnapshot failed. Reset to default pack.', e);
      const fallback = makeDefaultPack();
      const curId = fallback.stages[0]?.id ?? 1;
      set({ pack: fallback, currentStageId: curId, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null, numDraft: {} });
    }
  };


  return {
    pack: initialPack,
    currentStageId: initialStageId,

    editTarget: { kind: 'INITIAL', index: 0 },
    pillarLineStart: null,
    chainLineStart: null,

    currentLayer: 0,

    toolMode: 'PAINT',
    brush: 'BLOCK_NORMAL',
    color: 'R',

    brushConfig: {
      largeHp: 80,
      largeHiddenHp: 80,
      spawnerHp: 10,
      spawnerLeft: 'R',
      spawnerRight: 'R',
      chainHead: 'R',
      chainTail: 'R',
      chainHeadSide: 'LEFT',
    },
    setBrushConfig: (patch) => {
      set((st) => ({ brushConfig: { ...(st as any).brushConfig, ...(patch as any) } } as any));
    },

    selectedUid: null,
    lastSavedAt: null,
    undoDepth: 0,
    redoDepth: 0,
    numDraft: {},

    loadFromText: (jsonText) => {
      const pack = parsePack(jsonText);
      const stages = pack.stages.map((s) => recalcSupply(s));
      const sorted = stages.slice().sort((a, b) => a.id - b.id);
      const curId = sorted[0]?.id ?? 1;
      set({
        pack: { schemaVersion: 2, stages: sorted },
        currentStageId: curId,
        currentLayer: 0,
        selectedUid: null,
        editTarget: { kind: 'INITIAL', index: 0 },
        pillarLineStart: null,
        chainLineStart: null,
        numDraft: {},
      });
    },

    resetToDefault: () => {
      const p = makeDefaultPack();
      set({
        pack: p,
        currentStageId: p.stages[0]?.id ?? 1,
        currentLayer: 0,
        selectedUid: null,
        editTarget: { kind: 'INITIAL', index: 0 },
        pillarLineStart: null,
        chainLineStart: null,
        numDraft: {},
      });
    },

    // ✅ 숫자 입력 Draft
    // 역할: 입력 도중(빈 문자열 포함) 값을 보관해서 UX를 안정화합니다.
    setNumDraft: (key, value) => {
      const k = String(key ?? '');
      set((st) => ({ numDraft: { ...(st as any).numDraft, [k]: String(value ?? '') } }));
    },
    clearNumDraft: (key) => {
      const k = String(key ?? '');
      set((st) => {
        const next = { ...(st as any).numDraft };
        delete next[k];
        return { numDraft: next } as any;
      });
    },

    selectStage: (id) => {
      const pack = get().pack;
      const idx = stageIndex(pack, id);
      if (idx < 0) return;
      set({ currentStageId: id, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null });
    },

    addStageAfter: () => {
      const { pack, currentStageId } = get();
      const idx = stageIndex(pack, currentStageId);

      pushUndo();
      const template = idx >= 0 ? pack.stages[idx] : pack.stages[0] ?? makeEmptyStage(1);

      const newId = getNextStageId(pack.stages.map((s) => s.id));
      const newStage = makeStageFromTemplate(template, newId, 'empty');

      const stages = [...pack.stages, newStage].slice().sort((a, b) => a.id - b.id);
      set({ pack: { schemaVersion: 2, stages }, currentStageId: newId, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null });
    },

    duplicateStage: () => {
      const { pack, currentStageId } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const current = pack.stages[idx];
      const newId = getNextStageId(pack.stages.map((s) => s.id));
      const newStage = makeStageFromTemplate(current, newId, 'duplicate');
      const stages = [...pack.stages, newStage].slice().sort((a, b) => a.id - b.id);
      set({ pack: { schemaVersion: 2, stages }, currentStageId: newId, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null });
    },

    deleteStage: () => {
      const { pack, currentStageId } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const removedId = currentStageId;
      let stages = pack.stages.filter((s) => s.id !== removedId);

      if (stages.length === 0) {
        const st1 = makeEmptyStage(1);
        set({ pack: { schemaVersion: 2, stages: [recalcSupply(st1)] }, currentStageId: 1, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null });
        return;
      }

      stages = stages.slice().sort((a, b) => a.id - b.id);
      const ids = stages.map((s) => s.id);
      const nextId = pickNextSelectedId(ids, removedId);
      set({ pack: { schemaVersion: 2, stages }, currentStageId: nextId, currentLayer: 0, selectedUid: null, editTarget: { kind: 'INITIAL', index: 0 }, pillarLineStart: null, chainLineStart: null });
    },

    // ✅ 리플레이 리페어 등으로 생성된 stage를 현재 스테이지에 덮어씌웁니다.
    // - undo/redo 스냅샷을 남기고, pack 내 동일 id 스테이지를 교체합니다.
    replaceCurrentStage: (newStage) => {
      const { pack, currentStageId } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      pushUndo();

      const stages = pack.stages.slice();
      // supply/materialize/meta 정규화 포함
      const fixed = recalcSupply(deepCopyStage(newStage as any));
      stages[idx] = fixed;
      stages.sort((a, b) => a.id - b.id);

      set({
        pack: { schemaVersion: 2, stages },
        currentStageId: fixed.id,
        currentLayer: 0,
        selectedUid: null,
        editTarget: { kind: 'INITIAL', index: 0 },
        pillarLineStart: null,
        chainLineStart: null,
        numDraft: {},
      });
    },

    // 역할: 툴 모드가 바뀌면 기둥 라인 시작점/임시 상태가 남지 않도록 정리합니다.
    // 역할: 툴 전환 시 이전 드래그/선택 상태가 남지 않도록 초기화합니다.
    setToolMode: (m) => set({ toolMode: m, pillarLineStart: null, chainLineStart: null, selectedUid: null }),
    setBrush: (b) => set({ brush: b }),
    cancelChainLine: () => set({ chainLineStart: null }),
    // ✅ 색상 선택은 브러시 색만 변경 (colorCount는 “실제 배치된 색” 기준으로 자동 계산)
    setColor: (c) => set({ color: c }),

    setCurrentLayer: (layer) => {
      const { pack, currentStageId } = get();
      const idx = stageIndex(pack, currentStageId);
      const st = idx >= 0 ? pack.stages[idx] : pack.stages[0];
      const layerCount = Math.max(1, Math.min(5, Math.floor(st?.meta?.layerCount ?? 1)));
      const next = clampInt(layer, 0, layerCount - 1);
      set({ currentLayer: next, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    setEditTarget: (t) => {
      const kind = t.kind;
      const index = kind === 'SUPPLY' ? Math.max(0, Math.floor(t.index ?? 0)) : 0;
      set({ editTarget: { kind, index }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    setMeta: (patch) => {
      const { pack, currentStageId, currentLayer } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      // 이전 layerCount(추가 시 '이전 레이어 복사'에 사용)
      const prevLayerCount = clampInt((s.meta as any)?.layerCount ?? 1, 1, 5);
      const merged = { ...s.meta, ...patch } as any;
      // 기본 clamp (툴 UI는 number input이라도 안전장치)
      merged.layerCount = clampInt(merged.layerCount ?? 1, 1, 5);
      // colorCount는 “실제 배치된 색” 기준으로 recalcSupply에서 자동 계산됩니다.

      // ✅ 레이어가 늘어날 때: 새 레이어는 '이전 레이어'를 그대로 복사
      // - 예) 1겹 → 2겹: layer0을 layer1로 복사
      // - 예) 2겹 → 3겹: layer1을 layer2로 복사
      // - pillar/spawner는 고정 오브젝트라 복사하지 않음
      const nextLayerCount = merged.layerCount as number;
      if (nextLayerCount > prevLayerCount) {
        const getLayer = (o: any) => {
          const l = o?.layer;
          return Number.isFinite(l) ? Math.max(0, Math.min(4, Math.floor(l))) : 0;
        };

        for (let newLayer = prevLayerCount; newLayer < nextLayerCount; newLayer++) {
          // 혹시 이전에 layerCount를 줄였다 늘린 케이스 등으로 이미 오브젝트가 있다면, 의도치 않은 덮어쓰기를 피하기 위해 스킵
          const hasAny = s.board.objects.some((o: any) => getLayer(o) === newLayer);
          if (hasAny) continue;

          const srcLayer = newLayer - 1;
          const srcObjects = s.board.objects.filter((o: any) => getLayer(o) === srcLayer);
          for (const obj of srcObjects) {
            if (obj.type === 'PILLAR' || obj.type === 'SPAWNER_BOX') continue;
            s.board.objects.push({ ...obj, uid: uid(), layer: newLayer } as any);
          }
        }

        // ✅ Supply 페이지도 동일하게 “새 레이어 = 이전 레이어 복사”
        if (s.supply?.pages?.length) {
          for (const page of s.supply.pages) {
            for (let newLayer = prevLayerCount; newLayer < nextLayerCount; newLayer++) {
              const hasAny = page.objects.some((o: any) => getLayer(o) === newLayer);
              if (hasAny) continue;
              const srcLayer = newLayer - 1;
              const srcObjs = page.objects.filter((o: any) => getLayer(o) === srcLayer);
              for (const obj of srcObjs) {
                if (obj.type === 'PILLAR' || obj.type === 'SPAWNER_BOX') continue;
                page.objects.push({ ...obj, uid: uid(), layer: newLayer } as any);
              }
            }
          }
        }
      }

      // ✅ 캐넌 슬롯/대기라인
      merged.slotCount = clampInt(merged.slotCount ?? 3, 3, 5);
      // ✅ waitLineCount는 3~5 범위에서 사용자가 조절 가능
      merged.waitLineCount = clampInt(merged.waitLineCount ?? 3, 3, 5);

      // ✅ 슈터 카운트(툴 설정값)
      merged.connectShooterCount = clampInt(merged.connectShooterCount ?? 0, 0, 99);
      merged.hiddenShooterCount = clampInt(merged.hiddenShooterCount ?? 0, 0, 99);
      merged.lockShooterCount = clampInt(merged.lockShooterCount ?? 0, 0, 999);
      // ✅ pickerCols / pickerMaxCards
      merged.pickerCols = clampInt(merged.pickerCols ?? 2, 1, 10);
      // pickerMaxCards는 (대기라인 x 피커 열수)로 자동 계산
      merged.pickerMaxCards = clampInt(merged.pickerCols * merged.waitLineCount, 1, 50);
      // ✅ blockCount는 사용자가 입력한 목표값을 그대로 사용합니다.
      // 역할: blockCount 변경 시 supply.perCol을 자동으로 재분배/보정하지 않습니다. (불일치는 검증에서 안내)

      // recalcSupply가 blockCount를 최종 반영합니다.
      s.meta = merged;
      stages[idx] = recalcSupply(s);

      const nextLayer = clampInt(currentLayer, 0, merged.layerCount - 1);
      set({ pack: { ...pack, stages }, currentLayer: nextLayer });
    },

    // ✅ 공급 페이지 추가
    // 역할: AutoFix가 아니라, 사용자가 '공급 추가'를 눌렀을 때만 supplyPages를 실체화(materialize)합니다.
    addSupplyPage: () => {
      const { pack, currentStageId } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const pages = s.supply?.pages ?? [];
      const nextIndex = Math.max(0, Math.min(pages.length, SUPPLY_PAGE_CAP - 1));
      materializeSupplyPage(s, nextIndex);

      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, editTarget: { kind: 'SUPPLY', index: nextIndex }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    

    // ✅ 공급 페이지 제거
    // 역할: 현재 선택된 공급 페이지(실체화된 페이지)만 제거하고, 이후 페이지는 앞으로 당깁니다.
    //       supplyPages가 비면 '공급 추가 전' 상태로 돌아가며(초기 1페이지 패턴 자동 반복), 편집 타겟은 INITIAL로 복귀합니다.
    removeSupplyPage: (pageIndex: number) => {
      const { pack, currentStageId, editTarget } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const pages = (s.supply?.pages ?? []).slice();
      if (pages.length <= 0) return;

      const pi = clampInt(pageIndex, 0, pages.length - 1);

      // 가상 상속 페이지는 제거 대상이 아님(저장된 실체화 페이지만 제거)
      if (pi >= pages.length) return;

      pushUndo();

      pages.splice(pi, 1);
      if (pages.length <= 0) {
        s.supply = { mode: 'PATTERN', pages: [] } as any;
        stages[idx] = recalcSupply(s);
        set({ pack: { ...pack, stages }, editTarget: { kind: 'INITIAL', index: 0 }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
        return;
      }

      s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
      stages[idx] = recalcSupply(s);

      // 편집 타겟 보정(지운 인덱스가 현재/이후면 앞으로 당김)
      const nextIndex = Math.max(0, Math.min(pages.length - 1, editTarget.kind === 'SUPPLY' ? Math.min(editTarget.index, pages.length - 1) : Math.min(pi, pages.length - 1)));
      set({ pack: { ...pack, stages }, editTarget: { kind: 'SUPPLY', index: nextIndex }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    fillLayerWithColor: (mode) => {
      const { pack, currentStageId, currentLayer, color, editTarget } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const getTargetObjects = (): BoardObject[] => {
        if (editTarget.kind === 'INITIAL') return s.board.objects;
        const i = materializeSupplyPage(s, editTarget.index);
        return (s.supply!.pages![i].objects as any) ?? [];
      };
      const setTargetObjects = (objects: BoardObject[]) => {
        if (editTarget.kind === 'INITIAL') {
          s.board.objects = objects as any;
          return;
        }
        const i = materializeSupplyPage(s, editTarget.index);
        const pages = (s.supply?.pages ?? []).slice();
        pages[i] = { ...pages[i], objects: objects as any };
        s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
      };

      let objects = getTargetObjects().slice();
      const { occ } = buildOcc(objects, 10, 10);

      const removeUids = new Set<string>();
      for (let y = 0; y < 10; y++) {
        for (let x = 0; x < 10; x++) {
          const hit = uidAt(occ, currentLayer, x, y);
          if (!hit) continue;
          const obj = objects.find((o) => o.uid === hit) as any;
          if (!obj) continue;
          if (obj.type === 'PILLAR' || obj.type === 'SPAWNER_BOX') continue;
          if (mode === 'OVERWRITE') removeUids.add(hit);
        }
      }

      if (removeUids.size > 0) objects = objects.filter((o) => !removeUids.has(o.uid));

      const { occ: occ2 } = buildOcc(objects, 10, 10);
      for (let y = 0; y < 10; y++) {
        for (let x = 0; x < 10; x++) {
          const hit = uidAt(occ2, currentLayer, x, y);
          if (mode === 'EMPTY_ONLY' && hit) continue;
          if (mode === 'OVERWRITE' && hit) {
            const obj = objects.find((o) => o.uid === hit) as any;
            if (obj?.type === 'PILLAR' || obj?.type === 'SPAWNER_BOX') continue;
            continue;
          }
          objects.push({ uid: uid(), type: 'BLOCK_NORMAL', x, y, color, layer: currentLayer } as any);
        }
      }

      setTargetObjects(objects as any);
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: null });
    },

    clearCurrentLayer: () => {
      const { pack, currentStageId, currentLayer, editTarget } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const getTargetObjects = (): BoardObject[] => {
        if (editTarget.kind === 'INITIAL') return (s.board.objects as any) ?? [];
        const i = materializeSupplyPage(s, editTarget.index);
        return ((s.supply!.pages![i].objects as any) ?? []) as any;
      };
      const setTargetObjects = (objects: BoardObject[]) => {
        if (editTarget.kind === 'INITIAL') {
          s.board.objects = objects as any;
          return;
        }
        const i = materializeSupplyPage(s, editTarget.index);
        const pages = (s.supply?.pages ?? []).slice();
        pages[i] = { ...pages[i], objects: objects as any };
        s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
      };

      const objects = getTargetObjects().filter((o: any) => clampInt((o as any).layer ?? 0, 0, 4) !== currentLayer);
      setTargetObjects(objects);
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    clearCurrentPage: () => {
      const { pack, currentStageId, editTarget } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      if (editTarget.kind === 'INITIAL') {
        s.board.objects = [] as any;
      } else {
        const i = materializeSupplyPage(s, editTarget.index);
        const pages = (s.supply?.pages ?? []).slice();
        pages[i] = { ...pages[i], objects: [] as any };
        s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
      }

      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    randomDecorateCurrentLayer: (cfg) => {
      const { pack, currentStageId, currentLayer, editTarget } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const getTargetObjects = (): BoardObject[] => {
        if (editTarget.kind === 'INITIAL') return (s.board.objects as any) ?? [];
        const i = materializeSupplyPage(s, editTarget.index);
        return ((s.supply!.pages![i].objects as any) ?? []) as any;
      };
      const setTargetObjects = (objs: BoardObject[]) => {
        if (editTarget.kind === 'INITIAL') {
          s.board.objects = objs as any;
          return;
        }
        const i = materializeSupplyPage(s, editTarget.index);
        const pages = (s.supply?.pages ?? []).slice();
        pages[i] = { ...pages[i], objects: objs as any };
        s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
      };

      const randColors = Array.isArray(cfg.colors) && cfg.colors.length > 0 ? cfg.colors : (['R'] as Color12[]);

      // 작은 PRNG(시드+시간으로 매번 다르게)
      let seed = ((s.meta.seed ?? 1000) ^ (Date.now() & 0xfffffff)) >>> 0;
      const rng = () => {
        seed = (seed + 0x6d2b79f5) >>> 0;
        let t = seed;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
      const rInt = (min: number, max: number) => Math.floor(rng() * (max - min)) + min;
      const pick = <T,>(arr: T[]) => arr[rInt(0, arr.length)];

      let objects = getTargetObjects().slice();

      if (cfg.clearExisting) {
        objects = objects.filter((o: any) => clampInt((o as any).layer ?? 0, 0, 4) !== currentLayer);
      }

      // occupancy helper
      const occKey = (x: number, y: number) => `${x},${y}`;
      const occ = new Set<string>();
      const markOcc = (o: any) => {
        if (clampInt(o.layer ?? 0, 0, 4) !== currentLayer) return;
        if (o.type === 'BLOCK_LARGE') {
          for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) occ.add(occKey(o.x + dx, o.y + dy));
        } else if (o.type === 'PILLAR' || o.type === 'SPAWNER_BOX' || o.type === 'BLOCK_NORMAL' || o.type === 'CHAIN_BARRIER' || o.type === 'KEY' || o.type === 'LOCK' || o.type === 'BLOCK_HIDDEN') {
          occ.add(occKey(o.x, o.y));
        }
      };
      for (const o of objects) markOcc(o as any);

      const isFree = (x: number, y: number) => x >= 0 && x < 10 && y >= 0 && y < 10 && !occ.has(occKey(x, y));
      const isFree2x2 = (x: number, y: number) => isFree(x, y) && isFree(x + 1, y) && isFree(x, y + 1) && isFree(x + 1, y + 1);
      const occupy2x2 = (x: number, y: number) => {
        occ.add(occKey(x, y));
        occ.add(occKey(x + 1, y));
        occ.add(occKey(x, y + 1));
        occ.add(occKey(x + 1, y + 1));
      };
      const occupy1 = (x: number, y: number) => occ.add(occKey(x, y));

      // 1) large blocks
      if (cfg.includeLarge && cfg.largeCount > 0) {
        let placed = 0;
        let guard = 1000;
        while (placed < cfg.largeCount && guard-- > 0) {
          const x = rInt(0, 9);
          const y = rInt(0, 9);
          if (!isFree2x2(x, y)) continue;
          const obj: any = { uid: uid(), type: 'BLOCK_LARGE', x, y, w: 2, h: 2, color: pick(randColors), hp: Math.max(1, Math.floor(cfg.largeHp || 80)), layer: currentLayer };
          objects.push(obj);
          occupy2x2(x, y);
          placed++;
        }
      }

      // 2) pillars (lines)
      if (cfg.includePillar && cfg.pillarLines > 0) {
        const drawLine = (sx: number, sy: number, ex: number, ey: number) => {
          const cells: Array<{ x: number; y: number }> = [];
          const pushLine = (ax: number, ay: number, bx: number, by: number) => {
            if (ax === bx) {
              const step = ay <= by ? 1 : -1;
              for (let cy = ay; cy !== by + step; cy += step) cells.push({ x: ax, y: cy });
            } else if (ay === by) {
              const step = ax <= bx ? 1 : -1;
              for (let cx = ax; cx !== bx + step; cx += step) cells.push({ x: cx, y: ay });
            } else {
              pushLine(ax, ay, bx, ay);
              pushLine(bx, ay, bx, by);
            }
          };
          pushLine(sx, sy, ex, ey);
          for (const c of cells) {
            if (!isFree(c.x, c.y)) continue;
            const obj: any = { uid: uid(), type: 'PILLAR', x: c.x, y: c.y, h: 1, layer: currentLayer };
            objects.push(obj);
            occupy1(c.x, c.y);
          }
        };

        for (let i = 0; i < cfg.pillarLines; i++) {
          const sx = rInt(0, 10);
          const sy = rInt(0, 10);
          const ex = rInt(0, 10);
          const ey = rInt(0, 10);
          drawLine(sx, sy, ex, ey);
        }
      }

      // 3) spawners
      if (cfg.includeSpawner && cfg.spawnerCount > 0) {
        let placed = 0;
        let guard = 500;
        while (placed < cfg.spawnerCount && guard-- > 0) {
          // ✅ 생성박스는 2x2 영역(하단-좌측 기준)
          const x = rInt(0, 9); // x=0~8
          const y = rInt(0, 9); // y=0~8 (y+1 필요)
          if (!isFree(x, y)) continue;
          if (!isFree(x + 1, y)) continue;
          if (!isFree(x, y + 1)) continue;
          if (!isFree(x + 1, y + 1)) continue;
          const obj: any = {
            uid: uid(),
            type: 'SPAWNER_BOX',
            x,
            y,
            w: 2,
            h: 2,
            // hp = 생성할 블럭 수(총 생성량)
            hp: 10,
            spawn: { poolColors: randColors.slice(0, 2) },
            layer: currentLayer,
          };
          objects.push(obj);
          occupy1(x, y);
          occupy1(x + 1, y);
          occupy1(x, y + 1);
          occupy1(x + 1, y + 1);
          placed++;
        }
      }

      // 4) keys
      const placeSingles = (type: 'KEY', count: number) => {
        let placed = 0;
        let guard = 2000;
        while (placed < count && guard-- > 0) {
          const x = rInt(0, 10);
          const y = rInt(0, 10);
          if (!isFree(x, y)) continue;
          const obj: any = { uid: uid(), type, x, y, layer: currentLayer };
          objects.push(obj);
          occupy1(x, y);
          placed++;
        }
      };
      if (cfg.includeKey && cfg.keyCount > 0) placeSingles('KEY', cfg.keyCount);

      // 5) normal blocks fill
      const fillP = Math.max(0, Math.min(100, Math.floor(cfg.fillPercent)));
      const normalsPlaced: any[] = [];
      if (cfg.includeNormal && fillP > 0) {
        for (let y = 0; y < 10; y++) {
          for (let x = 0; x < 10; x++) {
            if (!isFree(x, y)) continue;
            if (rInt(0, 100) >= fillP) continue;
            const obj: any = { uid: uid(), type: 'BLOCK_NORMAL', x, y, color: pick(randColors), layer: currentLayer };
            objects.push(obj);
            normalsPlaced.push(obj);
            occupy1(x, y);
          }
        }
      }

      // 6) chain barrier convert
      const chainP = Math.max(0, Math.min(100, Math.floor(cfg.chainPercent)));
      if (cfg.includeChain && chainP > 0 && normalsPlaced.length > 0) {
        const convertCount = Math.max(0, Math.floor((normalsPlaced.length * chainP) / 100));
        for (let i = 0; i < convertCount; i++) {
          const t = normalsPlaced[rInt(0, normalsPlaced.length)];
          if (!t || t.type !== 'BLOCK_NORMAL') continue;
          t.type = 'CHAIN_BARRIER';
        }
      }

      setTargetObjects(objects as any);
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    clickCell: (x, y, opts) => {
      const { pack, currentStageId, currentLayer, toolMode, brush, color, editTarget, pillarLineStart, chainLineStart, brushConfig } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      // --- 편집 대상(objects) 얻기/설정 ---
      const getTargetObjects = (): BoardObject[] => {
        if (editTarget.kind === 'INITIAL') return s.board.objects;
        // ✅ supply 편집은 “실체화된 페이지”만 대상으로 합니다.
        return resolveSupplyPageObjects(s, editTarget.index);
      };
      const setTargetObjects = (objs: BoardObject[]) => {
        if (editTarget.kind === 'INITIAL') {
          s.board.objects = objs;
        } else {
          const i = materializeSupplyPage(s, editTarget.index);
          const pages = (s.supply?.pages ?? []).slice();
          pages[i] = { ...pages[i], objects: objs as any };
          s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
        }
      };

      let objects = getTargetObjects();

      const { occ } = buildOcc(objects, 10, 10);
      const hitUid = uidAt(occ, currentLayer, x, y);

      if (toolMode === 'SELECT') {
        set({ selectedUid: hitUid });
        return;
      }

      const forceErase = !!opts?.forceErase;

      if (toolMode === 'ERASE' || forceErase) {
        if (!hitUid) return;
        objects = objects.filter((o) => o.uid !== hitUid);
        setTargetObjects(objects);
        stages[idx] = recalcSupply(s);
        set({ pack: { ...pack, stages }, selectedUid: null });
        return;
      }

      // --- PAINT ---
      // ✅ PILLAR는 1번째 클릭 시작점, 2번째 클릭 끝점으로 선을 만듭니다.
      if (brush === 'PILLAR') {
        if (!pillarLineStart) {
          set({ pillarLineStart: { x, y }, selectedUid: null });
          return;
        }

        const sx = pillarLineStart.x;
        const sy = pillarLineStart.y;
        const ex = x;
        const ey = y;

        const cells: Array<{ x: number; y: number }> = [];
        const pushLine = (ax: number, ay: number, bx: number, by: number) => {
          if (ax === bx) {
            const step = ay <= by ? 1 : -1;
            for (let cy = ay; cy !== by + step; cy += step) cells.push({ x: ax, y: cy });
          } else if (ay === by) {
            const step = ax <= bx ? 1 : -1;
            for (let cx = ax; cx !== bx + step; cx += step) cells.push({ x: cx, y: ay });
          } else {
            // 직선이 아니면 L자로: 가로→세로
            pushLine(ax, ay, bx, ay);
            pushLine(bx, ay, bx, by);
          }
        };
        pushLine(sx, sy, ex, ey);

        const { occ: occ2 } = buildOcc(objects, 10, 10);
        const removeUids = new Set<string>();
        for (const c of cells) {
          const u = uidAt(occ2, currentLayer, c.x, c.y);
          if (u) removeUids.add(u);
        }
        if (removeUids.size > 0) objects = objects.filter((o) => !removeUids.has(o.uid));

        let lastUid: string | null = null;
        for (const c of cells) {
          if (c.x < 0 || c.x >= 10 || c.y < 0 || c.y >= 10) continue;
          const p: BoardObject = { uid: uid(), type: 'PILLAR', x: c.x, y: c.y, h: 1, layer: currentLayer };
          objects.push(p);
          lastUid = p.uid;
        }

        setTargetObjects(objects);
        stages[idx] = recalcSupply(s);
        set({ pack: { ...pack, stages }, selectedUid: lastUid, pillarLineStart: null, chainLineStart: null });
        return;
      }

      // ✅ CHAIN_BARRIER는 1번째 클릭 시작점, 2번째 클릭 끝점으로 가로 체인을 만듭니다.
      // - 길이: 2~10칸
      // - 머리/꼬리: chainOrder(0..len-1)로 표현
      // - 인접해도 다른 체인과 자동 연결되지 않도록 chainId를 항상 부여
      if (brush === 'CHAIN_BARRIER') {
        if (!chainLineStart) {
          set({ chainLineStart: { x, y }, selectedUid: null, pillarLineStart: null });
          return;
        }

        const sx = (chainLineStart.x | 0);
        const sy = (chainLineStart.y | 0);
        const ex = (x | 0);

        let x0 = Math.min(sx, ex);
        let x1 = Math.max(sx, ex);
        let len = (x1 - x0 + 1) | 0;
        len = Math.max(2, Math.min(10, len));

        // 보드 밖으로 나가면 통째로 시프트해서 들어오게 합니다.
        x0 = Math.max(0, Math.min(9 - len + 1, x0));
        x1 = x0 + len - 1;

        const cells: Array<{ x: number; y: number }> = [];
        for (let cx = x0; cx <= x1; cx++) cells.push({ x: cx, y: sy });

        // 덮어쓰기: 대상 셀에 이미 존재하는 오브젝트 제거(현재 레이어)
        const { occ: occ2 } = buildOcc(objects, 10, 10);
        const removeUids = new Set<string>();
        for (const c of cells) {
          const u = uidAt(occ2, currentLayer, c.x, c.y);
          if (u) removeUids.add(u);
        }
        if (removeUids.size > 0) objects = objects.filter((o) => !removeUids.has(o.uid));

        const gid = uid('chain');
        let lastUid: string | null = null;
        const headSide = ((brushConfig as any)?.chainHeadSide ?? 'LEFT') as 'LEFT' | 'RIGHT';
        for (let i = 0; i < cells.length; i++) {
          const c = cells[i];
          if (c.x < 0 || c.x >= 10 || c.y < 0 || c.y >= 10) continue;
          const chainOrder = headSide === 'RIGHT' ? (cells.length - 1 - i) : i;
          const p: any = { uid: uid(), type: 'CHAIN_BARRIER', x: c.x, y: c.y, color, chainId: gid, chainOrder, layer: currentLayer };
          objects.push(p);
          lastUid = p.uid;
        }

        setTargetObjects(objects);
        stages[idx] = recalcSupply(s);
        set({ pack: { ...pack, stages }, selectedUid: lastUid, pillarLineStart: null, chainLineStart: null });
        return;
      }

      // 생성할 오브젝트(1개 또는 여러 개)
      const newObjs: BoardObject[] = (() => {
        switch (brush) {
          case 'BLOCK_NORMAL':
            return [{ uid: uid(), type: 'BLOCK_NORMAL', x, y, color, layer: currentLayer }];
          case 'BLOCK_LARGE':
            return [{ uid: uid(), type: 'BLOCK_LARGE', x, y, w: 2, h: 2, color, hp: Math.floor((brushConfig as any)?.largeHp ?? 80), layer: currentLayer }];
          case 'BLOCK_LARGE_HIDDEN':
            // 히든 라지 블록(2x2): 선택된 color를 저장해 런타임에서 색상 매칭/카드 생성에 사용합니다.
            return [
              {
                uid: uid(),
                type: 'BLOCK_LARGE_HIDDEN',
                x,
                y,
                w: 2,
                h: 2,
                color,
                hp: Math.floor((brushConfig as any)?.largeHiddenHp ?? 80),
                revealRule: 'REACH_BOTTOM',
                layer: currentLayer,
              },
            ];
          case 'BLOCK_HIDDEN':
            // 히든 스몰 블록(1x1): 선택된 color를 저장해 공개 시 색상으로 변환되도록 합니다.
            return [{ uid: uid(), type: 'BLOCK_HIDDEN', x, y, color, revealRule: 'REACH_BOTTOM', layer: currentLayer }];
          case 'CHAIN_BARRIER': {
            // ✅ 체인 블럭은 '2-click 라인 배치'로만 생성합니다.
            // (여기까지 내려왔다면 1칸 배치 요청이므로, 안전하게 단일 셀 체인으로 처리)
            const gid = uid('chain');
            return [{ uid: uid(), type: 'CHAIN_BARRIER', x, y, color, chainId: gid, chainOrder: 0, layer: currentLayer } as any];
          }
          case 'KEY':
            return [{ uid: uid(), type: 'KEY', x, y, keyId: 'A', layer: currentLayer }];
          case 'LOCK':
            return [{ uid: uid(), type: 'LOCK', x, y, lockId: 'A', layer: currentLayer }];
          case 'SPAWNER_BOX': {
            const hp = Math.floor((brushConfig as any)?.spawnerHp ?? 10);
            const left = ((brushConfig as any)?.spawnerLeft ?? color) as any;
            const right = ((brushConfig as any)?.spawnerRight ?? left) as any;
            return [
              {
                uid: uid(),
                type: 'SPAWNER_BOX',
                x,
                y,
                w: 2,
                h: 2,
                // hp = 생성할 블럭 수(총 생성량)
                hp,
                // ✅ v48+: poolColors[0]=왼쪽, poolColors[1]=오른쪽
                spawn: { poolColors: [left, right] },
                layer: currentLayer,
              } as any,
            ];
          }
          default:
            return [{ uid: uid(), type: 'BLOCK_NORMAL', x, y, color, layer: currentLayer }];
        }
      })();

      // 겹치는 uid 제거(덮어쓰기)
      const { occ: occ2 } = buildOcc(objects, 10, 10);
      const cells: Array<{ x: number; y: number }> = [];
      for (const o of newObjs) for (const c of cellsOf(o)) cells.push(c);

      const removeUids = new Set<string>();
      for (const c of cells) {
        const u = uidAt(occ2, currentLayer, c.x, c.y);
        if (u) removeUids.add(u);
      }
      if (removeUids.size > 0) objects = objects.filter((o) => !removeUids.has(o.uid));
      objects.push(...newObjs);

      setTargetObjects(objects);
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: newObjs[0]?.uid ?? null });
    },


    // ✅ 다중 셀 적용(Shift 드래그 사각형 등)
    // 역할: 여러 셀에 대한 paint/erase를 Undo 1회로 묶어 빠르게 적용합니다.
    applyCells: (cells, opts) => {
      const { pack, currentStageId, currentLayer, toolMode, brush, color, editTarget, brushConfig } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;
      if (!cells || cells.length === 0) return;

      // PILLAR는 2클릭/라인 모델이라 다중 적용은 지원하지 않습니다.
      if (brush === 'PILLAR') return;

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const getTargetObjects = (): BoardObject[] => {
        if (editTarget.kind === 'INITIAL') return s.board.objects;
        return resolveSupplyPageObjects(s, editTarget.index);
      };
      const setTargetObjects = (objs: BoardObject[]) => {
        if (editTarget.kind === 'INITIAL') {
          s.board.objects = objs;
        } else {
          const i = materializeSupplyPage(s, editTarget.index);
          const pages = (s.supply?.pages ?? []).slice();
          pages[i] = { ...pages[i], objects: objs as any };
          s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
        }
      };

      let objects = getTargetObjects();

      const mode = (opts?.mode ?? toolMode) as 'PAINT' | 'ERASE';
      const forceErase = !!opts?.forceErase;
      let lastUid: string | null = null;

      // 중복 좌표 제거(드래그 중 동일 셀 반복 방지)
      const seen = new Set<string>();
      for (const c of cells) {
        const x = Math.floor(c.x);
        const y = Math.floor(c.y);
        if (x < 0 || x >= 10 || y < 0 || y >= 10) continue;
        const key = x + ',' + y;
        if (seen.has(key)) continue;
        seen.add(key);

        const { occ } = buildOcc(objects, 10, 10);
        const hitUid = uidAt(occ, currentLayer, x, y);

        if (mode === 'ERASE' || forceErase) {
          if (!hitUid) continue;
          objects = objects.filter((o) => o.uid !== hitUid);
          continue;
        }

        // --- PAINT (덮어쓰기) ---
        const newObjs: BoardObject[] = (() => {
          switch (brush) {
            case 'BLOCK_NORMAL':
              return [{ uid: uid(), type: 'BLOCK_NORMAL', x, y, color, layer: currentLayer }];
            case 'BLOCK_LARGE':
              return [{ uid: uid(), type: 'BLOCK_LARGE', x, y, w: 2, h: 2, color, hp: Math.floor((brushConfig as any)?.largeHp ?? 80), layer: currentLayer }];
            case 'BLOCK_LARGE_HIDDEN':
              return [
                {
                  uid: uid(),
                  type: 'BLOCK_LARGE_HIDDEN',
                  x,
                  y,
                  w: 2,
                  h: 2,
                  color,
                  hp: Math.floor((brushConfig as any)?.largeHiddenHp ?? 80),
                  revealRule: 'REACH_BOTTOM',
                  layer: currentLayer,
                } as any,
              ];
            case 'BLOCK_HIDDEN':
              return [{ uid: uid(), type: 'BLOCK_HIDDEN', x, y, color, revealRule: 'REACH_BOTTOM', layer: currentLayer }];
            case 'CHAIN_BARRIER': {
              // ✅ applyCells(사각형/드래그)에서는 체인을 1셀 단위로만 찍습니다.
              // (1xN 라인 체인은 clickCell의 2-click 로직으로 생성)
              const gid = uid('chain');
              return [{ uid: uid(), type: 'CHAIN_BARRIER', x, y, color, chainId: gid, chainOrder: 0, layer: currentLayer } as any];
            }
            case 'KEY':
              return [{ uid: uid(), type: 'KEY', x, y, keyId: 'A', layer: currentLayer }];
            case 'LOCK':
              return [{ uid: uid(), type: 'LOCK', x, y, lockId: 'A', layer: currentLayer }];
            case 'SPAWNER_BOX': {
              const hp = Math.floor((brushConfig as any)?.spawnerHp ?? 10);
              const left = ((brushConfig as any)?.spawnerLeft ?? color) as any;
              const right = ((brushConfig as any)?.spawnerRight ?? left) as any;
              return [
                {
                  uid: uid(),
                  type: 'SPAWNER_BOX',
                  x,
                  y,
                  // ✅ 생성박스 기본 2x2(영역) + hp(생성할 블럭 수)
                  w: 2,
                  h: 2,
                  hp,
                  spawn: { poolColors: [left, right] },
                  layer: currentLayer,
                } as any,
              ];
            }
            default:
              return [{ uid: uid(), type: 'BLOCK_NORMAL', x, y, color, layer: currentLayer }];
          }
        })();

        const { occ: occ2 } = buildOcc(objects, 10, 10);
        const coverCells: Array<{ x: number; y: number }> = [];
        for (const o of newObjs) for (const cc of cellsOf(o)) coverCells.push(cc);

        const removeUids = new Set<string>();
        for (const cc of coverCells) {
          const u = uidAt(occ2, currentLayer, cc.x, cc.y);
          if (u) removeUids.add(u);
        }
        if (removeUids.size > 0) objects = objects.filter((o) => !removeUids.has(o.uid));
        objects.push(...newObjs);
        lastUid = newObjs[0]?.uid ?? null;
      }

      setTargetObjects(objects);
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: lastUid, pillarLineStart: null, chainLineStart: null });
    },

    // ✅ 선택영역 붙여넣기
    // 역할: 상대좌표(relObjects)를 현재 편집 대상(초기/공급)에 오프셋(anchor) 적용 후 삽입합니다.
    // - 덮어쓰기: 새 오브젝트가 차지하는 셀에 존재하는 같은 레이어 오브젝트는 제거
    // - OOB는 스킵
    pasteObjects: (anchor, relObjects) => {
      const { pack, currentStageId, currentLayer, editTarget } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;
      if (!relObjects || relObjects.length === 0) return;

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const getTargetObjects = (): BoardObject[] => {
        if (editTarget.kind === 'INITIAL') return s.board.objects;
        return resolveSupplyPageObjects(s, editTarget.index);
      };
      const setTargetObjects = (objs: BoardObject[]) => {
        if (editTarget.kind === 'INITIAL') {
          s.board.objects = objs;
        } else {
          const i = materializeSupplyPage(s, editTarget.index);
          const pages = (s.supply?.pages ?? []).slice();
          pages[i] = { ...pages[i], objects: objs as any };
          s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;
        }
      };

      let objects = getTargetObjects();

      // 1) 붙여넣을 오브젝트 생성(새 uid + anchor 오프셋)
      const ax = Math.floor(anchor?.x ?? 0);
      const ay = Math.floor(anchor?.y ?? 0);
      const pasted: BoardObject[] = [];

      // ✅ CHAIN_BARRIER: 붙여넣기 시 체인 그룹이 "원본"과 연결되지 않도록 chainId를 재발급합니다.
      // - 같은 relObjects 안에서 동일 chainId는 동일한 새 id로 매핑(=묶음 유지)
      // - 서로 다른 chainId는 서로 다른 새 id(=서로 분리)
      const chainIdRemap = new Map<string, string>();
      for (const o of relObjects) {
        const no: any = { ...(o as any) };
        no.uid = uid();
        no.x = Math.floor((o as any).x ?? 0) + ax;
        no.y = Math.floor((o as any).y ?? 0) + ay;
        // 안전: 현재 레이어에 붙여넣기(복사 대상이 항상 현재 레이어였지만 방어)
        no.layer = currentLayer;

        if (String(no?.type ?? '') === 'CHAIN_BARRIER') {
          const oldId = String(no.chainId ?? no.chainGroupId ?? '').trim();
          if (oldId) {
            if (!chainIdRemap.has(oldId)) chainIdRemap.set(oldId, uid('chain'));
            no.chainId = chainIdRemap.get(oldId);
          }
        }
        pasted.push(no as BoardObject);
      }

      // 2) OOB 제거
      const inBoundsObj = (obj: BoardObject) => {
        for (const c of cellsOf(obj)) {
          if (c.x < 0 || c.x >= 10 || c.y < 0 || c.y >= 10) return false;
        }
        return true;
      };
      const pastedIn = pasted.filter(inBoundsObj);
      if (pastedIn.length === 0) return;

      // 3) 덮어쓰기: 차지하는 셀의 기존 uid 제거
      const { occ } = buildOcc(objects, 10, 10);
      const removeUids = new Set<string>();
      for (const po of pastedIn) {
        for (const c of cellsOf(po)) {
          const u = uidAt(occ, currentLayer, c.x, c.y);
          if (u) removeUids.add(u);
        }
      }
      if (removeUids.size > 0) objects = objects.filter((o) => !removeUids.has(o.uid));

      // 4) 삽입
      objects = objects.concat(pastedIn);

      setTargetObjects(objects);
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages }, selectedUid: null, pillarLineStart: null, chainLineStart: null });
    },

    setSelectedUid: (uid) => set({ selectedUid: uid }),

    updateSelectedObject: (patch) => {
      const { pack, currentStageId, selectedUid } = get();
      if (!selectedUid) return;
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      // 초기 보드 + 공급 페이지 전체에서 uid를 찾아 업데이트
      const updateInList = (list: BoardObject[]) => {
        const i = list.findIndex((o) => o.uid === selectedUid);
        if (i < 0) return false;
        const cur = list[i] as any;
        const next = { ...cur, ...patch } as BoardObject;
        list[i] = next;
        return true;
      };

      let done = updateInList(s.board.objects);
      if (!done && s.supply?.pages) {
        for (const p of s.supply.pages) {
          if (updateInList(p.objects as any)) {
            done = true;
            break;
          }
        }
      }
      if (!done) return;

      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages } });
    },

    bulkUpdateObjects: (uids, patch) => {
      const { pack, currentStageId } = get();
      const list = (uids ?? []).filter(Boolean);
      if (list.length === 0) return;

      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;

      const uidSet = new Set<string>(list);

      // patch 적용 규칙(안전): 타입에 따라 허용되는 필드만 반영
      const applyPatch = (o: BoardObject): BoardObject => {
        const cur: any = o as any;
        const next: any = { ...cur };

        // color
        if ((patch as any).color != null) {
          if (
            cur.type === 'BLOCK_NORMAL' ||
            cur.type === 'BLOCK_HIDDEN' ||
            cur.type === 'CHAIN_BARRIER' ||
            cur.type === 'BLOCK_LARGE' ||
            cur.type === 'BLOCK_LARGE_HIDDEN'
          ) {
            next.color = (patch as any).color;
          }
        }

        // hp
        if ((patch as any).hp != null) {
          if (cur.type === 'BLOCK_LARGE' || cur.type === 'BLOCK_LARGE_HIDDEN') {
            next.hp = (patch as any).hp;
          }
        }

        // 나머지 키는 그대로 합치되, x/y는 일괄 수정 대상에서 제외(요청사항)
        for (const [k, v] of Object.entries(patch as any)) {
          if (k === 'color' || k === 'hp' || k === 'x' || k === 'y') continue;
          (next as any)[k] = v;
        }
        return next as BoardObject;
      };

      const updateInList = (objs: BoardObject[]) => {
        let changed = false;
        for (let i = 0; i < objs.length; i++) {
          const o = objs[i] as any;
          if (!o?.uid || !uidSet.has(o.uid)) continue;
          const next = applyPatch(o as BoardObject);
          objs[i] = next;
          changed = true;
        }
        return changed;
      };

      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      let changed = updateInList(s.board.objects as any);
      if (s.supply?.pages) {
        for (const p of s.supply.pages as any[]) {
          if (p?.objects) {
            if (updateInList(p.objects as any)) changed = true;
          }
        }
      }

      if (!changed) return;
      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages } });
    },

    autoFix: () => {
      const { pack, currentStageId, currentLayer, color } = get();
      const idx = stageIndex(pack, currentStageId);
      if (idx < 0) return;


      pushUndo();

      const stages = pack.stages.slice();
      const s = deepCopyStage(stages[idx]);

      const meta: any = { ...s.meta };
      const initial = calcInitialBlocks(s.board.objects ?? [], 10, 10);
      // ✅ supply 목표는 meta.blockCount가 아니라 supply.perCol 합계로 정의합니다.
      // 역할: 초기 보드를 지웠을 때 supply가 "자동으로 폭증"하지 않도록 합니다.
      const initialNow = calcInitialBlocks(s.board.objects ?? [], 10, 10);
      const bcNow = Math.max(0, Math.floor((s.meta as any)?.blockCount ?? 0));
      const supplyBudget = Math.max(0, bcNow - initialNow);

      let pages = s.supply?.pages ? s.supply.pages.map((p: any) => ({ ...p, objects: (p.objects ?? []).slice() })) : [];
      if (supplyBudget <= 0) {
        pages = [];
        s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages: [] } as any;
        stages[idx] = recalcSupply({ ...s, meta });
        set({ pack: { ...pack, stages } });
        return;
      }
      // supplyPages가 없다면 AutoFix는 supply를 '생성'하지 않습니다(공급 추가 버튼으로만 실체화).
      if (pages.length === 0) {
        stages[idx] = recalcSupply({ ...s, meta });
        set({ pack: { ...pack, stages } });
        return;
      }

      // ✅ 역할: 공급 페이지가 비어있을 수 있으므로, 비어있는 페이지는 "직전 패턴 상속"으로 계산합니다.
      const rawBlocks = pages.map((p) => calcInitialBlocks((p.objects ?? []) as any, 10, 10));
      let last = Math.max(0, Math.floor(initial));
      const pageBlocks = rawBlocks.map((v) => {
        const b = Math.max(0, Math.floor(v ?? 0));
        if (b > 0) {
          last = b;
          return b;
        }
        return last;
      });

      // 현재 페이지들 기준으로 “실제로 사용할 장 수” 계산
      let active = 0;
      let sum = 0;
      for (let i = 0; i < pages.length; i++) {
        sum += pageBlocks[i] ?? 0;
        active = i + 1;
        if (sum >= supplyBudget) break;
      }
      if (active <= 0) active = 1;

      // helper: active pages에서 큰/작은 블록 레퍼런스 수집
      type Ref = { page: number; index: number; obj: any };
      const collectRefs = (pageCount: number) => {
        const large: Ref[] = [];
        const other: Ref[] = [];
        for (let pi = 0; pi < pageCount; pi++) {
          const objs = (pages[pi]?.objects ?? []) as any[];
          for (let oi = 0; oi < objs.length; oi++) {
            const o = objs[oi];
            if (!o) continue;
            if (o.type === 'PILLAR' || o.type === 'SPAWNER_BOX') continue;
            if (o.type === 'BLOCK_LARGE') large.push({ page: pi, index: oi, obj: o });
            else other.push({ page: pi, index: oi, obj: o });
          }
        }
        return { large, other };
      };

      const computeTotals = (pageCount: number) => {
        const { large, other } = collectRefs(pageCount);
        const otherSum = other.length; // countsAsBlock이며 large가 아닌 것들은 1개=1
        const largeHpSum = large.reduce((a, r) => a + Math.max(1, Math.floor(r.obj.hp ?? 80)), 0);
        const total = otherSum + largeHpSum;
        return { total, otherSum, largeHpSum, largeCount: large.length, large, other };
      };

      // ✅ 부족해도 AutoFix가 새 페이지를 자동 생성하지 않습니다.
      // 역할: AutoFix 후 '공급 제거'를 눌렀을 때 페이지가 폭증하는 UX 문제를 방지합니다.
      let t = computeTotals(active);
      if (t.total !== supplyBudget) {
        if (t.largeCount > 0) {
          // ✅ Large HP가 있으면: 레이아웃을 유지한 채 HP만 스케일해서 정확히 맞춤
          // 1) otherSum이 예산을 초과하면 other부터 제거
          while (t.otherSum > supplyBudget && t.other.length > 0) {
            const r = t.other.pop()!;
            (pages[r.page].objects as any[]).splice(r.index, 1);
            // 인덱스가 바뀌므로 전체를 다시 계산
            t = computeTotals(active);
          }

          // 2) targetLargeTotal 계산
          let targetLarge = supplyBudget - t.otherSum;
          // large가 최소 1씩 기여해야 하므로 부족하면 large를 제거
          while (t.largeCount > 0 && targetLarge < t.largeCount) {
            // 마지막 large 제거
            const r = t.large[t.large.length - 1];
            (pages[r.page].objects as any[]).splice(r.index, 1);
            t = computeTotals(active);
            targetLarge = supplyBudget - t.otherSum;
          }

          // 3) 남은 large들의 hp를 targetLarge로 맞춤
          if (t.largeCount > 0) {
            const curHp = t.large.reduce((a, r) => a + Math.max(1, Math.floor(r.obj.hp ?? 80)), 0);
            const desired = Math.max(t.largeCount, targetLarge);
            const factor = curHp > 0 ? desired / curHp : 1;
            const newHps = t.large.map((r) => Math.max(1, Math.round(Math.max(1, Math.floor(r.obj.hp ?? 80)) * factor)));
            let hpSum = newHps.reduce((a, b) => a + b, 0);

            // 반올림 오차 보정
            let safety = 100000;
            let cursor = 0;
            while (hpSum < desired && safety-- > 0) {
              newHps[cursor % newHps.length]++;
              hpSum++;
              cursor++;
            }
            safety = 100000;
            cursor = 0;
            while (hpSum > desired && safety-- > 0) {
              const i = cursor % newHps.length;
              if (newHps[i] > 1) {
                newHps[i]--;
                hpSum--;
              }
              cursor++;
            }

            // 적용
            for (let i = 0; i < t.large.length; i++) {
              const r = t.large[i];
              const obj = { ...r.obj, hp: newHps[i] };
              (pages[r.page].objects as any[])[r.index] = obj;
            }
          } else {
            // large가 없어졌으면 other로만 맞춤(제거/추가)
            // fallthrough below
          }
        }

        // ✅ large가 없거나, 위 로직 후에도 불일치면: 셀 기반으로 추가/제거
        // (초과: 제거 / 부족: 빈칸에 Normal 블록 추가)
        // ✅ 역할: active 범위에서 "현재 공급량"(셀 기반)을 계산합니다.
        // - pageBlocks는 위에서 이미 "빈 페이지 상속" 규칙이 반영된 블록 수 배열입니다.
        let cur = 0;
        for (let i = 0; i < active; i++) cur += pageBlocks[i] ?? 0;
        if (cur > supplyBudget) {
          let over = cur - supplyBudget;
          // 뒤에서부터 제거
          for (let pi = active - 1; pi >= 0 && over > 0; pi--) {
            const objs = pages[pi].objects as any[];
            for (let oi = objs.length - 1; oi >= 0 && over > 0; oi--) {
              const o = objs[oi];
              if (!o || o.type === 'PILLAR' || o.type === 'SPAWNER_BOX') continue;
              if (o.type === 'BLOCK_LARGE') {
                const hp = Math.max(1, Math.floor(o.hp ?? 80));
                if (hp > over) {
                  objs[oi] = { ...o, hp: hp - over };
                  over = 0;
                } else {
                  objs.splice(oi, 1);
                  over -= hp;
                }
              } else {
                objs.splice(oi, 1);
                over -= 1;
              }
            }
          }
        } else if (cur < supplyBudget) {
          let need = supplyBudget - cur;
          // 빈칸에 normal 추가(공간이 부족하면 더 이상 추가하지 않음)
          let pi = 0;
          let pageGuard = 0;
          while (need > 0 && pageGuard++ < 200) {
            if (pi >= active) break;
            const objs = pages[pi].objects as any[];
            const { occ } = buildOcc(objs as any, 10, 10);
            let placed = false;
            for (let y = 0; y < 10 && need > 0; y++) {
              for (let x = 0; x < 10 && need > 0; x++) {
                if (uidAt(occ, currentLayer, x, y)) continue;
                const n = { uid: uid(), type: 'BLOCK_NORMAL', x, y, layer: currentLayer, color } as any;
                objs.push(n);
                occ.set(`${currentLayer}:${x},${y}`, n.uid);
                need -= 1;
                placed = true;
              }
            }
            if (!placed) pi++;
          }
        }
      }

      s.meta = meta;
      s.supply = { ...(s.supply ?? { mode: 'PATTERN' }), mode: 'PATTERN', pages } as any;

      stages[idx] = recalcSupply(s);
      set({ pack: { ...pack, stages } });
    },

    undo: () => {
      if (_undo.length <= 0) return;
      try {
        const cur = get().getPackJson();
        const prev = _undo.pop()!;
        _redo.push(cur);
        if (_redo.length > HISTORY_CAP) _redo.shift();
        applySnapshot(prev);
        set({ undoDepth: _undo.length, redoDepth: _redo.length });
      } catch {}
    },

    redo: () => {
      if (_redo.length <= 0) return;
      try {
        const cur = get().getPackJson();
        const next = _redo.pop()!;
        _undo.push(cur);
        if (_undo.length > HISTORY_CAP) _undo.shift();
        applySnapshot(next);
        set({ undoDepth: _undo.length, redoDepth: _redo.length });
      } catch {}
    },

    // getPackJson은 "가벼운" 직렬화(편집/자동저장/히스토리용)만 수행합니다.
    // 클리어 보장 검증/재시도는 Export 경로에서만 수행해야 UI가 멈추지 않습니다.
    getPackJson: () => packToJson(get().pack),

    markSaved: (t) => set({ lastSavedAt: t }),
  };
});

// 작은 helper: 외부에서 저장할 때 씀
export function exportPackJson(): string {
  return packToJson(useStageTool.getState().pack);
}

// ✅ 외부 저장(클리어 보장 분배 포함)
export function exportPackJsonClearGuaranteed(): string {
  return packToJson(useStageTool.getState().pack, { exportClearGuaranteedCards: true });
}

// ✅ Export(클리어 보장 + 재시도 + 진행률)
// - 무거운 검증은 Export 버튼에서만 실행해야 UI가 멈추지 않습니다.
export async function exportPackJsonClearGuaranteedAsync(
  onProgress?: (p: any) => void
): Promise<string> {
  return await packToJsonClearGuaranteedAsync(useStageTool.getState().pack, onProgress as any);
}
