// 역할: UnitLineRack 대기라인(W1~W3) 시프트/오버플로 유지 로직 분리
// - UnitLineRack.ts 비대화를 줄이고, 대기라인 규칙을 한 곳에서 유지합니다.

import { tween, Tween } from 'cc';
import type { TweenEasing } from 'cc';

// W2→W1 이동(당김) 중 탭된 유닛을 '도착 후' 안전하게 장착합니다.
export function consumeQueuedEquipInColumn(r: any, col: number) {
    const i = col | 0;
    if (i < 0 || i >= 5) return;

    const s = r._slotW1[i];
    if (!s || !s.node?.isValid) return;
    if (s.moving) return;

    if (!s.equipQueued) return;
    s.equipQueued = false; // 1회 소비

    // 빈 슈팅 슬롯이 있을 때만 시도
    if (r._findFirstEmptyShooting() < 0) return;

    // W1 → S 장착 실행(기존 규칙 그대로)
    r._equipFromWaiting('W1', i);
}

// 특정 컬럼에서 W1/W2/W3 빈칸을 당겨 메우고, W3가 비면 오버플로에서 1개를 보충합니다.
export function shiftColumn(r: any, index: number) {
    const i = index | 0;
    if (i < 0 || i >= 5) return;

    const w1On = !!r.waitingLine01?.active;
    const w2On = !!r.waitingLine02?.active;
    const w3On = !!r.waitingLine03?.active;

    if (!w1On) return;

    const tryRefill = () => {
        if (w3On && !r._slotW3[i]) refillFromOverflow(r, i);
        // 컬럼 이동/보충이 끝나는 타이밍에 '도착 후 장착' 예약을 처리
        consumeQueuedEquipInColumn(r, i);
    };

    // (1) W1이 비었으면 W2 또는 W3를 W1으로 당김
    if (!r._slotW1[i]) {
        const s2 = w2On ? r._slotW2[i] : null;
        const s3 = w3On ? r._slotW3[i] : null;

        if (s2) {
            r._moveSlotNode(s2, 'W1', i, r.shiftMoveSec, 0, () => {
                // W2가 비었으면 W3 -> W2
                if (w3On && !r._slotW2[i]) {
                    const s3b = r._slotW3[i];
                    if (s3b) {
                        r._moveSlotNode(s3b, 'W2', i, r.shiftMoveSec, 0, () => tryRefill());
                        return;
                    }
                }
                tryRefill();
            });
            return;
        }

        if (s3) {
            r._moveSlotNode(s3, 'W1', i, r.shiftMoveSec, 0, () => tryRefill());
            return;
        }

        tryRefill();
        return;
    }

    // (2) W1은 차있고 W2가 비었으면 W3를 W2로 당김
    if (w2On && w3On && !r._slotW2[i] && r._slotW3[i]) {
        r._moveSlotNode(r._slotW3[i]!, 'W2', i, r.shiftMoveSec, 0, () => tryRefill());
        return;
    }

    // (3) 이동이 없어도 W3가 비었으면 보충
    tryRefill();
}

// overflow 유지(2단계 lock): 아이템/외부 로직으로 구멍이 생겨도 자동으로 복구
export function maintainWaitingOverflow(r: any) {
    const w1On = !!r.waitingLine01?.active;
    if (!w1On) return;

    const w2On = !!r.waitingLine02?.active;
    const w3On = !!r.waitingLine03?.active;

    for (let i = 0; i < 5; i++) {
        const p = r._placesW1[i];
        if (!p || !p.isValid || !p.activeInHierarchy) continue;

        // 컬럼 이동 중이면 스킵(연출 충돌 방지)
        const s1 = r._slotW1[i];
        const s2 = w2On ? r._slotW2[i] : null;
        const s3 = w3On ? r._slotW3[i] : null;
        if ((s1 && s1.moving) || (s2 && s2.moving) || (s3 && s3.moving)) continue;

        const hasOverflow = (r._overflowByCol[i]?.length ?? 0) > (r._overflowHeadByCol[i] | 0);
        const needsShift = !s1 && (s2 || s3 || hasOverflow);
        const needsShift2 = !!s1 && w2On && !s2 && !!s3; // W2 hole

        if (needsShift || needsShift2) {
            shiftColumn(r, i);
            continue;
        }

        // (2) W3만 비었고 overflow가 있으면 보충
        if (w3On && !s3 && hasOverflow) {
            refillFromOverflow(r, i);
        }
    }
}

// 가상 WaitingLine04+(오버플로)에서 1개를 꺼내 WaitingLine03으로 보충 + 이동 연출
export function refillFromOverflow(r: any, col: number) {
    const c = col | 0;
    if (c < 0 || c >= 5) return;
    if (!r.waitingLine03?.active) return;
    if (r._slotW3[c]) return;

    const q = r._overflowByCol[c];
    if (!q || q.length <= 0) return;

    const head = r._overflowHeadByCol[c] | 0;
    if (head >= q.length) {
        q.length = 0;
        r._overflowHeadByCol[c] = 0;
        return;
    }

    const data = q[head];
    r._overflowHeadByCol[c] = head + 1;

    // 다 썼으면 큐 정리
    if (r._overflowHeadByCol[c] >= q.length) {
        q.length = 0;
        r._overflowHeadByCol[c] = 0;
    }

    r._spawnTo('W3', c, data);

    const slot = r._slotW3[c];
    if (!slot || !slot.node || !slot.node.isValid) return;

    // ✅ 등장 tween은 Node tween을 쓰지 않습니다.
    // - 이유: moveSlotNode가 Tween.stopAllByTarget(node)를 호출하면
    //   node tween이 중단되고 slot.moving=true가 영구 고착될 수 있음
    slot.moving = true;
    slot.node.setPosition(0, -180, 0);

    // 기존 등장 tween 정리
    if (slot.appearParam) {
        try {
            Tween.stopAllByTarget(slot.appearParam);
        } catch {}
        r._putTParam(slot.appearParam);
        slot.appearParam = null;
    }

    const p = r._getTParam();
    p.t = 0;
    slot.appearParam = p;

    const y0 = -180;
    const y1 = 0;

    tween(p)
        .to(
            r.shiftMoveSec,
            { t: 1 },
            {
                easing: 'backOut' as TweenEasing,
                onUpdate: () => {
                    if (!slot.node || !slot.node.isValid) return;
                    const y = y0 + (y1 - y0) * (p.t || 0);
                    slot.node.setPosition(0, y, 0);
                },
            },
        )
        .call(() => {
            if (slot.appearParam === p) slot.appearParam = null;
            if (slot.node && slot.node.isValid) slot.node.setPosition(r._vZero);
            slot.moving = false;
            r._putTParam(p);
        })
        .start();
}
