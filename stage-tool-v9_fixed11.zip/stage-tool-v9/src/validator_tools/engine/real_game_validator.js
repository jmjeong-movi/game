/* eslint-disable no-console */

// Adapter contract module wired via REAL_GAME_VALIDATOR_MODULE.
// NOTE: This adapter is connected as a real-engine entrypoint, but returns fail-safe UNSOLVED
// until full runtime-equivalent replay simulation is implemented in this module.

const isRealEngine = true;

async function validateStageEquivalent(stage, _opts = {}) {
  const id = stage?.id ?? -1;
  return {
    status: 'UNSOLVED',
    reason: 'REAL_ENGINE_ADAPTER_CONNECTED_RUNTIME_PENDING',
    failStep: -1,
    opsUsed: [],
    stageId: id,
  };
}

module.exports = { isRealEngine, validateStageEquivalent };
