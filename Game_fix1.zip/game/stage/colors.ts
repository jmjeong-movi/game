import { COLOR_TOKEN_ORDER, COLOR_PALETTE_HEX_12, colorIdFromToken } from '../Types';

const COLOR_MAX = 12;

// 색상 토큰 배열(순서 보장) → token->index 맵 생성
export function makeColorIdMap(tokens: ReadonlyArray<string>): Record<string, number> {
    // 주의: 런타임 tile 색상 id는 0~11(Types.COLOR_TOKEN_ORDER) 기준을 유지해야 컬러/스프라이트가 안정적입니다.
    const out: Record<string, number> = Object.create(null);
    for (let i = 0; i < tokens.length; i++) out[String(tokens[i])] = i;
    return out;
}

// 팔레트(HEX)를 stage/meta 설정에 맞춰 생성합니다.
export function makePaletteHex(_colorCount: number) {
    // 역할: 런타임 팔레트(HEX) 생성
    // - 컬러 이슈 방지: stage.meta.colorCount가 3이라도, 토큰(R/Y/B)이 0/2/4 같은 “전역 색상 id”를 사용할 수 있습니다.
    // - 따라서 팔레트는 12색(전역) 기준을 유지합니다.
    return (COLOR_PALETTE_HEX_12 as readonly string[]).slice(0, COLOR_MAX);
}

// Color8(토큰/숫자)을 “전역 colorId(0~11)”로 정규화합니다.
// - 알 수 없는 토큰/범위 밖 숫자는 조용히 0으로 뭉개지 않고 즉시 throw(원인 추적 쉬움)
export function normalizeColorIdAny(color: any): number {
    // 1) 숫자(0~11) 지원
    if (typeof color === 'number' && isFinite(color)) {
        const v = Math.floor(color);
        if (v >= 0 && v < COLOR_MAX) return v;
        throw new Error(`[StageCompiler] invalid numeric colorId=${v} (expected 0~11)`);
    }

    // 2) 문자열 토큰 지원(R/O/Y/G/B/P/M/C/S/L/K/W)
    const token = String(color ?? '')
        .trim()
        .toUpperCase();
    const id = colorIdFromToken(token);
    if (id >= 0 && id < COLOR_MAX) return id;

    throw new Error(`[StageCompiler] unknown color token="${token}" (expected one of ${COLOR_TOKEN_ORDER.join(',')})`);
}
