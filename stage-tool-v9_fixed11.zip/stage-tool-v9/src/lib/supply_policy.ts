import type { BoardObjectType } from './schema';

export const SUPPLY_ALLOWED_TYPES = new Set<BoardObjectType | string>([
  'BLOCK_NORMAL',
  'BLOCK_SMALL',
  'BLOCK_HIDDEN',
  'BLOCK_LARGE',
  'BLOCK_LARGE_HIDDEN',
]);

export function sanitizeSupplyPagesToBlocksOnly(stage: any): number {
  const pages = stage?.supply?.pages;
  if (!Array.isArray(pages)) return 0;
  let removed = 0;
  for (const page of pages) {
    const objs = Array.isArray(page?.objects) ? page.objects : [];
    const next = objs.filter((o: any) => SUPPLY_ALLOWED_TYPES.has(String(o?.type ?? '')));
    removed += Math.max(0, objs.length - next.length);
    page.objects = next;
  }
  return removed;
}

export function isSupplyTypeAllowed(t: any): boolean {
  return SUPPLY_ALLOWED_TYPES.has(String(t ?? ''));
}
