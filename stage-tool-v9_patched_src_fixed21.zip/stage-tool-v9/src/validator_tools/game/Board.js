"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Board = void 0;
const cc_1 = require("cc");
const Config_1 = require("./Config");
const Types_1 = require("./Types");
const ColorPalette_1 = require("./ColorPalette");
const TileView_1 = require("./TileView");
const ProjectileView_1 = require("./ProjectileView");
const BoardIntroDrop_1 = require("./BoardIntroDrop");
const AudioManager_1 = require("../core/AudioManager");
const { ccclass, property } = cc_1._decorator;
let Board = class Board extends cc_1.Component {
    constructor() {
        super(...arguments);
        this.tilePrefab = null;
        this.bigTilePrefab = null;
        this.projectilePrefab = null;
        this.tileSize = Config_1.TILE_SIZE;
        this.warmupSmall = 40;
        this.warmupBig = 8;
        this.warmupProjectiles = 0;
        this.tileLayer = null;
        this.introDrop = null;
        this.projectileLayer = null;
        this.fxLayer = null;
        this.warmupShatterFx = 24;
        this.rows = Config_1.GRID_ROWS;
        this.cols = Config_1.GRID_COLS;
        this.colSupply = []; // length=cols, pop()으로 공급
        this.supplyLargeDefs = [];
        // 셀 점유: -1 비어있음, 그 외는 엔티티 id
        this.occ = new Int32Array(this.rows * this.cols);
        this.ents = new Map();
        this.nextEntId = 1;
        this.colReserved = [];
        this.colBusy = [];
        // 오브젝트 풀
        this.smallPool = new cc_1.NodePool();
        this.bigPool = new cc_1.NodePool();
        this.projectilePool = new cc_1.NodePool();
        // ✅ 제거 FX(Particle_Shatter) 오브젝트 풀
        this.shatterFxPool = new cc_1.NodePool();
        this.shatterFxTemplate = null;
        this.shatterFxRecycleDelay = 0; // 템플릿 기반 자동 계산(하드코딩 제거)
        this.remainingTiles = 0;
        this._totalBlocks = 0;
        this._destroyedBlocks = 0;
        this._onBlockDestroyed = null;
        this.unlockedLocks = new Set();
        this.initialized = false;
        this.initFailed = false;
        this.initFailLogged = false;
        // ✅ 이동 중 엔티티(낙하/정렬 Tween 진행 중) ref-count
        // - 역할: 발사 타겟 선택에서 moving 블럭을 우선 제외하여 발사 템포를 일정하게 유지
        this._movingEntRef = new Map();
        // ✅ 아이템3(블록 이동) 활성화 여부: 다음 블록 탭으로 색상 선택
        this._itemMoveBlockActive = false;
        // ✅ 아이템3 임시 버퍼(재사용 → GC 최소화)
        this._tmpOccItem = new Int32Array(this.rows * this.cols);
        this._tmpMovableEnts = [];
        this._tmpMoveNewR = [];
        this._tmpMoveNewC = [];
        this._tmpMovedEnts = [];
        this._tmpItemCols = []; // 아이템3: 영향받은 컬럼 목록(재사용)
        // ✅ 히든 공개/변환 임시 버퍼(재사용 → GC 최소화)
        // - 역할: 바닥에 닿은 히든 트리거를 감지하고, 히든 그룹 + 인접 연결 컴포넌트 변환을 수행
        this._tmpRevealBottomHidden = [];
        this._tmpRevealQueue = [];
        this._tmpRevealVisited = new Uint8Array(this.rows * this.cols);
        this._tmpRevealEntSet = new Set();
        this._tmpRevealSeedCellByColor = new Int32Array(12); // colorId(0~11) -> seed cell index
        this._tmpRevealChangedEnt = new Set();
        // ✅ 아이템3 임시: 선택된 엔티티 id Set(재사용 → GC 최소화)
        this._tmpMoveSelIds = new Set();
        // ✅ 아이템3 임시: 중력 처리 대상 리스트(재사용)
        this._tmpGravityList = [];
        // ✅ BIG 타겟 전역 LOCK: 한 번 BIG을 쏘기 시작하면 파괴될 때까지 다른 BIG은 타겟 불가
        this.currentBigTargetId = 0;
        // UI2(Enemys/Blocks/Line_01~15) 레이아웃 지원
        this.useLineLayout = false;
        this.lineNodes = [];
        this.colX = [];
        this.lineDy = 0; // Line 간격(세로)
        this.bottomLineIdx = 0; // lineNodes 기준 바닥 라인 인덱스
        // ✅ tileLayer(UITransform) 크기 기반 10x10 자동 배치용 캐시(라인 레이아웃 아닐 때 사용)
        this.gridW = 0;
        this.gridH = 0;
        this.stepX = 0;
        this.stepY = 0;
        this.originX = 0;
        this.originY = 0;
        this._tmpAim = new cc_1.Vec3();
        this._onTileTouchEnd = (ev) => {
            // // 역할: 아이템3 활성화 상태에서만 동작(다음 블록 탭으로 색상 결정)
            if (!this._itemMoveBlockActive)
                return;
            const n = ev?.target ?? null;
            if (!n || !n.isValid)
                return;
            const tv = this._getTileViewFromTarget(n);
            if (!tv)
                return;
            // 히든 제외
            if (tv.isHidden?.())
                return;
            // 일반 빅/스몰만: 체인/락/스포너 등 특수 블록 제외
            const sp = (tv.depth ?? 1) <= 1 ? tv.getSpecial?.() : null;
            if (sp)
                return;
            const cid = tv.colorId | 0;
            if (cid < 0)
                return;
            this._itemMoveBlockActive = false;
            this.useItemMoveColorBlocksToTop(cid).catch(() => { });
        };
    }
    // // 외부(CannonRack)에서 “중간점” 계산 시 할당을 줄이기 위한 임시 Vec3 제공
    tmpVec3() {
        return this._tmpAim;
    }
    // 컬럼 개수(외부 시스템이 TTL 배열 등 크기 맞출 때 사용)
    getColCount() {
        return this.cols;
    }
    // Validate that a (colorId, entId) is currently shootable at row0/col.
    // Used by UnitLineRack to keep a stable target (avoid per-shot retarget jitter).
    isShootableTarget(colorId, entId, col) {
        if (col < 0 || col >= this.cols)
            return false;
        if (this.colReserved[col] || this.colBusy[col])
            return false;
        const e = this.entAt(0, col);
        if (!e)
            return false;
        if ((e.id | 0) !== (entId | 0))
            return false;
        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
            return false;
        if ((e.view?.colorId ?? -999) !== (colorId | 0))
            return false;
        // Entity footprint cols must all be free
        const cols = this.entCols(e);
        for (const cc of cols) {
            if (this.colReserved[cc] || this.colBusy[cc])
                return false;
        }
        return true;
    }
    // ✅ 엔티티 기준 shootable 판정(컬럼 고정 불필요)
    // - 요구사항: BIG(2x2)처럼 여러 컬럼을 점유해도, "엔티티"를 고정으로 잡고 쏠 수 있어야 함
    // - UnitLineRack의 sticky/assignment가 entId 기반으로 동작하도록 지원
    isShootableEnt(colorId, entId) {
        const e = this.ents.get(entId | 0);
        if (!e)
            return { ok: false, col: -1 };
        if (e.row !== 0)
            return { ok: false, col: -1 };
        if ((e.view?.colorId ?? -999) !== (colorId | 0))
            return { ok: false, col: -1 };
        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
            return { ok: false, col: -1 };
        const cols = this.entCols(e);
        for (const cc of cols) {
            if (cc < 0 || cc >= this.cols)
                return { ok: false, col: -1 };
            if (this.colReserved[cc] || this.colBusy[cc])
                return { ok: false, col: -1 };
            const at = this.entAt(0, cc);
            if (!at || (at.id | 0) !== (e.id | 0))
                return { ok: false, col: -1 };
        }
        // 대표 컬럼은 앵커 col 사용(좌→우 우선/정렬에도 일관성)
        return { ok: true, col: e.col | 0 };
    }
    // ✅ 현재(row0)에서 colorId로 쏠 수 있는 BIG(2x2) 엔티티 목록을 좌→우로 반환
    // - 같은 BIG이 2컬럼을 차지하므로, entId 중복을 제거합니다.
    listShootableBigEnts(colorId, pref = 'LEFT') {
        const out = [];
        const usedEnt = new Set();
        // ✅ 사용자 요구: 좌→우(LEFT) 고정. pref는 호환용.
        for (let c = 0; c < this.cols; c++) {
            if (this.colReserved[c] || this.colBusy[c])
                continue;
            const e = this.entAt(0, c);
            if (!e)
                continue;
            if ((e.view?.colorId ?? -999) !== (colorId | 0))
                continue;
            if (!(e.w > 1 || e.h > 1))
                continue;
            if (usedEnt.has(e.id))
                continue;
            const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
                continue;
            // BIG은 footprint 전체가 free여야 실발사가 가능
            const cols = this.entCols(e);
            let ok = true;
            for (const cc of cols) {
                if (this.colReserved[cc] || this.colBusy[cc]) {
                    ok = false;
                    break;
                }
                const at = this.entAt(0, cc);
                if (!at || (at.id | 0) !== (e.id | 0)) {
                    ok = false;
                    break;
                }
            }
            if (!ok)
                continue;
            usedEnt.add(e.id);
            // 대표 컬럼은 앵커(좌하단) col
            out.push({ entId: e.id | 0, col: e.col | 0 });
        }
        return out;
    }
    // ✅ 현재(row0)에 존재하는 BIG(2x2) 엔티티 목록(좌→우), "사격 가능성"과 무관하게 반환
    // - 중요: colReserved/colBusy 때문에 순간적으로 shootable에서 빠져도, 유닛-타겟 고정 매칭이 깨지지 않도록 사용합니다.
    // - LOCK 미해제는 제외합니다(어차피 쏠 수 없음).
    listRow0BigEnts(colorId, pref = 'LEFT') {
        const out = [];
        const usedEnt = new Set();
        // ✅ 좌→우 고정
        for (let c = 0; c < this.cols; c++) {
            const e = this.entAt(0, c);
            if (!e)
                continue;
            if ((e.view?.colorId ?? -999) !== (colorId | 0))
                continue;
            if (!(e.w > 1 || e.h > 1))
                continue;
            // 앵커(좌하단) 컬럼에서만 수집(중복 방지)
            if ((e.col | 0) !== (c | 0))
                continue;
            if (usedEnt.has(e.id))
                continue;
            const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
                continue;
            usedEnt.add(e.id);
            out.push({ entId: e.id | 0, col: e.col | 0 });
        }
        return out;
    }
    countRow0Big(colorId, pref = 'LEFT') {
        return this.listRow0BigEnts(colorId, pref).length;
    }
    // ✅ countShootableBig: UnitLineRack의 BIG budget 계산용
    countShootableBig(colorId, pref = 'LEFT') {
        return this.listShootableBigEnts(colorId, pref).length;
    }
    // // 현재 colorId로 쏠 수 있는(앞줄 타겟이 있고 잠김/예약/바쁨이 아닌) 컬럼 개수
    countShootableColumns(colorId) {
        let n = 0;
        for (let c = 0; c < this.cols; c++) {
            if (this.colReserved[c] || this.colBusy[c])
                continue;
            const e = this.entAt(0, c);
            if (!e)
                continue;
            const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
                continue;
            if (e.view.colorId === colorId)
                n++;
        }
        return n;
    }
    // // colorId로 이번 프레임에 쏠 타겟(컬럼)을 최대 maxShots개 선택합니다.
    // // - pref: LEFT면 좌측부터, CENTER면 중앙에 가까운 순서
    // // - 엔티티(2x2 포함) 중복을 피해서 듀얼이 한 블럭에 몰빵되지 않게 합니다.
    // // - ✅ 중요: "다른 색" 유닛 그룹은 서로 간섭하지 않아야 합니다.
    // //   따라서 BIG(2x2) 전역 LOCK을 사용하지 않고, BIG은 "우선순위"만 높게 두되
    // //   colorId가 다르면 SMALL 타겟 탐색을 계속합니다.
    // NOTE: excludeEnt is a per-color, per-frame planning aid.
    // It prevents multiple units of the same color from picking the same target entity
    // before reservations are actually applied by tryShootAtColumnEx.
    pickShootTargets(colorId, maxShots, pref = 'LEFT', excludeEnt, allowBig = true) {
        const out = [];
        const want = Math.max(1, maxShots | 0);
        // 컬럼 우선순위: ✅ 항상 좌→우(왼쪽 우선)
        // - 사용자 요구: 왼쪽부터 오른쪽으로 갈수록 우선순위가 낮아짐
        // - pref는 호환을 위해 받지만, 실질 순서는 LEFT로 고정합니다.
        const order = [];
        for (let c = 0; c < this.cols; c++)
            order.push(c);
        // 선택된 엔티티 중복 방지
        // ✅ 요구사항: 컬럼(footprint) 겹침은 허용, 엔티티(블럭)만 겹치지 않으면 OK
        const usedEnt = new Set();
        const exEnt = excludeEnt;
        const tryPush = (e, col, isBig) => {
            if (!e)
                return;
            if (out.length >= want)
                return;
            if (this.colReserved[col] || this.colBusy[col])
                return;
            const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
                return;
            // 바닥(row0)만
            if (e.row !== 0)
                return;
            if ((e.view?.colorId ?? -999) !== (colorId | 0))
                return;
            if (usedEnt.has(e.id))
                return;
            if (exEnt?.has(e.id))
                return;
            // BIG은 footprint 전체가 예약/바쁨이면 어차피 발사 실패이므로 제외
            if (isBig) {
                const cols = this.entCols(e);
                for (const cc of cols) {
                    if (this.colReserved[cc] || this.colBusy[cc])
                        return;
                }
            }
            usedEnt.add(e.id);
            // Also mark into excludes (so subsequent pickShootTargets calls in the same frame
            // can avoid selecting the same entity).
            if (exEnt)
                exEnt.add(e.id);
            out.push({
                col,
                entId: e.id,
                world: this.cellWorldPos(0, col),
                isBig,
                hp: isBig ? (e.view.getHp?.() ?? 0) : 0,
            });
        };
        // 1) BIG 우선(하지만 전역 LOCK 없음)
        if (allowBig) {
            for (const c of order) {
                if (out.length >= want)
                    break;
                const e = this.entAt(0, c);
                if (!e)
                    continue;
                if (!(e.w > 1 || e.h > 1))
                    continue;
                // BIG은 앵커 col(가장 왼쪽)로 통일
                tryPush(e, e.col, true);
            }
        }
        // 2) 남는 샷은 SMALL로 채움
        for (const c of order) {
            if (out.length >= want)
                break;
            const e = this.entAt(0, c);
            if (!e)
                continue;
            if (e.w > 1 || e.h > 1)
                continue;
            tryPush(e, c, false);
        }
        return out;
    }
    // // shooterWorld    // // shooterWorld에서 “지정 컬럼(col)”로 colorId 발사를 시도합니다(가능하면 true).
    // // - 성공 시: 해당 엔티티가 점유하는 모든 컬럼을 colReserved로 예약(2x2 동시타격 방지)
    // // shooterWorld에서 “지정 컬럼(col)”로 colorId 발사를 시도합니다(가능하면 true).
    // // - 성공 시: 해당 엔티티가 점유하는 모든 컬럼을 colReserved로 예약(2x2 동시타격 방지)
    // // - out: 성공 시 예약된 컬럼 정보(할당 없이 재사용)
    tryShootAtColumnEx(shooterWorld, colorId, col, out) {
        // out 기본값(실패 시에도 안전)
        out.entId = 0;
        out.col0 = -1;
        out.col1 = -1;
        out.isBig = false;
        if (!this.projectilePrefab || !this.projectileLayer)
            return false;
        if (col < 0 || col >= this.cols)
            return false;
        if (this.colReserved[col] || this.colBusy[col])
            return false;
        const targetEnt = this.entAt(0, col);
        if (!targetEnt)
            return false;
        // LOCK은 키 전까지 제외
        const sp = (targetEnt.view.depth ?? 1) <= 1 ? targetEnt.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
            return false;
        if (targetEnt.view.colorId !== colorId)
            return false;
        // ✅ 핵심: 엔티티 점유 컬럼 전체 예약(메카닉끼리 같은 블럭 동시타격 방지)
        const reservedCols = sp?.t === 'CHAIN_SEG'
            ? this.chainGroupCols(String(sp?.id ?? ''))
            : this.entCols(targetEnt);
        for (const c of reservedCols) {
            if (this.colReserved[c] || this.colBusy[c])
                return false;
        }
        for (const c of reservedCols)
            this.colReserved[c] = true;
        const projectileNode = this.obtainProjectile();
        if (!projectileNode) {
            for (const c of reservedCols)
                this.colReserved[c] = false;
            return false;
        }
        // ✅ out 채우기(성공 시에만)
        out.entId = targetEnt.id;
        out.col0 = reservedCols.length > 0 ? reservedCols[0] | 0 : col | 0;
        out.col1 = reservedCols.length > 1 ? reservedCols[1] | 0 : -1;
        out.isBig = targetEnt.w > 1 || targetEnt.h > 1;
        const pv = projectileNode.getComponent(ProjectileView_1.ProjectileView);
        pv?.setColor(colorId);
        const layerUI = this.projectileLayer.getComponent(cc_1.UITransform);
        if (!layerUI) {
            this.releaseProjectile(projectileNode);
            for (const c of reservedCols)
                this.colReserved[c] = false;
            // out 롤백
            out.entId = 0;
            out.col0 = -1;
            out.col1 = -1;
            out.isBig = false;
            return false;
        }
        const start = layerUI.convertToNodeSpaceAR(shooterWorld);
        const endWorld = this.cellWorldPos(0, col);
        const end = layerUI.convertToNodeSpaceAR(endWorld);
        cc_1.Tween.stopAllByTarget(projectileNode);
        projectileNode.parent = this.projectileLayer;
        projectileNode.active = true;
        projectileNode.setScale(1, 1, 1);
        projectileNode.setPosition(start);
        const dist = cc_1.Vec3.distance(start, end);
        const speed = 20000; // ✅ 거리 무관에 가깝게(가까운 타겟 템포로 고정)
        const duration = Math.max(0.04, dist / speed);
        // ✅ StageTool headless simulation: 애니메이션/Tween을 건너뛰고 즉시 처리
        // - Cocos Tween 업데이트 루프가 없는 환경(혹은 대량 검증)에서 진행이 멈추는 것을 방지
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            this.releaseProjectile(projectileNode);
            this.handleHitColumn(col).catch(() => {
                // 최악 복구(예약 고착 방지)
                for (const c of reservedCols)
                    this.colReserved[c] = false;
                this.clearBusyAll();
            });
            return true;
        }
        (0, cc_1.tween)(projectileNode)
            .to(duration, { position: end })
            .call(() => {
            this.releaseProjectile(projectileNode);
            this.handleHitColumn(col).catch(() => {
                // 최악 복구(예약 고착 방지)
                for (const c of reservedCols)
                    this.colReserved[c] = false;
                this.clearBusyAll();
            });
        })
            .start();
        return true;
    }
    // 기존 API(호환): boolean만 필요할 때 사용
    tryShootAtColumn(shooterWorld, colorId, col) {
        const tmp = { entId: 0, col0: -1, col1: -1, isBig: false };
        // ⚠️ 이 경로는 할당이 발생하므로, 런타임(연사)에서는 UnitLineRack에서 tryShootAtColumnEx를 사용하세요.
        return this.tryShootAtColumnEx(shooterWorld, colorId, col, tmp);
    }
    onLoad() {
        // 플래그/배열을 미리 만들어 재할당을 줄입니다.
        this.colReserved = new Array(this.cols).fill(false);
        this.colBusy = new Array(this.cols).fill(false);
        this.occ.fill(-1);
    }
    start() {
        this.initOnce();
    }
    // 남은 타일 수(승리 조건 판단용)를 반환합니다.
    remaining() {
        return this.remainingTiles;
    }
    // 블럭이 완전히 제거될 때 호출할 리스너를 등록합니다.
    setOnBlockDestroyed(fn) {
        this._onBlockDestroyed = fn;
    }
    // 현재 스테이지 총 블럭 수(목표치)를 반환합니다.
    totalBlocks() {
        return this._totalBlocks;
    }
    // ✅ 엔티티가 현재 이동(낙하/정렬 Tween) 중인지 반환합니다.
    // - UnitLineRack에서 moving 타겟을 우선 제외해 “스몰→빅 전환 시 느려짐(컬럼 busy 대기)”을 줄입니다.
    isEntMoving(entId) {
        const c = this._movingEntRef.get(entId | 0) ?? 0;
        return c > 0;
    }
    beginItemMoveBlocksToTop() {
        // // 역할: 블록 이동 아이템 시작(다음 블록 탭으로 색상 선택)
        this._itemMoveBlockActive = true;
    }
    cancelItemMoveBlocksToTop() {
        // // 역할: 블록 이동 아이템 강제 종료
        this._itemMoveBlockActive = false;
    }
    // ✅ 터치 이벤트의 target이 자식 노드인 경우를 대비해 TileView를 상위로 탐색합니다.
    _getTileViewFromTarget(n) {
        // // 역할: 작은 블럭(내부 Root/Sprite 등) 터치 시에도 TileView를 정확히 찾기
        let cur = n;
        while (cur && cur.isValid) {
            const tv = cur.getComponent(TileView_1.TileView);
            if (tv)
                return tv;
            cur = cur.parent;
        }
        return null;
    }
    async useItemMoveColorBlocksToTop(colorId, moveSec = 0.16) {
        // // 역할: 선택한 블럭의 "색상"만 보드 최상단(가능한 가장 높은 row)으로 끌어올립니다.
        // // - 히든 블록 제외
        // // - 체인/락/유닛생성기 등 특수 블록 제외
        // // - 블럭 "정렬/재배치" 금지: 좌우(col)는 그대로 유지하고, 올라간 만큼 생긴 빈칸만 중력으로 자연스럽게 내려오게 합니다.
        const cid = colorId | 0;
        this._tmpMovableEnts.length = 0; // 선택된 엔티티 목록
        this._tmpMoveNewR.length = 0; // oldRow 저장(안전용)
        this._tmpMoveNewC.length = 0; // oldCol 저장(안전용)
        this._tmpMovedEnts.length = 0; // 이동 애니메이션 대상(중력 + 선택 이동)
        this._tmpMoveSelIds.clear();
        this._tmpItemCols.length = 0; // 영향 컬럼 수집 버퍼 초기화
        // 1) 선택 색상(일반 big/small)만 수집
        for (const e of this.ents.values()) {
            if (this.isEntMoving(e.id))
                continue;
            const v = e.view;
            if (!v || !v.node?.isValid)
                continue;
            if (v.isHidden?.())
                continue;
            const sp = (v.depth ?? 1) <= 1 ? v.getSpecial?.() : null;
            if (sp)
                continue;
            if ((v.colorId | 0) !== cid)
                continue;
            if (e.w <= 0 || e.h <= 0)
                continue;
            this._tmpMovableEnts.push(e);
            this._tmpMoveNewR.push(e.row);
            this._tmpMoveNewC.push(e.col);
            this._tmpMoveSelIds.add(e.id);
        }
        if (this._tmpMovableEnts.length === 0)
            return false;
        // 2) 선택된 블럭의 footprint를 점유그리드에서 제거(빈칸 생성)
        for (let i = 0; i < this._tmpMovableEnts.length; i++) {
            const e = this._tmpMovableEnts[i];
            for (let dy = 0; dy < e.h; dy++) {
                for (let dx = 0; dx < e.w; dx++) {
                    const r = e.row + dy;
                    const c = e.col + dx;
                    if (r < 0 || r >= this.rows || c < 0 || c >= this.cols)
                        continue;
                    this._tmpItemCols.push(c); // 아이템3: 이 컬럼은 위쪽 빈칸(supply 채움) 후보
                    const idx = this.indexOf(r, c);
                    if (this.occ[idx] === e.id)
                        this.occ[idx] = -1;
                }
            }
        }
        // 3) 나머지 블럭은 중력으로 자연스럽게 내려오게 함(선택된 블럭 제외)
        this._settleGravityExcluding(this._tmpMoveSelIds, this._tmpMovedEnts);
        // NOTE: supply 보충은 "선택 블럭을 최상단에 배치"한 뒤에 수행합니다.
        // - 이유: 중력 직후 바로 보충하면, 보충된 블럭이 선택 블럭의 배치 위치를 선점해 충돌/실패가 발생할 수 있습니다.
        // 4) 선택된 블럭을 "같은 col"에서 가능한 가장 높은 row로 배치(빅 먼저)
        this._tmpMovableEnts.sort((a, b) => {
            const abig = a.w > 1 || a.h > 1 ? 1 : 0;
            const bbig = b.w > 1 || b.h > 1 ? 1 : 0;
            if (abig !== bbig)
                return bbig - abig;
            // 기존에 위에 있던 블럭이 더 위에 남도록(자연스러운 느낌)
            if (a.row !== b.row)
                return b.row - a.row;
            return a.col - b.col;
        });
        const rows = this.rows | 0;
        const cols = this.cols | 0;
        const canPlaceAtSameCol = (e, r0) => {
            const c0 = e.col | 0;
            if (c0 < 0 || c0 + e.w > cols)
                return false;
            if (r0 < 0 || r0 + e.h > rows)
                return false;
            for (let dy = 0; dy < e.h; dy++) {
                for (let dx = 0; dx < e.w; dx++) {
                    const rr = r0 + dy;
                    const cc = c0 + dx;
                    const id = this.occ[this.indexOf(rr, cc)];
                    if (id >= 0)
                        return false;
                }
            }
            return true;
        };
        const occupyAtSameCol = (e, r0) => {
            const c0 = e.col | 0;
            for (let dy = 0; dy < e.h; dy++) {
                for (let dx = 0; dx < e.w; dx++) {
                    const rr = r0 + dy;
                    const cc = c0 + dx;
                    this.occ[this.indexOf(rr, cc)] = e.id;
                }
            }
        };
        for (let i = 0; i < this._tmpMovableEnts.length; i++) {
            const e = this._tmpMovableEnts[i];
            const oldR = e.row | 0;
            let placed = false;
            const rStart = rows - e.h;
            for (let r = rStart; r >= 0; r--) {
                if (!canPlaceAtSameCol(e, r))
                    continue;
                occupyAtSameCol(e, r);
                if (oldR !== r)
                    this._tmpMovedEnts.push(e);
                e.row = r;
                e.view.row = r;
                // col은 유지(정렬/재배치 금지)
                e.view.col = e.col;
                placed = true;
                break;
            }
            if (!placed) {
                // 이론상 거의 없지만, 장애물(히든/특수) 구성에 의해 실패할 수 있으므로 안전 복구
                for (let k = 0; k < this._tmpMovableEnts.length; k++) {
                    const ee = this._tmpMovableEnts[k];
                    const or = this._tmpMoveNewR[k] | 0;
                    const oc = this._tmpMoveNewC[k] | 0;
                    ee.row = or;
                    ee.col = oc;
                    ee.view.row = or;
                    ee.view.col = oc;
                }
                // occ 재구성
                this.occ.fill(-1);
                for (const ent of this.ents.values()) {
                    for (let dy = 0; dy < ent.h; dy++) {
                        for (let dx = 0; dx < ent.w; dx++) {
                            const rr = ent.row + dy;
                            const cc = ent.col + dx;
                            if (rr < 0 || rr >= this.rows || cc < 0 || cc >= this.cols)
                                continue;
                            this.occ[this.indexOf(rr, cc)] = ent.id;
                        }
                    }
                }
                return false;
            }
        }
        // 4-1) 선택 블럭 배치 이후, 상단 빈칸을 supply로 보충합니다.
        // - 역할: 아이템3 중력/공급 버그 방지(배치 우선 → 보충 후순위)
        // - 성능: 영향 컬럼만 대상으로 처리(버퍼 재사용)
        const spawned2 = this.fillTopHoles(this._tmpItemCols);
        for (let i = 0; i < spawned2.length; i++)
            this._tmpMovedEnts.push(spawned2[i]);
        this.revealHiddenAtBottom();
        // 5) 이동 애니메이션(중력으로 내려온 것 + 위로 올라간 선택 블럭)
        for (let i = 0; i < this._tmpMovedEnts.length; i++) {
            this.moveEnt(this._tmpMovedEnts[i], moveSec).catch(() => { });
        }
        return this._tmpMovedEnts.length > 0;
    }
    // ✅ (CardTray용) 색상별 “필요 탄 수”를 추정합니다.
    // - 이름은 Front지만, 실제로는 "현재 보드 + 남은 supply + 스포너 큐"까지 포함합니다.
    // - 역할: 카드 탄약이 부족해지는 문제 방지(스테이지 로드 직후 1회 호출 권장)
    estimateRequiredShotsByColorFront() {
        const out = new Map();
        // 1) 현재 보드 엔티티(스택/체인/큰블럭)
        for (const e of this.ents.values()) {
            const v = e.view;
            if (!v)
                continue;
            // 큰 블럭: 남은 HP만큼 해당 색상에 필요 타수
            if (e.w > 1 || e.h > 1) {
                const c = v.colorId;
                const n = Math.max(0, v.getHp() | 0);
                if (c >= 0 && n > 0)
                    out.set(c, (out.get(c) ?? 0) + n);
                continue;
            }
            const top = v.colorId;
            if (top < 0)
                continue;
            const depth = v.depth ?? 1;
            const sp = depth <= 1 ? v.getSpecial() : null;
            // CHAIN: hp만큼 같은 색상 타격
            if (sp?.t === 'CHAIN') {
                const hp = Math.max(1, sp.hp | 0);
                out.set(top, (out.get(top) ?? 0) + hp);
                continue;
            }
            // 일반 스택: 스택 내부 색상을 그대로 합산(겹이 바뀌며 필요 색도 바뀜)
            const stack = v.getStackRef();
            for (let i = 0; i < stack.length; i++) {
                const c = stack[i] | 0;
                if (c < 0)
                    continue;
                out.set(c, (out.get(c) ?? 0) + 1);
            }
            // SPAWNER: 큐까지 포함(큐 아이템도 결국 해당 색상이 필요)
            if (sp?.t === 'SPAWNER') {
                const q = Array.isArray(sp.queue) ? sp.queue : [];
                for (let i = 0; i < q.length; i++) {
                    const c = q[i] | 0;
                    if (c < 0)
                        continue;
                    out.set(c, (out.get(c) ?? 0) + 1);
                }
            }
        }
        // 2) 남은 supply
        for (let c = 0; c < this.cols; c++) {
            const st = this.colSupply[c];
            if (!st || st.length <= 0)
                continue;
            for (let i = 0; i < st.length; i++) {
                const col = st[i] | 0;
                if (col < 0)
                    continue;
                out.set(col, (out.get(col) ?? 0) + 1);
            }
        }
        return out;
    }
    // 컬럼 애니메이션/프로젝타일이 남아있는지 여부를 반환합니다.
    isBusy() {
        if (this.colReserved.some((v) => v))
            return true;
        if (this.colBusy.some((v) => v))
            return true;
        if (this.projectileLayer && this.projectileLayer.isValid && this.projectileLayer.children.length > 0)
            return true;
        return false;
    }
    // 현재 colorId로 즉시 발사가 가능한 컬럼이 있는지 확인합니다.
    canShootColor(colorId) {
        return this.findShootableColumn(colorId) >= 0;
    }
    // 바닥(앞줄)에서 해당 colorId가 존재하는지 확인합니다.
    hasFrontColor(colorId) {
        for (let c = 0; c < this.cols; c++) {
            const e = this.entAt(0, c);
            if (!e)
                continue;
            const top = e.view.colorId;
            if (top === colorId)
                return true;
        }
        return false;
    }
    /**
     * ✅ 보드 실제 상태 기반 row0(바닥) 색 분포를 반환합니다.
     * - 스턱(타겟 0) 구간에서 "젤 하단에 남은 블럭 색"을 근거로 need(color)를 계산할 때 사용합니다.
     * - NOTE: verify가 반환하는 snapshot/remainingTiles에 의존하지 않고, 실제 엔티티/TileView를 직접 읽습니다.
     *
     * @param out (옵션) 길이 12의 배열/TypedArray를 넘기면 그 배열을 재사용합니다.
     * @returns 길이 12의 Int32Array (colorId 0~11)
     */
    getFrontColorCounts(out) {
        const arr = out instanceof Int32Array ? out : new Int32Array(12);
        if (!(out instanceof Int32Array)) {
            // number[] 등은 직접 0으로 초기화
            if (Array.isArray(out)) {
                for (let i = 0; i < 12; i++)
                    out[i] = 0;
            }
            else {
                for (let i = 0; i < 12; i++)
                    arr[i] = 0;
            }
        }
        // Int32Array면 fill로 초기화
        if (arr instanceof Int32Array)
            arr.fill(0);
        for (let c = 0; c < this.cols; c++) {
            const e = this.entAt(0, c);
            if (!e)
                continue;
            const cid = (e.view?.colorId ?? -1) | 0;
            if (cid >= 0 && cid < 12)
                arr[cid] += 1;
        }
        return arr;
    }
    // 엔티티를 현재 row/col에 맞게 즉시 스냅(라인 레이아웃 부모까지 재설정)
    snapEntImmediate(e) {
        const n = e.view.node;
        const t = this.entParentAndLocal(e);
        if (!n || !t.parent)
            return;
        n.setParent(t.parent);
        n.setPosition(t.local);
    }
    // StageRuntime을 받아 보드/공급/남은블록을 초기화합니다.
    load(runtime) {
        this.initOnce();
        if (!this.isReady())
            return;
        this.resetBusyFlags();
        // ✅ tileLayer 크기(10x10 자동 배치 기준)를 최신으로 캐시
        // (레이아웃/리사이즈가 런타임 중에 바뀌는 경우를 대비)
        this.cacheTileLayerGridMetrics();
        // 기존 엔티티/점유 제거
        this.clearAllEntities();
        // 공급 스택 복사
        this.colSupply = Array.from({ length: this.cols }, (_, c) => runtime.columnSupply?.[c] ? runtime.columnSupply[c].slice() : []);
        // supply LARGE 정의 복사
        this.supplyLargeDefs = Array.isArray(runtime.supplyLargeDefs)
            ? runtime.supplyLargeDefs.slice()
            : [];
        // 키/락 상태 초기화
        this.unlockedLocks.clear();
        // ✅ remainingTiles는 “남은 제거 타수(=필요 탄 수)”로 사용
        // - 스택(겹) = 겹 수만큼
        // - CHAIN = hp만큼
        // - 큰 블럭 = hpMax만큼
        // - supply/스포너 큐 = 길이만큼
        this.remainingTiles = this.computeTotalHitsFromRuntime(runtime);
        // 진행도는 '총 블럭 수(totalBlocks)' 기준(블럭이 완전히 제거될 때만 증가)
        this._totalBlocks = Math.max(0, (runtime.totalBlocks ?? runtime.blockCount ?? 0) | 0);
        this._destroyedBlocks = 0;
        // 1x1 생성 (largeMask=true는 skip)
        const largeMask = runtime.largeMask;
        for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
                if (largeMask?.[r]?.[c])
                    continue;
                const stack = runtime.boardStacks?.[r]?.[c];
                if (Array.isArray(stack) && stack.length > 0) {
                    const e = this.spawnSmall(r, c);
                    if (!e)
                        continue;
                    e.view.setStack(stack);
                    e.view.setHidden(!!runtime.hiddenMask?.[r]?.[c]);
                    e.view.setSpecial(runtime.special?.[r]?.[c] ?? null);
                    this.commitEnt(e);
                    continue;
                }
                const v = runtime.board?.[r]?.[c] ?? -1;
                if (typeof v === 'number' && v >= 0) {
                    const e = this.spawnSmall(r, c);
                    if (!e)
                        continue;
                    e.view.setTop(v);
                    e.view.setHidden(!!runtime.hiddenMask?.[r]?.[c]);
                    e.view.setSpecial(runtime.special?.[r]?.[c] ?? null);
                    this.commitEnt(e);
                }
            }
        }
        // 2x2 큰 블럭 생성
        const lbs = runtime.largeBlocks ?? [];
        for (const lb of lbs) {
            const e = this.spawnBig(lb.y | 0, lb.x | 0);
            if (!e)
                continue;
            e.view.setTop(lb.colorId);
            e.view.setHp(lb.hp ?? 1, lb.hpMax ?? lb.hp ?? 1);
            e.view.setHidden(!!lb.hidden);
            e.view.setSpecial(null);
            this.commitEnt(e);
        }

        // ✅ 생성박스(runtime.spawnerBoxes)
        const sbs = Array.isArray(runtime.spawnerBoxes) ? runtime.spawnerBoxes : [];
        for (const sb of sbs) {
            const x0 = (sb?.x ?? -1) | 0;
            const y0 = (sb?.y ?? -1) | 0;
            const q = Array.isArray(sb?.queue) ? sb.queue.slice() : [];
            const colorsRaw = Array.isArray(sb?.colors) ? sb.colors : null;
            if (x0 < 0 || x0 + 1 >= this.cols)
                continue;
            if (y0 < 0 || y0 + 1 >= this.rows)
                continue;
            if (q.length <= 0)
                continue;
            const e = this.spawnSmall(y0 + 1, x0);
            if (!e)
                continue;
            // 2x1 footprint
            e.w = 2;
            e.h = 1;
            e.worth = 0;
            // ✅ v48+: 색상은 좌/우 고정(시각용으로는 왼쪽 색을 표시)
            const leftColor = ((colorsRaw?.[0] ?? q[0] ?? 0) | 0);
            const rightColor = ((colorsRaw?.[1] ?? q[1] ?? leftColor) | 0);
            e.view.setTop(leftColor);
            e.view.setHidden(false);
            e.view.setHp(1, 1);
            e.view.setSpecial({ t: 'SPAWNER_BOX', queue: q, colors: [leftColor, rightColor] });
            this.commitEnt(e);
        }
        // 로드 직후 중력 정리: 떠있는 블럭을 바닥(row=0)까지 내림
        const moved = this.settleGravity();
        for (const e of moved)
            this.snapEntImmediate(e);
        // 히든 블럭이 바닥에 닿아 있으면 즉시 공개
        this.revealHiddenAtBottom();

        // ✅ 생성박스가 바닥에 닿아 spawn row가 비면 즉시 생성
        const spSpawned0 = this.processSpawnerBoxes();
        for (const e of spSpawned0)
            this.snapEntImmediate(e);
        // 만약 보드가 완전히 비었는데 supply는 있다면: 1회 채워서 시작 가능하게 함
        if (this.ents.size === 0) {
            let hasSupply = false;
            for (let c = 0; c < this.cols; c++) {
                if (this.colSupply[c] && this.colSupply[c].length > 0) {
                    hasSupply = true;
                    break;
                }
            }
            if (hasSupply) {
                const cols = Array.from({ length: this.cols }, (_, i) => i);
                const spawned = this.fillTopHoles(cols);
                for (const e of spawned)
                    this.snapEntImmediate(e);
                this.revealHiddenAtBottom(cols);

                const spSpawned1 = this.processSpawnerBoxes();
                for (const e of spSpawned1)
                    this.snapEntImmediate(e);
            }
        }
        // ✅ 인트로 드랍 연출(옵션)
        this.playIntroDropIfAny();
    }
    // ✅ 인트로 드랍 연출을 실행합니다(Inspector에서 BoardIntroDrop를 연결한 경우만).
    // - 역할: 보드 로직(점유/중력)과 분리된 연출만 재생
    // - 성능: BoardIntroDrop 내부에서 Vec3 캐시/Opacity 재사용
    playIntroDropIfAny() {
        const intro = this.introDrop ?? this.getComponent(BoardIntroDrop_1.BoardIntroDrop);
        if (!intro || !intro.isValid)
            return;
        if (!intro.enabled || !intro.IntroEnabled)
            return;
        if (!this.tileLayer || !this.tileLayer.isValid)
            return;
        // entParentAndLocal은 private이므로 여기서만 브릿지합니다.
        intro.play({
            tileLayer: this.tileLayer,
            cols: this.cols,
            ents: this.ents.values(),
            getEntParentAndLocal: (e) => this.entParentAndLocal(e),
        });
    }
    // ✅ StageRuntime 기준 “총 필요 타수(=필요 탄 수)”를 계산합니다.
    // - 역할: CardTray 탄약 분배/승리 판정(remainingTiles) 정확도 보장
    // - 성능: 스테이지 로드 시 1회만 호출(런타임 중 매 프레임 호출 금지)
    computeTotalHitsFromRuntime(runtime) {
        let total = 0;
        const largeMask = runtime.largeMask;
        const board = runtime.board;
        const stacks = runtime.boardStacks;
        const special = runtime.special;
        // 1) 1x1 셀(스택/체인/일반)
        for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
                if (largeMask?.[r]?.[c])
                    continue;
                const sp = special?.[r]?.[c] ?? null;
                if (sp?.t === 'CHAIN') {
                    total += Math.max(1, sp.hp | 0);
                }
                else {
                    const st = stacks?.[r]?.[c];
                    if (Array.isArray(st) && st.length > 0)
                        total += st.length;
                    else {
                        const v = board?.[r]?.[c] ?? -1;
                        if (typeof v === 'number' && v >= 0)
                            total += 1;
                    }
                }
                // SPAWNER의 queue도 결국 나오는 블럭이므로 필요 타수에 포함
                if (sp?.t === 'SPAWNER' || sp?.t === 'SPAWNER_BOX') {
                    const q = Array.isArray(sp.queue) ? sp.queue : [];
                    total += q.length;
                }
            }
        }

        // ✅ 신규 생성박스(runtime.spawnerBoxes)의 queue도 포함
        const sbs = Array.isArray(runtime.spawnerBoxes) ? runtime.spawnerBoxes : [];
        for (const sb of sbs) {
            const q = Array.isArray(sb?.queue) ? sb.queue : [];
            total += q.length | 0;
        }
        // 2) 2x2 큰 블럭(HP 기반)
        const lbs = runtime.largeBlocks ?? [];
        for (let i = 0; i < lbs.length; i++) {
            const lb = lbs[i];
            const hpMax = lb.hpMax ?? lb.hp ?? 1;
            total += Math.max(1, hpMax | 0);
        }
        // 3) column supply
        // - SMALL/HIDDEN: 토큰 1개 = 1타
        // - LARGE(2x2): 토큰은 footprint(4셀)로 4개가 들어오지만, 필요 타수는 hpMax 1회만 더합니다.
        const cs = runtime.columnSupply ?? [];
        const seenLarge = new Set();
        for (let c = 0; c < this.cols; c++) {
            const st = cs[c];
            if (!Array.isArray(st))
                continue;
            for (let i = 0; i < st.length; i++) {
                const enc = st[i] | 0;
                if (enc >= Types_1.SUPPLY_LARGE_BASE) {
                    const idx = Math.floor((enc - Types_1.SUPPLY_LARGE_BASE) / 4);
                    if (idx >= 0)
                        seenLarge.add(idx);
                }
                else {
                    total += 1;
                }
            }
        }
        const defs = Array.isArray(runtime.supplyLargeDefs)
            ? runtime.supplyLargeDefs
            : [];
        for (const idx of seenLarge) {
            const d = defs[idx];
            const hpMax = d?.hpMax ?? d?.hp ?? 1;
            total += Math.max(1, hpMax | 0);
        }
        return Math.max(0, total | 0);
    }
    // shooterWorld에서 colorId로 발사를 시도합니다(가능하면 true).
    tryShoot(shooterWorld, colorId) {
        if (!this.projectilePrefab || !this.projectileLayer)
            return false;
        const col = this.findShootableColumn(colorId);
        if (col < 0)
            return false;
        const targetEnt = this.entAt(0, col);
        if (!targetEnt)
            return false;
        // ✅ 핵심: “타겟 엔티티가 점유하는 모든 컬럼”을 예약해서
        // (특히 2x2가 두 컬럼을 차지할 때) 다른 메카닉이 같은 블럭을 동시에 쏘지 못하게 막습니다.
        const sp0 = (targetEnt.view.depth ?? 1) <= 1 ? targetEnt.view.getSpecial() : null;
        const reservedCols = sp0?.t === 'CHAIN_SEG'
            ? this.chainGroupCols(String(sp0?.id ?? ''))
            : this.entCols(targetEnt);
        for (const c of reservedCols)
            this.colReserved[c] = true;
        const projectileNode = this.obtainProjectile();
        if (!projectileNode) {
            for (const c of reservedCols)
                this.colReserved[c] = false;
            return false;
        }
        const pv = projectileNode.getComponent(ProjectileView_1.ProjectileView);
        pv?.setColor(colorId);
        const layerUI = this.projectileLayer.getComponent(cc_1.UITransform);
        if (!layerUI) {
            this.releaseProjectile(projectileNode);
            for (const c of reservedCols)
                this.colReserved[c] = false;
            return false;
        }
        const start = layerUI.convertToNodeSpaceAR(shooterWorld);
        const endWorld = this.cellWorldPos(0, col);
        const end = layerUI.convertToNodeSpaceAR(endWorld);
        cc_1.Tween.stopAllByTarget(projectileNode);
        projectileNode.parent = this.projectileLayer;
        projectileNode.active = true;
        projectileNode.setScale(1, 1, 1);
        projectileNode.setPosition(start);
        const dist = cc_1.Vec3.distance(start, end);
        const speed = 20000;
        const duration = Math.max(0.05, dist / speed);
        // ✅ StageTool headless simulation: Tween 없이 즉시 처리
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            this.releaseProjectile(projectileNode);
            this.handleHitColumn(col).catch(() => {
                for (const c of reservedCols)
                    this.colReserved[c] = false;
                this.clearBusyAll();
            });
            return true;
        }
        (0, cc_1.tween)(projectileNode)
            .to(duration, { position: end })
            .call(() => {
            this.releaseProjectile(projectileNode);
            // ✅ 예약 해제는 handleHitColumn에서 “영향 컬럼 전체”를 정리하도록 바꿉니다.
            this.handleHitColumn(col).catch(() => {
                // 예외 복구(최악의 경우 예약이 영구 고착되는 것을 방지)
                for (const c of reservedCols)
                    this.colReserved[c] = false;
                this.clearBusyAll();
            });
        })
            .start();
        return true;
    }
    // ---------------- 히트/중력/공급 ----------------
    // 현재 colorId로 맞출 수 있는 바닥(앞줄) 컬럼을 찾습니다.
    findShootableColumn(colorId) {
        const start = Config_1.TARGET_LEFTMOST ? 0 : cc_1.math.randomRangeInt(0, this.cols);
        for (let k = 0; k < this.cols; k++) {
            const c = (start + k) % this.cols;
            if (this.colReserved[c] || this.colBusy[c])
                continue;
            const e = this.entAt(0, c);
            if (!e)
                continue;
            // LOCK(잠김)은 키를 얻기 전까지 발사 대상에서 제외
            const sp = e.view.getSpecial();
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
                continue;
            if (e.view.colorId === colorId)
                return c;
        }
        return -1;
    }
    // 히트 처리: (스택 pop) 또는 (제거 + 중력 + 공급)까지 처리합니다.
    async handleHitColumn(colHit) {
        const e0 = this.entAt(0, colHit);
        if (!e0) {
            // 타겟이 사라졌다면 최소한 현재 컬럼 예약은 해제
            this.colReserved[colHit] = false;
            this.colBusy[colHit] = false;
            return;
        }
        // ✅ 2x2 포함 “영향 컬럼 전체”(동일 블럭 중복 타격/중복 발사 방지 단위)
        const sp0 = (e0.view.depth ?? 1) <= 1 ? e0.view.getSpecial() : null;
        const affectedCols = sp0?.t === 'CHAIN_SEG'
            ? this.chainGroupCols(String(sp0?.id ?? ''))
            : this.entCols(e0);
        // 이미 다른 히트가 처리 중이면 이번 히트는 무시하되, 예약만 풀어 교착을 방지합니다.
        for (const c of affectedCols) {
            if (this.colBusy[c]) {
                for (const cc of affectedCols)
                    this.colReserved[cc] = false;
                return;
            }
        }
        for (const c of affectedCols)
            this.colBusy[c] = true;
        try {
            // 스택/특수는 1x1에서만 사용(2x2는 일반 블럭으로 취급)
            const depthBefore = e0.view.depth ?? 1;
            const sp = depthBefore <= 1 ? e0.view.getSpecial() : null;
            // (0) LOCK(잠김)은 히트 무시(타수 차감도 하지 않음)
            if (sp?.t === 'LOCK' && !this.unlockedLocks.has(sp.id))
                return;
            // ✅ 유효 히트 1회 = remainingTiles 1 감소(=필요 탄 1 소모)
            this.remainingTiles = Math.max(0, this.remainingTiles - 1);
            // ✅ 히트 파티클(Pre_FX_Particle_Hit)
            // - 역할: 타격 피드백(스택/체인/HP 포함 모든 “유효 히트”에 공통)
            e0.view.playHitFx();
            // (0.5) 2x2(큰 블럭) HP 처리(HP가 남으면 유지)
            if (e0.w > 1 || e0.h > 1) {
                const side = colHit - e0.col < e0.w / 2 ? -1 : 1;
                e0.view.hitSide(side, this.tileSize * 0.08);
                const hpLeft = e0.view.decHp(1);
                if (hpLeft > 0) {
                    this.tweenPop(e0.view.node).catch(() => { });
                    return;
                }
                // hp==0: 제거 + 중력 + 공급
                await this.tweenScaleOut(e0.view.node);
                // ✅ 제거 파티클(Particle_Shatter) : 블럭 컬러에 맞춰 Start Color 적용
                e0.view.node.getWorldPosition(this._tmpAim);
                this.playShatterFxAtWorld(this._tmpAim, e0.view.colorId);
                // ✅ BIG LOCK 해제: 현재 BIG이 파괴되면 즉시 다음 BIG/SMALL로 재탐색 가능
                if (this.currentBigTargetId === (e0.id | 0))
                    this.currentBigTargetId = 0;
                this.removeEnt(e0);
                this._notifyBlockDestroyed(e0.worth);
                const moved = this.settleGravity();
                const spawned = this.fillTopHoles(affectedCols);
                this.revealHiddenAtBottom(affectedCols);

                const spSpawned = this.processSpawnerBoxes();
                for (const e of spSpawned)
                    this.snapEntImmediate(e);
                // ✅ 이동 Tween은 기다리지 않습니다(발사 템포 일정화)
                for (const e of moved)
                    this.moveEnt(e, 0.08).catch(() => { });
                for (const e of spawned)
                    this.moveEnt(e, 0.1).catch(() => { });
                return;
            }
            // (0) CHAIN_SEG: 체인 묶음은 "히트되면 꼬리부터" 1칸씩 제거됩니다.
            // - 현재 히트된 셀(e0)은 유지될 수 있으며(꼬리가 아닐 경우), 실제 제거는 tail 셀에서 일어납니다.
            // - Export 시 chainId/chainOrder가 포함되면 그 순서를 따릅니다.
            if (sp?.t === 'CHAIN_SEG') {
                const chainId = String(sp?.id ?? '');
                let tail = null;
                let bestOrder = -2147483648;
                for (const ee of this.ents.values()) {
                    const s2 = (ee.view.depth ?? 1) <= 1 ? ee.view.getSpecial() : null;
                    if ((s2 == null ? void 0 : s2.t) !== 'CHAIN_SEG')
                        continue;
                    if (String((s2 == null ? void 0 : s2.id) ?? '') !== chainId)
                        continue;
                    const ord = Number.isFinite(s2 == null ? void 0 : s2.order) ? (s2.order | 0) : 0;
                    if (!tail || ord > bestOrder) {
                        tail = ee;
                        bestOrder = ord;
                    }
                }
                const target = tail ?? e0;
                const depthT = (target.view.depth ?? 1) | 0;
                if (depthT > 1) {
                    await this.tweenPop(target.view.node);
                    target.view.popTop();
                    return;
                }
                await this.tweenScaleOut(target.view.node);
                target.view.node.getWorldPosition(this._tmpAim);
                this.playShatterFxAtWorld(this._tmpAim, target.view.colorId);
                this.removeEnt(target);
                this._notifyBlockDestroyed(target.worth);
                const moved = this.settleGravity();
                const spawned = this.fillTopHoles(affectedCols);
                this.revealHiddenAtBottom(affectedCols);
                const spSpawned = this.processSpawnerBoxes();
                for (const e of spSpawned)
                    this.snapEntImmediate(e);
                for (const e of moved) {
                    this.moveEnt(e, 0.08).catch(() => { });
                }
                for (const e of spawned) {
                    this.moveEnt(e, 0.1).catch(() => { });
                }
                return;
            }

            // (0) CHAIN: hp를 줄이고, hp가 남으면 타일은 유지(이미 1타 차감)
            if (sp?.t === 'CHAIN') {
                const nextHp = Math.max(0, (sp.hp | 0) - 1);
                if (nextHp > 0) {
                    await this.tweenPop(e0.view.node);
                    e0.view.setSpecial({ t: 'CHAIN', hp: nextHp });
                    return;
                }
                // hp가 0이면 이 히트에서 바로 제거 처리
                e0.view.setSpecial(null);
            }
            // (A) 스택이 남아있으면: 1겹만 pop하고 중력/공급 없음(이미 1타 차감)
            if (depthBefore > 1) {
                await this.tweenPop(e0.view.node);
                e0.view.popTop();
                return;
            }
            // (1) KEY: 키를 얻으면 동일 id의 LOCK을 전부 해제
            if (sp?.t === 'KEY') {
                this.unlockedLocks.add(sp.id);
                e0.view.setSpecial(null);
            }
            // (1) SPAWNER: 미리 준비된 queue를 현재 컬럼 공급에 주입(타수는 이미 선계산되어 있음)
            if (sp?.t === 'SPAWNER') {
                const q = Array.isArray(sp.queue) ? sp.queue : [];
                if (q.length > 0) {
                    // supply는 pop()이므로 reverse 해서 unshift
                    const rev = q.slice().reverse();
                    this.colSupply[colHit].unshift(...rev);
                }
                e0.view.setSpecial(null);
            }
            // (B) 제거(이미 1타 차감)
            await this.tweenScaleOut(e0.view.node);
            // ✅ 제거 파티클(Particle_Shatter) : 블럭 컬러에 맞춰 Start Color 적용
            e0.view.node.getWorldPosition(this._tmpAim);
            this.playShatterFxAtWorld(this._tmpAim, e0.view.colorId);
            this.removeEnt(e0);
            this._notifyBlockDestroyed(e0.worth);
            const moved = this.settleGravity();
            const spawned = this.fillTopHoles(affectedCols);
            // ✅ 히든 블럭 공개/변환 트리거
            // - 역할: 일반(1x1) 블럭 제거 후 중력/공급으로 인해 바닥(row=0)에 히든이 닿을 수 있으므로 즉시 처리
            // - 성능: 영향 컬럼만 전달(내부는 안전하게 처리)
            this.revealHiddenAtBottom(affectedCols);

            const spSpawned = this.processSpawnerBoxes();
            for (const e of spSpawned)
                this.snapEntImmediate(e);
            // ✅ 이동 Tween은 기다리지 않습니다(발사 템포 일정화)
            for (const e of moved)
                this.moveEnt(e, 0.08).catch(() => { });
            for (const e of spawned)
                this.moveEnt(e, 0.1).catch(() => { });
        }
        finally {
            // ✅ 어떤 경로로 빠져나가든 “영향 컬럼 전체” 정리
            for (const c of affectedCols) {
                this.colReserved[c] = false;
                this.colBusy[c] = false;
            }
        }
    }
    // ---------------- 진행도 ----------------
    // 블럭이 완전히 제거될 때만 진행도를 올리고 콜백을 호출합니다.
    _notifyBlockDestroyed(worth) {
        const t = this._totalBlocks | 0;
        if (t <= 0)
            return;
        const w = Math.max(0, worth | 0);
        if (w <= 0)
            return;
        const next = this._destroyedBlocks + w;
        this._destroyedBlocks = next > t ? t : next;
        const cb = this._onBlockDestroyed;
        if (cb) {
            try {
                cb(this._destroyedBlocks, t);
            }
            catch { }
        }
    }
    // ---------------- 엔티티/점유 ----------------
    // (row,col)에 점유된 엔티티를 반환합니다.
    entAt(row, col) {
        if (row < 0 || row >= this.rows || col < 0 || col >= this.cols)
            return null;
        const id = this.occ[this.indexOf(row, col)];
        if (id < 0)
            return null;
        return this.ents.get(id) ?? null;
    }
    // ✅ CHAIN_SEG(체인 묶음) 예약/바쁨 처리용: 체인 묶음이 점유하는 "전체 컬럼"을 반환
    // - 체인 히트 시 꼬리가 다른 컬럼에서 제거될 수 있으므로, 묶음 전체를 동시에 쏘지 못하게 막습니다.
    chainGroupCols(chainId) {
        const set = new Set();
        const id = String(chainId ?? '');
        for (const ee of this.ents.values()) {
            const s2 = (ee.view.depth ?? 1) <= 1 ? ee.view.getSpecial() : null;
            if ((s2 == null ? void 0 : s2.t) !== 'CHAIN_SEG')
                continue;
            if (String((s2 == null ? void 0 : s2.id) ?? '') !== id)
                continue;
            for (let dx = 0; dx < ee.w; dx++) {
                const c = (ee.col + dx) | 0;
                if (c >= 0 && c < this.cols)
                    set.add(c);
            }
        }
        const out = Array.from(set);
        out.sort((a, b) => a - b);
        return out;
    }

    // 엔티티가 점유하는 컬럼 목록을 반환합니다.
    entCols(e) {
        const out = [];
        for (let dx = 0; dx < e.w; dx++) {
            const c = e.col + dx;
            if (c >= 0 && c < this.cols)
                out.push(c);
        }
        return out;
    }
    // 1x1 엔티티(작은 블럭)를 생성합니다.
    spawnSmall(row, col) {
        const tv = this.obtainTile('SMALL');
        if (!tv)
            return null;
        tv.row = row;
        tv.col = col;
        tv.clear();
        tv.node.active = true;
        tv.node.setScale(1, 1, 1);
        const ent = {
            id: this.nextEntId++,
            row,
            col,
            w: 1,
            h: 1,
            view: tv,
            worth: 1,
        };
        // 배치(라인 레이아웃이면 Line_XX / 아니면 tileLayer 기준 10x10)
        const t = this.entParentAndLocal(ent);
        tv.node.setParent(t.parent);
        tv.node.setPosition(t.local);
        return ent;
    }
    // 2x2 엔티티(큰 블럭)를 생성합니다.
    spawnBig(row, col) {
        const tv = this.obtainTile('BIG');
        if (!tv)
            return null;
        tv.row = row;
        tv.col = col;
        tv.clear();
        tv.node.active = true;
        tv.node.setScale(1, 1, 1);
        const ent = {
            id: this.nextEntId++,
            row,
            col,
            w: 2,
            h: 2,
            view: tv,
            worth: 4,
        };
        // 배치(라인 레이아웃이면 Line_XX / 아니면 tileLayer 기준 10x10)
        const t = this.entParentAndLocal(ent);
        tv.node.setParent(t.parent);
        tv.node.setPosition(t.local);
        return ent;
    }
    // 엔티티를 Map/점유 그리드에 반영합니다.
    commitEnt(e) {
        this.ents.set(e.id, e);
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= this.rows || c < 0 || c >= this.cols)
                    continue;
                this.occ[this.indexOf(r, c)] = e.id;
            }
        }
    }
    // 엔티티를 제거하고 노드를 풀로 반환합니다.
    removeEnt(e) {
        this.ents.delete(e.id);
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= this.rows || c < 0 || c >= this.cols)
                    continue;
                if (this.occ[this.indexOf(r, c)] === e.id)
                    this.occ[this.indexOf(r, c)] = -1;
            }
        }
        this.releaseTile(e.view);
    }
    // 모든 엔티티를 제거(스테이지 로드 시 호출).
    clearAllEntities() {
        for (const e of this.ents.values()) {
            cc_1.Tween.stopAllByTarget(e.view.node);
            this.releaseTile(e.view);
        }
        this.ents.clear();
        this._movingEntRef.clear();
        this.occ.fill(-1);
        this.nextEntId = 1;
    }
    // ---------------- 중력/공급 ----------------
    // ✅ 중력으로 엔티티를 아래로 떨어뜨리고, 이동한 엔티티 목록을 반환합니다.
    // - 기존처럼 pass 반복 + 매번 sort 하지 않고,
    //   바닥쪽(row 낮은)부터 "가능한 만큼" 한 번에 내립니다(정렬 1회).
    settleGravity() {
        const moved = new Set();
        // 바닥부터 처리(낮은 row 먼저)
        const list = Array.from(this.ents.values()).sort((a, b) => a.row - b.row);
        for (const e of list) {
            // 가능한 만큼 아래로 내림
            while (this.canFall(e)) {
                this.moveDownOne(e);
                moved.add(e);
            }
        }
        return Array.from(moved);
    }
    // ✅ 아이템3 전용: 특정 엔티티 id는 제외하고 중력 정렬합니다.
    // - 역할: 선택된 색상 블럭을 "빼고" 나머지만 자연스럽게 내려오게 함
    // - 성능: 배열/Set을 재사용해서 GC를 최소화
    _settleGravityExcluding(excludeIds, outMoved) {
        this._tmpGravityList.length = 0;
        for (const e of this.ents.values()) {
            if (excludeIds.has(e.id))
                continue;
            this._tmpGravityList.push(e);
        }
        // 바닥부터 처리(낮은 row 먼저)
        this._tmpGravityList.sort((a, b) => a.row - b.row);
        for (let i = 0; i < this._tmpGravityList.length; i++) {
            const e = this._tmpGravityList[i];
            let movedOnce = false;
            while (this.canFall(e)) {
                this.moveDownOne(e);
                movedOnce = true;
            }
            if (movedOnce)
                outMoved.push(e);
        }
    }
    // 엔티티가 아래로 1칸 떨어질 수 있는지 확인합니다.
    canFall(e) {
        // ✅ 생성박스(SPAWNER_BOX)는 "보드에 배치되면 절대 낙하하지 않음"(고정 오브젝트)
        const sp = e.view?.getSpecial?.();
        if (sp?.t === 'SPAWNER_BOX')
            return false;
        if (e.row <= 0)
            return false;
        const belowRow = e.row - 1;
        for (let dx = 0; dx < e.w; dx++) {
            const c = e.col + dx;
            if (c < 0 || c >= this.cols)
                return false;
            const idBelow = this.occ[this.indexOf(belowRow, c)];
            if (idBelow >= 0 && idBelow !== e.id)
                return false;
        }
        return true;
    }
    // 엔티티를 아래로 1칸 이동(점유 그리드만 갱신, 노드 위치는 트윈에서 처리).
    moveDownOne(e) {
        // 현재 footprint clear
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= this.rows || c < 0 || c >= this.cols)
                    continue;
                if (this.occ[this.indexOf(r, c)] === e.id)
                    this.occ[this.indexOf(r, c)] = -1;
            }
        }
        e.row -= 1;
        e.view.row = e.row;
        // 새 footprint set
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= this.rows || c < 0 || c >= this.cols)
                    continue;
                this.occ[this.indexOf(r, c)] = e.id;
            }
        }
    }
    // 영향을 받은 컬럼의 "위쪽 빈칸"을 supply로 채워 새 엔티티를 반환합니다.
    fillTopHoles(cols) {
        const out = [];
        const uniq = Array.from(new Set(cols)).filter((c) => c >= 0 && c < this.cols);
        const removeTokenFromCol = (col, token) => {
            const arr = this.colSupply[col];
            if (!Array.isArray(arr) || arr.length <= 0)
                return;
            for (let i = arr.length - 1; i >= 0; i--) {
                if ((arr[i] | 0) === (token | 0)) {
                    arr.splice(i, 1);
                    return;
                }
            }
        };
        for (const c of uniq) {
            // topmost occupied row
            let topOcc = -1;
            for (let r = this.rows - 1; r >= 0; r--) {
                if (this.occ[this.indexOf(r, c)] >= 0) {
                    topOcc = r;
                    break;
                }
            }
            // 위쪽 빈칸(row=rows-1..topOcc+1)을 채움
            for (let r = this.rows - 1; r > topOcc; r--) {
                if (this.occ[this.indexOf(r, c)] >= 0)
                    continue;
                const next = this.colSupply[c]?.pop();
                if (typeof next !== 'number')
                    break;
                // ✅ 공급 LARGE 토큰 처리: 4개 토큰을 1개의 BIG 엔티티로 합쳐 생성합니다.
                if (next >= Types_1.SUPPLY_LARGE_BASE) {
                    const raw = (next - Types_1.SUPPLY_LARGE_BASE) | 0;
                    const idx = Math.floor(raw / 4);
                    const cell = raw - idx * 4; // 0..3
                    const dx = cell & 1;
                    const dy = (cell / 2) | 0;
                    const def = this.supplyLargeDefs?.[idx];
                    if (!def) {
                        // 정의가 없으면 안전하게 되돌리고 중단
                        this.colSupply[c]?.push(next);
                        // BIG 토큰은 (2x2 자리/정의)가 준비될 때까지 대기해야 하므로
                        // 현재 row는 비워두고 다음 row를 계속 채웁니다.
                        continue;
                    }
                    const anchorCol = (c - dx) | 0;
                    const anchorRow = (r - dy) | 0;
                    // 경계/빈칸 조건(2x2 전체가 비어있어야 BIG을 생성 가능)
                    const canPlace = anchorCol >= 0 &&
                        anchorCol + 1 < this.cols &&
                        anchorRow >= 0 &&
                        anchorRow + 1 < this.rows &&
                        this.occ[this.indexOf(anchorRow, anchorCol)] < 0 &&
                        this.occ[this.indexOf(anchorRow, anchorCol + 1)] < 0 &&
                        this.occ[this.indexOf(anchorRow + 1, anchorCol)] < 0 &&
                        this.occ[this.indexOf(anchorRow + 1, anchorCol + 1)] < 0;
                    if (!canPlace) {
                        // 아직 BIG을 놓을 수 없으면 되돌리고 이 컬럼 채우기 중단(순서 보장)
                        this.colSupply[c]?.push(next);
                        // 현재 row는 비워두고, 아래 row에서 다시 시도할 수 있게 진행합니다.
                        // (top row에서는 2x2를 놓을 수 없는 케이스가 많아 여기서 break 하면 공급이 멈춘 것처럼 보입니다)
                        continue;
                    }
                    const e = this.spawnBig(anchorRow, anchorCol);
                    if (!e) {
                        this.colSupply[c]?.push(next);
                        // 생성 실패 시에도 공급 순서를 유지한 채 다음 row를 채웁니다.
                        continue;
                    }
                    e.view.setTop(def.colorId | 0);
                    e.view.setHidden(!!def.hidden);
                    e.view.setHp(def.hp ?? 1, def.hpMax ?? def.hp ?? 1);
                    e.view.setSpecial(null);
                    // 새로 생성된 블럭은 살짝 위에서 떨어뜨립니다.
                    const yOff = this.useLineLayout
                        ? this.lineDy * 0.6
                        : this.stepY > 0
                            ? this.stepY * 0.6
                            : this.tileSize * 0.6;
                    const { parent, local } = this.entParentAndLocal(e);
                    e.view.node.setParent(parent);
                    e.view.node.setPosition(local.x, local.y + yOff, 0);
                    this.commitEnt(e);
                    out.push(e);
                    // 나머지 3개 토큰 제거(이미 BIG이 2x2를 점유하므로 별도 생성되면 안 됨)
                    for (let cc = 0; cc < 4; cc++) {
                        if (cc === cell)
                            continue;
                        const token = (Types_1.SUPPLY_LARGE_BASE + idx * 4 + cc) | 0;
                        const odx = cc & 1;
                        const ocol = (anchorCol + odx) | 0;
                        // 같은 컬럼에서든 옆 컬럼에서든 스택 어딘가에 존재하는 토큰 1개만 제거
                        removeTokenFromCol(ocol, token);
                    }
                    // 이 셀은 BIG으로 채웠으므로 다음 r로 진행
                    continue;
                }
                const hidden = next < 0;
                const colorId = hidden ? -next - 1 : next;
                if (colorId < 0)
                    break;
                const e = this.spawnSmall(r, c);
                if (!e)
                    break;
                e.view.setTop(colorId);
                e.view.setHidden(hidden);
                e.view.setSpecial(null);
                // 새로 생성된 블럭은 살짝 위에서 떨어뜨립니다.
                const yOff = this.useLineLayout
                    ? this.lineDy * 0.6
                    : this.stepY > 0
                        ? this.stepY * 0.6
                        : this.tileSize * 0.6;
                const { parent, local } = this.entParentAndLocal(e);
                e.view.node.setParent(parent);
                e.view.node.setPosition(local.x, local.y + yOff, 0);
                this.commitEnt(e);
                out.push(e);
            }
        }
        return out;
    }
    // ✅ 바닥(row=0)에 도달한 히든 블럭을 공개합니다.
    // - 요구사항: "히든 블럭에 인접(4방향)한 같은색 히든 블럭"만 함께 공개되어야 합니다.
    // - 즉, 일반(비히든) 블럭의 색상을 바꾸는 변환은 하지 않습니다.
    // - 안정성: cols 힌트로 제한하면 누락이 생길 수 있어(중력/공급/아이템), 전체 컬럼을 검사합니다.
    revealHiddenAtBottom(cols) {
        const rows = this.rows | 0;
        const colsN = this.cols | 0;
        const inBounds = (r, c) => r >= 0 && r < rows && c >= 0 && c < colsN;
        // 0) 바닥 히든 후보 수집
        this._tmpRevealBottomHidden.length = 0;
        const pushHiddenAtCol = (c) => {
            const id = this.occ[this.indexOf(0, c)];
            if (id < 0)
                return;
            const e = this.ents.get(id);
            if (!e)
                return;
            const v = e.view;
            if (!v?.isHidden?.())
                return;
            this._tmpRevealBottomHidden.push(id);
        };
        // ✅ cols 힌트는 무시하고 항상 전체 컬럼을 검사합니다.
        for (let c = 0; c < colsN; c++)
            pushHiddenAtCol(c);
        if (this._tmpRevealBottomHidden.length === 0)
            return;
        const q = this._tmpRevealQueue;
        const visited = this._tmpRevealVisited;
        const entSet = this._tmpRevealEntSet;
        // 1) 바닥 히든마다: "같은 hiddenColor" 히든 연결 컴포넌트만 공개
        for (let i = 0; i < this._tmpRevealBottomHidden.length; i++) {
            const rootId = this._tmpRevealBottomHidden[i];
            const root = this.ents.get(rootId);
            if (!root)
                continue;
            const rv = root.view;
            if (!rv?.isHidden?.())
                continue;
            const hiddenColor = rv.colorId | 0;
            visited.fill(0);
            q.length = 0;
            entSet.clear();
            // root footprint에서 시작
            for (let dy = 0; dy < root.h; dy++) {
                for (let dx = 0; dx < root.w; dx++) {
                    const rr = root.row + dy;
                    const cc = root.col + dx;
                    if (!inBounds(rr, cc))
                        continue;
                    q.push(rr * colsN + cc);
                }
            }
            while (q.length > 0) {
                const key = q.pop();
                if (visited[key])
                    continue;
                visited[key] = 1;
                const r = (key / colsN) | 0;
                const c = key - r * colsN;
                const id = this.occ[this.indexOf(r, c)];
                if (id < 0)
                    continue;
                const e = this.ents.get(id);
                if (!e)
                    continue;
                const v = e.view;
                if (!v?.isHidden?.())
                    continue;
                if ((v.colorId | 0) !== hiddenColor)
                    continue;
                if (!entSet.has(id)) {
                    entSet.add(id);
                    // ✅ 역할: 히든 해제(스프라이트 갱신은 TileView.refresh에서 처리)
                    v.setHidden(false);
                }
                // footprint 주변 4방향 확장(셀 기반)
                for (let dy = 0; dy < e.h; dy++) {
                    for (let dx = 0; dx < e.w; dx++) {
                        const rr = e.row + dy;
                        const cc = e.col + dx;
                        if (rr + 1 < rows)
                            q.push((rr + 1) * colsN + cc);
                        if (rr - 1 >= 0)
                            q.push((rr - 1) * colsN + cc);
                        if (cc + 1 < colsN)
                            q.push(rr * colsN + (cc + 1));
                        if (cc - 1 >= 0)
                            q.push(rr * colsN + (cc - 1));
                    }
                }
            }
        }
        this.processKeysAtBottom();
    }

    // ✅ KEY: 키 블럭이 바닥(0행)에 닿으면 즉시 해당 id의 LOCK을 해제
    // - 키가 제거(파괴)되지 않아도, 바닥에 '닿는 순간' 해제되도록 처리
    processKeysAtBottom() {
        for (let c = 0; c < this.cols; c++) {
            const id = this.occ[this.indexOf(0, c)];
            if (id < 0)
                continue;
            const e = this.ents.get(id);
            if (!e)
                continue;
            if ((e.view.depth ?? 1) > 1)
                continue;
            const sp = e.view.getSpecial();
            if ((sp == null ? void 0 : sp.t) !== 'KEY')
                continue;
            this.unlockedLocks.add(sp.id);
        }
    }

    // ✅ 생성박스 처리
    // - 조건: 박스는 낙하하지 않고 고정. 박스 바로 아래(2x1 spawn row)가 비어있는 칸만큼 생성.
    // - 동작: spawn row의 각 셀이 비어있으면 queue에서 1개씩 꺼내 스몰 블럭을 생성(좌→우).
    // - queue 길이 = 남은 "생성할 블럭 수". 1개 생성할 때마다 1개 소비.
    // - queue가 소진되면 박스 몸통을 제거(타격 대상이 아님)
    processSpawnerBoxes() {
        const out = [];
        const spawners = Array.from(this.ents.values()).filter((e) => {
            const sp = e.view?.getSpecial?.();
            return sp?.t === 'SPAWNER_BOX';
        });
        for (const e of spawners) {
            if (e.w !== 2 || e.h !== 1)
                continue;
            const sp = e.view.getSpecial();
            if (!sp || sp.t !== 'SPAWNER_BOX')
                continue;
            const q = Array.isArray(sp.queue) ? sp.queue : [];
            const colorsRaw = Array.isArray(sp.colors) ? sp.colors : null;
            const leftColor = ((colorsRaw?.[0] ?? q[0] ?? 0) | 0);
            const rightColor = ((colorsRaw?.[1] ?? q[1] ?? leftColor) | 0);
            let next = ((sp.next ?? 0) | 0) & 1;
            if (q.length <= 0) {
                this.removeEnt(e);
                continue;
            }
            const c0 = e.col | 0;
            if (c0 < 0 || c0 + 1 >= this.cols)
                continue;
            const spawnRow = (e.row | 0) - 1;
            if (spawnRow < 0 || spawnRow >= this.rows)
                continue;
            const trySpawnAt = (col) => {
                if (q.length <= 0)
                    return false;
                if (this.entAt(spawnRow, col) != null)
                    return false;
                let dropRow = spawnRow;
                while (dropRow > 0 && this.entAt(dropRow - 1, col) == null)
                    dropRow--;
                const b = this.spawnSmall(dropRow, col);
                if (!b)
                    return false;
                // ✅ 성공적으로 생성된 경우에만 queue 소비
                q.shift();
                // ✅ v48+: 생성 색상은 셀(좌/우)에 고정
                const color = (next === 0 ? leftColor : rightColor) | 0;
                next = (next ^ 1) & 1;
                b.view.setTop(color);
                b.view.setHidden(false);
                b.view.setSpecial(null);
                this.commitEnt(b);
                out.push(b);
                return true;
            };
            let guard = 0;
            while (q.length > 0) {
                const progressedL = trySpawnAt(c0);
                const progressedR = trySpawnAt(c0 + 1);
                if (!progressedL && !progressedR)
                    break;
                guard++;
                if (guard > 200)
                    break;
            }
            e.view.setSpecial({ t: 'SPAWNER_BOX', queue: q, colors: [leftColor, rightColor], next });
            if (q.length <= 0) {
                this.removeEnt(e);
            }
        }
        return out;
    }
    // ---------------- Pool / Init ----------------
    // ✅ tileLayer(UITransform) 크기를 기준으로 10x10 셀 간격/원점을 캐싱합니다.
    // - 라인 레이아웃(useLineLayout)이면 사용하지 않습니다.
    // - tileLayer의 anchorX/anchorY를 반영해서 "어떤 앵커"여도 정확히 10x10이 들어가게 합니다.
    cacheTileLayerGridMetrics() {
        if (this.useLineLayout)
            return;
        if (!this.tileLayer || !this.tileLayer.isValid)
            return;
        const ui = this.tileLayer.getComponent(cc_1.UITransform);
        if (!ui)
            return;
        const w = Math.max(1, ui.width);
        const h = Math.max(1, ui.height);
        this.gridW = w;
        this.gridH = h;
        // tileLayer 크기만큼 10x10으로 "딱 붙게"
        this.stepX = w / this.cols;
        this.stepY = h / this.rows;
        // ✅ 핵심: AR 좌표의 (0,0)은 anchor 기준이므로 anchorX/Y 반영
        // 좌하단 셀(0,0)의 중심이 tileLayer 로컬 좌표에서 어디인지 계산
        const ax = ui.anchorX; // 0~1
        const ay = ui.anchorY; // 0~1
        // tileLayer 로컬에서 왼쪽 끝 = -w*ax, 아래 끝 = -h*ay
        this.originX = -w * ax + this.stepX * 0.5;
        this.originY = -h * ay + this.stepY * 0.5;
    }
    // ✅ 프리팹/레이어가 준비되면 풀을 초기화합니다.
    initOnce() {
        if (this.initialized || this.initFailed)
            return;
        // Headless validator: presentation-only initialization is unnecessary.
        if (globalThis.__HEADLESS__) {
            this.initialized = true;
            return;
        }
        if (!this.tileLayer || !this.tilePrefab) {
            if (!this.initFailLogged) {
                this.initFailLogged = true;
                if (!this.tileLayer)
                    console.error('[Board] tileLayer is null (UI2/Enemys/Blocks 연결 필요)');
                if (!this.tilePrefab)
                    console.error('[Board] tilePrefab(Pre_Enemy_Block_Small) is null (Prefab 연결 필요)');
            }
            this.initFailed = true;
            return;
        }
        // UI2의 Line_01~ 레이아웃이면 자동으로 라인/컬럼 좌표를 캐싱
        this.setupLineLayoutIfAny();
        // ✅ 라인 레이아웃이 아니라면 tileLayer 크기 기반 10x10 자동 배치 캐시
        this.cacheTileLayerGridMetrics();
        // 타일/총알 풀 예열(최초 1회)
        this.prewarmTiles('SMALL', this.warmupSmall);
        this.prewarmTiles('BIG', this.warmupBig);
        const projWarm = (this.warmupProjectiles | 0) > 0 ? this.warmupProjectiles | 0 : Config_1.PROJECTILE_POOL_WARMUP;
        this.prewarmProjectiles(projWarm);
        // ✅ 제거 FX(Particle_Shatter) 풀 초기화(하드코딩 없는 자동 수명 계산 포함)
        this.initShatterFxOnce();
        this.initialized = true;
    }
    // ✅ 제거(Particle_Shatter) FX 풀을 1회 초기화합니다.
    // - 역할: 블럭 노드가 즉시 풀로 반환되어도 파티클은 별도 노드로 끝까지 재생
    // - 성능: 템플릿은 1회만 추출, NodePool로 재사용
    // - 수명: ParticleSystem 설정(duration/startDelay/startLifetime) 기반으로 자동 회수 시간 계산(1.4초 하드코딩 제거)
    initShatterFxOnce() {
        if (this.shatterFxTemplate && this.shatterFxTemplate.isValid)
            return;
        if (!this.tilePrefab)
            return;
        if (!this.fxLayer)
            this.fxLayer = this.tileLayer; // FX 레이어가 없으면 tileLayer 사용
        // tilePrefab을 임시 1회 인스턴스화해서 Particle_Shatter 템플릿을 추출
        const tmp = (0, cc_1.instantiate)(this.tilePrefab);
        tmp.active = false;
        const sh = this.findNodeByName(tmp, 'Particle_Shatter');
        if (!sh) {
            console.warn('[Board] Particle_Shatter 노드를 찾지 못했습니다. 블럭 프리팹 내부에 Particle_Shatter가 있는지 확인해주세요.');
            tmp.destroy();
            return;
        }
        sh.active = false;
        this.shatterFxTemplate = (0, cc_1.instantiate)(sh);
        this.shatterFxTemplate.active = false;
        // ✅ 템플릿 기반 “자동 회수 딜레이” 계산(모든 ParticleSystem 중 최대값)
        this.shatterFxRecycleDelay = this.calcParticleNodeRecycleDelay(this.shatterFxTemplate);
        const warm = Math.max(0, Math.floor(this.warmupShatterFx));
        for (let i = 0; i < warm; i++) {
            const n = (0, cc_1.instantiate)(this.shatterFxTemplate);
            n.active = false;
            this.shatterFxPool.put(n);
        }
        tmp.destroy();
    }
    // ✅ 파티클 노드가 “완전히 끝날 때”까지의 최대 시간을 계산합니다.
    // - 구성: startDelay(max) + duration + startLifetime(max) + 안전 마진
    calcParticleNodeRecycleDelay(root) {
        const ps = root.getComponentsInChildren(cc_1.ParticleSystem);
        let maxT = 0;
        for (let i = 0; i < ps.length; i++) {
            const p = ps[i];
            // loop가 켜져있으면 회수 불가하므로, 재생 시 loop를 false로 강제합니다.
            // (여기서는 계산만)
            const delay = p.startDelay ? p.startDelay.getMax() : 0;
            const life = p.startLifetime ? p.startLifetime.getMax() : 0;
            const dur = Number.isFinite(p.duration) ? Math.max(0, p.duration) : 0;
            const t = delay + dur + life;
            if (t > maxT)
                maxT = t;
        }
        // 안전 마진(프레임/스케줄 지연 보정). 1.4초 같은 고정값이 아니라, 계산값에 소량만 더함.
        return Math.max(0.05, maxT + 0.05);
    }
    // ✅ 이름으로 자식 노드를 DFS로 탐색합니다.
    // - 역할: 프리팹 구조가 약간 달라도 Particle_Shatter를 찾을 수 있게 보강
    findNodeByName(root, name) {
        const stack = [root];
        while (stack.length) {
            const n = stack.pop();
            if (n.name === name)
                return n;
            const ch = n.children;
            for (let i = ch.length - 1; i >= 0; i--)
                stack.push(ch[i]);
        }
        return null;
    }
    // ✅ 제거 FX(Particle_Shatter)를 월드 좌표에서 재생합니다.
    // - 역할: 블럭 제거 시 파편 파티클의 Start Color를 “블럭 색상”으로 맞춰 보여줌
    playShatterFxAtWorld(worldPos, colorId) {
        if (!this.shatterFxTemplate || !this.shatterFxTemplate.isValid)
            return;
        const parent = this.fxLayer ?? this.tileLayer;
        if (!parent || !parent.isValid)
            return;
        const fx = this.shatterFxPool.size() > 0 ? this.shatterFxPool.get() : (0, cc_1.instantiate)(this.shatterFxTemplate);
        fx.active = true;
        fx.setScale(1, 1, 1);
        fx.setParent(parent);
        AudioManager_1.AudioManager.I?.playSfxByIndex(3, { volume: 1.0, minIntervalMs: 8 });
        const ui = parent.getComponent(cc_1.UITransform);
        const local = ui ? ui.convertToNodeSpaceAR(worldPos) : worldPos;
        fx.setPosition(local);
        // Start Color를 해당 블럭 컬러로 세팅
        const c = ColorPalette_1.ColorPalette.get(colorId);
        const ps = fx.getComponentsInChildren(cc_1.ParticleSystem);
        for (let i = 0; i < ps.length; i++) {
            const p = ps[i];
            p.playOnAwake = false;
            // loop 방지: 제거 FX는 1회 재생이 정상
            if (p.loop)
                p.loop = false;
            // Start Color 강제 적용(GradientRange.Mode.Color)
            try {
                const sc = p.startColor;
                sc.mode = cc_1.GradientRange.Mode.Color;
                sc.color.r = c.r;
                sc.color.g = c.g;
                sc.color.b = c.b;
                sc.color.a = 255;
            }
            catch {
                // ignore
            }
            try {
                p.stop();
                p.clear();
                p.play();
            }
            catch {
                // ignore
            }
        }
        // ✅ 하드코딩 제거: 템플릿 설정 기반 자동 회수
        const delay = this.shatterFxRecycleDelay > 0 ? this.shatterFxRecycleDelay : 0.05;
        this.scheduleOnce(() => {
            try {
                const ps2 = fx.getComponentsInChildren(cc_1.ParticleSystem);
                for (let i = 0; i < ps2.length; i++) {
                    try {
                        ps2[i].stop();
                        ps2[i].clear();
                    }
                    catch {
                        // ignore
                    }
                }
            }
            catch {
                // ignore
            }
            fx.active = false;
            fx.removeFromParent();
            this.shatterFxPool.put(fx);
        }, delay);
    }
    // // UI2 Blocks/Line_01~15 구조면 라인/컬럼 좌표를 캐싱하고 더미 슬롯을 숨깁니다.
    // // 단, "정확히 10x10 그리드"로 쓰는 구조가 아닐 경우 라인 레이아웃을 사용하지 않습니다.
    setupLineLayoutIfAny() {
        if (!this.tileLayer)
            return;
        const test = this.tileLayer.getChildByName('Line_01');
        if (!test)
            return;
        const lines = [];
        for (let i = 1; i <= 99; i++) {
            const name = `Line_${String(i).padStart(2, '0')}`;
            const n = this.tileLayer.getChildByName(name);
            if (!n)
                break;
            lines.push(n);
        }
        // ✅ "rows(10)" 개가 정확히 준비되지 않으면 라인 레이아웃 OFF
        if (lines.length !== this.rows)
            return;
        // ✅ "cols(10)" 개 슬롯이 Line_01에 정확히 있어야 라인 레이아웃 ON
        const slotNodes = lines[0].children;
        if (slotNodes.length < this.cols)
            return;
        // ✅ 라인 이름(Line_01~)의 위/아래 배치는 프로젝트마다 다를 수 있으므로,
        //    실제 y 좌표 기준으로 "바닥(row=0) -> 위(row=rows-1)" 순서로 정렬합니다.
        // - 역할: row 감소/증가와 화면 상 이동 방향이 항상 일치하도록 보장
        // - 버그픽스: 타겟 제거 후 다음 라인이 내려오지 않던 현상(라인 매핑 뒤집힘)을 방지
        const sortedByY = lines.slice().sort((a, b) => a.position.y - b.position.y);
        // ✅ 정렬 후에도 cols 슬롯이 충분한지 재검증(안전장치)
        const bottomSlots = sortedByY[0]?.children ?? [];
        if (bottomSlots.length < this.cols)
            return;
        this.useLineLayout = true;
        this.lineNodes = sortedByY;
        this.bottomLineIdx = 0;
        this.lineDy = Math.abs(sortedByY[1].position.y - sortedByY[0].position.y);
        // // 컬럼 X는 "바닥 라인"의 자식(더미 슬롯) 위치를 사용
        // - 라인마다 동일한 슬롯 X를 공유한다는 전제(일반적인 그리드 프리팹)
        const xs = bottomSlots
            .map((c) => c.position.x)
            .slice(0)
            .sort((a, b) => a - b);
        this.colX = xs.slice(0, this.cols);
        // // 더미 슬롯을 숨김(겹침 방지)
        for (const ln of sortedByY) {
            for (const ch of ln.children) {
                // ✅ 이름 규칙이 프로젝트마다 달라서 "무조건" 숨기고 싶으면 조건을 더 넓히는 게 안전합니다.
                // 현재는 기존 조건 + 'Slot'/'Cell'류를 포함해 폭넓게 숨김.
                const nm = ch.name ?? '';
                if (nm.startsWith('Enemy_') ||
                    nm.startsWith('Block_') ||
                    nm.includes('Enemy_Block') ||
                    nm.includes('Slot') ||
                    nm.includes('Cell') ||
                    nm.includes('Grid')) {
                    ch.active = false;
                }
            }
        }
    }
    // 보드가 정상 초기화됐는지 반환합니다.
    isReady() {
        return this.initialized && !this.initFailed;
    }
    // 작은/큰 블럭(TileView) 노드를 풀에서 꺼냅니다.
    obtainTile(kind) {
        if (!this.tileLayer)
            return null;
        if (kind === 'BIG') {
            const prefab = this.bigTilePrefab ?? this.tilePrefab;
            if (!prefab)
                return null;
            const n = this.bigPool.size() > 0 ? this.bigPool.get() : (0, cc_1.instantiate)(prefab);
            n.__poolKind = 'BIG';
            n.parent = this.tileLayer;
            n.active = true;
            const tv = n.getComponent(TileView_1.TileView);
            if (!tv) {
                n.destroy();
                return null;
            }
            const anyN = n;
            if (!anyN.__boundItemTouch) {
                // // 역할: (BIG) 아이템3 선택용 터치 바인딩(풀 재사용 시 중복 바인딩 방지)
                anyN.__boundItemTouch = true;
                n.on(cc_1.Node.EventType.TOUCH_END, this._onTileTouchEnd, this);
            }
            return tv;
        }
        // SMALL
        if (!this.tilePrefab)
            return null;
        const n = this.smallPool.size() > 0 ? this.smallPool.get() : (0, cc_1.instantiate)(this.tilePrefab);
        n.__poolKind = 'SMALL';
        n.parent = this.tileLayer;
        n.active = true;
        const tv = n.getComponent(TileView_1.TileView);
        if (!tv) {
            n.destroy();
            return null;
        }
        const anyN = n;
        if (!anyN.__boundItemTouch) {
            // // 역할: (SMALL) 아이템3 선택용 터치 바인딩(풀 재사용 시 중복 바인딩 방지)
            // - 스몰 블럭이 터치 타겟이 되는 경우가 많아서 BIG과 동일하게 바인딩이 필요합니다.
            anyN.__boundItemTouch = true;
            n.on(cc_1.Node.EventType.TOUCH_END, this._onTileTouchEnd, this);
        }
        return tv;
    }
    // 블럭 노드를 풀로 반환합니다.
    releaseTile(tv) {
        const n = tv.node;
        cc_1.Tween.stopAllByTarget(n);
        tv.clear();
        tv.setHidden(false);
        tv.setSpecial(null);
        n.active = false;
        n.removeFromParent();
        const kind = n.__poolKind;
        if (kind === 'BIG')
            this.bigPool.put(n);
        else
            this.smallPool.put(n);
    }
    // 타일(블럭) 풀을 미리 채웁니다.
    prewarmTiles(kind, count) {
        const warm = Math.max(0, Math.floor(count));
        if (warm <= 0)
            return;
        if (kind === 'BIG') {
            const prefab = this.bigTilePrefab ?? this.tilePrefab;
            if (!prefab)
                return;
            for (let i = 0; i < warm; i++) {
                const n = (0, cc_1.instantiate)(prefab);
                n.__poolKind = 'BIG';
                n.active = false;
                this.bigPool.put(n);
            }
            return;
        }
        // SMALL
        if (!this.tilePrefab)
            return;
        for (let i = 0; i < warm; i++) {
            const n = (0, cc_1.instantiate)(this.tilePrefab);
            n.__poolKind = 'SMALL';
            n.active = false;
            this.smallPool.put(n);
        }
    }
    // 프로젝타일 풀을 미리 채웁니다.
    prewarmProjectiles(count) {
        if (!this.projectilePrefab)
            return;
        const warm = Math.max(0, Math.floor(count));
        for (let i = 0; i < warm; i++) {
            const n = (0, cc_1.instantiate)(this.projectilePrefab);
            n.active = false;
            this.projectilePool.put(n);
        }
    }
    // 프로젝타일을 풀에서 꺼냅니다(없으면 새로 생성).
    obtainProjectile() {
        if (!this.projectilePrefab)
            return null;
        const n = this.projectilePool.size() > 0 ? this.projectilePool.get() : (0, cc_1.instantiate)(this.projectilePrefab);
        return n;
    }
    // 프로젝타일을 풀로 반환합니다.
    releaseProjectile(n) {
        cc_1.Tween.stopAllByTarget(n);
        n.active = false;
        n.removeFromParent();
        this.projectilePool.put(n);
    }
    // 컬럼 상태 플래그를 초기화합니다.
    resetBusyFlags() {
        for (let c = 0; c < this.cols; c++) {
            this.colReserved[c] = false;
            this.colBusy[c] = false;
        }
    }
    // busy를 전부 해제합니다(예외/에러 복구용).
    clearBusyAll() {
        for (let c = 0; c < this.cols; c++)
            this.colBusy[c] = false;
    }
    // 엔티티를 목표 좌표로 이동(필요 시 Line_XX로 리페어런트)합니다.
    _incMoving(entId) {
        const id = entId | 0;
        const c = this._movingEntRef.get(id) ?? 0;
        this._movingEntRef.set(id, c + 1);
    }
    _decMoving(entId) {
        const id = entId | 0;
        const c = (this._movingEntRef.get(id) ?? 0) - 1;
        if (c > 0)
            this._movingEntRef.set(id, c);
        else
            this._movingEntRef.delete(id);
    }
    moveEnt(e, duration) {
        const n = e.view.node;
        const t = this.entParentAndLocal(e);
        if (!n || !t.parent)
            return Promise.resolve();
        // ✅ moving ref-count 증가(타겟 선택에서 제외용)
        this._incMoving(e.id);
        // Line 레이아웃에서는 row 변화 시 부모(Line)가 바뀌므로,
        // 부모가 다르면 월드좌표 유지로 리페어런트 후 이동합니다.
        const p = n.parent !== t.parent
            ? this.tweenMoveReparent(n, t.parent, t.local, duration)
            : this.tweenMove(n, t.local, duration);
        return p.then(() => {
            this._decMoving(e.id);
        }, () => {
            this._decMoving(e.id);
        });
    }
    // ---------------- Tween Helpers ----------------
    // 제거 시 스케일을 줄이며 숨깁니다.
    tweenScaleOut(n, duration = 0.08) {
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            try {
                n.setScale(new cc_1.Vec3(0.0, 0.0, 1.0));
            }
            catch { }
            return Promise.resolve();
        }
        cc_1.Tween.stopAllByTarget(n);
        return new Promise((resolve) => {
            (0, cc_1.tween)(n)
                .to(duration, { scale: new cc_1.Vec3(0.0, 0.0, 1.0) })
                .call(() => resolve())
                .start();
        });
    }
    // 스택 pop/피격 시 살짝 튀는 느낌을 줍니다.
    tweenPop(n) {
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            try {
                n.setScale(new cc_1.Vec3(1, 1, 1));
            }
            catch { }
            return Promise.resolve();
        }
        cc_1.Tween.stopAllByTarget(n);
        return new Promise((resolve) => {
            (0, cc_1.tween)(n)
                .to(0.06, { scale: new cc_1.Vec3(1.12, 1.12, 1) })
                .to(0.06, { scale: new cc_1.Vec3(1, 1, 1) })
                .call(() => resolve())
                .start();
        });
    }
    // 이동 애니메이션을 수행합니다.
    tweenMove(n, pos, duration) {
        if (typeof globalThis !== 'undefined' && globalThis.__STAGE_TOOL_FAST_SIM__) {
            try {
                n.setPosition(pos);
            }
            catch { }
            return Promise.resolve();
        }
        cc_1.Tween.stopAllByTarget(n);
        return new Promise((resolve) => {
            (0, cc_1.tween)(n)
                .to(duration, { position: pos })
                .call(() => resolve())
                .start();
        });
    }
    // 부모를 바꾸면서(월드 위치 유지) targetLocal 로 이동합니다.
    tweenMoveReparent(n, newParent, targetLocal, duration) {
        cc_1.Tween.stopAllByTarget(n);
        const wp = n.worldPosition.clone();
        n.setParent(newParent);
        n.setWorldPosition(wp);
        return this.tweenMove(n, targetLocal, duration);
    }
    // ---------------- 좌표/인덱스 ----------------
    // 보드 좌표(row,col)를 로컬 위치(셀 중심)로 변환합니다.
    cellPos(row, col) {
        // UI2: Blocks/Line_01~가 "정확히 10x10"이면 라인 좌표 사용
        if (this.useLineLayout && this.lineNodes.length > 0) {
            const line = this.lineForRow(row);
            const x = this.colX[col] ?? 0;
            const y = line ? line.position.y : 0;
            return new cc_1.Vec3(x, y, 0);
        }
        // ✅ tileLayer 기준 10x10 자동 배치
        if (this.stepX <= 0 || this.stepY <= 0)
            this.cacheTileLayerGridMetrics();
        const sx = this.stepX > 0 ? this.stepX : Math.max(1, this.tileSize | 0);
        const sy = this.stepY > 0 ? this.stepY : Math.max(1, this.tileSize | 0);
        return new cc_1.Vec3(this.originX + col * sx, this.originY + row * sy, 0);
    }
    // 2x2 엔티티(좌하단 앵커)의 로컬 위치(중심)로 변환합니다.
    bigPos(row, col) {
        // 2x2는 (col,col+1) / (row,row+1)의 중간
        const p0 = this.cellPos(row, col);
        const p1 = this.cellPos(row + 1, col + 1);
        return new cc_1.Vec3((p0.x + p1.x) * 0.5, (p0.y + p1.y) * 0.5, 0);
    }
    // 엔티티의 로컬 위치를 반환합니다.
    entPos(e) {
        return e.w === 2 && e.h === 2 ? this.bigPos(e.row, e.col) : this.cellPos(e.row, e.col);
    }
    // row에 해당하는 Line 노드를 반환합니다(row=0은 바닥).
    lineForRow(row) {
        if (!this.useLineLayout || this.lineNodes.length === 0)
            return null;
        // ✅ lineNodes는 setupLineLayoutIfAny에서 y 기준으로 "바닥(row=0) -> 위" 순으로 정렬되어 있습니다.
        // - 역할: row와 실제 화면 라인 매핑을 항상 일치시킴
        const idx = row | 0;
        if (idx < 0 || idx >= this.lineNodes.length)
            return null;
        return this.lineNodes[idx];
    }
    // 엔티티의 부모(Line)와 로컬 좌표를 계산합니다(타일은 y=0, 2x2는 y=-dy/2).
    entParentAndLocal(e) {
        if (!this.tileLayer || !this.useLineLayout || this.lineNodes.length === 0) {
            return { parent: this.tileLayer, local: this.entPos(e) };
        }
        const topRow = e.row + e.h - 1;
        const parent = this.lineForRow(topRow) ?? this.tileLayer;
        if (e.w === 2 && e.h === 2) {
            const x0 = this.colX[e.col] ?? 0;
            const x1 = this.colX[e.col + 1] ?? x0 + (this.colX[1] ?? 0) - (this.colX[0] ?? 0);
            return { parent, local: new cc_1.Vec3((x0 + x1) * 0.5, -this.lineDy * 0.5, 0) };
        }
        return { parent, local: new cc_1.Vec3(this.colX[e.col] ?? 0, 0, 0) };
    }
    // ✅ 셀 중심의 월드 좌표를 반환합니다.
    // - 라인 유무와 상관 없이 tileLayer 기준 변환으로 통일(계산 일관성)
    cellWorldPos(row, col) {
        const local = this.cellPos(row, col);
        const ref = this.tileLayer && this.tileLayer.isValid ? this.tileLayer : this.node;
        const ui = ref.getComponent(cc_1.UITransform);
        return ui ? ui.convertToWorldSpaceAR(local) : ref.getWorldPosition().clone().add(local);
    }
    // 2D -> 1D 인덱스로 변환합니다.
    indexOf(r, c) {
        return r * this.cols + c;
    }
    // // 아틀라스 지연 로드/교체 등으로 인해 모든 타일의 스프라이트를 강제로 갱신합니다.
    forceRefreshAllTiles() {
        // 역할: TileView 내부의 refresh를 재호출하여 spriteFrame/tint를 다시 적용
        for (const ent of this.ents.values()) {
            ent.view?.forceRefresh?.();
        }
    }
    isItemMoveBlocksToTopActive() {
        // // 역할: 아이템3(블록 이동) 모드가 활성인지 외부에서 확인
        // // - BottomItemBar의 오버레이 종료 타이밍(색상 선택/취소 시 자동 닫기)에 사용
        return !!this._itemMoveBlockActive;
    }
};
exports.Board = Board;
__decorate([
    property({ tooltip: '작은(1x1) 블럭 프리펩(Pre_Enemy_Block_Small)' })
], Board.prototype, "tilePrefab", void 0);
__decorate([
    property({ tooltip: '큰(2x2) 블럭 프리펩(Pre_Enemy_Block_Big). BLOCK_LARGE는 이 프리펩을 1개만 생성합니다.' })
], Board.prototype, "bigTilePrefab", void 0);
__decorate([
    property({ tooltip: '총알 프리팹(Mechanic_Ball)' })
], Board.prototype, "projectilePrefab", void 0);
__decorate([
    property({ tooltip: '그리드 한 칸 크기(프리팹/캔버스에 맞춰 조정)' })
], Board.prototype, "tileSize", void 0);
__decorate([
    property({ tooltip: '작은 블럭 풀 예열 개수(0이면 예열 안 함)' })
], Board.prototype, "warmupSmall", void 0);
__decorate([
    property({ tooltip: '큰 블럭 풀 예열 개수(0이면 예열 안 함)' })
], Board.prototype, "warmupBig", void 0);
__decorate([
    property({ tooltip: '총알 풀 예열 개수(0이면 Config(PROJECTILE_POOL_WARMUP) 사용)' })
], Board.prototype, "warmupProjectiles", void 0);
__decorate([
    property({ type: cc_1.Node, tooltip: '블럭이 생성될 부모 노드(UI2/Enemys/Blocks)' })
], Board.prototype, "tileLayer", void 0);
__decorate([
    property({
        type: BoardIntroDrop_1.BoardIntroDrop,
        tooltip: '인트로 드랍 연출 컴포넌트(BoardIntroDrop). 비워두면 인트로 드랍을 실행하지 않습니다.',
    })
], Board.prototype, "introDrop", void 0);
__decorate([
    property({ type: cc_1.Node, tooltip: '프로젝타일(총알)이 생성될 부모 노드(UI2/Mechanic/Projectiles 등)' })
], Board.prototype, "projectileLayer", void 0);
__decorate([
    property({
        type: cc_1.Node,
        tooltip: 'FX(파티클)가 생성될 부모 노드(없으면 tileLayer 사용). 블럭 위에 띄우려면 별도 FX 레이어를 권장',
    })
], Board.prototype, "fxLayer", void 0);
__decorate([
    property({ tooltip: '제거 FX(Particle_Shatter) 풀 예열 개수' })
], Board.prototype, "warmupShatterFx", void 0);
exports.Board = Board = __decorate([
    ccclass('Board')
], Board);
