"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUPPLY_LARGE_BASE = exports.COLOR_PALETTE_HEX_12 = exports.COLOR_TOKEN_ORDER = void 0;
exports.colorIdFromToken = colorIdFromToken;
exports.paletteHexByColorCount = paletteHexByColorCount;
exports.spriteIndexFromColorId = spriteIndexFromColorId;
exports.buildPaletteHex = buildPaletteHex;
const ColorPalette_1 = require("./ColorPalette");
exports.COLOR_TOKEN_ORDER = [
    'R',
    'O',
    'Y',
    'G',
    'B',
    'P',
    'M',
    'C',
    'S',
    'L',
    'K',
    'W',
];
// 토큰 → colorId (미지원 토큰이면 -1)
// 토큰 → colorId (0~11)
// ⚠️ 중요
// - stage.meta.colorCount는 "스테이지에서 실제로 쓰는 색의 개수"일 뿐,
//   토큰(R/Y/B 등)이 어떤 id에 매핑되는지의 기준이 아닙니다.
// - 따라서 colorCount로 토큰 검색 범위를 자르면,
//   colorCount=3인 스테이지에서 'B'가 -1로 떨어져 빨강(0)으로 덮이는 현상이 발생합니다.
// - 여기서는 항상 12색 전체 토큰 순서(COLOR_TOKEN_ORDER)를 기준으로 id를 반환합니다.
function colorIdFromToken(token, _colorCount) {
    const t = (token ?? '').trim().toUpperCase();
    for (let i = 0; i < exports.COLOR_TOKEN_ORDER.length; i++) {
        if (exports.COLOR_TOKEN_ORDER[i] === t)
            return i;
    }
    return -1;
}
// 표준 12색 팔레트(위 COLOR_TOKEN_ORDER와 1:1 매칭)
// - 필요 시 colorCount만큼 앞에서 잘라 사용하세요.
exports.COLOR_PALETTE_HEX_12 = [
    '#ff3b30', // R
    '#ff9f0a', // O
    '#ffd60a', // Y
    '#34c759', // G
    '#0a84ff', // B
    '#bf5af2', // P
    '#ff2d55', // M
    '#64d2ff', // C
    '#30d158', // S
    '#ac8e68', // L
    '#1c1c1e', // K
    '#ffffff', // W
];
function paletteHexByColorCount(colorCount) {
    const max = Math.max(0, Math.min(exports.COLOR_PALETTE_HEX_12.length, colorCount | 0));
    return exports.COLOR_PALETTE_HEX_12.slice(0, max);
}
// colorId → 스프라이트 인덱스(01~12)
function spriteIndexFromColorId(colorId) {
    const id = colorId | 0;
    return id >= 0 ? id + 1 : 0;
}
function buildPaletteHex(colorCount) {
    const n = Math.max(0, Math.min(ColorPalette_1.DEFAULT_PALETTE_HEX_12.length, colorCount | 0));
    return ColorPalette_1.DEFAULT_PALETTE_HEX_12.slice(0, n);
}
// ----------------- Supply: LARGE(2x2) 토큰 -----------------
// columnSupply는 pop() 기반이어서 기본적으로 "셀 1개 = 토큰 1개"로 흘러갑니다.
// 그러나 공급에서 2x2 LARGE를 "진짜 엔티티"로 생성하려면
// 2x2 footprint(4셀)에 대해 서로 연결된 토큰을 넣고, 런타임에서 1회에 BIG 1개로 합쳐 생성해야 합니다.
//
// 인코딩 규칙:
// - SMALL/HIDDEN: 기존처럼 colorId(>=0) / -(colorId+1)
// - LARGE: SUPPLY_LARGE_BASE + (idx*4 + cell)
//   - idx: supplyLargeDefs 배열 인덱스
//   - cell: 0..3 ( (0,0)(1,0)(0,1)(1,1) )  // anchor(좌하단) 기준
exports.SUPPLY_LARGE_BASE = 1000000;
