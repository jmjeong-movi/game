// 역할: UnitLineRack(유닛 라인)에서 Spine 소켓/본 이름을 한 곳에서 관리
// - UnitLineRack.ts 비대화를 줄이고, 스폰/소켓/IK 관련 문자열을 공유합니다.

// Spine bone names
export const BONE_CENTER = 'Cannon_Attack_Center_Muzzle';
export const BONE_LEFT = 'Cannon_Attack_Left_Muzzle';
export const BONE_RIGHT = 'Cannon_Attack_Right_Muzzle';
export const IK_TARGET_BONE = 'Cannon_Target';

// ✅ 하위 호환: 과거 패치/코드에서 사용하던 이름
export const BONE_IK = IK_TARGET_BONE;
export const BONE_IK_MIRROR = 'Cannon_Target_Mirror';

// Spine socket paths
export const PATH_CENTER = 'root/Cannon_Attack/Connon_Attack_1/Cannon_Attack_Center_Muzzle';
export const PATH_LEFT = 'root/Cannon_Attack/Cannon_Attack_2/Cannon_Attack_Left/Cannon_Attack_Left_Muzzle';
export const PATH_RIGHT = 'root/Cannon_Attack/Cannon_Attack_2/Cannon_Attack_Right/Cannon_Attack_Right_Muzzle';

// Ammo label socket path
export const PATH_LABEL = 'root/Unit/Body/Cannon_Target_Mirror/Label_Num';
