console.log('hello ts', 1+1);
