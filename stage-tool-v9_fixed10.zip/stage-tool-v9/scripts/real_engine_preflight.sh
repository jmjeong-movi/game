#!/usr/bin/env bash
set -euo pipefail

MOD="${REAL_GAME_VALIDATOR_MODULE:-}"
if [[ -z "$MOD" ]]; then
  echo "REAL_GAME_VALIDATOR_MODULE is not set"
  exit 2
fi
if [[ ! -f "$MOD" ]]; then
  echo "REAL_GAME_VALIDATOR_MODULE file not found: $MOD"
  exit 3
fi

node - <<'NODE' "$MOD"
const p = process.argv[1];
const mod = require(require('path').resolve(process.cwd(), p));
if (!mod || mod.isRealEngine !== true || typeof mod.validateStageEquivalent !== 'function') {
  console.error('module contract invalid (need isRealEngine=true and validateStageEquivalent)');
  process.exit(4);
}
console.log('real engine preflight OK:', p);
NODE
