#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/.."
CLI_JS="stage-tool-v9/src/validator_tools/cli.js"
[[ -f "$CLI_JS" ]] || { echo "validator CLI not found: $CLI_JS"; exit 2; }
node "$CLI_JS" repair \
  --input stagepack_v2_replay_solved_fixed21.json \
  --output stagepack_v2_replay_solved_fixed21_validation.json \
  --report stagepack_v2_replay_solved_fixed21_report.json
node stage-tool-v9/src/validator_tools/gen_test_matrix.mjs
node "$CLI_JS" repair \
  --input stagepack_v2_matrix_120_seed.json \
  --output stagepack_v2_matrix_120.json \
  --report stagepack_v2_matrix_120_report.json
python - <<'PY'
import json
rep=json.load(open('stagepack_v2_matrix_120_report.json','r',encoding='utf-8'))
rows=rep.get('results',[])
uns=[r for r in rows if str(r.get('status'))!='SOLVED']
print('[matrix]',len(rows),'unsolved',len(uns))
if uns:
    raise SystemExit(3)
PY
