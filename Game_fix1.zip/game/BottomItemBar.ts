import { _decorator, Component, Button, find } from 'cc';
import { UnitLineRack } from './UnitLineRack';
import { Board } from './Board';
import { ItemUseOverlay, ItemUseMode } from './ItemUseOverlay';

const { ccclass, property } = _decorator;

@ccclass('BottomItemBar')
export class BottomItemBar extends Component {
    @property({ type: UnitLineRack, tooltip: '유닛 라인 랙(대기/슈팅 라인)' })
    unitLineRack: UnitLineRack | null = null;

    @property({ type: Board, tooltip: '보드(아이템3 블록 이동)' })
    board: Board | null = null;

    @property({ type: ItemUseOverlay, tooltip: 'Canvas/UI/Root/Item Use에 붙인 ItemUseOverlay 컴포넌트' })
    itemUseOverlay: ItemUseOverlay | null = null;

    @property({ type: Button, tooltip: '아이템1 버튼' })
    btnItem1: Button | null = null;

    @property({ type: Button, tooltip: '아이템2 버튼' })
    btnItem2: Button | null = null;

    @property({ type: Button, tooltip: '아이템3 버튼' })
    btnItem3: Button | null = null;

    private _useMode: ItemUseMode = 0;

    private _tryAutoBindRefs(): void {
        // ✅ 인스펙터 연결 누락 시에도 동작하도록 런타임 자동 바인딩
        // (현재 Canvas.prefab에서 itemUseOverlay가 null로 저장돼 있어 UI가 안 뜨는 케이스가 있음)

        // 1) ItemUseOverlay
        if (!this.itemUseOverlay || !this.itemUseOverlay.isValid) {
            const n =
                find('Canvas/UI/Root/SafeAreaRoot/Item Use') ||
                find('UI/Root/SafeAreaRoot/Item Use') ||
                find('SafeAreaRoot/Item Use');
            const c = n?.getComponent(ItemUseOverlay) ?? null;
            if (c) this.itemUseOverlay = c;
        }

        // 2) UnitLineRack
        if (!this.unitLineRack || !this.unitLineRack.isValid) {
            const n = find('Canvas/UI/Root/Unit_Position') || find('UI/Root/Unit_Position') || find('Unit_Position');
            const c = n?.getComponent(UnitLineRack) ?? null;
            if (c) this.unitLineRack = c;
        }

        // 3) Board (⚠️ 씬에 "Board"라는 이름 노드가 여러 개 있어서 BGRoot 경로로만 찾습니다)
        if (!this.board || !this.board.isValid) {
            const n =
                find('Canvas/UI/Root/BGRoot/Board') ||
                find('UI/Root/BGRoot/Board') ||
                find('BGRoot/Board');
            const c = n?.getComponent(Board) ?? null;
            if (c) this.board = c;
        }

        // 4) Buttons (Bottom_Menu 하위에서 탐색)
        const root = this.node;

        const getBtn = (itemName: string, btnName: string): Button | null => {
            const item = root.getChildByName(itemName);
            const btnNode = item?.getChildByName(btnName) ?? null;
            return (btnNode?.getComponent(Button) as Button) ?? null;
        };

        if (!this.btnItem1 || !this.btnItem1.isValid) this.btnItem1 = getBtn('Item_1', 'Btn_Item_1');
        if (!this.btnItem2 || !this.btnItem2.isValid) this.btnItem2 = getBtn('Item_2', 'Btn_Item_2');
        if (!this.btnItem3 || !this.btnItem3.isValid) this.btnItem3 = getBtn('Item_3', 'Btn_Item_3');

        // 혹시 노드명이 다른 프로젝트/프리팹을 위한 최후의 fallback
        if ((!this.btnItem1 || !this.btnItem1.isValid) && root.isValid) {
            const all = root.getComponentsInChildren(Button);
            this.btnItem1 = all.find((b) => b?.node?.name === 'Btn_Item_1') ?? this.btnItem1;
            this.btnItem2 = all.find((b) => b?.node?.name === 'Btn_Item_2') ?? this.btnItem2;
            this.btnItem3 = all.find((b) => b?.node?.name === 'Btn_Item_3') ?? this.btnItem3;
        }

        // 5) Overlay 내부 버튼도 누락되었을 수 있어 보정(아이템2 셔플 확인 버튼)
        const ov = this.itemUseOverlay;
        if (ov && ov.isValid) {
            if (!ov.btnExit || !ov.btnExit.isValid) {
                const n = find('TextBox/Exit', ov.node);
                const b = n?.getComponent(Button) ?? null;
                if (b) ov.btnExit = b;
            }
            if (!ov.btnShuffle || !ov.btnShuffle.isValid) {
                const n = find('Dimmed_Shuffle/Btn_Shuffle', ov.node);
                const b = n?.getComponent(Button) ?? null;
                if (b) ov.btnShuffle = b;
            }
        }
    }

    onLoad() {
        this._tryAutoBindRefs();

        // 역할: 초기 오버레이 닫기
        this.itemUseOverlay?.close();

        // 역할: 아이템 버튼 클릭 바인딩
        this.btnItem1?.node.on(Button.EventType.CLICK, this._onItem1, this);
        this.btnItem2?.node.on(Button.EventType.CLICK, this._onItem2, this);
        this.btnItem3?.node.on(Button.EventType.CLICK, this._onItem3, this);

        // 역할: 오버레이(Exit/Shuffle) 클릭 바인딩
        this.itemUseOverlay?.btnExit?.node.on(Button.EventType.CLICK, this._onExitItemUse, this);
        this.itemUseOverlay?.btnShuffle?.node.on(Button.EventType.CLICK, this._onConfirmShuffle, this);
    }

    update() {
        // 역할: 아이템1/3은 모드 종료 시 자동으로 오버레이를 닫습니다.
        if (!this.itemUseOverlay || !this.itemUseOverlay.isOpen()) return;

        if (this._useMode === 1) {
            const active = this.unitLineRack?.isItemSelectUnitToShootActive?.() ?? false;
            if (!active) this._closeItemUseOverlay(false);
        } else if (this._useMode === 3) {
            const active = this.board?.isItemMoveBlocksToTopActive?.() ?? false;
            if (!active) this._closeItemUseOverlay(false);
        }
    }

    onDestroy() {
        // 역할: 중복 리스너 방지
        this.btnItem1?.node.off(Button.EventType.CLICK, this._onItem1, this);
        this.btnItem2?.node.off(Button.EventType.CLICK, this._onItem2, this);
        this.btnItem3?.node.off(Button.EventType.CLICK, this._onItem3, this);

        this.itemUseOverlay?.btnExit?.node.off(Button.EventType.CLICK, this._onExitItemUse, this);
        this.itemUseOverlay?.btnShuffle?.node.off(Button.EventType.CLICK, this._onConfirmShuffle, this);
    }

    private _openItemUseOverlay(mode: ItemUseMode) {
        // 역할: 오버레이 open + 현재 모드 기록
        if (!this.itemUseOverlay) return;
        this._useMode = mode;
        this.itemUseOverlay.open(mode);
    }

    private _closeItemUseOverlay(doCancel: boolean) {
        // 역할: 오버레이 닫기 + 필요 시 모드 취소
        const mode = this._useMode;

        if (doCancel) {
            if (mode === 1) {
                this.unitLineRack?.cancelItemSelectUnitToShoot();
            } else if (mode === 3) {
                this.board?.cancelItemMoveBlocksToTop?.();
            }
        }

        this._useMode = 0;
        this.itemUseOverlay?.close();
    }

    private _onExitItemUse() {
        // 역할: TextBox/Exit 클릭 → 아이템 사용 취소
        this._closeItemUseOverlay(true);
    }

    private _onConfirmShuffle() {
        // 역할: Dimmed_Shuffle/Btn_Shuffle 클릭 시에만 셔플 발동
        if (this._useMode !== 2) return;

        this.board?.cancelItemMoveBlocksToTop?.();
        this.unitLineRack?.cancelItemSelectUnitToShoot();
        this.unitLineRack?.useItemShuffleUnits();

        this._closeItemUseOverlay(false);
    }

    private _onItem1() {
        // 역할: 아이템1 클릭 → 하단 영역 dim + 유닛 선택 모드 시작
        this.board?.cancelItemMoveBlocksToTop?.();

        this._openItemUseOverlay(1);
        this.unitLineRack?.beginItemSelectUnitToShoot();
    }

    private _onItem2() {
        // 역할: 아이템2 클릭 → 셔플 dim만 띄우고, 확인 버튼 클릭 때 셔플
        this.board?.cancelItemMoveBlocksToTop?.();
        this.unitLineRack?.cancelItemSelectUnitToShoot();

        this._openItemUseOverlay(2);
    }

    private _onItem3() {
        // 역할: 아이템3 클릭 → 상단 영역 dim + 블록 이동 모드 시작
        this.unitLineRack?.cancelItemSelectUnitToShoot();
        this._openItemUseOverlay(3);
        this.board?.beginItemMoveBlocksToTop();
    }
}
