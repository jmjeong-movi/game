"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectileView = void 0;
const cc_1 = require("cc");
class ProjectileView extends cc_1.Component {
    setColor(_cid) { }
}
exports.ProjectileView = ProjectileView;
