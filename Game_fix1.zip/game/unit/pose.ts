// 역할: UnitLineRack 조준/IK/포즈 리셋 로직 분리
// - UnitLineRack.ts 비대화를 줄이고, 스테이지 전환/풀링 재사용 시 포즈 초기화 규칙을 한 곳에서 유지합니다.

// 스테이지 전환/재시작: 모든 슬롯의 조준/IK/예약/애니메이션 상태를 하드 리셋
export function resetAllAimAndPose(r: any): void {
    for (let i = 0; i < 5; i++) {
        const s0 = r._slotS[i];
        if (s0) resetSlotAimAndPose(r, s0);

        const w1 = r._slotW1[i];
        if (w1) resetSlotAimAndPose(r, w1);

        const w2 = r._slotW2[i];
        if (w2) resetSlotAimAndPose(r, w2);

        const w3 = r._slotW3[i];
        if (w3) resetSlotAimAndPose(r, w3);
    }
}

// 단일 슬롯 조준/IK/예약/애니메이션 상태를 즉시 홈 포즈로 되돌림
export function resetSlotAimAndPose(_r: any, s: any): void {
    // 이동/도착 후 장착 예약 제거
    s.moving = false;
    s.equipQueued = false;

    // 발사/예약 상태 초기화
    s.canShootNow = false;
    s.pendingDual = false;
    s.pendingT = 0;
    s.pendingCol = -1;
    s.pendingColorId = -1;
    s.pendingMuzzle = 'L';
    s.pendingIsBig = false;

    // aim 상태 초기화
    s.aimHasTarget = false;
    s.aimInited = false;
    s.aimRefreshCd = 0;
    s.targetHoldT = 0;
    s.reacquireDelayT = 0;
    s.postEquipDelayT = 0;

    // IK 타겟을 홈으로 강제 복귀
    if (s.aimHomeInited) {
        s.aimCurX = s.aimHomeX;
        s.aimCurY = s.aimHomeY;
        s.aimDesX = s.aimHomeX;
        s.aimDesY = s.aimHomeY;

        if (s.ikTarget) {
            try {
                if (typeof s.ikTarget.setPosition === 'function') {
                    s.ikTarget.setPosition(s.aimHomeX, s.aimHomeY);
                } else {
                    s.ikTarget.x = s.aimHomeX;
                    s.ikTarget.y = s.aimHomeY;
                }
            } catch {}
        }
    } else {
        s.aimCurX = 0;
        s.aimCurY = 0;
        s.aimDesX = 0;
        s.aimDesY = 0;
    }

    // 듀얼 플립 초기화
    s.dualFlip = 0;

    // Skeleton 트랙/포즈 리셋
    if (s.skel) {
        try {
            s.skel.clearTracks();
            s.skel.setToSetupPose();

            const idle = s.aimHomeAnim && s.aimHomeAnim.length > 0 ? s.aimHomeAnim : 'Idle';
            s.skel.setAnimation(0, idle, true);
            s.lastAnim = idle;
        } catch {}
    }

    // 시각적 잔상 제거
    if (s.opacity) {
        s.opacity.opacity = 255;
    }
}

// 스테이지 전환: 현재 배치된 모든 유닛의 자세/조준 상태를 초기화
export function resetAllExistingUnitPoses(r: any): void {
    const apply = (arr: any[] | null) => {
        if (!arr) return;
        for (let i = 0; i < arr.length; i++) {
            const s = arr[i];
            if (!s || !s.node?.isValid) continue;
            s.equipQueued = false;
            r._ensureAnim(s, 'Idle');
            resetUnitPose(r, s);
        }
    };

    apply(r._slotS);
    apply(r._slotW1);
    apply(r._slotW2);
    apply(r._slotW3);
}

// 풀링 재사용/스테이지 전환: 단일 유닛 자세 초기화
export function resetUnitPose(r: any, slot: any): void {
    if (!slot || !slot.node || !slot.node.isValid) return;

    const skel: any = slot.skel;
    if (skel && skel.isValid) {
        // 이전 애니 트랙/IK 잔상 제거
        try {
            skel.clearTracks?.();
        } catch {}
        try {
            skel.setToSetupPose?.();
        } catch {}
        try {
            skel.setBonesToSetupPose?.();
        } catch {}
        try {
            skel.setSlotsToSetupPose?.();
        } catch {}
        try {
            skel.updateWorldTransform?.();
        } catch {}

        // Idle 트랙 재지정
        try {
            const mode = r._getMode(slot.data);
            const idleName = slot.line === 'S' ? `Attack_${mode}_Idle` : `Idle_${mode}`;
            skel.setAnimation?.(0, idleName, true);
            slot.lastAnim = idleName;
            r._captureAimHome(slot, idleName);
        } catch {}
    }

    const hx = slot.aimHomeInited ? slot.aimHomeX : 0;
    const hy = slot.aimHomeInited ? slot.aimHomeY : 0;

    slot.aimHasTarget = false;
    slot.canShootNow = false;

    slot.aimCurX = hx;
    slot.aimCurY = hy;
    slot.aimDesX = hx;
    slot.aimDesY = hy;
    slot.aimInited = true;
    slot.aimRefreshCd = 0;
    slot.targetEntId = 0;
    slot.targetCol = -1;
    slot.targetStickyT = 0;

    slot.targetHoldT = 0;
    slot.reacquireDelayT = 0;
    slot.postEquipDelayT = 0;

    slot.pendingDual = false;
    slot.pendingT = 0;
    slot.pendingCol = -1;
    slot.pendingColorId = 0;

    slot.dualFlip = 0;

    // IK 적용
    r._applyIkLocal(slot, hx, hy);
}
