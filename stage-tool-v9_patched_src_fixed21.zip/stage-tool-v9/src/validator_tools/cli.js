"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const StageCompiler_1 = require("./game/StageCompiler");
const Board_1 = require("./game/Board");
const cc_1 = require("cc");
const Types_1 = require("./game/Types");
// NOTE: This file is shipped inside the stage tool (browser/Electron renderer).
// The original validator CLI depends on Node.js built-ins (fs/process) and auto-runs main().
// For the stage tool we keep the core logic (simulateStage/repairStagePack/beamReorderDeckForStage)
// but strip Node-only IO so it can be imported safely.
function getCardColorId(cd) {
    const v = cd?.colorId;
    if (typeof v === 'number')
        return v | 0;
    const c = cd?.color;
    if (typeof c === 'number')
        return c | 0;
    if (typeof c === 'string')
        return (0, Types_1.colorIdFromToken)(c);
    return -1;
}
function computeNeedCountsFromBoard(board, out) {
    // Prefer runtime Board API if present.
    try {
        if (typeof board?.getFrontColorCounts === 'function') {
            return board.getFrontColorCounts(out);
        }
    }
    catch { }
    const arr = out ?? new Int32Array(12);
    arr.fill(0);
    const cols = (board?.cols ?? board?._cols ?? 5) | 0;
    for (let c = 0; c < cols; c++) {
        const ent = board?.entAt?.(0, c);
        const cid = (ent?.view?.colorId ?? -1) | 0;
        if (cid >= 0 && cid < 12)
            arr[cid] += 1;
    }
    return arr;
}
// Counts only *shootable* targets (filters LOCK etc.) by delegating to Board.pickShootTargets.
// This keeps autofix decisions consistent with the simulator's target selection.
function computeShootableNeedCountsFromBoard(board, out) {
    const arr = out ?? new Int32Array(12);
    arr.fill(0);
    // Prefer Board API if present.
    const cols = (board?.cols ?? board?._cols ?? 5) | 0;
    if (typeof board?.pickShootTargets === 'function') {
        for (let cid = 0; cid < 12; cid++) {
            try {
                const ts = board.pickShootTargets(cid, Math.max(1, cols), 'LEFT', undefined, true) ?? [];
                arr[cid] = (Array.isArray(ts) ? ts.length : 0) | 0;
            }
            catch {
                arr[cid] = 0;
            }
        }
        return arr;
    }
    // Fallback to raw row0 counts.
    return computeNeedCountsFromBoard(board, arr);
}
function pickTopNeedColors(need, k) {
    const ids = [];
    for (let i = 0; i < need.length; i++) {
        if ((need[i] | 0) > 0)
            ids.push(i);
    }
    ids.sort((a, b) => (need[b] | 0) - (need[a] | 0));
    return ids.slice(0, Math.max(0, k | 0));
}
function pickTargets(board, colorId, shots, excludeEnt) {
    return board.pickShootTargets(colorId, shots, 'LEFT', excludeEnt, true) ?? [];
}
function computeDeckCardCountsByColor(deck, deckIdx, out) {
    const arr = out ?? new Int32Array(12);
    arr.fill(0);
    if (!Array.isArray(deck))
        return arr;
    const start = Math.max(0, deckIdx | 0);
    for (let i = start; i < deck.length; i++) {
        const c = getCardColorId(deck[i]);
        if (c >= 0 && c < 12)
            arr[c] += 1;
    }
    return arr;
}
function entropyFromCounts(cnt) {
    let sum = 0;
    for (let i = 0; i < cnt.length; i++)
        sum += Math.max(0, cnt[i] | 0);
    if (sum <= 0)
        return 0;
    let h = 0;
    for (let i = 0; i < cnt.length; i++) {
        const c = Math.max(0, cnt[i] | 0);
        if (c <= 0)
            continue;
        const p = c / sum;
        h -= p * Math.log(p);
    }
    return h;
}
function computeAmmoLeftByColor(slots, deck, deckIdx, out) {
    const arr = out ?? new Int32Array(12);
    arr.fill(0);
    for (const s of slots) {
        if (!s)
            continue;
        const c = s.data.colorId | 0;
        if (c >= 0 && c < 12)
            arr[c] += Math.max(0, s.ammo | 0);
    }
    for (let i = deckIdx; i < deck.length; i++) {
        const cd = deck[i];
        const c = getCardColorId(cd);
        if (c >= 0 && c < 12)
            arr[c] += Math.max(0, (cd?.ammo ?? 0) | 0);
    }
    return arr;
}
async function hit(board, col) {
    const fn = board['handleHitColumn'];
    if (typeof fn !== 'function')
        throw new Error('Board.handleHitColumn not found');
    await fn.call(board, col);
}
// ====== Repair ops (unit order / ammo distribution only) ======
function reorderUpcomingDeckByNeed(deck, deckIdx, needCounts, bringN, scanLimit = 64) {
    if (!Array.isArray(deck) || deckIdx >= deck.length)
        return false;
    const bringCards = Math.max(1, bringN | 0);
    const needed = [];
    for (let c = 0; c < 12; c++) {
        if ((needCounts[c] | 0) > 0)
            needed.push(c);
    }
    if (needed.length <= 0)
        return false;
    // If only one color is needed, allow concentrating that color.
    // Otherwise, cap how many cards per needed color we pull forward.
    const perColorCap = needed.length <= 1
        ? bringCards
        : Math.max(2, Math.floor(bringCards / needed.length) + 2);
    // Only scan a local window to avoid dragging far-future cards too early (causes strict oscillation).
    const scanN = Math.max(bringCards, Math.max(8, scanLimit | 0));
    const scanEnd = Math.min(deck.length, deckIdx + scanN);
    const remain = deck.slice(deckIdx, scanEnd);
    if (remain.length <= 0)
        return false;
    const scored = [];
    for (let i = 0; i < remain.length; i++) {
        const cd = remain[i];
        const c = getCardColorId(cd);
        if (c < 0 || c >= 12)
            continue;
        const n = needCounts[c] | 0;
        if (n <= 0)
            continue;
        const a = Math.max(0, (cd?.ammo ?? 0) | 0);
        // Need dominates. Ammo slightly boosts (high-ammo cards should be pulled when needed).
        const score = (Math.min(999, Math.max(0, n)) * 1000) + Math.min(99, a);
        scored.push({ i, c, score });
    }
    if (scored.length <= 0)
        return false;
    scored.sort((x, y) => (y.score - x.score) || (x.i - y.i));
    const pickedIdx = new Set();
    const perPicked = new Int32Array(12);
    for (const s of scored) {
        if (pickedIdx.size >= bringCards)
            break;
        if (needed.length > 1 && (perPicked[s.c] | 0) >= perColorCap)
            continue;
        pickedIdx.add(s.i);
        perPicked[s.c] += 1;
    }
    if (pickedIdx.size <= 0)
        return false;
    const picked = [];
    const rest = [];
    for (let i = 0; i < remain.length; i++) {
        if (pickedIdx.has(i))
            picked.push(remain[i]);
        else
            rest.push(remain[i]);
    }
    const next = picked.concat(rest);
    for (let i = 0; i < next.length; i++)
        deck[deckIdx + i] = next[i];
    return true;
}
function rebalanceAmmoByNeed(deck, deckIdx, needCounts, minAmmoPerCard = 1, moveBudget = 20) {
    if (!Array.isArray(deck) || deckIdx >= deck.length)
        return false;
    // If no need signal, skip.
    let needSum = 0;
    for (let i = 0; i < needCounts.length; i++)
        needSum += Math.max(0, needCounts[i] | 0);
    if (needSum <= 0)
        return false;
    // Total ammo remaining in deck segment.
    let totalAmmo = 0;
    const ammoByColor = new Int32Array(12);
    for (let i = deckIdx; i < deck.length; i++) {
        const cd = deck[i];
        const a = Math.max(0, (cd?.ammo ?? 0) | 0);
        totalAmmo += a;
        const c = getCardColorId(cd);
        if (c >= 0 && c < 12)
            ammoByColor[c] += a;
    }
    if (totalAmmo <= 0)
        return false;
    // Desired ammo per color proportional to need.
    const desired = new Int32Array(12);
    let desiredSum = 0;
    for (let c = 0; c < 12; c++) {
        const w = Math.max(0, needCounts[c] | 0);
        if (w <= 0)
            continue;
        const d = Math.floor((totalAmmo * w) / needSum);
        desired[c] = d;
        desiredSum += d;
    }
    let rem = totalAmmo - desiredSum;
    if (rem > 0) {
        const order = pickTopNeedColors(needCounts, 12);
        let p = 0;
        while (rem-- > 0 && order.length > 0) {
            desired[order[p % order.length]] += 1;
            p++;
        }
    }
    const deficit = new Int32Array(12);
    const surplus = new Int32Array(12);
    for (let c = 0; c < 12; c++) {
        const a = ammoByColor[c] | 0;
        const d = desired[c] | 0;
        if (d > a)
            deficit[c] = d - a;
        else if (a > d)
            surplus[c] = a - d;
    }
    function findDonor(colorId) {
        for (let i = deck.length - 1; i >= deckIdx; i--) {
            const cd = deck[i];
            if (getCardColorId(cd) !== colorId)
                continue;
            const a = Math.max(0, (cd?.ammo ?? 0) | 0);
            if (a > minAmmoPerCard)
                return i;
        }
        return -1;
    }
    function findReceiver(colorId) {
        for (let i = deckIdx; i < deck.length; i++) {
            const cd = deck[i];
            if (getCardColorId(cd) === colorId)
                return i;
        }
        return -1;
    }
    let moved = 0;
    const giveOrder = pickTopNeedColors(needCounts, 12);
    for (const rc of giveOrder) {
        let needAmt = deficit[rc] | 0;
        if (needAmt <= 0)
            continue;
        const recvIdx = findReceiver(rc);
        if (recvIdx < 0)
            continue;
        // Prefer taking from colors that are not needed at all.
        for (let dc = 0; dc < 12 && needAmt > 0; dc++) {
            if ((needCounts[dc] | 0) > 0)
                continue;
            while ((surplus[dc] | 0) > 0 && needAmt > 0 && moved < moveBudget) {
                const donorIdx = findDonor(dc);
                if (donorIdx < 0)
                    break;
                const dAmmo = Math.max(0, (deck[donorIdx]?.ammo ?? 0) | 0);
                const rAmmo = Math.max(0, (deck[recvIdx]?.ammo ?? 0) | 0);
                deck[donorIdx].ammo = Math.max(minAmmoPerCard, dAmmo - 1);
                deck[recvIdx].ammo = rAmmo + 1;
                surplus[dc] -= 1;
                needAmt -= 1;
                moved += 1;
            }
        }
        if (moved >= moveBudget)
            break;
    }
    return moved > 0;
}
// Slot-level autofix: swap a needed card into a chosen slot (does not change stagepack, only sim behavior)
function tryAutoFixSlotsByNeed(board, slots, deck, deckIdx) {
    // Autofix intent: when STUCK, ensure at least one of the current front-row colors
    // (or other shootable colors) exists in the slots. This handles the common deadlock
    // where row0 colors are absent from slots even though the deck still contains them.
    const row0 = computeNeedCountsFromBoard(board);
    const shootNeed = computeShootableNeedCountsFromBoard(board);
    // Current slot color histogram.
    const slotCnt = new Int32Array(12);
    for (const s of slots) {
        if (!s)
            continue;
        const c = (s.data.colorId | 0);
        if (c >= 0 && c < 12)
            slotCnt[c] += 1;
    }
    // Build candidate color list.
    // Priority 1: colors present on row0 but missing from slots.
    // Priority 2: colors that are shootable (per pickShootTargets) but missing from slots.
    // Fallback: top shootable colors (even if already in slots), to allow reshuffle.
    const cand = [];
    for (let c = 0; c < 12; c++) {
        const r = row0[c] | 0;
        if (r > 0 && (slotCnt[c] | 0) <= 0)
            cand.push(c);
    }
    for (let c = 0; c < 12; c++) {
        const s = shootNeed[c] | 0;
        if (s > 0 && (slotCnt[c] | 0) <= 0 && !cand.includes(c))
            cand.push(c);
    }
    if (cand.length <= 0) {
        const top = pickTopNeedColors(shootNeed, 3);
        for (const c of top)
            cand.push(c);
    }
    if (cand.length <= 0)
        return { ok: false, newDeckIdx: deckIdx };
    // Rank candidates considering (a) row0 weight, (b) shootable weight, (c) availability in deck.
    // Prefer earlier deck indices so we don't pull from too far ahead.
    const ranked = [];
    for (const c of cand) {
        let firstIdx = -1;
        for (let i = deckIdx; i < deck.length; i++) {
            if (getCardColorId(deck[i]) === c) {
                firstIdx = i;
                break;
            }
        }
        if (firstIdx < 0)
            continue;
        const r = row0[c] | 0;
        const s = shootNeed[c] | 0;
        const missing = (slotCnt[c] | 0) <= 0;
        const score = (missing ? 1e6 : 0) +
            (r > 0 ? 5e5 + 50 * r : 0) +
            (s > 0 ? 2e5 + 20 * s : 0) -
            5 * (firstIdx - deckIdx);
        ranked.push({ color: c, deckPos: firstIdx, score });
    }
    ranked.sort((a, b) => b.score - a.score);
    if (ranked.length <= 0)
        return { ok: false, newDeckIdx: deckIdx };
    // Attempt swaps in ranked order (some candidates might fail due to edge-case slot state).
    for (const pick of ranked) {
        const need = pick.color;
        const k = pick.deckPos;
        // Choose a slot to replace: duplicated colors / not-need / low ammo
        let bestIdx = -1;
        let bestSlotScore = -1e9;
        for (let i = 0; i < slots.length; i++) {
            const s = slots[i];
            if (!s)
                continue;
            const color = s.data.colorId | 0;
            let dup = 0;
            for (const o of slots)
                if (o && ((o.data.colorId | 0) === color))
                    dup++;
            let score = 0;
            if (color !== need)
                score += 10;
            score += Math.max(0, dup - 1) * 5;
            score += Math.max(0, 20 - (s.ammo | 0)) * 0.1;
            if (score > bestSlotScore) {
                bestSlotScore = score;
                bestIdx = i;
            }
        }
        if (bestIdx < 0)
            continue;
        const picked = deck[k];
        if (!picked)
            continue;
        const replaced = slots[bestIdx].data;
        slots[bestIdx] = { data: picked, ammo: Math.max(0, (picked.ammo ?? 0) | 0), deckPos: k | 0 };
        deck[k] = replaced;
        return { ok: true, newDeckIdx: deckIdx };
    }
    return { ok: false, newDeckIdx: deckIdx };
}
async function simulateStage(stage, maxSteps, maxAutoFixPerStage) {
    const runtime = (0, StageCompiler_1.compileRuntimeFromV2)(stage);
    const b = new Board_1.Board();
    b.tilePrefab = new cc_1.Prefab();
    b.bigTilePrefab = new cc_1.Prefab();
    b.projectilePrefab = new cc_1.Prefab();
    b.tileLayer = new cc_1.Node('tileLayer');
    b.projectileLayer = new cc_1.Node('projectileLayer');
    b.fxLayer = new cc_1.Node('fxLayer');
    b.onLoad?.();
    b.start?.();
    b.load(runtime);
    const capacity = Math.max(1, runtime.slotCount | 0);
    const deck = Array.isArray(runtime.cards) ? runtime.cards.slice() : [];
    let deckIdx = 0;
    const slots = Array.from({ length: capacity }, () => null);
    let steps = 0;
    let shotsFired = 0;
    let autoFixUsed = 0;
    const needBuf = new Int32Array(12);
    const ammoBuf = new Int32Array(12);
    while (b.remaining() > 0 && steps < maxSteps) {
        steps++;
        // In the real game, colBusy/colReserved are cleared by frame updates.
        // Headless simulation does not run a full engine loop, so clear them per step.
        try {
            b.resetBusyFlags?.();
        }
        catch (e) {
            // 이 단계에서 실패하면 export 결과가 게임 로직과 불일치할 수 있으므로
            // 조용히 무시하지 않고 상위로 전달합니다.
            throw e;
        }
        // Fill empty slots from deck
        for (let i = 0; i < capacity; i++) {
            if (slots[i])
                continue;
            if (deckIdx >= deck.length)
                break;
            const drawPos = deckIdx;
            const cd = deck[deckIdx++];
            const ammo = Math.max(0, (cd.ammo ?? 0) | 0);
            slots[i] = { data: cd, ammo, deckPos: drawPos | 0 };
        }
        // STUCK check
        let filled = 0;
        for (let i = 0; i < capacity; i++)
            if (slots[i])
                filled++;
        if (filled >= capacity) {
            let anyCanShoot = false;
            for (let i = 0; i < capacity; i++) {
                const s = slots[i];
                if (!s || s.ammo <= 0)
                    continue;
                const shots = Math.max(1, (s.data.shotCount ?? 1) | 0);
                const ts = pickTargets(b, s.data.colorId | 0, shots, new Set());
                if (ts.length > 0) {
                    anyCanShoot = true;
                    break;
                }
            }
            if (!anyCanShoot) {
                if (autoFixUsed < maxAutoFixPerStage) {
                    // 1) In-sim slot swap (fast)
                    const r1 = tryAutoFixSlotsByNeed(b, slots, deck, deckIdx);
                    if (r1.ok) {
                        autoFixUsed++;
                        deckIdx = r1.newDeckIdx;
                        continue;
                    }
                    // 2) Deck reorder + ammo rebalance (unit order / ammo distribution)
                    const shootNeed = computeShootableNeedCountsFromBoard(b, needBuf);
                    const didReorder = reorderUpcomingDeckByNeed(deck, deckIdx, shootNeed, Math.max(3, capacity));
                    const didAmmo = rebalanceAmmoByNeed(deck, deckIdx, shootNeed, 1, 12);
                    if (didReorder || didAmmo) {
                        autoFixUsed++;
                        continue;
                    }
                }
                const row0 = computeNeedCountsFromBoard(b, needBuf);
                const shootNeed = computeShootableNeedCountsFromBoard(b, needBuf);
                const ammo = computeAmmoLeftByColor(slots, deck, deckIdx, ammoBuf);
                const ent = entropyFromCounts(row0);
                let rowSum = 0;
                let rowMax = 0;
                for (let i = 0; i < row0.length; i++) {
                    const v = Math.max(0, row0[i] | 0);
                    rowSum += v;
                    if (v > rowMax)
                        rowMax = v;
                }
                const maxFrac = rowSum > 0 ? rowMax / rowSum : 0;
                const metrics = { row0Entropy: ent, row0MaxFrac: maxFrac, row0Counts: Array.from(row0), ammoByColor: Array.from(ammo) };
                const slotColors = slots.map((s) => (s ? (s.data.colorId | 0) : -1));
                const slotAmmo = slots.map((s) => (s ? (s.ammo | 0) : 0));
                const slotDeckPos = slots.map((s) => (s ? (s.deckPos | 0) : -1));
                // Remaining deck color histogram (not including current slots)
                const deckColorCounts = new Int32Array(12);
                for (let i = deckIdx; i < deck.length; i++) {
                    const c = getCardColorId(deck[i]);
                    if (c >= 0 && c < 12)
                        deckColorCounts[c] += 1;
                }
                return {
                    status: 'STUCK',
                    steps,
                    remaining: b.remaining(),
                    deckLeft: Math.max(0, deck.length - deckIdx),
                    autoFixUsed,
                    stuck: {
                        // raw row0 colors vs actually shootable colors can differ due to LOCK, etc.
                        needCounts: Array.from(shootNeed),
                        row0Counts: Array.from(row0),
                        deckColorCounts: Array.from(deckColorCounts),
                        deckIdx,
                        slotColors,
                        slotAmmo,
                        slotDeckPos,
                    },
                    metrics,
                };
            }
        }
        // One "round": each slot shoots once (up to shotCount bullets)
        const excludeEnt = new Set();
        for (let i = 0; i < capacity; i++) {
            const s = slots[i];
            if (!s)
                continue;
            if (s.ammo <= 0) {
                slots[i] = null;
                continue;
            }
            const colorId = s.data.colorId | 0;
            const wantShots = Math.max(1, (s.data.shotCount ?? 1) | 0);
            const targets = pickTargets(b, colorId, wantShots, excludeEnt);
            if (!Array.isArray(targets) || targets.length <= 0)
                continue;
            const bullets = Math.min(s.ammo, targets.length);
            for (let k = 0; k < bullets; k++) {
                const t = targets[k];
                excludeEnt.add(t.entId | 0);
                await hit(b, t.col | 0);
                shotsFired++;
                s.ammo -= 1;
                if (b.remaining() <= 0)
                    break;
            }
            if (s.ammo <= 0)
                slots[i] = null;
            if (b.remaining() <= 0)
                break;
        }
    }
    if (b.remaining() <= 0) {
        const row0 = computeNeedCountsFromBoard(b, needBuf);
        const ammo = computeAmmoLeftByColor(slots, deck, deckIdx, ammoBuf);
        const ent = entropyFromCounts(row0);
        let rowSum = 0, rowMax = 0;
        for (let i = 0; i < row0.length; i++) {
            const v = Math.max(0, row0[i] | 0);
            rowSum += v;
            if (v > rowMax)
                rowMax = v;
        }
        const maxFrac = rowSum > 0 ? rowMax / rowSum : 0;
        return { status: 'SOLVED', steps, shotsFired, autoFixUsed, metrics: { row0Entropy: ent, row0MaxFrac: maxFrac, row0Counts: Array.from(row0), ammoByColor: Array.from(ammo) } };
    }
    {
        const row0 = computeNeedCountsFromBoard(b, needBuf);
        const ammo = computeAmmoLeftByColor(slots, deck, deckIdx, ammoBuf);
        const ent = entropyFromCounts(row0);
        let rowSum = 0, rowMax = 0;
        for (let i = 0; i < row0.length; i++) {
            const v = Math.max(0, row0[i] | 0);
            rowSum += v;
            if (v > rowMax)
                rowMax = v;
        }
        const maxFrac = rowSum > 0 ? rowMax / rowSum : 0;
        return { status: 'UNKNOWN', steps, remaining: b.remaining(), shotsFired, autoFixUsed, metrics: { row0Entropy: ent, row0MaxFrac: maxFrac, row0Counts: Array.from(row0), ammoByColor: Array.from(ammo) } };
    }
}
function scoreSimResult(r) {
    if (!r)
        return -1e12;
    const rem = ((r.remaining ?? 0) | 0);
    const steps = ((r.steps ?? 0) | 0);
    const ent = (r.metrics?.row0Entropy ?? 0);
    const maxFrac = (r.metrics?.row0MaxFrac ?? 0);
    const ammoByColor = Array.isArray(r.metrics?.ammoByColor) ? r.metrics.ammoByColor : [];
    // Penalties to avoid future dead-ends:
    // - high maxFrac => one color dominates row0 (fixation)
    // - low entropy => concentrated distribution
    const fixationPenalty = 2500 * Math.max(0, maxFrac - 0.55) + 800 * Math.max(0, 1.4 - ent);
    // Ammo starvation penalty: if a dominant row0 color exists but ammo is near zero.
    let starvationPenalty = 0;
    const row0Counts = Array.isArray(r.metrics?.row0Counts) ? r.metrics.row0Counts : [];
    if (ammoByColor.length === 12 && row0Counts.length === 12) {
        let dom = -1;
        let domCnt = -1;
        for (let i = 0; i < 12; i++) {
            const v = row0Counts[i] | 0;
            if (v > domCnt) {
                domCnt = v;
                dom = i;
            }
        }
        if (dom >= 0 && domCnt > 0) {
            const a = ammoByColor[dom] | 0;
            if (a <= 0)
                starvationPenalty += 3000;
            else if (a < 5)
                starvationPenalty += (5 - a) * 400;
        }
    }
    if (r.status === 'SOLVED') {
        return 1e12 - steps - 5 * (r.shotsFired ?? 0);
    }
    if (r.status === 'UNKNOWN') {
        return -rem - fixationPenalty - starvationPenalty + 0.001 * steps;
    }
    if (r.status === 'STUCK') {
        return -rem - 2000 - fixationPenalty - starvationPenalty + 0.001 * steps;
    }
    return -1e12;
}
async function beamReorderDeckForStage(stage, baseDeck, opts) {
    const depth = Math.max(0, opts.depth | 0);
    const window = Math.max(1, opts.window | 0);
    const beam = Math.max(1, opts.beam | 0);
    const simStepsLong = Math.max(80, opts.simSteps | 0);
    const simStepsShort = Math.max(60, Math.min(220, Math.floor(simStepsLong / 10)));
    function applyOpIdx(list, op) {
        if (op.t === "swp") {
            const a = op.i | 0, b = op.j | 0;
            if (a < 0 || b < 0 || a >= list.length || b >= list.length || a === b)
                return;
            const tmp = list[a];
            list[a] = list[b];
            list[b] = tmp;
            return;
        }
        const from = op.from | 0;
        const to = op.to | 0;
        if (from < 0 || from >= list.length)
            return;
        const item = list.splice(from, 1)[0];
        const dst = Math.max(0, Math.min(list.length, to));
        list.splice(dst, 0, item);
    }
    function materialize(plan) {
        const n = plan.base.length | 0;
        const idx = new Array(n);
        for (let i = 0; i < n; i++)
            idx[i] = i;
        for (const op of plan.ops)
            applyOpIdx(idx, op);
        const out = new Array(n);
        for (let i = 0; i < n; i++)
            out[i] = plan.base[idx[i]];
        return out;
    }
    function deckSigFromPlan(plan, lim = 28) {
        const n = plan.base.length | 0;
        const m = Math.min(Math.max(0, lim | 0), n);
        const idx = new Array(n);
        for (let i = 0; i < n; i++)
            idx[i] = i;
        for (const op of plan.ops)
            applyOpIdx(idx, op);
        let sig = "";
        for (let k = 0; k < m; k++) {
            const cd = plan.base[idx[k]];
            sig += String(getCardColorId(cd)) + ':' + String(cd?.ammo ?? 0) + ';';
        }
        return sig;
    }
    class LruMap {
        constructor(maxSize) {
            this.maxSize = maxSize;
            this.m = new Map();
        }
        get(k) {
            const v = this.m.get(k);
            if (v === undefined)
                return undefined;
            this.m.delete(k);
            this.m.set(k, v);
            return v;
        }
        set(k, v) {
            if (this.m.has(k))
                this.m.delete(k);
            this.m.set(k, v);
            if (this.m.size > this.maxSize) {
                const it = this.m.keys().next();
                if (!it.done)
                    this.m.delete(it.value);
            }
        }
    }
    const cacheCap = Math.max(800, Math.min(9000, (beam * Math.max(1, depth) * 10) | 0));
    const simCache = new LruMap(cacheCap);
    function shrinkSim(r) {
        if (!r)
            return r;
        return {
            status: r.status,
            remaining: r.remaining,
            steps: r.steps,
            stuck: r.stuck,
            shotsFired: r.shotsFired,
            deckIdx: (r?.stuck?.deckIdx ?? r?.deckIdx) | 0,
            stuckSnap: r?.stuck ?? undefined,
            metrics: r.metrics ? {
                row0Entropy: r.metrics.row0Entropy,
                row0MaxFrac: r.metrics.row0MaxFrac,
                row0Counts: r.metrics.row0Counts,
                ammoByColor: r.metrics.ammoByColor,
            } : undefined,
        };
    }
    async function simulatePlan(plan, steps) {
        const sig = String(steps) + '|' + deckSigFromPlan(plan, 30);
        const cached = simCache.get(sig);
        if (cached)
            return cached;
        const deck = materialize(plan);
        const st = JSON.parse(JSON.stringify(stage));
        if (st?.cards?.authored && Array.isArray(st.cards.authored))
            st.cards.authored = deck;
        else
            st.cards = deck;
        const r = await simulateStage(st, steps, 0);
        const rr = shrinkSim(r);
        simCache.set(sig, rr);
        return rr;
    }
    function clonePlan(plan, extra) {
        if (!extra || extra.length === 0)
            return { base: plan.base, ops: plan.ops.slice() };
        const ops = plan.ops.slice();
        for (const op of extra)
            ops.push(op);
        return { base: plan.base, ops };
    }
    function pushDedup(best, c) {
        const s = c.sig ?? (c.sig = deckSigFromPlan(c.plan, 24));
        const prev = best.get(s);
        if (!prev || (c.plan.ops.length < prev.plan.ops.length))
            best.set(s, c);
    }
    function genStuckOps(cand, pivot, look = 10) {
        const r = cand.last;
        const stuck = r?.stuckSnap;
        if (!stuck)
            return [];
        const ops = [];
        const deckIdx = (stuck.deckIdx ?? pivot) | 0;
        const slotDeckPos = Array.isArray(stuck.slotDeckPos) ? stuck.slotDeckPos : [];
        const needCountsArr = Array.isArray(stuck.needCounts) ? stuck.needCounts : [];
        const need = new Int32Array(12);
        for (let i = 0; i < 12 && i < needCountsArr.length; i++)
            need[i] = needCountsArr[i] | 0;
        const topNeed = pickTopNeedColors(need, 3);
        const start = Math.max(0, deckIdx);
        const end = Math.min(cand.plan.base.length - 1, start + Math.max(2, look));
        const candidates = [];
        for (let j = start; j <= end; j++) {
            const c = getCardColorId(cand.plan.base[j]);
            if (topNeed.includes(c))
                candidates.push(j);
        }
        const slotPos = slotDeckPos.filter((p) => typeof p === "number" && p >= 0 && p < cand.plan.base.length);
        for (let si = 0; si < Math.min(3, slotPos.length); si++) {
            for (let dj = 0; dj < Math.min(6, candidates.length); dj++) {
                ops.push([{ t: "swp", i: slotPos[si] | 0, j: candidates[dj] | 0 }]);
            }
        }
        const p0 = Math.max(0, Math.min(cand.plan.base.length - 1, deckIdx));
        for (let j = p0 + 1; j <= Math.min(cand.plan.base.length - 1, p0 + 7); j++) {
            ops.push([{ t: "ins", from: j, to: p0 }]);
        }
        const backTo = Math.max(0, p0 - Math.min(10, Math.floor((pivot + 3) / 2)));
        for (let j = p0 + 6; j <= Math.min(cand.plan.base.length - 1, p0 + 12); j += 2) {
            ops.push([{ t: "ins", from: j, to: backTo }]);
        }
        return ops;
    }
    function opHeuristic(plan, ops, pivot) {
        const deck = plan.base;
        const n = deck.length;
        const idx = new Array(n);
        for (let i = 0; i < n; i++)
            idx[i] = i;
        for (const op0 of plan.ops)
            applyOpIdx(idx, op0);
        for (const op of ops)
            applyOpIdx(idx, op);
        const lim = Math.min(n, Math.max(12, pivot + 8));
        const cnt = new Int32Array(12);
        for (let k = Math.max(0, pivot); k < lim; k++) {
            const cd = deck[idx[k]];
            const c = getCardColorId(cd);
            if (c >= 0 && c < 12)
                cnt[c] += 1;
        }
        const h = entropyFromCounts(cnt);
        let max = 0, sum = 0;
        for (let i = 0; i < 12; i++) {
            const v = cnt[i] | 0;
            if (v > max)
                max = v;
            sum += v;
        }
        const maxFrac = sum > 0 ? max / sum : 1;
        return h * 10 - maxFrac * 20 - (ops.length * 0.5);
    }
    const basePlan = { base: baseDeck, ops: [] };
    let cur = [{ plan: basePlan, score: -1e18 }];
    {
        const r = await simulatePlan(basePlan, simStepsLong);
        cur[0].last = r;
        cur[0].score = scoreSimResult(r);
        if (r.status === "SOLVED")
            return { deck: materialize(basePlan), best: r };
    }
    const maxNext = Math.max(beam * 40, beam + 240);
    for (let d = 0; d < depth; d++) {
        const pivot = d;
        const nextBest = new Map();
        for (const cand of cur) {
            const start = pivot;
            const end = Math.min(baseDeck.length - 1, pivot + window - 1);
            const opList = [];
            for (let j = start + 1; j <= end; j++)
                opList.push([{ t: "ins", from: j, to: start }]);
            if (cand.last?.status === "STUCK") {
                const stuckOps = genStuckOps(cand, pivot, window + 4);
                for (const o of stuckOps)
                    opList.push(o);
                const topSingle = stuckOps.slice(0, 10);
                for (let i = 0; i < Math.min(6, topSingle.length); i++) {
                    for (let j = 0; j < Math.min(4, topSingle.length); j++) {
                        if (i === j)
                            continue;
                        opList.push([...topSingle[i], ...topSingle[j]]);
                    }
                }
                for (let i = 0; i < Math.min(4, topSingle.length); i++) {
                    for (let j = 0; j < Math.min(3, topSingle.length); j++) {
                        for (let k = 0; k < Math.min(3, topSingle.length); k++) {
                            if (i === j || j === k || i === k)
                                continue;
                            opList.push([...topSingle[i], ...topSingle[j], ...topSingle[k]]);
                        }
                    }
                }
            }
            const ranked = opList
                .map((ops) => ({ ops, hs: opHeuristic(cand.plan, ops, pivot) }))
                .sort((a, b) => b.hs - a.hs)
                .slice(0, Math.max(18, beam * 6));
            for (const ro of ranked) {
                const plan2 = clonePlan(cand.plan, ro.ops);
                const c2 = { plan: plan2, score: -1e18 };
                pushDedup(nextBest, c2);
                if (nextBest.size >= maxNext)
                    break;
            }
            if (nextBest.size >= maxNext)
                break;
        }
        const uniq = Array.from(nextBest.values());
        for (const c of uniq) {
            const rS = await simulatePlan(c.plan, simStepsShort);
            c.last = rS;
            c.score = scoreSimResult(rS) - 0.05 * c.plan.ops.length;
            if (rS.status === "SOLVED") {
                const rL = await simulatePlan(c.plan, simStepsLong);
                if (rL.status === "SOLVED")
                    return { deck: materialize(c.plan), best: rL };
                c.last = rL;
                c.score = scoreSimResult(rL) - 0.05 * c.plan.ops.length;
            }
        }
        uniq.sort((a, b) => b.score - a.score);
        const preKeep = uniq.slice(0, Math.max(beam * 3, beam + 6));
        for (const c of preKeep) {
            const rL = await simulatePlan(c.plan, simStepsLong);
            c.last = rL;
            c.score = scoreSimResult(rL) - 0.05 * c.plan.ops.length;
            if (rL.status === "SOLVED")
                return { deck: materialize(c.plan), best: rL };
        }
        preKeep.sort((a, b) => b.score - a.score);
        cur = preKeep.slice(0, beam);
        if (cur.length === 0)
            break;
    }
    cur.sort((a, b) => b.score - a.score);
    const best = cur[0];
    return { deck: best ? materialize(best.plan) : baseDeck.slice(), best: best?.last };
}
function repairSwapNeededIntoStuckSlots(cardsArr, stuck, need) {
    if (!stuck || !Array.isArray(cardsArr) || cardsArr.length <= 0)
        return false;
    const deckIdx = (stuck.deckIdx ?? 0) | 0;
    const slotColors = Array.isArray(stuck.slotColors) ? stuck.slotColors : [];
    const slotAmmo = Array.isArray(stuck.slotAmmo) ? stuck.slotAmmo : [];
    const slotDeckPos = Array.isArray(stuck.slotDeckPos) ? stuck.slotDeckPos : [];
    const cap = slotColors.length | 0;
    if (cap <= 0 || slotDeckPos.length !== cap)
        return false;
    // Current slot histogram.
    const presentCnt = new Int32Array(12);
    for (const c0 of slotColors) {
        const c = (c0 ?? -1) | 0;
        if (c >= 0 && c < 12)
            presentCnt[c] += 1;
    }

    // ✅ 남은 덱(undrawn)에 실제로 존재하는 색만 대상으로 선택
    // - needCounts 동률(예: 1)에서 덱에 없는 색을 먼저 고르면 donor를 못 찾아 swap이 실패 → STUCK 반복
    const deckColorCounts = Array.isArray(stuck.deckColorCounts) ? stuck.deckColorCounts : [];
    const hasRemainingCard = (c) => ((deckColorCounts?.[c] ?? 0) | 0) > 0;
    // Pick ONE target color to inject.
    // Priority: needed colors that are currently missing from slots.
    let target = -1;
    let bestW = -1;
    for (let c = 0; c < 12; c++) {
        const w = need[c] | 0;
        if (w <= 0)
            continue;
        if ((presentCnt[c] | 0) > 0)
            continue;
        if (!hasRemainingCard(c))
            continue;
        if (w > bestW) {
            bestW = w;
            target = c;
        }
    }
    if (target < 0) {
        const top = pickTopNeedColors(need, 8);
        let pick = -1;
        for (const c0 of top) {
            const c = (c0 ?? -1) | 0;
            if (c < 0 || c >= 12)
                continue;
            if ((presentCnt[c] | 0) > 0)
                continue;
            if (!hasRemainingCard(c))
                continue;
            pick = c;
            break;
        }
        if (pick < 0)
            return false;
        target = pick;
    }
    // Pick a slot to replace: prefer (a) high ammo, (b) duplicated colors, (c) colors not needed now.
    let pickSlot = -1;
    let bestScore = -1e18;
    for (let i = 0; i < cap; i++) {
        const sc = (slotColors[i] ?? -1) | 0;
        const pos = (slotDeckPos[i] ?? -1) | 0;
        if (pos < 0 || pos >= cardsArr.length)
            continue;
        if (sc === target)
            continue;
        const a = (slotAmmo[i] ?? 0) | 0;
        const have = sc >= 0 && sc < 12 ? (presentCnt[sc] | 0) : 0;
        const neededNow = sc >= 0 && sc < 12 ? ((need[sc] | 0) > 0) : false;
        let score = 0;
        if (!neededNow)
            score += 2200; // useless for the current front
        if (have >= 2)
            score += 800; // duplicated colors tend to deadlock
        score += Math.min(120, Math.max(0, a)) * 3; // high ammo blocks longer
        score += Math.max(0, pos - Math.max(0, deckIdx - 6)) * 0.15; // prefer local swaps
        if (score > bestScore) {
            bestScore = score;
            pickSlot = i;
        }
    }
    // If everything is already the target color (rare), still try swapping the highest-ammo slot.
    if (pickSlot < 0) {
        let bestA = -1;
        for (let i = 0; i < cap; i++) {
            const pos = (slotDeckPos[i] ?? -1) | 0;
            if (pos < 0 || pos >= cardsArr.length)
                continue;
            const a = (slotAmmo[i] ?? 0) | 0;
            if (a > bestA) {
                bestA = a;
                pickSlot = i;
            }
        }
    }
    if (pickSlot < 0)
        return false;
    const pickPos = (slotDeckPos[pickSlot] ?? -1) | 0;
    if (pickPos < 0 || pickPos >= cardsArr.length)
        return false;
    // Find a donor in the undrawn segment (>= deckIdx), but keep it local first.
    function findDonorLocal(colorId, startFrom, scanN) {
        const start = Math.max(0, startFrom | 0);
        const end = Math.min(cardsArr.length, start + Math.max(1, scanN | 0));
        for (let j = start; j < end; j++) {
            if (getCardColorId(cardsArr[j]) === (colorId | 0))
                return j;
        }
        return -1;
    }
    const startFrom = Math.max(0, deckIdx);
    let donor = findDonorLocal(target, startFrom, 80);
    if (donor < 0)
        donor = findDonorLocal(target, startFrom + 80, cardsArr.length);
    if (donor < 0 || donor === pickPos)
        return false;
    const tmp = cardsArr[pickPos];
    cardsArr[pickPos] = cardsArr[donor];
    cardsArr[donor] = tmp;
    return true;
}
// Stagepack-level repair: only reorder cards / redistribute ammo.
async function repairStagePack(pack, maxSteps, maxAutoFixPerStage, maxIters, beamOpts, onlyStageId) {
    const stages = Array.isArray(pack?.stages) ? pack.stages : Array.isArray(pack) ? pack : [];
    const outPack = JSON.parse(JSON.stringify(pack));
    const outStages = Array.isArray(outPack?.stages) ? outPack.stages : outPack;
    const results = [];
    for (let i = 0; i < stages.length; i++) {
        const st = outStages[i];
        const id = st.id ?? (i + 1);
        if (typeof onlyStageId === 'number' && (id | 0) !== (onlyStageId | 0)) {
            continue;
        }
        let last = null;
        let bestSolved = null;
        let strictLast = null;
        // Adaptive strict repair state: when we hit the same STUCK signature repeatedly,
        // expand the repair pivot further back to escape local minima.
        let prevStuckSig = '';
        let stagnation = 0;
        let backjump = 0;
        // ✅ Final-mode: deck order를 JSON에 고정하기 위해, GENERATE 스테이지는 1회 bake하여 AUTHORED로 변환합니다.
        // - 이렇게 하면 게임 로직에서 카드 재배치/재정렬을 제거해도 항상 동일한 순서로 배치/공급됩니다.
        try {
            const cardsObj = st.cards ?? (st.cards = {});
            const hasAuthored = Array.isArray(cardsObj.authored) && cardsObj.authored.length > 0;
            const hasList = Array.isArray(cardsObj.list) && cardsObj.list.length > 0;
            if (!hasAuthored) {
                if (hasList) {
                    cardsObj.mode = cardsObj.mode ?? 'AUTHORED';
                    cardsObj.authored = cardsObj.list;
                }
                else {
                    const m = cardsObj.mode;
                    if (m == null || m === 'GENERATE') {
                        const rt = (0, StageCompiler_1.compileRuntimeFromV2)(st);
                        const baked = (rt?.cards ?? []).map((cd, idx) => ({
                            color: Types_1.COLOR_TOKEN_ORDER[(cd?.colorId ?? -1) | 0] ?? ((cd?.colorId ?? -1) | 0),
                            ammo: (cd?.ammo ?? 0) | 0,
                            shotCount: cd?.shotCount,
                            hintStep: ((cd?.hintStep ?? (idx + 1)) | 0),
                            hintRank: cd?.hintRank,
                            kind: cd?.kind,
                        }));
                        cardsObj.mode = 'AUTHORED';
                        cardsObj.authored = baked;
                    }
                }
            }
                        else {
                if (cardsObj.mode == null)
                    cardsObj.mode = 'AUTHORED';
            }
            // ✅ Edited stages can invalidate authored deck totals (e.g., meta.blockCount changed).
            // If StageCompiler throws "authored ammo mismatch", rebuild deck by re-generating once.
            if (Array.isArray(cardsObj.authored) && cardsObj.authored.length > 0) {
                try {
                    const layerCount = st?.meta?.layerCount ?? 1;
                    const enableStacks = (layerCount | 0) > 1;
                    (0, StageCompiler_1.compileRuntimeFromV2)(st, { enableStacks });
                }
                catch (e) {
                    const msg = String(e?.message ?? e);
                    if (msg.includes('authored ammo mismatch') || msg.includes('ammo sum mismatch')) {
                        const rules = cardsObj.rules;
                        const src = cardsObj.src;
                        cardsObj.mode = 'GENERATE';
                        delete cardsObj.authored;
                        delete cardsObj.list;
                        const layerCount = st?.meta?.layerCount ?? 1;
                        const enableStacks = (layerCount | 0) > 1;
                        const rt = (0, StageCompiler_1.compileRuntimeFromV2)(st, { enableStacks });
                        const baked = (rt?.cards ?? []).map((cd, idx) => ({
                            color: Types_1.COLOR_TOKEN_ORDER[(cd?.colorId ?? -1) | 0] ?? ((cd?.colorId ?? -1) | 0),
                            ammo: (cd?.ammo ?? 0) | 0,
                            shotCount: cd?.shotCount,
                            hintStep: ((cd?.hintStep ?? (idx + 1)) | 0),
                            hintRank: cd?.hintRank,
                            kind: cd?.kind,
                        }));
                        cardsObj.mode = 'AUTHORED';
                        cardsObj.rules = rules;
                        cardsObj.src = src ?? cardsObj.src ?? 'STAGE_TOOL';
                        cardsObj.authored = baked;
                    }
                    else {
                        throw e;
                    }
                }
            }
        }
        catch { }
        for (let it = 0; it <= maxIters; it++) {
            // 1) Simulate with in-sim autofix (represents runtime fail-safe).
            last = await simulateStage(st, maxSteps, maxAutoFixPerStage);
            if (last.status === 'SOLVED') {
                // Keep the best "solved with autofix" result for reporting even if strict remains stuck.
                if (!bestSolved || ((bestSolved.autoFixUsed ?? 0) | 0) > ((last.autoFixUsed ?? 0) | 0)) {
                    bestSolved = last;
                }
                // 2) Optional strict re-check (no autofix) to see if authored deck order is inherently clearable.
                if (maxAutoFixPerStage > 0 && ((last.autoFixUsed ?? 0) | 0) > 0) {
                    strictLast = await simulateStage(st, maxSteps, 0);
                    bestSolved.strict = strictLast;
                    if (strictLast.status === 'SOLVED') {
                        // Great: strict also solves.
                        bestSolved = strictLast;
                        break;
                    }
                    // If we have no repair iterations, report bestSolved (with strict attached) and stop.
                    if (maxIters <= 0)
                        break;
                    // Continue repairing against the strict stuck snapshot.
                    last = strictLast;
                }
                else {
                    break;
                }
            }
            if (last.status === 'UNKNOWN')
                break;
            if (last.status !== 'STUCK')
                break;
            if (it >= maxIters)
                break;
            // Repair: reorder remaining deck front using the stuck needCounts.
            const needCounts = Array.isArray(last?.stuck?.needCounts) ? last.stuck.needCounts : [];
            if (needCounts.length !== 12)
                break;
            // Track repeated STUCK patterns.
            {
                const s = last?.stuck ?? {};
                const deckIdx = (s.deckIdx ?? 0) | 0;
                const slotColors = Array.isArray(s.slotColors) ? s.slotColors : [];
                const slotPos = Array.isArray(s.slotDeckPos) ? s.slotDeckPos : [];
                const sig = `${deckIdx}|${slotColors.join(',')}|${slotPos.join(',')}|${needCounts.join(',')}`;
                if (sig === prevStuckSig) {
                    stagnation += 1;
                }
                else {
                    prevStuckSig = sig;
                    stagnation = 0;
                    backjump = 0;
                }
                if (stagnation >= 2) {
                    backjump = Math.min(80, backjump + 20);
                }
            }
            // StageV2 card list: support stage.cards.authored or stage.cards (fallback)
            let cardsArr = Array.isArray(st?.cards?.authored)
                ? st.cards.authored
                : Array.isArray(st?.cards)
                    ? st.cards
                    : [];
            // If the stage uses cards.mode=GENERATE (no authored/list), we cannot repair deck order unless
            // we first "bake" the generated deck into an authored list.
            // This keeps STRICT reproducibility while still allowing stage-tool to author in GENERATE mode.
            if (!Array.isArray(cardsArr) || cardsArr.length === 0) {
                const m = st?.cards?.mode;
                if (m == null || m === 'GENERATE') {
                    try {
                        const rt = (0, StageCompiler_1.compileRuntimeFromV2)(st);
                        const authored = (rt?.cards ?? []).map((cd, idx) => ({
                            color: Types_1.COLOR_TOKEN_ORDER[(cd?.colorId ?? -1) | 0] ?? ((cd?.colorId ?? -1) | 0),
                            ammo: (cd?.ammo ?? 0) | 0,
                            shotCount: cd?.shotCount,
                            hintStep: ((cd?.hintStep ?? (idx + 1)) | 0),
                            hintRank: cd?.hintRank,
                            kind: cd?.kind,
                        }));
                        st.cards = st.cards ?? {};
                        st.cards.mode = 'AUTHORED';
                        st.cards.authored = authored;
                        cardsArr = authored;
                    }
                    catch {
                        // Ignore and fall through to break.
                    }
                }
            }
            if (!Array.isArray(cardsArr) || cardsArr.length === 0)
                break;
            // Apply repair on authored cards directly.
            const need = new Int32Array(needCounts);
            // 0) Strict-deadlock repair: swap needed colors into the exact deck positions that filled the stuck slots.
            // This targets the common strict STUCK where slots are occupied by a color with no remaining targets.
            const didSlotSwap = repairSwapNeededIntoStuckSlots(cardsArr, last?.stuck, need);
            // 1) Global reorder: pull top need colors forward.
            const tmpDeck = cardsArr.slice();
            const rawDeckIdx = Math.max(0, (last?.stuck?.deckIdx ?? 0) | 0);
            const slotPos = Array.isArray(last?.stuck?.slotDeckPos) ? last.stuck.slotDeckPos : [];
            let minSlotPos = rawDeckIdx;
            for (const p0 of slotPos) {
                const p = (p0 ?? -1) | 0;
                if (p >= 0)
                    minSlotPos = Math.min(minSlotPos, p);
            }
            const pivotBase = Math.max(0, Math.min(rawDeckIdx, minSlotPos));
            const pivotDeckIdx = Math.max(0, pivotBase - (backjump | 0));
            // Pull needed colors forward, but keep it LOCAL and MINIMAL to avoid strict oscillation.
            const neededColors = pickTopNeedColors(need, 12);
            const capSlots = (Array.isArray(last?.stuck?.slotColors) ? last.stuck.slotColors.length : 0) | 0;
            // If only one color is needed, a huge pull (e.g. 48) tends to create the next deadlock when the front color flips.
            // Keep it small and local; rely on slot-swap to break the immediate deadlock.
            const bringCards = (neededColors.length <= 1)
                ? Math.min(12, Math.max(4, capSlots + 3))
                : Math.min(24, Math.max(8, capSlots * 4));
            const scanLimit = (neededColors.length <= 1) ? 56 : 72;
            // If we successfully swapped a needed card into a stuck slot, avoid additional reorder unless we're stagnating.
            const doReorder = (!didSlotSwap) || (stagnation > 0);
            if (doReorder) {
                reorderUpcomingDeckByNeed(tmpDeck, pivotDeckIdx, need, Math.min(bringCards, tmpDeck.length - pivotDeckIdx), scanLimit);
            }
            for (let k = 0; k < tmpDeck.length; k++)
                cardsArr[k] = tmpDeck[k];
            // 2) If still stuck on next iteration, run a deterministic beam search over deck order.
            // IMPORTANT: Beam uses many headless simulations (each allocates a Board/Nodes).
            // Keep it stable by running it at most once per stage-repair call.
            if (beamOpts.enabled && it === 0) {
                const base = cardsArr.slice();
                const { deck: bestDeck, best } = await beamReorderDeckForStage(st, base, {
                    depth: beamOpts.depth,
                    window: beamOpts.window,
                    beam: beamOpts.beam,
                    simSteps: Math.min(beamOpts.simSteps, maxSteps),
                });
                for (let k = 0; k < bestDeck.length; k++)
                    cardsArr[k] = bestDeck[k];
                if (best?.status === 'SOLVED')
                    break;
            }
        }
        const out = bestSolved ?? last;
        // Ensure strict result is surfaced when we have it.
        // - SOLVED(autoFixUsed=0)인 경우는 이미 strict-clear이므로, 이전 iter의 stale strict 스냅샷을 붙이지 않습니다.
        const outAutoFix = (out?.autoFixUsed ?? 0) | 0;
        const wantStrict = out?.status !== 'SOLVED' || outAutoFix > 0;
        if (wantStrict && strictLast && out && !out.strict)
            out.strict = strictLast;
        // ✅ Final export: authored deck 순서가 곧 "배치/공급" 순서이므로, hintStep도 배열 순서대로 1..N으로 재부여합니다.
        try {
            const cardsObj = st.cards ?? (st.cards = {});
            if (cardsObj.mode == null)
                cardsObj.mode = 'AUTHORED';
            const arr = Array.isArray(cardsObj.authored) ? cardsObj.authored : [];
            for (let k = 0; k < arr.length; k++) {
                const d = arr[k] ?? {};
                d.hintStep = (k + 1) | 0;
                arr[k] = d;
            }
            cardsObj.authored = arr;
        }
        catch { }
        results.push({ id, ...out });
    }
    const summary = {
        total: results.length,
        solved: results.filter((r) => r.status === 'SOLVED').length,
        stuck: results.filter((r) => r.status === 'STUCK').length,
        unknown: results.filter((r) => r.status === 'UNKNOWN').length,
        error: results.filter((r) => r.status === 'ERROR').length,
    };
    return { pack: outPack, report: { summary, results } };
}
async function main() {
    const args = process.argv.slice(2);
    const inIdx = args.indexOf('--in');
    const reportIdx = args.indexOf('--report');
    const outIdx = args.indexOf('--out');
    const maxStepsIdx = args.indexOf('--max-steps');
    const fixIdx = args.indexOf('--max-autofix');
    const itersIdx = args.indexOf('--repair-iters');
    const stageIdIdx = args.indexOf('--stage-id');
    const inp = inIdx >= 0 ? args[inIdx + 1] : '';
    const reportPath = reportIdx >= 0 ? args[reportIdx + 1] : '';
    const outPath = outIdx >= 0 ? args[outIdx + 1] : '';
    const maxSteps = maxStepsIdx >= 0 ? parseInt(args[maxStepsIdx + 1] ?? '50000', 10) : 50000;
    // Autofix is cheap (slot swap / local deck reorder). Default higher to avoid false STUCK
    // when the deck still contains needed colors but the current slots do not.
    const maxAutoFixPerStage = fixIdx >= 0 ? parseInt(args[fixIdx + 1] ?? '100', 10) : 100;
    // Stagepack repair iterations. Strict-SOLVED requires more iterations on some packs.
    const maxIters = itersIdx >= 0 ? parseInt(args[itersIdx + 1] ?? '120', 10) : 120;
    const onlyStageId = stageIdIdx >= 0 ? parseInt(args[stageIdIdx + 1] ?? '', 10) : undefined;
    const beamOffIdx = args.indexOf('--beam-off');
    const beamAutoIdx = args.indexOf('--beam-auto');
    const beamDepthIdx = args.indexOf('--beam-depth');
    const beamWindowIdx = args.indexOf('--beam-window');
    const beamWidthIdx = args.indexOf('--beam-width');
    const beamSimIdx = args.indexOf('--beam-simsteps');
    const beamOpts = {
        enabled: beamOffIdx < 0,
        depth: beamDepthIdx >= 0 ? parseInt(args[beamDepthIdx + 1] ?? '12', 10) : 12,
        window: beamWindowIdx >= 0 ? parseInt(args[beamWindowIdx + 1] ?? '10', 10) : 10,
        beam: beamWidthIdx >= 0 ? parseInt(args[beamWidthIdx + 1] ?? '16', 10) : 16,
        simSteps: beamSimIdx >= 0 ? parseInt(args[beamSimIdx + 1] ?? '2000', 10) : 2000,
    };
    if (!inp) {
        console.error('Usage: node dist/cli.js --in stagepack.json --report report.json [--out stagepack_repaired.json] [--stage-id N] [--repair-iters N] [--max-steps N] [--max-autofix N] [--beam-off] [--beam-auto] [--beam-depth N] [--beam-window N] [--beam-width N] [--beam-simsteps N]');
        process.exit(1);
    }
    const pack = loadJson(inp);
    // If enabled, progressively increase beam strength when stages remain STUCK.
    // This never modifies board/tile data; only card order/ammo can change.
    const autoBeam = beamAutoIdx >= 0;
    // Keep beam-auto stable: conservative levels, bounded cache, and early-stop on non-improvement.
    const beamLevels = [
        { depth: Math.max(8, Math.min(12, beamOpts.depth)), window: Math.max(8, Math.min(10, beamOpts.window)), beam: Math.max(10, Math.min(14, beamOpts.beam)), simSteps: Math.max(1000, Math.min(1500, beamOpts.simSteps)) },
        { depth: 12, window: 9, beam: 12, simSteps: 1400 },
    ];
    let curPack = pack;
    let outPack = null;
    let report = null;
    if (autoBeam && beamOpts.enabled) {
        let prevStuck = 1e9;
        let prevRemainSum = 1e18;
        let stale = 0;
        for (let li = 0; li < beamLevels.length; li++) {
            const lvl = beamLevels[li];
            const { pack: p2, report: r2 } = await repairStagePack(curPack, maxSteps, maxAutoFixPerStage, maxIters, { enabled: true, depth: lvl.depth, window: lvl.window, beam: lvl.beam, simSteps: lvl.simSteps }, onlyStageId);
            outPack = p2;
            report = r2;
            curPack = p2;
            const stuck = (report?.summary?.stuck ?? 0) | 0;
            let remainSum = 0;
            try {
                const res = Array.isArray(report?.results) ? report.results : [];
                for (const rr of res) {
                    if (rr?.status === 'STUCK')
                        remainSum += Math.max(0, (rr.remaining ?? 0) | 0);
                }
            }
            catch { }
            console.log(`[validator] beam-auto level ${li + 1}/${beamLevels.length}: depth=${lvl.depth} window=${lvl.window} beam=${lvl.beam} simSteps=${lvl.simSteps} -> stuck=${stuck}`);
            if (stuck <= 0)
                break;
            // Early-stop if both stuck count and remaining-sum stop improving.
            const improved = (stuck < prevStuck) || (remainSum + 5 < prevRemainSum);
            if (improved) {
                prevStuck = stuck;
                prevRemainSum = remainSum;
                stale = 0;
            }
            else {
                stale++;
                if (stale >= 2)
                    break;
            }
        }
    }
    else {
        const r = await repairStagePack(curPack, maxSteps, maxAutoFixPerStage, maxIters, beamOpts, onlyStageId);
        outPack = r.pack;
        report = r.report;
    }
    // Helpful debugging context for interpreting arrays like needCounts/ammoByColor.
    if (report && !report.colorMap) {
        report.colorMap = Types_1.COLOR_TOKEN_ORDER.map((token, id) => ({ id, token }));
    }
    if (reportPath) {
        fs_1.default.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    }
    else {
        console.log(JSON.stringify(report, null, 2));
    }
    if (outPath)
        fs_1.default.writeFileSync(outPath, JSON.stringify(outPack, null, 2));
    // Always print a small summary so "silent success" doesn't confuse users.
    const s = report?.summary;
    if (s) {
        console.log(`[validator] done. total=${s.total} solved=${s.solved} stuck=${s.stuck} unknown=${s.unknown} error=${s.error}`);
        if (onlyStageId != null)
            console.log(`[validator] filtered stage-id=${onlyStageId}`);
        if (reportPath)
            console.log(`[validator] report: ${reportPath}`);
        if (outPath)
            console.log(`[validator] out: ${outPath}`);
    }
}

// ---- Export API for the stage tool ----
exports.simulateStage = simulateStage;
exports.repairStagePack = repairStagePack;
exports.beamReorderDeckForStage = beamReorderDeckForStage;

// CLI entry is intentionally disabled in the stage tool bundle.
