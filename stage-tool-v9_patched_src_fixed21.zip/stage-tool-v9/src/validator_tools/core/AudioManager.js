"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AudioManager = void 0;
class AudioManager {
    static get I() { return this.inst; }
    playSfx(_name, _vol) { }
    playSfxByIndex(_idx, _opt) { }
    playBgmByIndex(_idx, _loop = true) { }
}
exports.AudioManager = AudioManager;
AudioManager.inst = new AudioManager();
