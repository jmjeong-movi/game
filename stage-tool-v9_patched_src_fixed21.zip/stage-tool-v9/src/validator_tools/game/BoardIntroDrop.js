"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BoardIntroDrop = void 0;
const cc_1 = require("cc");
class BoardIntroDrop extends cc_1.Component {
    constructor() {
        super(...arguments);
        this.IntroEnabled = false;
    }
    play(_args) { }
}
exports.BoardIntroDrop = BoardIntroDrop;
