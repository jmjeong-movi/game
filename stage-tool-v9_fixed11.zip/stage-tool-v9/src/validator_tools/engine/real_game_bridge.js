/* eslint-disable no-console */
const fs = require('fs');
const path = require('path');

function loadExternalEngine() {
  const modPathRaw = process.env.REAL_GAME_VALIDATOR_MODULE || '';
  if (!modPathRaw) return null;
  const modPath = path.resolve(process.cwd(), modPathRaw);
  if (!fs.existsSync(modPath)) return null;
  // eslint-disable-next-line import/no-dynamic-require, global-require
  const mod = require(modPath);
  if (!mod || typeof mod.validateStageEquivalent !== 'function') return null;
  return { mod, modPath };
}

module.exports = { loadExternalEngine };
