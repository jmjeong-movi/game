require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/ts-node/register/transpile-only');
const fs = require('fs');

(async () => {
  const mod = await import('./src/lib/replay_repair.ts');
  const repairStageUntilReplaySolved = mod.repairStageUntilReplaySolved;
  if (typeof repairStageUntilReplaySolved !== 'function') throw new Error('repairStageUntilReplaySolved not found');

  const pack = JSON.parse(fs.readFileSync('/mnt/data/stagepack_v2.json', 'utf-8'));
  const stages = Array.isArray(pack?.stages) ? pack.stages.slice() : [];
  stages.sort((a, b) => ((a?.id ?? 0) | 0) - ((b?.id ?? 0) | 0));

  const outStages = [];
  const results = [];
  const replayFailures = [];

  for (let si = 0; si < stages.length; si++) {
    const st = stages[si];
    const id = (st?.id ?? (si + 1)) | 0;

    const { stage: fixedStage, report, replay } = await repairStageUntilReplaySolved(st, {
      maxIters: 800,
      maxRounds: 200000,
      maxShots: 2000000,
    });

    outStages.push(fixedStage);

    const row = {
      id,
      replay: {
        status: replay?.status ?? 'UNKNOWN',
        reason: replay?.reason ?? null,
        clicked: replay?.clicked ?? 0,
        rounds: replay?.rounds ?? 0,
        shotsFired: replay?.shotsFired ?? 0,
        nextHint: replay?.nextHint ?? null,
        stuck: replay?.stuck ?? null,
      },
      replayRepair: report,
    };
    results.push(row);

    if ((replay?.status ?? 'UNKNOWN') !== 'SOLVED') {
      replayFailures.push({
        id,
        status: replay?.status ?? 'UNKNOWN',
        reason: replay?.reason ?? null,
        clicked: replay?.clicked ?? 0,
        rounds: replay?.rounds ?? 0,
        shotsFired: replay?.shotsFired ?? 0,
        nextHint: replay?.nextHint ?? null,
        stuck: replay?.stuck ?? null,
        replayRepair: report,
      });
    }

    console.log(`[${si + 1}/${stages.length}] stageId=${id} replay=${replay?.status} iters=${report?.iters ?? 0} reason=${replay?.reason ?? ''}`);
  }

  const summary = {
    total: stages.length,
    replaySolved: results.filter((r) => String(r?.replay?.status) === 'SOLVED').length,
    replayStuck: results.filter((r) => String(r?.replay?.status) === 'STUCK').length,
    replayUnknown: results.filter((r) => String(r?.replay?.status) === 'UNKNOWN').length,
  };

  const outPack = { ...pack, schemaVersion: 2, stages: outStages };

  fs.writeFileSync('/mnt/data/stagepack_v2_strict_solved_FIXED16.json', JSON.stringify(outPack, null, 2));
  fs.writeFileSync('/mnt/data/report_stagepack_v2_strict_solved_FIXED16.json', JSON.stringify({ summary, results, replayFailures }, null, 2));

  console.log('summary', summary);
  if (replayFailures.length > 0) {
    console.log('FAILURES', replayFailures.map((f) => ({ id: f.id, status: f.status, reason: f.reason })));
    process.exitCode = 2;
  }
})();
