export const GRID_ROWS = 10;
export const GRID_COLS = 10;
export const TILE_W = 60;
export const TILE_H = 65;

// ✅ legacy scalar(가로 기준). 기존 코드(TILE_SIZE)는 TILE_W로 동작합니다.
export const TILE_SIZE = TILE_W;

// 기본 카드 개수(스테이지에서 별도 지정이 없을 때 사용)
export const DEFAULT_CARD_COUNT = 25;

// 총알(프로젝타일) 풀 프리워밍 개수
export const PROJECTILE_POOL_WARMUP = 40;

// 바닥줄 타겟 선택 방식: true=왼쪽부터, false=랜덤 시작 스캔
export const TARGET_LEFTMOST = true;
