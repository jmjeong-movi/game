"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TileView = void 0;
const cc_1 = require("cc");
class TileView extends cc_1.Component {
    constructor() {
        super(...arguments);
        this.node = new cc_1.Node();
        this.row = 0;
        this.col = 0;
        this.colorId = 0;
        this.depth = 1;
        this._stack = [];
        this._hidden = false;
        this._special = null;
        this._hp = 1;
        this._hpMax = 1;
    }
    clear() {
        this._stack = [];
        this.depth = 1;
        this.colorId = 0;
        this._hidden = false;
        this._special = null;
        this._hp = 1;
        this._hpMax = 1;
    }
    setTop(cid) {
        this.colorId = cid | 0;
        this.depth = 1;
        this._stack = [this.colorId];
    }
    setStack(stack) {
        this._stack = stack.slice();
        this.depth = Math.max(1, this._stack.length | 0);
        this.colorId = this._stack[this._stack.length - 1] | 0;
    }
    popTop() {
        if (this._stack.length > 1) {
            this._stack.pop();
            this.depth = this._stack.length;
            this.colorId = this._stack[this._stack.length - 1] | 0;
        }
        else {
            this.depth = 1;
        }
    }
    setHidden(v) { this._hidden = !!v; }
    isHidden() { return this._hidden; }
    setSpecial(sp) { this._special = sp; }
    getSpecial() { return this._special; }
    setHp(hp, hpMax) {
        this._hp = Math.max(1, hp | 0);
        this._hpMax = Math.max(1, hpMax | 0);
    }
    getHp() { return this._hp; }
    getStackRef() { return this._stack; }
    decHp(d) {
        this._hp = Math.max(0, (this._hp | 0) - (d | 0));
        return this._hp;
    }
    hpLeft() { return this._hp; }
    hpMax() { return this._hpMax; }
    // FX/animation no-ops
    playHitFx() { }
    hitSide(_side, _amount) { }
    forceRefresh() { }
}
exports.TileView = TileView;
