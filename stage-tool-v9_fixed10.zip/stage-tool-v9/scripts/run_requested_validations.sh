#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOOL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$REPO_ROOT" ]]; then
  REPO_ROOT="$(cd "$TOOL_DIR/../.." && pwd)"
fi
cd "$REPO_ROOT"

if [[ -n "${REAL_GAME_VALIDATOR_MODULE:-}" ]]; then
  "$TOOL_DIR/scripts/real_engine_preflight.sh" || true
fi

CLI_JS="$TOOL_DIR/src/validator_tools/cli.js"
[[ -f "$CLI_JS" ]] || { echo "validator CLI not found: $CLI_JS"; exit 2; }

node "$CLI_JS" repair \
  --input stagepack_v2_replay_solved_fixed21.json \
  --output stagepack_v2_replay_solved_fixed21_validation.json \
  --report stagepack_v2_replay_solved_fixed21_report.json || true

node "$CLI_JS" repair \
  --input stagepack_v2_matrix_120.json \
  --output stagepack_v2_matrix_120_validated.json \
  --report stagepack_v2_matrix_120_report.json || true

python - <<'PY'
import json
out={}
for p,key in [('stagepack_v2_replay_solved_fixed21_report.json','fixed21'),('stagepack_v2_matrix_120_report.json','matrix120')]:
    d=json.load(open(p,'r',encoding='utf-8'))
    s=d.get('summary',{})
    rows=d.get('results',[])
    reasons={}
    for r in rows:
        if str(r.get('status'))!='SOLVED':
            k=str(r.get('reason','UNKNOWN'))
            reasons[k]=reasons.get(k,0)+1
    out[key]={
        'validationMode': d.get('validationMode'),
        'validationTrust': d.get('validationTrust'),
        'engineInfo': d.get('engineInfo'),
        'summary': s,
        'unsolvedReasons': reasons,
    }
out['nextAction']='RUN scripts/real_engine_preflight.sh then revalidate'
print(json.dumps(out,ensure_ascii=False,indent=2))
open('validation_fixed10_report.json','w',encoding='utf-8').write(json.dumps(out,ensure_ascii=False,indent=2))
if out['matrix120']['summary'].get('unsolved',1)>0:
    raise SystemExit(3)
PY
