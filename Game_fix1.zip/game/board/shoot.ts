// 역할: Board 발사/타겟 선택 로직 분리
// - Board.ts의 과도한 파일 크기를 줄이고, 유닛/리플레이/검증이 공통으로 쓰는 조준 규칙을 한 곳에서 유지합니다.

import { UITransform, Vec3, tween, Tween } from 'cc';

import { ProjectileView } from '../ProjectileView';

// ---------------------------------------------
// ✅ 공중 체인(바닥이 비었을 때만) 타게팅 지원
//
// 요구사항:
// - 체인 블럭(CHAIN_SEG)이 바닥(row0)이 아닌 다른 row에 배치되어
//   그 때문에 다른 블럭이 내려오지 못해 "바닥열에(기둥 제외) 더 이상 타겟이 없을 때"
//   공중 체인 세그먼트를 타겟/히트할 수 있어야 합니다.
// - 그 전(바닥에 타겟이 남아있을 때)에는 공중 체인을 타겟으로 잡지 않습니다.
// ---------------------------------------------

function hasRow0ShootableNonPillar(b: any): boolean {
    const cols = (b?.cols ?? 0) | 0;
    for (let c = 0; c < cols; c++) {
        const e = b.entAt?.(0, c);
        if (!e) continue;

        const depth = (e.view?.depth ?? 1) | 0;
        const sp = depth <= 1 ? e.view?.getSpecial?.() ?? null : null;

        // 타겟으로 "잡지 않는" 오브젝트는 제외
        if (sp?.t === 'PILLAR') continue;
        if (sp?.t === 'SPAWNER_BOX') continue;
        if (sp?.t === 'LOCK' && !b.unlockedLocks?.has?.(sp.id)) continue;

        // 남아있는 row0 타겟이 하나라도 있으면 공중 체인 타겟팅을 금지
        return true;
    }
    return false;
}

function canTargetAirChain(b: any): boolean {
    // row0에 "기둥 제외" 타겟이 하나도 없을 때만 허용
    return !hasRow0ShootableNonPillar(b);
}

// ✅ 최하단 엔티티 탐색(타겟 불가 오브젝트는 스킵)
// - 요구사항: 바닥(row0)에 '기둥 제외' 타겟이 없을 때, 공중 체인 타게팅 시
//   (row0에 PILLAR가 있어도) 그 위의 CHAIN_SEG를 타겟으로 잡을 수 있어야 합니다.
function findLowestTargetableEntInColumn(b: any, col: number): { e: any; row: number } | null {
    const rows = ((b?.rows ?? 10) | 0) as number;
    const entAt = b?.entAt;
    if (typeof entAt !== 'function') return null;
    for (let r = 0; r < rows; r++) {
        const e = entAt.call(b, r, col);
        if (!e) continue;

        const depth = (e.view?.depth ?? 1) | 0;
        const sp = depth <= 1 ? e.view?.getSpecial?.() ?? null : null;

        // 타겟 불가 오브젝트는 스킵
        if (sp?.t === 'PILLAR') continue;
        if (sp?.t === 'SPAWNER_BOX') continue;
        if (sp?.t === 'LOCK' && !b.unlockedLocks?.has?.(sp.id)) continue;

        return { e, row: r | 0 };
    }
    return null;
}

// ✅ CHAIN_SEG는 '꼬리(최대 order)'를 타겟으로 삼습니다.
// - hit.ts와 동일한 방식으로 tail을 찾되, shoot.ts에서 재사용합니다.
function resolveChainTailEnt(b: any, chainId: string): any | null {
    const cid = String(chainId ?? '');
    if (!cid) return null;

    let tail: any = null;
    let bestOrd = -2147483648;

    const seg = b?._chainSegIds?.get?.(cid);
    if (seg && seg.size > 0) {
        for (const entId of seg) {
            const ee = b?.ents?.get?.(entId | 0);
            if (!ee) continue;
            const s2 = (ee.view?.depth ?? 1) <= 1 ? ee.view?.getSpecial?.() : null;
            if (s2?.t !== 'CHAIN_SEG') continue;
            if (String((s2 as any).id ?? '') !== cid) continue;
            const ord = Number.isFinite((s2 as any).order) ? (((s2 as any).order as any) | 0) : 0;
            if (!tail || ord > bestOrd) {
                tail = ee;
                bestOrd = ord;
            }
        }
        return tail;
    }

    // fallback(매우 드묾)
    try {
        for (const ee of b?.ents?.values?.() ?? []) {
            const s2 = (ee.view?.depth ?? 1) <= 1 ? ee.view?.getSpecial?.() : null;
            if (s2?.t !== 'CHAIN_SEG') continue;
            if (String((s2 as any).id ?? '') !== cid) continue;
            const ord = Number.isFinite((s2 as any).order) ? (((s2 as any).order as any) | 0) : 0;
            if (!tail || ord > bestOrd) {
                tail = ee;
                bestOrd = ord;
            }
        }
    } catch {
        // ignore
    }
    return tail;
}

// Validate that a (colorId, entId) is currently shootable at row0/col.
// Used by UnitLineRack to keep a stable target (avoid per-shot retarget jitter).
export function isShootableTarget(b: any, colorId: number, entId: number, col: number): boolean {
    if (col < 0 || col >= b.cols) return false;
    if (b.colReserved[col] || b.colBusy[col] || (b.colSpawnLock?.[col] ?? 0)) return false;
    const e = b.entAt(0, col);
    if (!e) return false;
    if ((e.id | 0) !== (entId | 0)) return false;
    const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
    // ✅ 타겟 불가 오브젝트
    if (sp?.t === 'SPAWNER_BOX') return false;
    if (sp?.t === 'PILLAR') return false;
    if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) return false;
    if ((e.view?.colorId ?? -999) !== (colorId | 0)) return false;

    // ✅ 성능: entCols() 배열 할당 제거(컬럼 bitmask)
    // - CHAIN_SEG는 그룹 전체 컬럼이 모두 free여야 합니다.
    const m =
        sp?.t === 'CHAIN_SEG'
            ? (b.chainColMask ? b.chainColMask(String((sp as any).id ?? '')) : 1 << (col | 0))
            : b.entColMask
              ? b.entColMask(e)
              : 1 << (col | 0);

    for (let cc = 0; cc < b.cols; cc++) {
        if (!(m & (1 << cc))) continue;
        if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) return false;
    }
    return true;
}

// 엔티티 기준 shootable 판정(컬럼 고정 불필요)
export function isShootableEnt(b: any, colorId: number, entId: number): { ok: boolean; col: number } {
    const e = b.ents.get(entId | 0);
    if (!e) return { ok: false, col: -1 };

    // 기본: row0(바닥) 타겟
    if ((e.row | 0) === 0) {
        if ((e.view?.colorId ?? -999) !== (colorId | 0)) return { ok: false, col: -1 };

        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        // ✅ 타겟 불가 오브젝트
        if (sp?.t === 'SPAWNER_BOX') return { ok: false, col: -1 };
        if (sp?.t === 'PILLAR') return { ok: false, col: -1 };
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) return { ok: false, col: -1 };

        const isChain = sp?.t === 'CHAIN_SEG';
        const m =
            isChain && b.chainColMask
                ? b.chainColMask(String((sp as any).id ?? ''))
                : b.entColMask
                  ? b.entColMask(e)
                  : 1 << (e.col | 0);

        for (let cc = 0; cc < b.cols; cc++) {
            if (!(m & (1 << cc))) continue;
            if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) return { ok: false, col: -1 };

            // BIG은 footprint 전체가 같은 엔티티여야 함(부분 타격/분리 방지)
            if (!isChain) {
                const at = b.entAt(0, cc);
                if (!at || (at.id | 0) !== (e.id | 0)) return { ok: false, col: -1 };
            }
        }

        // CHAIN_SEG는 본인 컬럼만 동일 엔티티인지 확인(그 외 컬럼은 같은 체인 다른 세그먼트)
        if (isChain) {
            const at0 = b.entAt(0, e.col | 0);
            if (!at0 || (at0.id | 0) !== (e.id | 0)) return { ok: false, col: -1 };
        }
        return { ok: true, col: e.col | 0 };
    }

    // ✅ 확장: 공중(row>0) 체인 세그먼트는 "바닥에 더 이상 타겟이 없을 때(기둥 제외)"만 shootable
    // - 일반 블럭/빅블럭은 기존 정책대로 row0에서만 타겟
    if (!canTargetAirChain(b)) return { ok: false, col: -1 };

    if ((e.view?.colorId ?? -999) !== (colorId | 0)) return { ok: false, col: -1 };
    const spAir = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
    if (spAir?.t !== 'CHAIN_SEG') return { ok: false, col: -1 };

    // "해당 컬럼에서 가장 아래의 타겟 가능한 엔티티" 여야만 공중 체인으로 인정
    // - row0에 PILLAR가 있어도 그 위의 체인을 찾을 수 있어야 함
    const lowest = findLowestTargetableEntInColumn(b, e.col | 0);
    if (!lowest || !lowest.e || ((lowest.e.id | 0) !== (e.id | 0))) return { ok: false, col: -1 };
    if ((lowest.row | 0) <= 0) return { ok: false, col: -1 };

    const mAir = b.chainColMask ? b.chainColMask(String((spAir as any).id ?? '')) : 1 << (e.col | 0);
    for (let cc = 0; cc < b.cols; cc++) {
        if (!(mAir & (1 << cc))) continue;
        if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) return { ok: false, col: -1 };
    }
    return { ok: true, col: e.col | 0 };
}

// 현재(row0)에서 colorId로 쏠 수 있는 BIG(2x2) 엔티티 목록(좌→우)
export function listShootableBigEnts(b: any, colorId: number, _pref: any = 'LEFT'): { entId: number; col: number }[] {
    const out: { entId: number; col: number }[] = [];

    // 좌→우 고정
    for (let c = 0; c < b.cols; c++) {
        if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) continue;
        const e = b.entAt(0, c);
        if (!e) continue;
        if ((e.view?.colorId ?? -999) !== (colorId | 0)) continue;
        if (!(e.w > 1 || e.h > 1)) continue;
        // 앵커(좌하단)에서만 수집 → 중복/Set 제거
        if ((e.col | 0) !== (c | 0)) continue;

        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) continue;

        // BIG은 footprint 전체가 free여야 실발사가 가능
        const m = b.entColMask ? b.entColMask(e) : (1 << (e.col | 0));
        let ok = true;
        for (let cc = 0; cc < b.cols; cc++) {
            if (!(m & (1 << cc))) continue;
            if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) {
                ok = false;
                break;
            }
            const at = b.entAt(0, cc);
            if (!at || (at.id | 0) !== (e.id | 0)) {
                ok = false;
                break;
            }
        }
        if (!ok) continue;
        out.push({ entId: e.id | 0, col: e.col | 0 });
    }

    return out;
}

// 현재(row0)에 존재하는 BIG(2x2) 엔티티 목록(좌→우), shootable 여부와 무관
export function listRow0BigEnts(b: any, colorId: number, _pref: any = 'LEFT'): { entId: number; col: number }[] {
    const out: { entId: number; col: number }[] = [];

    for (let c = 0; c < b.cols; c++) {
        const e = b.entAt(0, c);
        if (!e) continue;
        if ((e.view?.colorId ?? -999) !== (colorId | 0)) continue;
        if (!(e.w > 1 || e.h > 1)) continue;

        // 앵커(좌하단) 컬럼에서만 수집(중복 방지)
        if ((e.col | 0) !== (c | 0)) continue;

        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) continue;

        out.push({ entId: e.id | 0, col: e.col | 0 });
    }
    return out;
}

export function countRow0Big(b: any, colorId: number, pref: any = 'LEFT'): number {
    // ✅ 성능: 배열 생성 제거
    let n = 0;
    for (let c = 0; c < b.cols; c++) {
        const e = b.entAt(0, c);
        if (!e) continue;
        if ((e.view?.colorId ?? -999) !== (colorId | 0)) continue;
        if (!(e.w > 1 || e.h > 1)) continue;
        if ((e.col | 0) !== (c | 0)) continue;
        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) continue;
        n++;
    }
    return n;
}

export function countShootableBig(b: any, colorId: number, pref: any = 'LEFT'): number {
    // ✅ 성능: 배열/Set 생성 제거
    let n = 0;
    for (let c = 0; c < b.cols; c++) {
        if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) continue;
        const e = b.entAt(0, c);
        if (!e) continue;
        if ((e.view?.colorId ?? -999) !== (colorId | 0)) continue;
        if (!(e.w > 1 || e.h > 1)) continue;
        if ((e.col | 0) !== (c | 0)) continue;

        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) continue;

        const m = b.entColMask ? b.entColMask(e) : 1 << (e.col | 0);
        let ok = true;
        for (let cc = 0; cc < b.cols; cc++) {
            if (!(m & (1 << cc))) continue;
            if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) {
                ok = false;
                break;
            }
            const at = b.entAt(0, cc);
            if (!at || (at.id | 0) !== (e.id | 0)) {
                ok = false;
                break;
            }
        }
        if (!ok) continue;
        n++;
    }
    return n;
}

// colorId로 이번 프레임에 쏠 수 있는(앞줄 타겟이 있고 잠김/예약/바쁨이 아닌) 컬럼 개수
export function countShootableColumns(b: any, colorId: number): number {
    let n = 0;
    for (let c = 0; c < b.cols; c++) {
        if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) continue;
        const e = b.entAt(0, c);
        if (!e) continue;

        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) continue;

        if ((e.view.colorId | 0) === (colorId | 0)) n++;
    }
    return n;
}

// colorId로 이번 프레임에 쏠 타겟(컬럼)을 최대 maxShots개 선택
// - 엔티티(2x2 포함) 중복을 피해서 듀얼이 한 블럭에 몰빵되지 않게 함
// NOTE: excludeEnt is a per-color, per-frame planning aid.
export function pickShootTargets(
    b: any,
    colorId: number,
    maxShots: number,
    _pref: any = 'LEFT',
    excludeEnt?: Set<number>,
    allowBig: boolean = true,
): any[] {
    const out: any[] = [];
    const want = Math.max(1, maxShots | 0);

    const usedEnt: Set<number> = b._tmpPickUsedEnt;
    usedEnt.clear();
    const exEnt = excludeEnt;

    const tryPush = (e: any, col: number, isBig: boolean) => {
        if (!e) return;
        if (out.length >= want) return;
        if (b.colReserved[col] || b.colBusy[col] || (b.colSpawnLock?.[col] ?? 0)) return;

        const sp = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) return;

        // ✅ 타겟 불가 오브젝트
        if (sp?.t === 'SPAWNER_BOX') return;
        if (sp?.t === 'PILLAR') return;

        // 바닥(row0)만
        if (e.row !== 0) return;
        if ((e.view?.colorId ?? -999) !== (colorId | 0)) return;
        if (usedEnt.has(e.id)) return;
        if (exEnt?.has(e.id)) return;

        // BIG은 footprint 전체가 예약/바쁨이면 제외
        if (isBig) {
            const m = b.entColMask ? b.entColMask(e) : 1 << (col | 0);
            for (let cc = 0; cc < b.cols; cc++) {
                if (!(m & (1 << cc))) continue;
                if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) return;
            }
        }

        usedEnt.add(e.id);
        if (exEnt) exEnt.add(e.id);

        // ✅ 성능: 타겟 월드좌표 Vec3 할당 최소화
        // - Board.tmpV3()/cellWorldPosInto()가 있으면 Vec3 풀을 사용합니다.
        const world =
            typeof b?.cellWorldPosInto === 'function' && typeof b?.tmpV3 === 'function'
                ? b.cellWorldPosInto(0, col, b.tmpV3())
                : b.cellWorldPos(0, col);

        out.push({
            col,
            entId: e.id,
            world,
            isBig,
            hp: isBig ? (e.view.getHp?.() ?? 0) : 0,
        });
    };

    // 1) BIG 우선
    if (allowBig) {
        for (let c = 0; c < b.cols; c++) {
            if (out.length >= want) break;
            const e = b.entAt(0, c);
            if (!e) continue;
            if (!(e.w > 1 || e.h > 1)) continue;
            // 앵커에서만 시도(중복 호출 제거)
            if ((e.col | 0) !== (c | 0)) continue;
            tryPush(e, e.col, true);
        }
    }

    // 2) 남는 샷은 SMALL로 채움
    for (let c = 0; c < b.cols; c++) {
        if (out.length >= want) break;
        const e = b.entAt(0, c);
        if (!e) continue;
        if (e.w > 1 || e.h > 1) continue;

        // ✅ CHAIN_SEG는 '꼬리'만 타겟으로(요구사항)
        const sp0 = (e.view.depth ?? 1) <= 1 ? e.view.getSpecial() : null;
        if (sp0?.t === 'CHAIN_SEG') {
            const chainId = String((sp0 as any).id ?? '');
            const tail = resolveChainTailEnt(b, chainId);
            if (!tail) continue;
            // row0 tail만 허용(다른 세그먼트는 스킵)
            if (((tail.row ?? 0) | 0) !== 0) continue;
            const tc = (tail.col ?? -1) | 0;
            if (tc !== (c | 0)) continue;
            tryPush(tail, tc, false);
            continue;
        }

        tryPush(e, c, false);
    }

    // 3) ✅ 바닥(row0)에 타겟이 더 이상 없을 때(기둥 제외) 공중 체인(CHAIN_SEG) 타겟팅
    // - 목적: 공중 체인이 낙하를 막아 row0가 비는 교착 상태에서 진행 가능하게
    if (out.length <= 0 && canTargetAirChain(b)) {
        // ✅ 공중 체인도 '꼬리'를 타겟으로
        // - 우선 컬럼별 "최하단 타겟 가능" 엔티티를 스캔하여 체인 그룹을 발견
        // - 각 그룹의 tail(entId/col/row)을 1회만 계산
        const tailById: Map<string, any> = (b as any)._tmpPickAirChainTailById ?? new Map();
        (b as any)._tmpPickAirChainTailById = tailById;
        tailById.clear();

        for (let c = 0; c < b.cols; c++) {
            if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) continue;
            const low = findLowestTargetableEntInColumn(b, c);
            if (!low) continue;
            const e = low.e;
            const r = low.row | 0;
            if (r <= 0) continue;

            const depth = (e.view?.depth ?? 1) | 0;
            const sp = depth <= 1 ? e.view?.getSpecial?.() ?? null : null;
            if (sp?.t !== 'CHAIN_SEG') continue;
            if ((e.view?.colorId ?? -999) !== (colorId | 0)) continue;

            const chainId = String((sp as any).id ?? '');
            if (!chainId) continue;
            if (tailById.has(chainId)) continue;

            const tail = resolveChainTailEnt(b, chainId);
            if (!tail) continue;
            // tail도 공중(row>0)이어야 함
            const tr = (tail.row ?? 0) | 0;
            if (tr <= 0) continue;
            if ((tail.view?.colorId ?? -999) !== (colorId | 0)) continue;

            // tail이 그 컬럼에서 "최하단 타겟 가능"이어야 함(기둥 위 체인 포함)
            const tc = (tail.col ?? -1) | 0;
            const lowTail = tc >= 0 ? findLowestTargetableEntInColumn(b, tc) : null;
            if (!lowTail || !lowTail.e || ((lowTail.e.id | 0) !== (tail.id | 0))) continue;

            tailById.set(chainId, tail);
        }

        // tailCol 좌→우 순으로 push(요구사항: 좌측 우선)
        for (let c = 0; c < b.cols; c++) {
            if (out.length >= want) break;
            if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) continue;

            // 이 컬럼이 어떤 체인 tail인지 찾기(최대 체인 그룹 수가 작아 선형 탐색 허용)
            let tail: any = null;
            let chainId = '';
            for (const [cid, te] of tailById) {
                if (((te?.col ?? -1) | 0) === (c | 0)) {
                    tail = te;
                    chainId = cid;
                    break;
                }
            }
            if (!tail) continue;

            const entId = (tail.id | 0) as number;
            if (usedEnt.has(entId)) continue;
            if (exEnt?.has(entId)) continue;

            const sTail = (tail.view?.depth ?? 1) <= 1 ? tail.view?.getSpecial?.() ?? null : null;
            if (sTail?.t !== 'CHAIN_SEG') continue;

            // 체인 묶음은 그룹 전체 컬럼이 free여야 함
            const m = b.chainColMask ? b.chainColMask(String(chainId ?? (sTail as any).id ?? '')) : 1 << (c | 0);
            let ok = true;
            for (let cc = 0; cc < b.cols; cc++) {
                if (!(m & (1 << cc))) continue;
                if (b.colReserved[cc] || b.colBusy[cc] || (b.colSpawnLock?.[cc] ?? 0)) {
                    ok = false;
                    break;
                }
            }
            if (!ok) continue;

            usedEnt.add(entId);
            if (exEnt) exEnt.add(entId);

            const r = (tail.row ?? 0) | 0;
            const world =
                typeof b?.cellWorldPosInto === 'function' && typeof b?.tmpV3 === 'function'
                    ? b.cellWorldPosInto(r, c, b.tmpV3())
                    : b.cellWorldPos(r, c);

            out.push({
                col: c,
                entId,
                world,
                isBig: false,
                hp: 0,
                row: r,
            });
        }
    }

    return out;
}

// shooterWorld에서 “지정 컬럼(col)”로 colorId 발사를 시도
// - 성공 시: 해당 엔티티가 점유하는 모든 컬럼을 colReserved로 예약
export function tryShootAtColumnEx(b: any, shooterWorld: Vec3, colorId: number, col: number, out: any): boolean {
    // out 기본값(실패 시에도 안전)
    out.entId = 0;
    out.col0 = -1;
    out.col1 = -1;
    out.isBig = false;

    if (!b.projectilePrefab || !b.projectileLayer) return false;
    if (col < 0 || col >= b.cols) return false;
    if (b.colReserved[col] || b.colBusy[col] || (b.colSpawnLock?.[col] ?? 0)) return false;

    // 기본 타겟: row0(바닥)
    let targetEnt = b.entAt(0, col);
    let targetRow = 0;

    // ✅ 공중 체인 타겟(바닥에 더 이상 타겟이 없을 때만)
    // - row0가 비어있거나, row0가 PILLAR/LOCK(잠김)/SPAWNER_BOX 등 "타겟 불가" 오브젝트일 때
    //   그 위의 최하단 타겟 가능한 엔티티가 CHAIN_SEG이면 그 row로 발사
    const depth0 = targetEnt ? ((targetEnt.view?.depth ?? 1) | 0) : 0;
    const sp0 = targetEnt && depth0 <= 1 ? targetEnt.view?.getSpecial?.() ?? null : null;
    const row0NonTargetable =
        !!targetEnt &&
        (sp0?.t === 'PILLAR' ||
            sp0?.t === 'SPAWNER_BOX' ||
            (sp0?.t === 'LOCK' && !b.unlockedLocks?.has?.(sp0.id)));

    if (!targetEnt || row0NonTargetable) {
        if (!canTargetAirChain(b)) return false;
        const low = findLowestTargetableEntInColumn(b, col);
        if (!low) return false;
        if ((low.row | 0) <= 0) return false;
        const e = low.e;
        const depth = (e.view?.depth ?? 1) | 0;
        const sp = depth <= 1 ? e.view?.getSpecial?.() ?? null : null;
        if (sp?.t !== 'CHAIN_SEG') return false;
        targetEnt = e;
        targetRow = low.row | 0;
    }

    // LOCK은 키 전까지 제외
    let sp = (targetEnt.view.depth ?? 1) <= 1 ? targetEnt.view.getSpecial() : null;
    if (sp?.t === 'LOCK' && !b.unlockedLocks.has(sp.id)) return false;

    // ✅ 타겟 불가 오브젝트
    if (sp?.t === 'SPAWNER_BOX') return false;
    if (sp?.t === 'PILLAR') return false;

    if ((targetEnt.view.colorId | 0) !== (colorId | 0)) return false;

    // ✅ CHAIN_SEG는 꼬리로 정규화(요구사항)
    // - 호출자가 체인의 다른 세그먼트 컬럼을 넘겨도, 실제 발사/예약은 tail 기준으로 처리
    let targetCol = col | 0;
    if (sp?.t === 'CHAIN_SEG') {
        const chainId = String((sp as any).id ?? '');
        const tail = resolveChainTailEnt(b, chainId);
        if (tail && tail.view && ((tail.view?.colorId ?? -999) | 0) === (colorId | 0)) {
            targetEnt = tail;
            targetCol = (tail.col ?? targetCol) | 0;
            targetRow = (tail.row ?? targetRow) | 0;
            sp = (targetEnt.view.depth ?? 1) <= 1 ? targetEnt.view.getSpecial() : sp;
        }
    }

    // ✅ 엔티티 점유 컬럼 전체 예약(같은 블럭 동시타격 방지)
    // - 성능: reservedCols 배열 할당 제거(컬럼 bitmask)
    const reservedMask =
        sp?.t === 'CHAIN_SEG' && b.chainColMask
            ? b.chainColMask(String((sp as any).id ?? ''))
            : b.entColMask
              ? b.entColMask(targetEnt)
              : 1 << (targetCol | 0);

    for (let c = 0; c < b.cols; c++) {
        if (!(reservedMask & (1 << c))) continue;
        if (b.colReserved[c] || b.colBusy[c] || (b.colSpawnLock?.[c] ?? 0)) return false;
    }
    for (let c = 0; c < b.cols; c++) {
        if (!(reservedMask & (1 << c))) continue;
        b.colReserved[c] = 1;
        // ✅ 예약 마스크 캐시(스턱/예외 복구 + 배열 할당 제거)
        // - Board.handleHitColumn에서 target이 사라져도 정확히 예약 해제가 가능
        if (b.colResMask) b.colResMask[c] = reservedMask | 0;
    }

    const projectileNode = b.obtainProjectile();
    if (!projectileNode) {
        for (let c = 0; c < b.cols; c++) {
            if (!(reservedMask & (1 << c))) continue;
            b.colReserved[c] = 0;
            if (b.colResMask) b.colResMask[c] = 0;
        }
        return false;
    }

    // out 채우기(성공 시에만)
    out.entId = targetEnt.id;
    // col0/col1은 시각/디버깅 용도로만 사용(체인은 2개까지만 노출)
    out.col0 = -1;
    out.col1 = -1;
    for (let c = 0; c < b.cols; c++) {
        if (!(reservedMask & (1 << c))) continue;
        if (out.col0 < 0) out.col0 = c;
        else if (out.col1 < 0) {
            out.col1 = c;
            break;
        }
    }
    if (out.col0 < 0) out.col0 = targetCol | 0;
    out.isBig = targetEnt.w > 1 || targetEnt.h > 1;

    const pv = projectileNode.getComponent(ProjectileView);
    pv?.setColor(colorId | 0);

    const layerUI = b.projectileLayer.getComponent(UITransform);
    if (!layerUI) {
        b.releaseProjectile(projectileNode);
        for (let c = 0; c < b.cols; c++) {
            if (!(reservedMask & (1 << c))) continue;
            b.colReserved[c] = 0;
            if (b.colResMask) b.colResMask[c] = 0;
        }
        // out 롤백
        out.entId = 0;
        out.col0 = -1;
        out.col1 = -1;
        out.isBig = false;
        return false;
    }

    // ✅ 성능: convertToNodeSpaceAR의 반환 Vec3 할당을 제거
    // - 프로젝타일마다 Vec3 2개를 캐시해 tween 파라미터로 재사용합니다.
    const v0 = (pv as any)?.tmp0 ? (pv as any).tmp0() : new Vec3();
    const v1 = (pv as any)?.tmp1 ? (pv as any).tmp1() : new Vec3();
    layerUI.convertToNodeSpaceAR(shooterWorld, v0);
    const endWorld =
        typeof b?.cellWorldPosInto === 'function' && typeof b?.tmpV3 === 'function'
            ? b.cellWorldPosInto(targetRow | 0, targetCol, b.tmpV3())
            : b.cellWorldPos(targetRow | 0, targetCol);
    layerUI.convertToNodeSpaceAR(endWorld, v1);

    Tween.stopAllByTarget(projectileNode);
    projectileNode.parent = b.projectileLayer;
    projectileNode.active = true;
    projectileNode.setScale(1, 1, 1);
    projectileNode.setPosition(v0);

    const dist = Vec3.distance(v0, v1);
    const speed = 20000;

    // ✅ 안전장치: 좌표가 NaN/Infinity로 오염되면 duration이 NaN이 되어 tween/.call/scheduleOnce가 모두 깨지며
    // projectile/colReserved가 영구 고착될 수 있습니다.
    let duration = dist / speed;
    if (!Number.isFinite(duration) || duration <= 0) duration = 0.05;
    if (duration < 0.04) duration = 0.04;

// ✅ 안전장치(중요): tween이 stop/중단되면 .call()이 실행되지 않아
    // projectile이 회수되지 않거나(colReserved/colBusy가 해제되지 않음) 보드가 영구 BUSY가 되는 케이스가 있습니다.
    // - 특히 유닛을 "와라락" 넣어서 연사가 몰릴 때 재현 가능.
    // - 따라서 "완료 1회"를 보장하는 finishOnce + schedule fallback을 둡니다.
    let finished = false;

    const forceClearReservation = () => {
        // 최악 복구(예약/바쁨 고착 방지)
        try {
            for (let c = 0; c < b.cols; c++) {
                if (!(reservedMask & (1 << c))) continue;
                b.colReserved[c] = 0;
                b.colBusy[c] = 0;
                if (b.colResMask) b.colResMask[c] = 0;
            }
        } catch {
            // ignore
        }
        try {
            b.clearBusyAll?.();
        } catch {
            // ignore
        }
    };

    const finishOnce = () => {
        if (finished) return;
        finished = true;

        try {
            b.releaseProjectile(projectileNode);
        } catch {
            // ignore
        }

        // handleHitColumn은 내부에서 예약/바쁨을 정리하지만,
        // Promise가 영구 대기(hang)하는 경우를 대비해 워치독을 둡니다.
        try {
            const p: Promise<void> =
                typeof b?.handleHitCell === 'function'
                    ? b.handleHitCell(targetRow | 0, targetCol | 0)
                    : b.handleHitColumn(targetCol | 0);

            let settled = false;
            const tid = setTimeout(() => {
                if (settled) return;
                forceClearReservation();
            }, 1500);

            p.then(
                () => {
                    settled = true;
                    clearTimeout(tid);
                },
                () => {
                    settled = true;
                    clearTimeout(tid);
                    forceClearReservation();
                },
            );
        } catch {
            forceClearReservation();
        }
    };

    tween(projectileNode).to(duration, { position: v1 }).call(finishOnce).start();

    // tween 콜백이 불리지 않는 최악 케이스 대비(일회성 fallback)
    try {
        const extra = 0.25;
        const base = Number.isFinite(duration) ? duration : 0.05;
        const delaySec = Math.max(0.05, base + extra);
        if (typeof b?.scheduleOnce === 'function') {
            b.scheduleOnce(() => {
                if (!finished) finishOnce();
            }, delaySec);
        } else {
            setTimeout(() => {
                if (!finished) finishOnce();
            }, Math.floor(delaySec * 1000));
        }
    } catch {
        // ignore
    }

    return true;
}
