import { UITransform, Vec3, Tween, tween } from 'cc';

// 역할: Board 특수 블럭(히든/키/생성박스) 처리 로직 분리
// - Board.ts 파일 크기를 줄이고, 특수 규칙을 한 곳에서 관리합니다.

// ✅ 바닥(row=0)에 도달한 히든 블럭 공개
// - 요구사항: 같은색 히든(4방향 인접)만 함께 공개
export function revealHiddenAtBottom(b: any, _cols?: number[]) {
    const rows = b.rows | 0;
    const colsN = b.cols | 0;

    const inBounds = (r: number, c: number) => r >= 0 && r < rows && c >= 0 && c < colsN;

    // 0) 바닥 히든 후보 수집
    b._tmpRevealBottomHidden.length = 0;

    const pushHiddenAtCol = (c: number) => {
        const id = b.occ[b.indexOf(0, c)];
        if (id < 0) return;
        const e = b.ents.get(id);
        if (!e) return;
        const v = e.view;
        if (!v?.isHidden?.()) return;
        b._tmpRevealBottomHidden.push(id);
    };

    // cols 힌트는 무시하고 항상 전체 컬럼 검사
    for (let c = 0; c < colsN; c++) pushHiddenAtCol(c);

    // hidden이 없더라도 키 바닥 처리는 항상 수행
    if (b._tmpRevealBottomHidden.length === 0) {
        processKeysAtBottom(b);
        return;
    }

    const q = b._tmpRevealQueue;
    const visited = b._tmpRevealVisited;
    const entSet = b._tmpRevealEntSet;

    // 1) 바닥 히든마다: 같은 hiddenColor 히든 연결 컴포넌트만 공개
    for (let i = 0; i < b._tmpRevealBottomHidden.length; i++) {
        const rootId = b._tmpRevealBottomHidden[i];
        const root = b.ents.get(rootId);
        if (!root) continue;
        const rv = root.view;
        if (!rv?.isHidden?.()) continue;

        const hiddenColor = rv.colorId | 0;

        visited.fill(0);
        q.length = 0;
        entSet.clear();

        // root footprint에서 시작
        for (let dy = 0; dy < root.h; dy++) {
            for (let dx = 0; dx < root.w; dx++) {
                const rr = root.row + dy;
                const cc = root.col + dx;
                if (!inBounds(rr, cc)) continue;
                q.push(rr * colsN + cc);
            }
        }

        while (q.length > 0) {
            const key = q.pop()!;
            if (visited[key]) continue;
            visited[key] = 1;

            const r = (key / colsN) | 0;
            const c = key - r * colsN;
            const id = b.occ[b.indexOf(r, c)];
            if (id < 0) continue;

            const e = b.ents.get(id);
            if (!e) continue;
            const v = e.view;
            if (!v?.isHidden?.()) continue;
            if ((v.colorId | 0) !== hiddenColor) continue;

            if (!entSet.has(id)) {
                entSet.add(id);
                // 히든 해제(스프라이트 갱신은 TileView.refresh에서 처리)
                v.setHidden(false);
            }

            // footprint 주변 4방향 확장(셀 기반)
            for (let dy = 0; dy < e.h; dy++) {
                for (let dx = 0; dx < e.w; dx++) {
                    const rr = e.row + dy;
                    const cc = e.col + dx;
                    if (rr + 1 < rows) q.push((rr + 1) * colsN + cc);
                    if (rr - 1 >= 0) q.push((rr - 1) * colsN + cc);
                    if (cc + 1 < colsN) q.push(rr * colsN + (cc + 1));
                    if (cc - 1 >= 0) q.push(rr * colsN + (cc - 1));
                }
            }
        }
    }

    processKeysAtBottom(b);
}

// ✅ KEY: 키가 바닥에 닿으면 해당 id의 LOCK을 해제
export function processKeysAtBottom(b: any) {
    for (let c = 0; c < b.cols; c++) {
        const id = b.occ[b.indexOf(0, c)];
        if (id < 0) continue;
        const e = b.ents.get(id);
        if (!e) continue;
        if ((e.view.depth ?? 1) > 1) continue;
        const sp = e.view.getSpecial();
        if (sp?.t !== 'KEY') continue;

        // ✅ 키 획득 처리(LOCK 블럭/유닛 해제)
        try {
            b.collectKey?.(sp.id);
        } catch {
            // ignore
            try {
                b.unlockedLocks?.add?.(sp.id);
            } catch {}
        }

        // ✅ 바닥에 닿은 키는 즉시 제거 + 카운트 반영
        try {
            e.view.setSpecial?.(null);
        } catch {}
        const worth = (e.worth ?? 1) | 0;
        try {
            b.remainingTiles = Math.max(0, (b.remainingTiles ?? 0) - worth);
        } catch {}
        try {
            (b as any)._notifyBlockDestroyed?.(worth);
        } catch {}
        try {
            b.removeEnt?.(e);
        } catch {}
    }
}

// ✅ 생성박스 처리
// - 박스는 낙하하지 않고 고정(2x2 점유)
// - 박스 바로 아래 2x1 spawn row가 비어있는 칸만큼 블럭을 생성
// - queue가 소진되면 박스를 제거
export function processSpawnerBoxes(b: any): any[] {
    const out: any[] = [];

    // ✅ 성능: ents 전체 스캔 제거(등록된 SPAWNER_BOX만 순회)
    const ids: Set<number> | null = b?._spawnerIds instanceof Set ? (b._spawnerIds as Set<number>) : null;
    if (!ids || ids.size <= 0) return out;

    // ✅ 스포너에서 생성되는 블럭이 (이벤트→낙하) 중에 맞아버리거나,
    // 스폰 전 "논리 점유" 때문에 다른 블럭 낙하가 막히는 현상을 줄이기 위해 별도의 컬럼 락을 둡니다.
    const ensureColSpawnLock = () => {
        if (!b.colSpawnLock || (b.colSpawnLock.length | 0) !== (b.cols | 0)) {
            try {
                b.colSpawnLock = new Uint8Array(b.cols | 0);
            } catch {
                b.colSpawnLock = new Array(b.cols | 0).fill(0);
            }
        }
    };
    const lockCol = (col: number, v: number) => {
        try {
            ensureColSpawnLock();
            b.colSpawnLock[col | 0] = v ? 1 : 0;
        } catch {}
    };

    for (const entId of ids) {
        const e = b.ents.get(entId | 0);
        if (!e) continue;

        // ✅ SPAWNER_BOX는 2x2 점유(legacy 2x1도 호환)
        if (e.w !== 2 || (e.h !== 2 && e.h !== 1)) continue;

        const sp = e.view.getSpecial?.();
        if (!sp || sp.t !== 'SPAWNER_BOX') continue;

        // pending 애니 진행 중이면 스킵(중복 스폰 방지)
        if ((sp as any).pending) continue;

        const q = Array.isArray((sp as any).queue) ? ((sp as any).queue as any[]) : [];
        const i0 = ((sp as any).i ?? 0) | 0;

        const colorsRaw = Array.isArray((sp as any).colors) ? ((sp as any).colors as any[]) : null;
        const leftColor = ((colorsRaw?.[0] ?? (q[0] ?? 0)) as any) | 0;
        const rightColor = ((colorsRaw?.[1] ?? (q[1] ?? leftColor)) as any) | 0;

        // ✅ 큐 소진: pending 중이 아니면 생성박스 제거
        if (q.length <= 0 || i0 >= q.length) {
            try {
                b.removeEnt?.(e);
            } catch {}
            continue;
        }

        const c0 = e.col | 0;
        if (c0 < 0 || c0 + 1 >= b.cols) continue;

        // spawn row = 박스 바로 아래 1줄
        const spawnRow = (e.row | 0) - 1;
        if (spawnRow < 0 || spawnRow >= b.rows) continue;

        // ✅ 이번 프레임에는 최대 2개(좌/우)만 스폰 "계획"
        // - 실제 생성(spawnSmall/commitEnt)과 HP(i) 소비는 Spine 이벤트 시점에 수행합니다.
        //
        // ⚠️ 중요 버그 케이스(사용자 리포트)
        // - 스포너가 Create 애니(pending) 중일 때, 아래 셀이(예: CHAIN_SEG 제거로) 비게 되면
        //   기존 구현은 "계획 시점"의 빈칸만 spawn하여 새로 빈 칸이 된 쪽을 놓치는 경우가 있었습니다.
        // - 해결: 계획은 "애니 재생 여부"와 "초기 락"에만 사용하고,
        //         실제 spawn 대상(좌/우)은 이벤트 시점에 다시 검사해 결정합니다.
        const prePlans: Array<{ col: number; colorId: number }> = [];
        let cursor = i0;

        if (cursor < q.length && b.entAt(spawnRow, c0) == null) {
            prePlans.push({ col: c0, colorId: leftColor });
            cursor++;
        }
        if (cursor < q.length && b.entAt(spawnRow, c0 + 1) == null) {
            prePlans.push({ col: c0 + 1, colorId: rightColor });
            cursor++;
        }

        const spawnedAny = prePlans.length > 0;

        // ✅ pending 마킹(중복 스폰 방지) + 색상 유지
        e.view.setSpecial?.({
            t: 'SPAWNER_BOX',
            queue: q,
            i: i0,
            colors: [leftColor, rightColor],
            pending: spawnedAny,
        } as any);

        if (!spawnedAny) continue;

        // ✅ 이벤트 전/낙하 중 컬럼 발사 잠금(스포너 생성 연출 중 조준/발사로 인한 흔들림 방지)
        // - 초기 계획된 컬럼만 우선 잠그고,
        //   이벤트 시점에 추가로 빈 칸이 되면 그때 잠금을 추가합니다.
        for (const p of prePlans) lockCol(p.col, 1);

        const tileLayer = b.tileLayer;
        const tileUI: UITransform | null = tileLayer && tileLayer.isValid ? tileLayer.getComponent(UITransform) : null;

        const tmpStartWorld = new Vec3();
        const tmpEndWorld = new Vec3();
        const tmpEndLocal = new Vec3();

        const doSpawnAtEvent = () => {
            let i = i0;

            // ✅ 이벤트 시점에 다시 빈칸을 확인해서 실제 spawn 대상을 결정
            // - 좌→우 순서
            const plans: Array<{ col: number; colorId: number }> = [];
            let cursor2 = i;

            if (cursor2 < q.length && b.entAt(spawnRow, c0) == null) {
                plans.push({ col: c0, colorId: leftColor });
                cursor2++;
            }
            if (cursor2 < q.length && b.entAt(spawnRow, c0 + 1) == null) {
                plans.push({ col: c0 + 1, colorId: rightColor });
                cursor2++;
            }

            // ✅ 초기에는 잠겼지만, 이벤트 시점에는 스폰하지 않는 컬럼은 즉시 잠금 해제
            // - (예) 계획 당시 비어있었지만, 애니 중 다른 블럭이 내려와서 채워진 경우
            // - (예) CHAIN_SEG가 남아 있어 스폰이 불가능한 경우
            for (const p of prePlans) {
                const col = p.col | 0;
                let stillPlanned = false;
                for (let k = 0; k < plans.length; k++) {
                    if ((plans[k].col | 0) === col) {
                        stillPlanned = true;
                        break;
                    }
                }
                if (!stillPlanned) lockCol(col, 0);
            }

            // ✅ 새로 빈 칸이 되어서 이번 이벤트에 스폰하는 컬럼은 잠금 보장
            for (const p of plans) lockCol(p.col, 1);

            // 이벤트 시점에 결국 스폰할 곳이 없다면(2칸 모두 채워짐 등) pending만 해제하고 종료
            if (plans.length <= 0) {
                try {
                    const now = e.view.getSpecial?.();
                    if (now?.t === 'SPAWNER_BOX') {
                        (now as any).i = i;
                        (now as any).pending = false;
                        (now as any).colors = [leftColor, rightColor];
                        e.view.setSpecial(now as any);
                    } else {
                        e.view.setSpecial({
                            t: 'SPAWNER_BOX',
                            queue: q,
                            i,
                            colors: [leftColor, rightColor],
                            pending: false,
                        } as any);
                    }
                } catch {
                    // ignore
                }

                // (큐가 끝났는데 스폰을 못한 경우는 거의 없지만) 방어적으로 제거 체크
                if (i >= q.length) {
                    try {
                        b.removeEnt?.(e);
                    } catch {}
                }
                return;
            }

            for (const plan of plans) {
                const col = plan.col | 0;

                if (i >= q.length) {
                    lockCol(col, 0);
                    continue;
                }

                // 이벤트 시점에 spawn row가 채워졌으면 이번 생성은 스킵(HP도 소비하지 않음)
                if (b.entAt(spawnRow, col) != null) {
                    lockCol(col, 0);
                    continue;
                }

                // 생성 즉시 아래가 비면 곧바로 내려가야 리플레이/검증과 일치
                let dropRow = spawnRow;
                while (dropRow > 0 && b.entAt(dropRow - 1, col) == null) dropRow--;

                const bb = b.spawnSmall(dropRow, col);
                if (!bb) {
                    lockCol(col, 0);
                    continue;
                }

                // ✅ 성공 시에만 HP(커서) 소비
                i++;

                // ✅ 블럭 속성 초기화
                bb.view.setTop((plan.colorId | 0) as any);
                bb.view.setHidden(false);
                bb.view.setSpecial(null);

                // ✅ 풀링 잔상 제거(특히 스포너 생성 블럭 크기/스케일 문제 방지)
                try {
                    bb.view.resetBodyTransform?.();
                } catch {}

                // ✅ 보드 점유 반영
                b.commitEnt(bb);

                // (참고) out은 즉시 사용되지는 않지만, 디버그/테스트용으로 유지
                out.push(bb);

                // ✅ 연출: 혀 안쪽 -> spawnRow 셀 -> (낙하) 최종 위치(dropRow)
                try {
                    const node = bb.view?.node;
                    if (!node || !node.isValid) {
                        lockCol(col, 0);
                        continue;
                    }

                    // start: tileLayer 밑으로 두면 좌표 변환이 단순해집니다.
                    if (tileLayer && tileLayer.isValid) node.setParent(tileLayer);

                    // start pos: 혀 안쪽(월드) - 좌/우 각각 다른 시작점
                    const side: 'L' | 'R' = col === (c0 | 0) ? 'L' : 'R';
                    const sw =
                        e.view.getSpawnerTongueInnerWorldPosLR?.(side, tmpStartWorld) ??
                        e.view.getSpawnerTongueInnerWorldPos?.(tmpStartWorld) ??
                        (tileLayer && tileLayer.isValid ? tileLayer.getWorldPosition(tmpStartWorld) : tmpStartWorld);
                    try {
                        node.setWorldPosition(sw);
                    } catch {}

                    // start scale: 너무 작게 시작하면 "뿅"(팝) 느낌이 강해집니다.
                    // - 혀에서 "미끄러져 나오는" 감을 주기 위해 시작 스케일을 완만하게 조정
                    const body = bb.view.bodyNode?.() ?? null;
                    let baseScale: Vec3 | null = null;
                    if (body && body.isValid) {
                        baseScale = new Vec3(body.scale.x, body.scale.y, body.scale.z);
                        const s0 = 0.68; // ✅ 0.25 -> 0.68 (팝 감소)
                        body.setScale(baseScale.x * s0, baseScale.y * s0, baseScale.z);
                    }

                    // slide end: spawnRow 셀 중심(월드)
                    let endWorld: Vec3 | null = null;
                    try {
                        endWorld = (b as any).cellWorldPos?.(spawnRow, col) ?? null;
                    } catch {}
                    if (!endWorld) endWorld = node.getWorldPosition(tmpEndWorld);

                    // convert to tileLayer local
                    if (tileUI) {
                        tileUI.convertToNodeSpaceAR(endWorld, tmpEndLocal);
                    } else {
                        const tlw =
                            tileLayer && tileLayer.isValid ? tileLayer.getWorldPosition(tmpEndWorld) : tmpEndWorld;
                        tmpEndLocal.set(endWorld.x - tlw.x, endWorld.y - tlw.y, 0);
                    }

                    // duration: 혀(슬라이드) + (필요 시) 낙하
                    // - 요구사항: "혀에서 나와서" 셀에 안착하는 느낌(셀에서 뿅 방지)

                    // 셀 단위(라인 레이아웃이면 lineDy/colX, 아니면 stepY/stepX)
                    const cellY = b.useLineLayout
                        ? Math.max(1e-3, Math.abs(b.lineDy || b.tileSizeY || b.tileSize))
                        : Math.max(1e-3, Math.abs(b.stepY || b.tileSizeY || b.tileSize));
                    const cellX = b.useLineLayout
                        ? Math.max(1e-3, Math.abs(((b.colX?.[1] ?? 0) - (b.colX?.[0] ?? 0)) || b.tileSize))
                        : Math.max(1e-3, Math.abs(b.stepX || b.tileSize));

                    const endLocal = new Vec3(tmpEndLocal.x, tmpEndLocal.y, 0);

                    // slide duration: 시작~spawnRow 거리 기반
                    const sx0 = node.position.x;
                    const sy0 = node.position.y;
                    const dx0 = endLocal.x - sx0;
                    const dy0 = endLocal.y - sy0;
                    const slideDist = Math.sqrt(dx0 * dx0 + dy0 * dy0);
                    const slideSpeed = Math.max(900, cellY * 16);
                    const slideDur = Math.max(0.12, Math.min(0.30, slideDist / slideSpeed));

                    // fall duration: (spawnRow -> dropRow) 셀 거리 기반(자유낙하 근사)
                    const distRows = Math.max(0, (spawnRow - dropRow) | 0);
                    const fallDist = distRows * cellY;
                    const g = 9000; // UI 단위에서의 중력 근사(튜닝값)
                    const fallDur = Math.max(0.06, Math.min(0.42, Math.sqrt((2 * Math.max(0, fallDist)) / g)));

                    // scale tween: "혀 슬라이드" 구간에서만 자연스럽게 원래 크기로
                    if (body && body.isValid && baseScale) {
                        Tween.stopAllByTarget(body);
                        tween(body).to(slideDur, { scale: baseScale }, { easing: 'quadOut' }).start();
                    }

                    // move: 혀 -> (안착) spawnRow 셀
                    // - dropRow==spawnRow(=더 이상 낙하 없음)인 경우: 셀 위에서 살짝 내려앉는 2단 모션으로 "안착" 강화
                    // - 낙하가 더 남아있으면(=distRows>0) 불필요한 멈춤을 만들지 않기 위해 직행
                    Tween.stopAllByTarget(node);

                    if (distRows <= 0) {
                        // hover point(셀 중심보다 약간 위)로 이동 후, 짧게 내려앉기
                        const hoverOff = Math.max(8, Math.min(28, cellY * 0.28));
                        const hoverLocal = new Vec3(endLocal.x, endLocal.y + hoverOff, 0);
                        const settleDur = Math.max(0.06, Math.min(0.12, hoverOff / 360));

                        tween(node)
                            .to(slideDur, { position: hoverLocal }, { easing: 'sineOut' })
                            .to(settleDur, { position: endLocal }, { easing: 'quadIn' })
                            .call(() => {
                                // ✅ 라인 레이아웃에서는 row에 따라 부모(Line)가 달라질 수 있으므로
                                //    마지막에 moveEnt(거의 0초)를 한번 태워 "정상 부모"로 복귀시킵니다.
                                try {
                                    const p = (b as any).moveEnt?.(bb, 0.01);
                                    const done = () => {
                                        try {
                                            // ✅ 최종적으로 spawnRow에 "착지"한 케이스만 착지 FX
                                            bb.view.playLandFx?.(0.09);
                                        } catch {}
                                        lockCol(col, 0);
                                    };
                                    if (p && typeof p.then === 'function') {
                                        p.then(
                                            () => done(),
                                            () => done(),
                                        );
                                    } else {
                                        done();
                                    }
                                } catch {
                                    lockCol(col, 0);
                                }
                            })
                            .start();
                    } else {
                        // 낙하가 남아있으면: 혀 -> spawnRow 셀로 이동 후 바로 낙하 트윈
                        tween(node)
                            .to(slideDur, { position: endLocal }, { easing: 'sineOut' })
                            .call(() => {
                                try {
                                    const p = (b as any).moveEnt?.(bb, fallDur);
                                    if (p && typeof p.then === 'function') {
                                        p.then(
                                            () => lockCol(col, 0),
                                            () => lockCol(col, 0),
                                        );
                                    } else {
                                        lockCol(col, 0);
                                    }
                                } catch {
                                    lockCol(col, 0);
                                }
                            })
                            .start();
                    }
                } catch {
                    lockCol(col, 0);
                }
            }

            // ✅ pending 해제 + HP(i) 반영(라벨 업데이트)
            try {
                const now = e.view.getSpecial?.();
                if (now?.t === 'SPAWNER_BOX') {
                    (now as any).i = i;
                    (now as any).pending = false;
                    (now as any).colors = [leftColor, rightColor];
                    e.view.setSpecial(now as any);
                } else {
                    e.view.setSpecial({
                        t: 'SPAWNER_BOX',
                        queue: q,
                        i,
                        colors: [leftColor, rightColor],
                        pending: false,
                    } as any);
                }
            } catch {
                // ignore
            }

            // ✅ 마지막 생성까지 끝났으면 생성박스 제거
            if (i >= q.length) {
                try {
                    b.removeEnt?.(e);
                } catch {}
            }
        };

        // ✅ Create 애니 이벤트 타이밍에 생성/연출 수행
        try {
            e.view.playSpawnerCreateAnim?.(doSpawnAtEvent);
        } catch {
            // fallback: 즉시 생성
            doSpawnAtEvent();
        }
    }

    return out;
}
