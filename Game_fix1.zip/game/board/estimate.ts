// 역할: Board 색상별 "필요 탄 수" 추정 로직 분리
// - 기능 변경 없이 Board.ts에서 코드만 분리합니다.

export function estimateRequiredShotsByColorFront(b: any): Map<number, number> {
    const out = new Map<number, number>();

    // 1) 현재 보드 엔티티(스택/체인/큰블럭)
    for (const e of b.ents.values()) {
        const v = e.view;
        if (!v) continue;

        // 큰 블럭: 남은 HP만큼 해당 색상에 필요 타수
        if (e.w > 1 || e.h > 1) {
            const c = v.colorId;
            const n = Math.max(0, v.getHp() | 0);
            if (c >= 0 && n > 0) out.set(c, (out.get(c) ?? 0) + n);
            continue;
        }

        const top = v.colorId;
        if (top < 0) continue;

        const depth = v.depth ?? 1;
        const sp = depth <= 1 ? v.getSpecial() : null;

        // CHAIN: hp만큼 같은 색상 타격
        if (sp?.t === 'CHAIN') {
            const hp = Math.max(1, sp.hp | 0);
            out.set(top, (out.get(top) ?? 0) + hp);
            continue;
        }

        // 일반 스택: 스택 내부 색상을 그대로 합산
        const stack = v.getStackRef();
        for (let i = 0; i < stack.length; i++) {
            const c = stack[i] | 0;
            if (c < 0) continue;
            out.set(c, (out.get(c) ?? 0) + 1);
        }

        // SPAWNER: 큐까지 포함
        if (sp?.t === 'SPAWNER') {
            const q = Array.isArray(sp.queue) ? sp.queue : [];
            for (let i = 0; i < q.length; i++) {
                const c = q[i] | 0;
                if (c < 0) continue;
                out.set(c, (out.get(c) ?? 0) + 1);
            }
        }
    }

    // 2) 남은 supply
    for (let c = 0; c < b.cols; c++) {
        const st = b.colSupply[c];
        if (!st || st.length <= 0) continue;
        for (let i = 0; i < st.length; i++) {
            const col = st[i] | 0;
            if (col < 0) continue;
            out.set(col, (out.get(col) ?? 0) + 1);
        }
    }

    return out;
}
