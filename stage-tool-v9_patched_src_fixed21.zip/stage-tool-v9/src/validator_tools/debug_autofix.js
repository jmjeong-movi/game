const fs = require('fs');
const { compileRuntimeFromV2 } = require('./game/StageCompiler');
const { Board } = require('./game/Board');
const { Node, Prefab } = require('cc');

function computeNeedCountsFromBoard(board, out){
  const arr = out || new Int32Array(12); arr.fill(0);
  try { if (typeof board?.getFrontColorCounts === 'function') return board.getFrontColorCounts(arr); } catch {}
  const cols = (board?.cols ?? board?._cols ?? 5) | 0;
  for (let c=0;c<cols;c++){
    const ent = board?.entAt?.(0,c);
    const cid = (ent?.view?.colorId ?? -1)|0;
    if(cid>=0&&cid<12) arr[cid]+=1;
  }
  return arr;
}
function computeShootableNeedCountsFromBoard(board, out){
  const arr = out || new Int32Array(12); arr.fill(0);
  const cols=(board?.cols ?? board?._cols ?? 5)|0;
  if(typeof board?.pickShootTargets==='function'){
    for(let cid=0;cid<12;cid++){
      try{
        const ts = board.pickShootTargets(cid, Math.max(1, cols), 'LEFT', undefined, true) || [];
        arr[cid] = (Array.isArray(ts)?ts.length:0)|0;
      }catch{arr[cid]=0;}
    }
    return arr;
  }
  return computeNeedCountsFromBoard(board, arr);
}

function pickTopNeedColors(need,k){
  const ids=[]; for(let i=0;i<need.length;i++) if((need[i]|0)>0) ids.push(i);
  ids.sort((a,b)=>(need[b]|0)-(need[a]|0));
  return ids.slice(0,Math.max(0,k|0));
}

function tryAutoFixSlotsByNeed(board, slots, deck, deckIdx){
  const row0 = computeNeedCountsFromBoard(board);
  const shootNeed = computeShootableNeedCountsFromBoard(board);
  const slotCnt=new Int32Array(12);
  for(const s of slots){ if(!s) continue; const c=s.data.colorId|0; if(c>=0&&c<12) slotCnt[c]++; }
  const cand=[];
  for(let c=0;c<12;c++){ const r=row0[c]|0; if(r>0 && (slotCnt[c]|0)<=0) cand.push(c); }
  for(let c=0;c<12;c++){ const s=shootNeed[c]|0; if(s>0 && (slotCnt[c]|0)<=0 && !cand.includes(c)) cand.push(c); }
  if(cand.length<=0){ for(const c of pickTopNeedColors(shootNeed,3)) cand.push(c); }
  if(cand.length<=0) return {ok:false,newDeckIdx:deckIdx};
  const ranked=[];
  for(const c of cand){
    let first=-1;
    for(let i=deckIdx;i<deck.length;i++){ if((deck[i]?.colorId|0)===c){ first=i; break; } }
    if(first<0) continue;
    const r=row0[c]|0, s=shootNeed[c]|0;
    const missing=(slotCnt[c]|0)<=0;
    const score=(missing?1e6:0)+(r>0?5e5+50*r:0)+(s>0?2e5+20*s:0)-5*(first-deckIdx);
    ranked.push({color:c,deckPos:first,score});
  }
  ranked.sort((a,b)=>b.score-a.score);
  for(const pick of ranked){
    const need=pick.color, k=pick.deckPos;
    let bestIdx=-1, bestSlotScore=-1e9;
    for(let i=0;i<slots.length;i++){
      const s=slots[i]; if(!s) continue;
      const color=s.data.colorId|0;
      let dup=0; for(const o of slots) if(o && ((o.data.colorId|0)===color)) dup++;
      let score=0; if(color!==need) score+=10;
      score+=Math.max(0,dup-1)*5;
      score+=Math.max(0,20-(s.ammo|0))*0.1;
      if(score>bestSlotScore){bestSlotScore=score;bestIdx=i;}
    }
    if(bestIdx<0) continue;
    const picked=deck[k]; if(!picked) continue;
    const replaced=slots[bestIdx].data;
    slots[bestIdx]={data:picked, ammo: Math.max(0,(picked.ammo??0)|0)};
    deck[k]=replaced;
    return {ok:true,newDeckIdx:deckIdx,need,k,bestIdx};
  }
  return {ok:false,newDeckIdx:deckIdx};
}

(async function(){
  const pack = JSON.parse(fs.readFileSync('/mnt/data/stagepack_repaired.json','utf8'));
  const stage = pack.stages.find(s=>s.id===2);
  const runtime = compileRuntimeFromV2(stage);
  const b = new Board();
  b.tilePrefab = new Prefab(); b.bigTilePrefab = new Prefab(); b.projectilePrefab = new Prefab();
  b.tileLayer = new Node('tileLayer'); b.projectileLayer = new Node('projectileLayer'); b.fxLayer = new Node('fxLayer');
  b.onLoad?.(); b.start?.();
  b.load(runtime);
  const capacity = Math.max(1, runtime.slotCount|0);
  const deck = runtime.cards.slice();
  let deckIdx=0;
  const slots = Array.from({length:capacity},()=>null);
  const pickTargets=(colorId,shots)=>b.pickShootTargets(colorId, shots, 'LEFT', new Set(), true) || [];

  for(let step=1; step<300; step++){
    b.resetBusyFlags?.();
    for(let i=0;i<capacity;i++){
      if(slots[i]) continue;
      if(deckIdx>=deck.length) break;
      const cd=deck[deckIdx++];
      slots[i]={data:cd, ammo: Math.max(0,(cd.ammo??0)|0)};
    }
    let filled=0; for(let i=0;i<capacity;i++) if(slots[i]) filled++;
    if(filled>=capacity){
      let any=false;
      for(let i=0;i<capacity;i++){
        const s=slots[i];
        if(!s||s.ammo<=0) continue;
        const shots=Math.max(1,(s.data.shotCount??1)|0);
        const ts=pickTargets(s.data.colorId|0, shots);
        if(ts.length>0){ any=true; break; }
      }
      if(!any){
        console.log('STUCK at step',step,'deckIdx',deckIdx,'slotColors',slots.map(s=>s.data.colorId));
        const r=tryAutoFixSlotsByNeed(b, slots, deck, deckIdx);
        console.log('autofix result',r,'new slotColors',slots.map(s=>s.data.colorId));
        break;
      }
    }
    // shoot
    const exclude=new Set();
    for(let i=0;i<capacity;i++){
      const s=slots[i]; if(!s) continue;
      if(s.ammo<=0){ slots[i]=null; continue; }
      const want=Math.max(1,(s.data.shotCount??1)|0);
      const ts=b.pickShootTargets(s.data.colorId|0, want, 'LEFT', exclude, true) || [];
      if(ts.length<=0) continue;
      const bullets=Math.min(s.ammo, ts.length);
      for(let k=0;k<bullets;k++){
        const t=ts[k]; exclude.add(t.entId|0);
        await b.handleHitColumn(t.col|0);
        s.ammo-=1;
      }
      if(s.ammo<=0) slots[i]=null;
    }
  }
})();
