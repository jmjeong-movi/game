// 역할: Board 중력(낙하) 로직 분리
// - Board.ts 비대화를 줄이고, 중력 규칙을 한 곳에서 유지합니다.

// ✅ 중력으로 엔티티를 아래로 떨어뜨리고, 이동한 엔티티 목록을 반환합니다.
export function settleGravity(b: any): any[] {
    const list = b._tmpGravityList;
    list.length = 0;
    for (const e of b.ents.values()) list.push(e);

    // 바닥부터 처리(낮은 row 먼저)
    list.sort((a: any, c: any) => (a.row | 0) - (c.row | 0));

    const moved = b._tmpMovedEnts;
    moved.length = 0;

    for (let i = 0; i < list.length; i++) {
        const e = list[i];
        let movedOnce = false;
        while (canFall(b, e)) {
            moveDownOne(b, e);
            movedOnce = true;
        }
        if (movedOnce) moved.push(e);
    }

    return moved;
}

// ✅ 아이템3 전용: 특정 엔티티 id는 제외하고 중력 정렬합니다.
export function settleGravityExcluding(b: any, excludeIds: Set<number>, outMoved: any[]): void {
    b._tmpGravityList.length = 0;

    for (const e of b.ents.values()) {
        if (excludeIds.has(e.id)) continue;
        b._tmpGravityList.push(e);
    }

    b._tmpGravityList.sort((a: any, c: any) => (a.row | 0) - (c.row | 0));

    for (let i = 0; i < b._tmpGravityList.length; i++) {
        const e = b._tmpGravityList[i];
        let movedOnce = false;

        while (canFall(b, e)) {
            moveDownOne(b, e);
            movedOnce = true;
        }

        if (movedOnce) outMoved.push(e);
    }
}

// 엔티티가 아래로 1칸 떨어질 수 있는지 확인합니다.
export function canFall(b: any, e: any): boolean {
    // 생성박스(SPAWNER_BOX)는 보드에 배치되면 절대 낙하하지 않음
    const sp = e.view?.getSpecial?.();
    if (sp?.t === 'SPAWNER_BOX') return false;

    // ✅ PILLAR(기둥)도 고정 오브젝트
    if (sp?.t === 'PILLAR') return false;

    // ✅ CHAIN_SEG(체인/슬라임)도 "스턱" 오브젝트(길이만 줄어들고 위치는 고정)
    if (sp?.t === 'CHAIN_SEG') return false;

    if ((e.row | 0) <= 0) return false;

    const belowRow = (e.row | 0) - 1;
    for (let dx = 0; dx < (e.w | 0); dx++) {
        const c = (e.col | 0) + dx;
        if (c < 0 || c >= b.cols) return false;

        const idBelow = b.occ[b.indexOf(belowRow, c)];
        if (idBelow >= 0 && (idBelow | 0) !== (e.id | 0)) return false;
    }
    return true;
}

// 엔티티를 아래로 1칸 이동(점유 그리드만 갱신)
export function moveDownOne(b: any, e: any): void {
    // 현재 footprint clear
    for (let dy = 0; dy < (e.h | 0); dy++) {
        for (let dx = 0; dx < (e.w | 0); dx++) {
            const r = (e.row | 0) + dy;
            const c = (e.col | 0) + dx;
            if (r < 0 || r >= b.rows || c < 0 || c >= b.cols) continue;
            const idx = b.indexOf(r, c);
            if ((b.occ[idx] | 0) === (e.id | 0)) b.occ[idx] = -1;
        }
    }

    e.row = (e.row | 0) - 1;
    e.view.row = e.row;

    // 새 footprint set
    for (let dy = 0; dy < (e.h | 0); dy++) {
        for (let dx = 0; dx < (e.w | 0); dx++) {
            const r = (e.row | 0) + dy;
            const c = (e.col | 0) + dx;
            if (r < 0 || r >= b.rows || c < 0 || c >= b.cols) continue;
            b.occ[b.indexOf(r, c)] = e.id;
        }
    }
}
