// 역할: UnitLineRack 머즐 FX(프리팹+풀) 로직 분리
// - 기능 변경 없이 UnitLineRack.ts에서 코드만 분리합니다.

import { CurveRange, instantiate, Node, ParticleSystem, ParticleSystem2D } from 'cc';

import { AudioManager } from '../../core/AudioManager';

// ⚠️ 중요(성능): 머즐 FX는 연사 중 매우 자주 호출됩니다.
// console.log 스팸은 브라우저/에디터를 "멈춘 것처럼" 만들 수 있어 기본적으로 완전 차단합니다.
// (디버그가 필요하면 아래 값을 true로 바꾸고, 1~2회만 찍히도록 추가 제한을 두세요.)
const DEBUG_MUZZLE_FX = false;

export const MUZZLE_FX_TAG = '__muzzleFx';

// 라벨/타일 컬러 팔레트와 동일한 순서(0..11)
export const MUZZLE_COLOR_HEX = [
    'FC5A59',
    'E87C48',
    'E2AB2E',
    '7FBE63',
    '5EB2E4',
    '9F85E4',
    'E485C1',
    '73C7BF',
    '728FE9',
    'B2CC6F',
    '7C7D8F',
    '8B90A0',
];

type MuzzleType = 'C' | 'L' | 'R';

function colorIdToFrameIdx0(colorId: number): number {
    const c = colorId | 0;
    if (c >= 0 && c <= 11) return c;
    if (c >= 1 && c <= 12) return c - 1;
    return ((c % 12) + 12) % 12;
}

function frameIdxToHex(frameIdx0: number): string {
    const i = (((frameIdx0 | 0) % 12) + 12) % 12;
    return MUZZLE_COLOR_HEX[i] ?? '??????';
}

// 유닛(또는 소켓) 아래에 남아있는 발사 FX를 즉시 회수
export function despawnMuzzleFxUnder(r: any, host: Node | null) {
    if (!host || !host.isValid) return;

    const ch = host.children;
    for (let i = ch.length - 1; i >= 0; i--) {
        const n = ch[i];
        if (!n || !n.isValid) continue;
        if (!(n as any)[MUZZLE_FX_TAG]) continue;

        // active 리스트에서 제거
        const list = r._fxActive;
        for (let k = list.length - 1; k >= 0; k--) {
            if (list[k].node === n) {
                list.splice(k, 1);
                break;
            }
        }

        // 파티클 정지
        try {
            const ps3 = n.getComponent(ParticleSystem);
            (ps3 as any)?.stop?.();
        } catch {}
        try {
            const ps2 = n.getComponent(ParticleSystem2D);
            (ps2 as any)?.stopSystem?.();
        } catch {}

        n.active = false;
        n.removeFromParent();
        r._muzzleFxPool.put(n);
    }
}

// 슬롯을 모르는 회수 경로에서도 트리 전체에서 FX 제거
export function despawnMuzzleFxInTree(r: any, root: Node | null) {
    if (!root || !root.isValid) return;

    const st: Node[] = r._tmpNodeStack;
    st.length = 0;
    st.push(root);

    while (st.length > 0) {
        const n = st.pop()!;
        if (!n || !n.isValid) continue;

        if ((n as any)[MUZZLE_FX_TAG]) {
            const list = r._fxActive;
            for (let k = list.length - 1; k >= 0; k--) {
                if (list[k].node === n) {
                    list.splice(k, 1);
                    break;
                }
            }

            try {
                const ps3 = n.getComponent(ParticleSystem);
                (ps3 as any)?.stop?.();
            } catch {}
            try {
                const ps2 = n.getComponent(ParticleSystem2D);
                (ps2 as any)?.stopSystem?.();
            } catch {}

            n.active = false;
            n.removeFromParent();
            r._muzzleFxPool.put(n);
            continue;
        }

        const ch = n.children;
        for (let i = ch.length - 1; i >= 0; i--) st.push(ch[i]);
    }
}

// 풀 워밍업
export function prewarmMuzzleFx(r: any) {
    const pf = r.muzzleFxPrefab;
    if (!pf) return;

    const n = Math.max(0, Math.min(100, r.muzzleFxWarmup | 0));
    for (let i = 0; i < n; i++) {
        const nd = instantiate(pf);
        nd.active = false;
        nd.removeFromParent();
        r._muzzleFxPool.put(nd);
    }
}

// 수명 만료 FX 회수
export function tickFxRecycle(r: any, dt: number) {
    const list = r._fxActive;
    for (let i = list.length - 1; i >= 0; i--) {
        const it = list[i];
        it.t -= dt;
        if (it.t > 0) continue;

        const nd = it.node;
        list.splice(i, 1);

        if (!nd || !nd.isValid) continue;
        nd.active = false;
        nd.removeFromParent();
        r._muzzleFxPool.put(nd);
    }
}

// 머즐 FX 재생(원본 로그/설정 유지)
export function playMuzzleFx(r: any, slot: any, muzzle: MuzzleType, colorId: number) {
    const pf = r.muzzleFxPrefab;
    if (!pf) return;

    let host: Node | null = null;
    if (muzzle === 'C') host = slot.muzzleCenter;
    else if (muzzle === 'L') host = slot.muzzleLeft;
    else host = slot.muzzleRight;

    if (!host || !host.isValid) host = slot.node;
    if (!host || !host.isValid) return;

    const nd = r._muzzleFxPool.size() > 0 ? r._muzzleFxPool.get()! : instantiate(pf);
    if (!nd) return;

    (nd as any)[MUZZLE_FX_TAG] = 1;

    nd.active = true;
    nd.setParent(host);
    nd.setPosition(0, 0, 0);
    nd.setRotationFromEuler(0, 0, 0);
    nd.setScale(1, 1, 1);

    const frameIdx0 = colorIdToFrameIdx0(colorId);
    const hex = frameIdxToHex(frameIdx0);

    const ps3 = nd.getComponent(ParticleSystem);
    if (ps3) {
        const mod: any = (ps3 as any).textureAnimationModule;
        const sf: any = mod?.startFrame;

        if (sf) {
            try {
                sf.mode = CurveRange.Mode.Constant;
                sf.constant = frameIdx0;

                // NOTE: 성능/안정성 이슈로 기본 로그는 완전 차단합니다.
                // if (DEBUG_MUZZLE_FX) console.log(...)
            } catch (e) {
                // if (DEBUG_MUZZLE_FX) console.warn('[MuzzleFX] failed to set startFrame:', e);
            }
        } else {
            // if (DEBUG_MUZZLE_FX) console.warn(...)
        }

        try {
            (ps3 as any).stop?.();
            (ps3 as any).play?.();

            AudioManager.I?.playSfxByIndex(slot.shotSfxIdx, { volume: 1.0, minIntervalMs: 15 });
        } catch {}
    } else {
        const ps2 = nd.getComponent(ParticleSystem2D);
        if (ps2) {
            if (DEBUG_MUZZLE_FX) {
                console.warn(
                    `[MuzzleFX] ParticleSystem2D detected(3D가 아님). startFrame 제어가 다를 수 있음. colorId=${colorId} frameIdx0=${frameIdx0} hex=#${hex} muzzle=${muzzle} nd=${nd.name}`,
                );
            }
            try {
                ps2.resetSystem();
            } catch {}
        }
    }

    const life = r.muzzleFxRecycleSec > 0 ? r.muzzleFxRecycleSec : 0.35;
    r._fxActive.push({ node: nd, t: life });
}
