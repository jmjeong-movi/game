"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TARGET_LEFTMOST = exports.PROJECTILE_POOL_WARMUP = exports.DEFAULT_CARD_COUNT = exports.TILE_SIZE = exports.GRID_COLS = exports.GRID_ROWS = void 0;
exports.GRID_ROWS = 10;
exports.GRID_COLS = 10;
exports.TILE_SIZE = 62.5;
// 기본 카드 개수(스테이지에서 별도 지정이 없을 때 사용)
exports.DEFAULT_CARD_COUNT = 25;
// 총알(프로젝타일) 풀 프리워밍 개수
exports.PROJECTILE_POOL_WARMUP = 40;
// 바닥줄 타겟 선택 방식: true=왼쪽부터, false=랜덤 시작 스캔
exports.TARGET_LEFTMOST = true;
