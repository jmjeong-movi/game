import type { BoardObject, Color12, StageV2 } from './schema';
import { COLOR12 } from './schema';
import { countsAsBlock } from './board';

// ----------------- helpers -----------------

function clampInt(n: number, lo: number, hi: number): number {
  const v = Math.floor(Number.isFinite(n) ? n : 0);
  return Math.max(lo, Math.min(hi, v));
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function objWeightForHits(o: BoardObject): number {
  if (!countsAsBlock(o)) return 0;
  // stage 데이터는 color("R") 또는 colorId(0..11) 중 하나를 사용할 수 있습니다.
  // 실제 색상 파싱은 addObj에서 처리하지만, 둘 다 없으면 0으로 처리합니다.
  if ((o as any).color == null && (o as any).colorId == null) return 0;
  if (o.type === 'BLOCK_LARGE' || o.type === 'BLOCK_LARGE_HIDDEN') {
    return Math.max(1, Math.floor((o as any).hp ?? 80));
  }
  // NORMAL/HIDDEN/CHAIN: 1 hit
  if (o.type === 'BLOCK_NORMAL' || o.type === 'BLOCK_HIDDEN' || o.type === 'CHAIN_BARRIER') return 1;
  // KEY/LOCK는 색이 없으므로 여기까지 오면 0
  return 0;
}

function roundDownToStep(n: number, step: number) {
  if (step <= 1) return Math.floor(n);
  return Math.floor(n / step) * step;
}

function roundUpToStep(n: number, step: number) {
  if (step <= 1) return Math.ceil(n);
  return Math.ceil(n / step) * step;
}

function splitTotalIntoCards(
  total: number,
  ammoMax: number,
  shot2Rate: number,
  seed: number,
): Array<{ ammo: number; shotCount: 1 | 2 }> {
  // ✅ exact sum, hard cap 50
  // ✅ 우선도: 1총구=20, 2총구=30 (10은 웬만하면 사용하지 않음)
  const T = Math.max(0, Math.floor(total));
  if (T <= 0) return [];

  const max = clampInt(ammoMax, 1, 50);
  const r = Math.max(0, Math.min(1, Number.isFinite(shot2Rate) ? shot2Rate : 0));
  const rng = mulberry32(seed);

  const out: Array<{ ammo: number; shotCount: 1 | 2 }> = [];

  // --- Case 1) T가 10의 배수이고(>=20), ammoMax가 30 이상이면: 20/30만으로 정확히 맞춤 ---
  if (T % 10 === 0 && T >= 20 && max >= 30) {
    // ✅ 20/30만으로 정확히 합계를 맞추면서, 30이 과도하게 많아지지 않도록 조합을 선택합니다.
    // - 기본 목표: shot2Rate(=30 비율)에 가깝게
    // - 동시에 카드 수 과다(=오버플로우/유실 위험)와 30 과다를 함께 억제
    // - cost가 가장 낮은 (a=20개수, b=30개수) 조합을 선택
    let bestA = -1;
    let bestB = -1;
    let bestCost = Number.POSITIVE_INFINITY;
    for (let b = 0; b <= Math.floor(T / 30); b++) {
      const rem = T - 30 * b;
      if (rem < 0) continue;
      if (rem % 20 !== 0) continue;
      const a = rem / 20;
      const n = a + b;
      if (n <= 0) continue;
      const prop = b / n;
      // 가중치: (비율 맞춤) > (카드 수) > (30 억제)
      const cost = Math.abs(prop - r) * 1000 + n * 1 + b * 8;
      if (cost < bestCost) {
        bestCost = cost;
        bestA = a;
        bestB = b;
      }
    }
    if (bestA >= 0 && bestB >= 0) {
      for (let i = 0; i < bestB; i++) out.push({ ammo: 30, shotCount: 2 });
      for (let i = 0; i < bestA; i++) out.push({ ammo: 20, shotCount: 1 });
      // 순서만 약간 섞어 변주(합계/단위 유지)
      for (let i = out.length - 1; i > 0; i--) {
        if (rng() > 0.15) continue;
        const j = Math.floor(rng() * (i + 1));
        const t = out[i];
        out[i] = out[j];
        out[j] = t;
      }
      return out;
    }
    // 이론상 여기로 오면 데이터가 이상한 케이스(예: max < 20 등) → 아래 일반 처리로 폴백
  }

  // --- Case 2) T가 10의 배수이고(>=20)인데 max가 30 미만: 20 우선, 10은 최소화 ---
  if (T % 10 === 0 && T >= 20 && max < 30) {
    const use20 = Math.floor(T / 20);
    let rem = T - use20 * 20;
    for (let i = 0; i < use20; i++) out.push({ ammo: Math.min(20, max), shotCount: 1 });
    // rem은 0 또는 10일 수 있음. 10은 정말 불가피한 경우만.
    if (rem > 0) out.push({ ammo: Math.min(rem, max), shotCount: 1 });
    return out;
  }

  // --- Case 3) T가 5의 배수(10의 배수는 아님): 25를 1개 사용하고 나머지는 20/30로 해결 ---
  //  - 10/5는 T가 너무 작을 때만 불가피
  if (T % 5 === 0 && T % 10 !== 0 && max >= 25) {
    if (T === 5) return [{ ammo: 5, shotCount: 1 }];
    if (T === 15) return [{ ammo: 15, shotCount: 1 }];
    // 큰 값은 25 하나를 먼저 떼고 나머지를 20/30로 구성
    out.push({ ammo: 25, shotCount: 1 });
    const rest = T - 25;
    const restParts = splitTotalIntoCards(rest, ammoMax, shot2Rate, seed + 17);
    for (const p of restParts) out.push(p);
    return out;
  }

  // --- General fallback: 기존 방식(단, 10 사용을 최대한 억제) ---
  // step: 10이 가능하면 10, 아니면 5, 그래도 안 되면 1
  let step = 1;
  if (T % 10 === 0) step = 10;
  else if (T % 5 === 0) step = 5;

  const maxStep = Math.max(step, roundDownToStep(max, step));
  let remain = T;
  while (remain > 0) {
    // prefer 30/20, but keep exact sum
    const want2 = rng() < r;
    const shotCount: 1 | 2 = want2 ? 2 : 1;
    const pref = shotCount === 2 ? 30 : 20;

    let take = Math.min(pref, maxStep, remain);
    take = roundDownToStep(take, step) || take;

    // 10 방지: 10이 생기기 쉬운 상황(remain - take === 10 등)에서는 20 쪽으로 조정
    if (step >= 5 && remain - take === 10 && take > 20) {
      take = 20;
    }

    out.push({ ammo: take, shotCount: take >= 30 ? 2 : 1 });
    remain -= take;
  }

  // ✅ 10 최소화(가능할 때 제거)
  // - max>=30 이고 step=10인 케이스에서,
  //   (30 + 10)을 (20 + 20)으로 치환하면 합계를 유지하면서 10을 제거할 수 있습니다.
  // - 총알 10은 "정말 불가피"할 때만 남기고, 그 외에는 제거합니다.
  if (step === 10 && max >= 30) {
    let changed = true;
    while (changed) {
      changed = false;
      const i10 = out.findIndex((c) => c.ammo === 10);
      if (i10 < 0) break;
      const i30 = out.findIndex((c) => c.ammo === 30);
      if (i30 < 0) break;
      // replace one 30 and one 10 with two 20s
      out.splice(Math.max(i10, i30), 1);
      out.splice(Math.min(i10, i30), 1);
      out.push({ ammo: 20, shotCount: 1 }, { ammo: 20, shotCount: 1 });
      changed = true;
    }
  }

  // 합계 보정
  const sum = out.reduce((a, b) => a + b.ammo, 0);
  if (sum !== T && out.length > 0) out[out.length - 1].ammo += T - sum;

  // ✅ 10 최소화(가능하면 제거)
  // - T가 10의 배수이고 max>=30인 상황에서, {30}+{10} 조합이 생기면 {20}+{20}로 치환합니다.
  // - 합계는 유지되면서 10이 사라집니다.
  if (T % 10 === 0 && max >= 30) {
    while (true) {
      const i10 = out.findIndex((c) => c.ammo === 10);
      if (i10 < 0) break;
      const i30 = out.findIndex((c) => c.ammo === 30);
      if (i30 < 0) break;
      // 30 하나를 20으로 낮추고, 10 카드를 20으로 올려서 20,20 만들기
      out[i30].ammo = 20;
      out[i30].shotCount = 1;
      out[i10].ammo = 20;
      out[i10].shotCount = 1;
    }
  }

  // shotCount 보정(누락 방지)
  for (const c of out) {
    if (c.shotCount !== 1 && c.shotCount !== 2) c.shotCount = c.ammo >= 30 ? 2 : 1;
  }

  return out;
}

function arrangeNoAdjacent(cards: Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }>, seed: number): Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }> {
  if (cards.length <= 2) return cards.slice();
  const rng = mulberry32(seed + 777);
  const by: Record<string, Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }>> = {};
  for (const c of COLOR12) by[c] = [];
  for (const cd of cards) by[cd.color].push(cd);
  for (const c of COLOR12) {
    const arr = by[c];
    // deterministic shuffle
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(mulberry32(seed + 9000 + c.charCodeAt(0) + i)() * (i + 1));
      const t = arr[i];
      arr[i] = arr[j];
      arr[j] = t;
    }
  }

  const idx: Record<string, number> = {} as any;
  const rem: Record<string, number> = {} as any;
  for (const c of COLOR12) {
    idx[c] = 0;
    rem[c] = by[c].length;
  }

  const out: Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }> = [];
  let prev: string | null = null;
  const total = cards.length;
  for (let k = 0; k < total; k++) {
    // pick color with max remaining, avoid prev if possible
    let maxRem = -1;
    for (const c of COLOR12) {
      if (rem[c] <= 0) continue;
      if (c === prev) continue;
      maxRem = Math.max(maxRem, rem[c]);
    }
    let allowPrev = false;
    if (maxRem < 0) {
      allowPrev = true;
      for (const c of COLOR12) maxRem = Math.max(maxRem, rem[c]);
    }
    let pick: string | null = null;
    let seen = 0;
    for (const c of COLOR12) {
      if (rem[c] !== maxRem || rem[c] <= 0) continue;
      if (!allowPrev && c === prev) continue;
      seen++;
      if (rng() < 1 / seen) pick = c;
    }
    if (!pick) {
      for (const c of COLOR12) {
        if (rem[c] > 0) {
          pick = c;
          break;
        }
      }
    }
    const cd = by[pick!][idx[pick!]];
    idx[pick!]++;
    rem[pick!]--;
    out.push(cd);
    prev = pick;
  }
  return out;
}

function columnAwareWeave(cards: Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }>, cols: number, seed: number) {
  const ccols = clampInt(cols, 1, 10);
  if (ccols <= 1 || cards.length <= 2) return cards.slice();

  const rng = mulberry32(seed + 4242);
  const by: Record<string, Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }>> = {} as any;
  for (const c of COLOR12) by[c] = [];
  for (const cd of cards) by[cd.color].push(cd);

  // shuffle per-color queues
  const q: Record<string, Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }>> = {} as any;
  for (const c of COLOR12) {
    const arr = by[c].slice();
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(mulberry32(seed + 9000 + c.charCodeAt(0) + i)() * (i + 1));
      const t = arr[i];
      arr[i] = arr[j];
      arr[j] = t;
    }
    q[c] = arr;
  }

  const columns: Array<Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }>> = Array.from({ length: ccols }, () => []);
  const prev: Array<string | null> = Array.from({ length: ccols }, () => null);
  const total = cards.length;

  const popColor = (avoid: string | null): string | null => {
    let maxLen = -1;
    for (const c of COLOR12) {
      const len = q[c].length;
      if (len <= 0) continue;
      if (c === avoid) continue;
      maxLen = Math.max(maxLen, len);
    }
    let allowAvoid = false;
    if (maxLen < 0) {
      allowAvoid = true;
      for (const c of COLOR12) maxLen = Math.max(maxLen, q[c].length);
    }
    let pick: string | null = null;
    let seen = 0;
    for (const c of COLOR12) {
      if (q[c].length !== maxLen || q[c].length <= 0) continue;
      if (!allowAvoid && c === avoid) continue;
      seen++;
      if (rng() < 1 / seen) pick = c;
    }
    return pick;
  };

  let col = 0;
  for (let i = 0; i < total; i++) {
    const pick = popColor(prev[col]);
    if (!pick) break;
    const cd = q[pick].shift()!;
    columns[col].push(cd);
    prev[col] = pick;
    col = (col + 1) % ccols;
  }

  // weave back (row-major)
  const out: Array<{ color: Color12; ammo: number; shotCount: 1 | 2 }> = [];
  let maxRows = 0;
  for (const colArr of columns) maxRows = Math.max(maxRows, colArr.length);
  for (let r = 0; r < maxRows; r++) {
    for (let c = 0; c < ccols; c++) {
      if (r < columns[c].length) out.push(columns[c][r]);
    }
  }
  return out;
}

function bottomRowColors(stage: StageV2): Color12[] {
  const set = new Set<string>();
  for (const o of stage.board.objects ?? []) {
    const anyO: any = o as any;
    if (anyO == null) continue;
    const t = String(anyO.type ?? '');
    if (t !== 'BLOCK_NORMAL' && t !== 'BLOCK_HIDDEN' && t !== 'CHAIN_BARRIER') continue;
    if (Math.floor(anyO.y ?? -1) !== 0) continue;
    if (anyO.color && COLOR12.includes(anyO.color)) set.add(anyO.color);
  }
  return Array.from(set.values()) as Color12[];
}

function promoteIntoFirstN(cards: Array<{ color: Color12; ammo: number }>, colors: Color12[], n: number) {
  let write = 0;
  const limit = clampInt(n, 1, Math.max(1, cards.length));
  for (const c of colors) {
    if (write >= limit) break;
    for (let i = write; i < cards.length; i++) {
      if (cards[i].color === c) {
        const t = cards[write];
        cards[write] = cards[i];
        cards[i] = t;
        write++;
        break;
      }
    }
  }
}

// ----------------- public API -----------------

export function buildClearGuaranteedAuthoredCards(stage: StageV2, materializedSupplyPages: Array<{ objects: BoardObject[] }>): Array<{ color: Color12; ammo: number; shotCount: 1 | 2; hintStep?: number }> {
  const seed = clampInt((stage.meta as any).seed ?? 1000 + stage.id, 0, 0x7fffffff);
  // ✅ 클리어 보장 Export는 "20/30 우선도"를 강제합니다.
  // - stage.meta.ammoMax가 10으로 저장되어 있더라도, 보장 분배는 20/30 중심으로 쪼개야 합니다.
  // - 10은 (총합이 20/30 조합으로 정확히 떨어지지 않는 등) 불가피한 경우에만 사용됩니다.
  const ammoMax = Math.max(30, clampInt((stage.meta as any).ammoMax ?? 50, 1, 50));
  const shot2Rate = Number.isFinite((stage.meta as any).shot2Rate) ? Number((stage.meta as any).shot2Rate) : 0.3;
  const cols = clampInt((stage.meta as any).pickerCols ?? 2, 1, 10);
  const slotCount = clampInt((stage.meta as any).slotCount ?? 3, 1, 10);

  // 1) per-color required hits
  const hits = new Map<Color12, number>();
  for (const c of COLOR12) hits.set(c, 0);

  const normalizeColor = (o: BoardObject): Color12 | null => {
    const anyO: any = o as any;
    const c = anyO?.color;
    if (typeof c === 'string' && COLOR12.includes(c as any)) return c as Color12;
    if (typeof c === 'number' && Number.isFinite(c)) {
      const idx = (((c as number) % 12) + 12) % 12;
      return COLOR12[idx] as Color12;
    }
    const cid = anyO?.colorId;
    if (typeof cid === 'number' && Number.isFinite(cid)) {
      const idx = ((cid % 12) + 12) % 12;
      return COLOR12[idx] as Color12;
    }
    return null;
  };
  const addObj = (o: BoardObject) => {
    const c = normalizeColor(o);
    if (!c) return;
    const w = objWeightForHits(o);
    if (w <= 0) return;
    hits.set(c, (hits.get(c) ?? 0) + w);
  };
  for (const o of stage.board.objects ?? []) addObj(o);
  for (const p of materializedSupplyPages ?? []) {
    for (const o of p.objects ?? []) addObj(o);
  }

  // 2) split into cards
  let cards: Array<{ color: Color12; ammo: number; shotCount: 1 | 2; hintStep?: number }> = [];
  for (const c of COLOR12) {
    const need = hits.get(c) ?? 0;
    if (need <= 0) continue;
    const parts = splitTotalIntoCards(need, ammoMax, shot2Rate, seed + 10000 + c.charCodeAt(0) * 97);
    for (const p of parts) cards.push({ color: c, ammo: p.ammo, shotCount: p.shotCount });
  }

  // 3) order: avoid adjacency, then column-aware (overflow), then ensure shooter range has bottom colors
  cards = arrangeNoAdjacent(cards, seed);
  cards = columnAwareWeave(cards, cols, seed);
  promoteIntoFirstN(cards, bottomRowColors(stage), slotCount);

  // 4) ✅ 전체 덱 순번(클리어 가능한 장착 순서 힌트)
  // - 모든 카드에 1..N 순번을 부여합니다.
  // - 게임에서는 이 hintStep을 그대로 라벨에 표시합니다.
  for (let i = 0; i < cards.length; i++) {
    (cards[i] as any).hintStep = i + 1;
  }

  // 4) 전체 덱에 "클리어 가능한 장착 순서"(hintStep)를 부여합니다.
  // - 게임에서 라벨에 1..N 순번이 표시되며, 이 순서대로 장착/교체하면 클리어가 가능하도록 유도합니다.
  for (let i = 0; i < cards.length; i++) (cards[i] as any).hintStep = i + 1;

  return cards;
}

/**
 * ✅ Export용 힌트: "어떤 색 유닛을 장착 슬롯에 넣으면 클리어가 쉬운지"(추천 장착 순서)
 *
 * - 목표: 스테이지 JSON만 보고도 권장 장착 색을 바로 알 수 있게 합니다.
 * - 정책(간단/안전):
 *   1) (초기 보드 + Export 시점 materialize된 supply.pages) 기준으로 색상별 필요 타수(hits)를 계산
 *   2) hits 내림차순으로 색을 정렬
 *   3) slotCount 개수만큼 앞에서부터 채움
 *   4) 색이 slotCount보다 적으면: hits가 가장 큰 색을 반복해서 채움
 *
 * ⚠️ 주의: 이 값은 "힙업용 힌트"이며, 실제 클리어 가능성은 타겟팅/보드 상황에 따라 달라질 수 있습니다.
 * 하지만 카드 분배가 클리어 보장(AUTHORED)인 상태에서 "주로 써야 할 색"을 알려주는 데는 충분합니다.
 */
export function buildClearGuaranteedEquipOrder(stage: StageV2, materializedSupplyPages: Array<{ objects: BoardObject[] }>): string[] {
  const slotCount = clampInt((stage.meta as any).slotCount ?? 3, 1, 10);

  // 1) per-color required hits
  const hits = new Map<Color12, number>();
  for (const c of COLOR12) hits.set(c, 0);

  const normalizeColor = (o: BoardObject): Color12 | null => {
    const anyO: any = o as any;
    const c = anyO?.color;
    if (typeof c === 'string' && COLOR12.includes(c as any)) return c as Color12;
    if (typeof c === 'number' && Number.isFinite(c)) {
      const idx = (((c as number) % 12) + 12) % 12;
      return COLOR12[idx] as Color12;
    }
    const cid = anyO?.colorId;
    if (typeof cid === 'number' && Number.isFinite(cid)) {
      const idx = ((cid % 12) + 12) % 12;
      return COLOR12[idx] as Color12;
    }
    return null;
  };
  const addObj = (o: BoardObject) => {
    const c = normalizeColor(o);
    if (!c) return;
    const w = objWeightForHits(o);
    if (w <= 0) return;
    hits.set(c, (hits.get(c) ?? 0) + w);
  };
  for (const o of stage.board.objects ?? []) addObj(o);
  for (const p of materializedSupplyPages ?? []) {
    for (const o of p.objects ?? []) addObj(o);
  }

  // active colors
  const active = COLOR12.filter((c) => (hits.get(c) ?? 0) > 0);
  if (active.length === 0) {
    // edge: no colored blocks => default to R1
    return Array.from({ length: slotCount }, () => 'R1');
  }

  // 2) greedy slot hint: pick color with max remaining hits (deterministic),
  // and choose shotCount preference (1=>20, 2=>30).
  // - choose 2 when remaining >= 30, else 1
  // - subtract pref from remaining so later slots can diversify if needed
  const rem = new Map<Color12, number>();
  for (const c of COLOR12) rem.set(c, hits.get(c) ?? 0);

  const out: string[] = [];
  for (let i = 0; i < slotCount; i++) {
    let best: Color12 = active[0];
    for (const c of active) {
      const rc = rem.get(c) ?? 0;
      const rb = rem.get(best) ?? 0;
      if (rc > rb) best = c;
      else if (rc === rb && COLOR12.indexOf(c) < COLOR12.indexOf(best)) best = c;
    }

    const rbest = rem.get(best) ?? 0;
    const shotCount: 1 | 2 = rbest >= 30 ? 2 : 1;
    const pref = shotCount === 2 ? 30 : 20;

    out.push(`${best}${shotCount}`);
    rem.set(best, Math.max(0, rbest - pref));
  }

  return out;
}
