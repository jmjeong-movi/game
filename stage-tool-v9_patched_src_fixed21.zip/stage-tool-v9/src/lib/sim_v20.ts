// validator_tools_v20의 headless 시뮬레이터(Board/StageCompiler)를 스테이지툴(웹)에서 호출하기 위한 래퍼입니다.
// - 목적: "현재 스테이지가 실제 플레이 루프에서 풀리는지 / 어디서 STUCK 나는지"를 UI에서 바로 확인.
//
// NOTE
// - validator_tools는 CommonJS 출력이라 Vite(ESM)에서 named export로 import하면
//   `does not provide an export named ...` 에러가 날 수 있습니다.
// - 그래서 런타임 dynamic import + 인터롭( mod.X / mod.default?.X / mod.default )으로 가져옵니다.

import { Node, Prefab } from 'cc';
import { COLOR_TOKEN_ORDER } from './runtime/Types';

// validator_tools 쪽 타입 정의는 JS라 TS에서 바로 import가 안 됩니다.
// 필요한 최소 필드만 로컬 타입으로 정의합니다.
type CardData = { colorId: number; ammo?: number; shotCount?: number; hintStep?: number };

type SimSlot = { data: CardData; ammo: number; srcIdx: number };

export type SimV20Opts = {
  maxSteps?: number;
  /** STUCK가 나면 deck order를 소폭 수정하고 재시도합니다. */
  autoRepair?: boolean;
  /** autoRepair 최대 반복 횟수 */
  repairMaxAttempts?: number;
  /** swap 대상(나쁜 색)을 pivot 앞쪽에서 찾는 범위 */
  repairBackWindow?: number;
  /** (역설계) 보드 하단 밴드 수요 기반으로 최초 덱을 재정렬합니다. 기본 true(autoRepair일 때). */
  constructByBoardBands?: boolean;
  /** autoRepair에서 한 번에 여러 후보를 probe-sim 하고 최선 덱을 고릅니다. */
  repairBeamWidth?: number;
  /** 후보 평가용 probe 시뮬레이션 스텝 수 */
  repairProbeSteps?: number;
};

type SimDeckSummary = {
  colors: number[];
  tokens: string[];
  ammo: number[];
  shotCount: number[];
};

type SimRepairInfo = {
  enabled: boolean;
  attempts: number;
  applied: boolean;
  history: Array<{
    pivotDeckIdx: number;
    pickedNeedColor: number;
    swappedA: number;
    swappedB: number;
    /** 한 번의 attempt에서 여러 swap을 적용한 경우 */
    swaps?: Array<[number, number]>;
    /** 어떤 전략으로 수정했는지 */
    reason?: string;
  }>;
};

type SimBase = {
  deck?: SimDeckSummary;
  /** stage.cards.mode=AUTHORED에 바로 넣을 수 있는 형태(순서 중요) */
  suggestedAuthoredCards?: Array<{ color: string; ammo: number; shotCount?: number; hintStep: number }>;
  repair?: SimRepairInfo;
};

export type SimV20Result =
  | ({ status: 'SOLVED'; steps: number; shotsFired: number; metrics: any } & SimBase)
  | ({ status: 'UNKNOWN'; steps: number; remaining: number; shotsFired: number; metrics: any } & SimBase)
  | ({
      status: 'STUCK';
      steps: number;
      remaining: number;
      deckLeft: number;
      stuck: any;
      metrics: any;
    } & SimBase);

function cjsPick<T = any>(mod: any, name: string): T {
  return (mod?.[name] ?? mod?.default?.[name] ?? mod?.default) as T;
}

function cloneCard(cd: CardData): CardData {
  // runtime.cards는 객체를 재사용할 수 있으므로, deck reorder/스왑에 안전하도록 얕은 복사.
  return {
    colorId: cd.colorId | 0,
    ammo: (cd.ammo ?? 0) | 0,
    shotCount: (cd.shotCount ?? 1) | 0,
    hintStep: cd.hintStep == null ? undefined : (cd.hintStep | 0),
  };
}

function makeDeckSummary(deck: CardData[]): SimDeckSummary {
  const colors: number[] = new Array(deck.length);
  const tokens: string[] = new Array(deck.length);
  const ammo: number[] = new Array(deck.length);
  const shotCount: number[] = new Array(deck.length);
  for (let i = 0; i < deck.length; i++) {
    const d = deck[i];
    const c = (d?.colorId ?? 0) | 0;
    colors[i] = c;
    tokens[i] = COLOR_TOKEN_ORDER[c] ?? '?';
    ammo[i] = (d?.ammo ?? 0) | 0;
    shotCount[i] = (d?.shotCount ?? 1) | 0;
  }
  return { colors, tokens, ammo, shotCount };
}

function makeSuggestedAuthoredCards(deck: CardData[]) {
  return deck.map((d, i) => {
    const c = (d?.colorId ?? 0) | 0;
    const token = COLOR_TOKEN_ORDER[c] ?? 'R';
    const sc = (d?.shotCount ?? 1) | 0;
    return {
      color: token,
      ammo: Math.max(0, (d?.ammo ?? 0) | 0),
      shotCount: sc === 1 ? undefined : sc,
      hintStep: i + 1,
    };
  });
}

// --- reverse-design helpers (board → deck order) ---

const TOKEN_TO_COLORID: Record<string, number> = (() => {
  const m: Record<string, number> = Object.create(null);
  for (let i = 0; i < COLOR_TOKEN_ORDER.length; i++) {
    const t = COLOR_TOKEN_ORDER[i];
    if (typeof t === 'string' && t.length > 0) m[t] = i;
  }
  return m;
})();

function tokenToColorId(tok: any): number {
  const t = typeof tok === 'string' ? tok : '';
  const v = (TOKEN_TO_COLORID as any)[t];
  return v == null ? -1 : (v | 0);
}

function fnv1a32(h: number, v: number): number {
  // v: 0..255
  h ^= v & 255;
  // 32-bit FNV-1a prime multiply
  return (h * 16777619) >>> 0;
}

function hashDeck(deck: CardData[], sample = 512): number {
  // Deck can be huge(2k+). Sample head/tail to detect cycles cheaply.
  let h = 2166136261 >>> 0;
  const n = deck.length | 0;
  const take = Math.min(sample, n);
  for (let i = 0; i < take; i++) {
    const d = deck[i];
    h = fnv1a32(h, (d?.colorId ?? 0) | 0);
    h = fnv1a32(h, ((d?.ammo ?? 0) | 0) & 255);
    h = fnv1a32(h, ((d?.shotCount ?? 1) | 0) & 255);
  }
  for (let i = Math.max(0, n - take); i < n; i++) {
    const d = deck[i];
    h = fnv1a32(h, (d?.colorId ?? 0) | 0);
    h = fnv1a32(h, ((d?.ammo ?? 0) | 0) & 255);
    h = fnv1a32(h, ((d?.shotCount ?? 1) | 0) & 255);
  }
  return h >>> 0;
}

function breakStreakInWindow(deck: CardData[], windowLen: number, maxStreak: number) {
  const n = deck.length;
  const w = Math.min(Math.max(0, windowLen | 0), n);
  if (w <= 1) return;

  let streak = 1;
  for (let i = 1; i < w; i++) {
    const prevC = (deck[i - 1]?.colorId ?? -1) | 0;
    const curC = (deck[i]?.colorId ?? -1) | 0;
    if (curC >= 0 && curC === prevC) streak++;
    else streak = 1;

    if (streak <= maxStreak) continue;

    // find a later different color and swap
    let j = i + 1;
    while (j < n) {
      const cj = (deck[j]?.colorId ?? -1) | 0;
      if (cj >= 0 && cj !== curC) break;
      j++;
    }
    if (j >= n) return;
    const tmp = deck[i];
    deck[i] = deck[j];
    deck[j] = tmp;
    streak = 1;
  }
}

function reorderDeckByBoardBands(stage: any, runtime: any, deck: CardData[]): CardData[] {
  const objs = stage?.board?.objects;
  if (!Array.isArray(objs) || objs.length <= 0) return deck;

  const h = Math.max(1, (stage?.board?.h ?? 10) | 0);
  // 5-row bands: (0..4), (5..9) on 10x10. If board height differs, still keep ~2 bands.
  const bandH = Math.max(1, Math.floor(h / 2));
  const bandN = Math.max(1, Math.ceil(h / bandH));

  const demandByBand: Int32Array[] = Array.from({ length: bandN }, () => new Int32Array(12));
  for (const o of objs) {
    const cid = tokenToColorId(o?.color);
    if (cid < 0 || cid >= 12) continue;
    const y = (o?.y ?? 0) | 0;
    const band = Math.max(0, Math.min(bandN - 1, Math.floor(y / bandH)));
    const hp = Math.max(1, (o?.hp ?? o?.HP ?? o?.health ?? 1) | 0);
    demandByBand[band][cid] += hp;
  }

  const firstBand = new Int32Array(12);
  const weighted = new Int32Array(12);
  firstBand.fill(999);
  weighted.fill(0);
  for (let b = 0; b < bandN; b++) {
    const w = (bandN - b) * (bandN - b); // bottom band has highest weight
    const arr = demandByBand[b];
    for (let cid = 0; cid < 12; cid++) {
      const v = arr[cid] | 0;
      if (v <= 0) continue;
      if (b < firstBand[cid]) firstBand[cid] = b;
      weighted[cid] += v * w;
    }
  }

  const out = deck.slice();
  out.sort((a, b) => {
    const ca = (a?.colorId ?? -1) | 0;
    const cb = (b?.colorId ?? -1) | 0;
    const fa = ca >= 0 && ca < 12 ? (firstBand[ca] | 0) : 999;
    const fb = cb >= 0 && cb < 12 ? (firstBand[cb] | 0) : 999;
    if (fa !== fb) return fa - fb;
    const wa = ca >= 0 && ca < 12 ? (weighted[ca] | 0) : 0;
    const wb = cb >= 0 && cb < 12 ? (weighted[cb] | 0) : 0;
    if (wa !== wb) return wb - wa;
    const aa = (a?.ammo ?? 0) | 0;
    const ab = (b?.ammo ?? 0) | 0;
    if (aa !== ab) return ab - aa;
    const sa = (a?.shotCount ?? 1) | 0;
    const sb = (b?.shotCount ?? 1) | 0;
    return sb - sa;
  });

  // early pipeline(슬롯+대기)에서 과점 방지
  const slotCount = Math.max(1, runtime?.slotCount | 0);
  const pickerCols = Math.max(1, (runtime?.pickerCols ?? 5) | 0);
  const waitLineCount = Math.max(1, (runtime?.waitLineCount ?? 3) | 0);
  const waitCap = Math.max(0, waitLineCount * pickerCols);
  breakStreakInWindow(out, slotCount + waitCap + 6, 2);
  return out;
}

function entropyFromCounts(cnt: Int32Array): number {
  let sum = 0;
  for (let i = 0; i < cnt.length; i++) sum += Math.max(0, cnt[i] | 0);
  if (sum <= 0) return 0;
  let h = 0;
  for (let i = 0; i < cnt.length; i++) {
    const c = Math.max(0, cnt[i] | 0);
    if (c <= 0) continue;
    const p = c / sum;
    h -= p * Math.log(p);
  }
  return h;
}

function computeRow0Counts(board: any, out?: Int32Array): Int32Array {
  // Prefer Board API if present.
  try {
    if (typeof board?.getFrontColorCounts === 'function') {
      return board.getFrontColorCounts(out);
    }
  } catch {}

  const arr = out ?? new Int32Array(12);
  arr.fill(0);
  const cols = (board?.cols ?? board?._cols ?? 10) | 0;
  for (let c = 0; c < cols; c++) {
    const ent = board?.entAt?.(0, c);
    const cid = (ent?.view?.colorId ?? -1) | 0;
    if (cid >= 0 && cid < 12) arr[cid] += 1;
  }
  return arr;
}

function computeShootableNeedCounts(board: any, out?: Int32Array): Int32Array {
  const arr = out ?? new Int32Array(12);
  arr.fill(0);
  const cols = (board?.cols ?? board?._cols ?? 10) | 0;

  if (typeof board?.pickShootTargets === 'function') {
    for (let cid = 0; cid < 12; cid++) {
      try {
        // wantShots를 넉넉히 줘서 "지금 즉시 쏠 수 있는 후보" 크기를 근사
        const ts = board.pickShootTargets(cid, Math.max(1, cols), 'LEFT', undefined, true) ?? [];
        arr[cid] = (Array.isArray(ts) ? ts.length : 0) | 0;
      } catch {
        arr[cid] = 0;
      }
    }
  }
  return arr;
}

function pickTargets(board: any, colorId: number, shots: number, excludeEnt: Set<number>): any[] {
  return board.pickShootTargets(colorId, shots, 'LEFT', excludeEnt, true) ?? [];
}

function computeAmmoByColor(shooters: (SimSlot | null)[], waiting: SimSlot[], deck: CardData[], deckIdx: number, out?: Int32Array) {
  const arr = out ?? new Int32Array(12);
  arr.fill(0);
  for (const s of shooters) {
    if (!s) continue;
    const c = s.data.colorId | 0;
    if (c >= 0 && c < 12) arr[c] += Math.max(0, s.ammo | 0);
  }
  for (const w of waiting) {
    if (!w) continue;
    const c = w.data.colorId | 0;
    if (c >= 0 && c < 12) arr[c] += Math.max(0, w.ammo | 0);
  }
  for (let i = deckIdx; i < deck.length; i++) {
    const d = deck[i];
    const c = d?.colorId | 0;
    if (c >= 0 && c < 12) arr[c] += Math.max(0, (d?.ammo ?? 0) | 0);
  }
  return arr;
}

async function hit(board: any, col: number): Promise<void> {
  const fn = (board as any)['handleHitColumn'];
  if (typeof fn !== 'function') throw new Error('Board.handleHitColumn not found');
  await fn.call(board, col);
}

function chooseNeedColor(needCounts: Int32Array, slotColors: number[]): number {
  let best = -1;
  let bestV = 0;
  for (let cid = 0; cid < 12; cid++) {
    const v = needCounts[cid] | 0;
    if (v <= 0) continue;
    // STUCK 상태에선 slotColors는 모두 "쏠 타겟 0"인 색들인 경우가 대부분이므로,
    // slot에 없는 색을 우선.
    if (slotColors.includes(cid)) continue;
    if (v > bestV) {
      best = cid;
      bestV = v;
    }
  }
  if (best >= 0) return best;

  // slot에 있어도 상관없이 최대값 하나
  best = -1;
  bestV = 0;
  for (let cid = 0; cid < 12; cid++) {
    const v = needCounts[cid] | 0;
    if (v > bestV) {
      best = cid;
      bestV = v;
    }
  }
  return best;
}

// --- auto-repair (beam search) helpers ---

type RepairCandidate = {
  nextDeck: CardData[];
  pickedNeedColor: number;
  swappedA: number;
  swappedB: number;
  swaps?: Array<[number, number]>;
  reason?: string;
};

function scoreSimResult(res: SimV20Result): number {
  // Higher is better.
  if (res.status === 'SOLVED') return 1_000_000_000 + Math.max(0, 1_000_000 - (res.steps | 0));

  const remaining = Math.max(0, (res as any).remaining ?? 0);
  const steps = Math.max(0, res.steps | 0);
  const stuck = (res as any).stuck;
  const deckIdx = Math.max(0, (stuck?.deckIdx ?? 0) | 0);
  const deckLeft = Math.max(0, (res as any).deckLeft ?? 0);

  // Prefer deeper progress, fewer remaining, and fewer deck left.
  let s = 0;
  s += deckIdx * 10;
  s += steps * 3;
  s -= remaining * 1000;
  s -= deckLeft * 5;

  // Encourage more diverse row0 when available (helps avoid single-color front deadlocks).
  const ent = (res as any)?.metrics?.row0Entropy;
  if (typeof ent === 'number') s += Math.floor(ent * 1000);
  return s;
}

function swap2(deck: CardData[], a: number, b: number) {
  if (a === b) return;
  const t = deck[a];
  deck[a] = deck[b];
  deck[b] = t;
}

function tabuKey(a: number, b: number): string {
  const x = Math.min(a, b);
  const y = Math.max(a, b);
  return `${x}-${y}`;
}

function moveCard(deck: CardData[], from: number, to: number) {
  if (from === to) return;
  const n = deck.length;
  if (from < 0 || from >= n || to < 0 || to >= n) return;
  const [c] = deck.splice(from, 1);
  deck.splice(to, 0, c);
}

function bestNeedOrder(needCounts: number[]): number[] {
  const arr: Array<[number, number]> = [];
  for (let c = 0; c < 12; c++) {
    const v = Math.max(0, (needCounts?.[c] ?? 0) | 0);
    if (v > 0) arr.push([v, c]);
  }
  arr.sort((a, b) => b[0] - a[0]);
  return arr.map((x) => x[1]);
}

function findNeedSrcFromDeck(deck: CardData[], start: number, needColor: number): number {
  for (let i = Math.max(0, start | 0); i < deck.length; i++) {
    if (((deck[i]?.colorId ?? -1) | 0) === (needColor | 0)) return i;
  }
  return -1;
}

function makeBeamCandidates(
  deck: CardData[],
  stuck: {
    deckIdx: number;
    slotColors: number[];
    slotSrcIdx?: number[];
    waitSrcIdx?: number[];
    waitCap?: number;
    needCounts: number[];
    _tabu?: Set<string>;
  },
  repairBackWindow: number,
  limit = 12,
): RepairCandidate[] {
  const tabu = stuck._tabu;
  const pivot = Math.max(0, stuck.deckIdx | 0);
  const needOrder = bestNeedOrder(stuck.needCounts);
  const candidates: RepairCandidate[] = [];

  // 0) existing heuristic (baseline)
  const base = repairDeckByStuck(
    deck,
    {
      deckIdx: pivot,
      slotColors: Array.isArray(stuck.slotColors) ? stuck.slotColors : [],
      slotSrcIdx: Array.isArray(stuck.slotSrcIdx) ? stuck.slotSrcIdx : [],
      waitSrcIdx: Array.isArray(stuck.waitSrcIdx) ? stuck.waitSrcIdx : [],
      needCounts: Array.isArray(stuck.needCounts) ? stuck.needCounts : [],
      _tabu: tabu,
    },
    repairBackWindow,
  );
  if (base) {
    candidates.push({
      nextDeck: base.nextDeck,
      pickedNeedColor: base.pickedNeedColor,
      swappedA: base.swappedA,
      swappedB: base.swappedB,
      swaps: base.swaps,
      reason: 'heuristic',
    });
  }

  const slotSrc = (Array.isArray(stuck.slotSrcIdx) ? stuck.slotSrcIdx : []).filter((x) => (x ?? -1) >= 0) as number[];
  const waitSrc = (Array.isArray(stuck.waitSrcIdx) ? stuck.waitSrcIdx : []).filter((x) => (x ?? -1) >= 0) as number[];
  const targets = [...slotSrc, ...waitSrc];
  const topNeeds = needOrder.slice(0, 3);

  // 1) bring needed card earlier near pivot (move/splice) -- evaluate early
  const injectPos = Math.max(
    0,
    pivot - (Math.max(1, stuck.slotColors?.length ?? 3) + Math.max(0, (stuck.waitCap ?? 0) | 0) + 1),
  );
  for (const needColor of topNeeds) {
    const needIdx = findNeedSrcFromDeck(deck, pivot, needColor);
    if (needIdx < 0) continue;
    if (needIdx === injectPos) continue;
    const nd = deck.slice();
    const card = nd.splice(needIdx, 1)[0];
    nd.splice(injectPos, 0, card);
    candidates.push({
      nextDeck: nd,
      pickedNeedColor: needColor,
      swappedA: needIdx,
      swappedB: injectPos,
      swaps: [[needIdx, injectPos]],
      reason: 'move',
    });
    if (candidates.length >= limit) return candidates;
  }

  // 2) window partition by need (pull top need colors forward near pivot)
  {
    const start = Math.max(0, pivot - Math.max(8, repairBackWindow | 0));
    const end = Math.min(deck.length, pivot + Math.max(12, repairBackWindow | 0));
    if (end - start >= 8 && topNeeds.length > 0) {
      const nd = deck.slice();
      const seg = nd.slice(start, end);
      const set = new Set<number>(topNeeds);
      const a: CardData[] = [];
      const b: CardData[] = [];
      for (const c of seg) (set.has((c?.colorId ?? -1) | 0) ? a : b).push(c);
      const merged = a.concat(b);
      for (let i = 0; i < merged.length; i++) nd[start + i] = merged[i];
      candidates.push({
        nextDeck: nd,
        pickedNeedColor: topNeeds[0] ?? -1,
        swappedA: start,
        swappedB: end - 1,
        reason: 'partition',
      });
      if (candidates.length >= limit) return candidates;
    }
  }

  // 3) direct inject: swap a needed color into any current slot/wait source index
  for (const needColor of topNeeds) {
    const needIdx = findNeedSrcFromDeck(deck, pivot, needColor);
    if (needIdx < 0) continue;
    for (const badIdx of targets) {
      if (badIdx < 0 || badIdx >= deck.length) continue;
      if (tabu && tabu.has(tabuKey(needIdx, badIdx))) continue;
      const nd = deck.slice();
      swap2(nd, needIdx, badIdx);
      candidates.push({
        nextDeck: nd,
        pickedNeedColor: needColor,
        swappedA: needIdx,
        swappedB: badIdx,
        swaps: [[needIdx, badIdx]],
        reason: 'inject',
      });
      if (candidates.length >= limit) return candidates;
    }
  }

  return candidates.slice(0, limit);
}


function repairDeckByStuck(
  deck: CardData[],
  stuck: {
    deckIdx: number;
    slotColors: number[];
    slotAmmo?: number[];
    slotSrcIdx?: number[];
    waitColors?: number[];
    waitSrcIdx?: number[];
    needCounts: number[];
    deckColorCounts?: number[];
    // optional: tabu swap keys to avoid oscillation
    _tabu?: Set<string>;
  },
  repairBackWindow: number,
): { nextDeck: CardData[]; pickedNeedColor: number; swappedA: number; swappedB: number; swaps?: Array<[number, number]> } | null {
  const pivot = Math.max(0, stuck.deckIdx | 0);
  if (pivot >= deck.length) return null;

  const slotColors = Array.isArray(stuck.slotColors) ? stuck.slotColors.map((v) => v | 0) : [];
  const slotAmmo = Array.isArray(stuck.slotAmmo) ? stuck.slotAmmo.map((v) => v | 0) : [];
  const slotSrcIdx = Array.isArray(stuck.slotSrcIdx) ? stuck.slotSrcIdx.map((v) => v | 0) : [];
  const waitColors = Array.isArray(stuck.waitColors) ? stuck.waitColors.map((v) => v | 0) : [];
  const waitSrcIdx = Array.isArray(stuck.waitSrcIdx) ? stuck.waitSrcIdx.map((v) => v | 0) : [];
  const tabu = stuck._tabu;

  const need = new Int32Array(12);
  if (Array.isArray(stuck.needCounts)) {
    for (let i = 0; i < 12; i++) need[i] = (stuck.needCounts[i] ?? 0) | 0;
  }

  const needOrder = Array.from({ length: 12 }, (_, i) => i)
    .filter((cid) => (need[cid] | 0) > 0)
    .sort((a, b) => (need[b] | 0) - (need[a] | 0));

  if (needOrder.length <= 0 || slotColors.length <= 0 || slotSrcIdx.length !== slotColors.length) return null;

  // 남은 덱/대기열 색 분포(교체 우선순위 계산용)
  const remain = new Int32Array(12);
  if (Array.isArray((stuck as any).deckColorCounts) && (stuck as any).deckColorCounts.length >= 12) {
    for (let i = 0; i < 12; i++) remain[i] = (((stuck as any).deckColorCounts[i] ?? 0) | 0);
  } else {
    for (let i = pivot; i < deck.length; i++) {
      const c = (deck[i]?.colorId ?? -1) | 0;
      if (c >= 0 && c < 12) remain[c] += 1;
    }
  }

  const waitCount = new Int32Array(12);
  for (let i = 0; i < waitColors.length; i++) {
    const c = (waitColors[i] ?? -1) | 0;
    if (c >= 0 && c < 12) waitCount[c] += 1;
  }

  const keyOf = (a: number, b: number) => {
    const x = Math.min(a, b);
    const y = Math.max(a, b);
    return `${x}-${y}`;
  };

  const canSwap = (a: number, b: number) => {
    if (a < 0 || b < 0 || a >= deck.length || b >= deck.length) return false;
    if (a === b) return false;
    if (tabu && tabu.has(keyOf(a, b))) return false;
    return true;
  };

  const findNeedSrcFromWait = (needColor: number, used: Set<number>): number => {
    if (waitColors.length !== waitSrcIdx.length) return -1;
    // wait 내부에 여러 개면 "앞쪽(shift에 가까운)" 것을 우선
    for (let i = 0; i < waitColors.length; i++) {
      if ((waitColors[i] | 0) === (needColor | 0)) {
        const s = (waitSrcIdx[i] ?? -1) | 0;
        if (s >= 0 && s < deck.length && !used.has(s)) return s;
      }
    }
    return -1;
  };

  const findNeedSrcFromDeck = (needColor: number): number => {
    for (let i = pivot; i < deck.length; i++) {
      if (((deck[i]?.colorId ?? -1) | 0) === (needColor | 0)) return i;
    }
    return -1;
  };

  // --- Multi swap plan: slotCount 만큼의 최우선 need 색을 slot에 최소 1개씩 넣기 ---
  const slotCount = slotColors.length;
  const targetColors = needOrder.slice(0, Math.min(slotCount, needOrder.length));
  const slotSet = new Set<number>(slotColors.filter((c) => c >= 0));
  const missing: number[] = [];
  for (const c of targetColors) if (!slotSet.has(c)) missing.push(c);

  // bad slot 후보: (1) need=0인 색 (2) targetColors에 포함 안 된 색
  const badSlotIdxs = Array.from({ length: slotCount }, (_, i) => i)
    .filter((i) => {
      const c = slotColors[i] | 0;
      if (c < 0) return true;
      if ((need[c] | 0) === 0) return true;
      if (!targetColors.includes(c)) return true;
      return false;
    })
    .sort((i, j) => {
      const ci = slotColors[i] | 0;
      const cj = slotColors[j] | 0;
      const si = ((remain[ci] | 0) + (waitCount[ci] | 0)) * 100 + (slotAmmo[i] ?? 0);
      const sj = ((remain[cj] | 0) + (waitCount[cj] | 0)) * 100 + (slotAmmo[j] ?? 0);
      return sj - si; // 풍부하고 ammo 많은 색을 먼저 교체
    });

  const nextDeck = deck.slice();
  const swaps: Array<[number, number]> = [];

  const usedIdx = new Set<number>();
  const consumeBadSrc = (): number => {
    while (badSlotIdxs.length > 0) {
      const si = badSlotIdxs.shift()!;
      const s = (slotSrcIdx[si] ?? -1) | 0;
      if (s >= 0 && s < deck.length && !usedIdx.has(s)) {
        usedIdx.add(s);
        return s;
      }
    }
    return -1;
  };

  // missing 색을 하나씩 slot에 주입
  let forcedCandidate: { a: number; b: number; needColor: number } | null = null;
  for (const needColor of missing) {
    const badSrc = consumeBadSrc();
    if (badSrc < 0) break;

    let goodSrc = findNeedSrcFromWait(needColor, usedIdx);
    if (goodSrc < 0) {
      const dsrc = findNeedSrcFromDeck(needColor);
      if (dsrc >= 0 && !usedIdx.has(dsrc)) goodSrc = dsrc;
    }
    if (goodSrc < 0) continue;

    if (!canSwap(badSrc, goodSrc)) {
      if (!forcedCandidate) forcedCandidate = { a: badSrc, b: goodSrc, needColor };
      continue;
    }

    const tmp = nextDeck[badSrc];
    nextDeck[badSrc] = nextDeck[goodSrc];
    nextDeck[goodSrc] = tmp;

    swaps.push([badSrc, goodSrc]);
    usedIdx.add(goodSrc);

    // slotSet 갱신
    slotSet.add(needColor);
  }

  // tabu 때문에 후보가 전부 막힌 경우: 최소 1회는 강제로 적용 (무한 반복은 simulateStageV20의 최근 tabu로 제어)
  if (swaps.length === 0 && forcedCandidate) {
    const { a, b, needColor } = forcedCandidate;
    if (a >= 0 && b >= 0 && a < nextDeck.length && b < nextDeck.length && a !== b) {
      const tmp = nextDeck[a];
      nextDeck[a] = nextDeck[b];
      nextDeck[b] = tmp;
      return { nextDeck, pickedNeedColor: needColor, swappedA: a, swappedB: b, swaps: [[a, b]] };
    }
  }

  // multi-swap이 1개라도 성립하면 그걸 반환
  if (swaps.length > 0) {
    const [a, b] = swaps[0];
    return { nextDeck, pickedNeedColor: (missing[0] ?? needOrder[0]) | 0, swappedA: a, swappedB: b, swaps };
  }

  // --- Fallback: 기존 단일 swap (waiting -> shooter 또는 pivot 이후 -> shooter) ---
  const pickBadSlotIndex = (): number => {
    let best = -1;
    let bestAmmo = 1e9;
    for (let i = 0; i < slotColors.length; i++) {
      const c = slotColors[i] | 0;
      const a = slotAmmo[i] ?? 0;
      if (c < 0) continue;
      if ((need[c] | 0) > 0) continue;
      if (a < bestAmmo) {
        best = i;
        bestAmmo = a;
      }
    }
    if (best >= 0) return best;
    return slotColors.length > 0 ? 0 : -1;
  };

  const badSlot = pickBadSlotIndex();
  const badSrc = badSlot >= 0 ? (slotSrcIdx[badSlot] ?? -1) : -1;

  if (badSrc >= 0 && waitColors.length === waitSrcIdx.length && waitColors.length > 0) {
    for (const needColor of needOrder) {
      const needSrc = findNeedSrcFromWait(needColor, new Set());
      if (needSrc < 0) continue;
      if (!canSwap(badSrc, needSrc)) continue;

      const out = deck.slice();
      const tmp = out[badSrc];
      out[badSrc] = out[needSrc];
      out[needSrc] = tmp;
      return { nextDeck: out, pickedNeedColor: needColor, swappedA: badSrc, swappedB: needSrc, swaps: [[badSrc, needSrc]] };
    }
  }

  for (const needColor of needOrder) {
    const idxNeed = findNeedSrcFromDeck(needColor);
    if (idxNeed < 0) continue;

    let idxBad = -1;
    if (badSrc >= 0 && badSrc < deck.length) idxBad = badSrc;
    else {
      const start = Math.max(0, pivot - Math.max(1, repairBackWindow | 0));
      for (let i = pivot - 1; i >= start; i--) {
        const c = (deck[i]?.colorId ?? -1) | 0;
        if (c === needColor) continue;
        if (slotColors.includes(c)) {
          idxBad = i;
          break;
        }
      }
      if (idxBad < 0) idxBad = Math.max(0, pivot - 1);
    }

    if (!canSwap(idxBad, idxNeed)) continue;

    const out = deck.slice();
    const tmp = out[idxBad];
    out[idxBad] = out[idxNeed];
    out[idxNeed] = tmp;
    return { nextDeck: out, pickedNeedColor: needColor, swappedA: idxBad, swappedB: idxNeed, swaps: [[idxBad, idxNeed]] };
  }

  return null;
}


async function createHeadlessBoard(BoardCtor: any, runtime: any) {
  const b = new BoardCtor();
  // headless에서 Prefab/Node만 있으면 동작하도록 구성되어 있습니다.
  (b as any).tilePrefab = new Prefab();
  (b as any).bigTilePrefab = new Prefab();
  (b as any).projectilePrefab = new Prefab();
  (b as any).tileLayer = new Node('tileLayer');
  (b as any).projectileLayer = new Node('projectileLayer');
  (b as any).fxLayer = new Node('fxLayer');
  (b as any).onLoad?.();
  (b as any).start?.();
  b.load(runtime);
  return b;
}

async function simulateOnce(
  BoardCtor: any,
  runtime: any,
  deck: CardData[],
  maxSteps: number,
): Promise<SimV20Result> {
  const b = await createHeadlessBoard(BoardCtor, runtime);

  const slotCount = Math.max(1, runtime.slotCount | 0);
  const pickerCols = Math.max(1, (runtime.pickerCols ?? 5) | 0);
  const waitLineCount = Math.max(1, (runtime.waitLineCount ?? 3) | 0);
  const waitCap = Math.max(0, waitLineCount * pickerCols);

  let deckIdx = 0;
  const waiting: SimSlot[] = [];
  const shooters: (SimSlot | null)[] = Array.from({ length: slotCount }, () => null);

  const drawNextToWaiting = () => {
    if (deckIdx >= deck.length) return;
    const idx = deckIdx | 0;
    const cd = deck[deckIdx++];
    waiting.push({ data: cd, ammo: Math.max(0, (cd.ammo ?? 0) | 0), srcIdx: idx });
  };

  const refillWaitingToCap = () => {
    while (waiting.length < waitCap && deckIdx < deck.length) drawNextToWaiting();
  };

  const pullWaitingToShooter = (i: number) => {
    if (shooters[i]) return;
    if (waiting.length <= 0) return;
    const next = waiting.shift()!;
    shooters[i] = next;
    // 대기칸 하나가 비었으니 즉시 덱에서 보충
    if (deckIdx < deck.length) drawNextToWaiting();
  };

  // 초기 채우기
  refillWaitingToCap();
  for (let i = 0; i < slotCount; i++) pullWaitingToShooter(i);
  refillWaitingToCap();

  const row0Buf = new Int32Array(12);
  const needBuf = new Int32Array(12);
  const ammoBuf = new Int32Array(12);

  let steps = 0;
  let shotsFired = 0;

  while (b.remaining() > 0 && steps < maxSteps) {
    steps++;

    // headless에서는 프레임 루프가 없어서 busy flag가 남을 수 있으니 매 스텝 초기화
    try {
      (b as any).resetBusyFlags?.();
    } catch {}

    // 빈 슈터를 대기열에서 채우기
    for (let i = 0; i < slotCount; i++) pullWaitingToShooter(i);
    refillWaitingToCap();

    // STUCK 체크(게임 판정과 동일: 슈터가 꽉 찼고 전원 타겟 0)
    let filled = 0;
    const slotColors: number[] = new Array(slotCount);
    const slotAmmo: number[] = new Array(slotCount);
    const slotSrcIdx: number[] = new Array(slotCount);
    for (let i = 0; i < slotCount; i++) {
      const s = shooters[i];
      if (s) filled++;
      slotColors[i] = s ? (s.data.colorId | 0) : -1;
      slotAmmo[i] = s ? (s.ammo | 0) : 0;
      slotSrcIdx[i] = s ? (s.srcIdx | 0) : -1;
    }
    if (filled >= slotCount) {
      let anyCanShoot = false;
      for (let i = 0; i < slotCount; i++) {
        const s = shooters[i];
        if (!s || s.ammo <= 0) continue;
        const wantShots = Math.max(1, (s.data.shotCount ?? 1) | 0);
        const ts = pickTargets(b as any, s.data.colorId | 0, wantShots, new Set());
        if (ts.length > 0) {
          anyCanShoot = true;
          break;
        }
      }
      if (!anyCanShoot) {
        const row0 = computeRow0Counts(b as any, row0Buf);
        const need = computeShootableNeedCounts(b as any, needBuf);
        const ammo = computeAmmoByColor(shooters, waiting, deck, deckIdx, ammoBuf);

        const ent = entropyFromCounts(row0);
        let rowSum = 0;
        let rowMax = 0;
        for (let i = 0; i < row0.length; i++) {
          const v = Math.max(0, row0[i] | 0);
          rowSum += v;
          if (v > rowMax) rowMax = v;
        }
        const maxFrac = rowSum > 0 ? rowMax / rowSum : 0;
        const metrics = {
          row0Entropy: ent,
          row0MaxFrac: maxFrac,
          row0Counts: Array.from(row0),
          ammoByColor: Array.from(ammo),
        };

        const deckColorCounts = new Int32Array(12);
        for (let i = deckIdx; i < deck.length; i++) {
          const c = (deck[i]?.colorId | 0);
          if (c >= 0 && c < 12) deckColorCounts[c] += 1;
        }

        const waitColors = waiting.map((w) => (w?.data?.colorId ?? -1) | 0);
        const waitAmmo = waiting.map((w) => (w?.ammo ?? 0) | 0);
        const waitSrcIdx = waiting.map((w) => (w?.srcIdx ?? -1) | 0);

        return {
          status: 'STUCK',
          steps,
          remaining: b.remaining(),
          deckLeft: Math.max(0, deck.length - deckIdx),
          stuck: {
            needCounts: Array.from(need),
            row0Counts: Array.from(row0),
            deckColorCounts: Array.from(deckColorCounts),
            deckIdx,
            slotColors,
            slotAmmo,
            slotSrcIdx,
            waitCap,
            waitLineCount,
            pickerCols,
            waitColors,
            waitAmmo,
            waitSrcIdx,
          },
          metrics,
        };
      }
    }

    // 한 라운드: 슈터당 1회 발사(shotCount만큼 타겟)
    const excludeEnt = new Set<number>();
    for (let i = 0; i < slotCount; i++) {
      const s = shooters[i];
      if (!s) continue;
      if (s.ammo <= 0) {
        shooters[i] = null;
        pullWaitingToShooter(i);
        continue;
      }
      const colorId = s.data.colorId | 0;
      const wantShots = Math.max(1, (s.data.shotCount ?? 1) | 0);
      const targets = pickTargets(b as any, colorId, wantShots, excludeEnt);
      if (!Array.isArray(targets) || targets.length <= 0) continue;

      const bullets = Math.min(s.ammo, targets.length);
      for (let k = 0; k < bullets; k++) {
        const t: any = targets[k];
        excludeEnt.add(t.entId | 0);
        await hit(b, t.col | 0);
        shotsFired++;
        s.ammo -= 1;
        if (b.remaining() <= 0) break;
      }
      if (s.ammo <= 0) {
        shooters[i] = null;
        pullWaitingToShooter(i);
      }
      if (b.remaining() <= 0) break;
    }
  }

  // 종료(UNKNOWN 또는 SOLVED)
  const row0 = computeRow0Counts(b as any, row0Buf);
  const ammo = computeAmmoByColor(shooters, waiting, deck, deckIdx, ammoBuf);
  const ent = entropyFromCounts(row0);
  let rowSum = 0;
  let rowMax = 0;
  for (let i = 0; i < row0.length; i++) {
    const v = Math.max(0, row0[i] | 0);
    rowSum += v;
    if (v > rowMax) rowMax = v;
  }
  const maxFrac = rowSum > 0 ? rowMax / rowSum : 0;
  const metrics = {
    row0Entropy: ent,
    row0MaxFrac: maxFrac,
    row0Counts: Array.from(row0),
    ammoByColor: Array.from(ammo),
  };

  if (b.remaining() <= 0) return { status: 'SOLVED', steps, shotsFired, metrics };
  return { status: 'UNKNOWN', steps, remaining: b.remaining(), shotsFired, metrics };
}

export async function simulateStageV20(stage: any, opts?: SimV20Opts): Promise<SimV20Result> {
  const maxSteps = Math.max(1, (opts?.maxSteps ?? 50000) | 0);
  const autoRepair = !!opts?.autoRepair;
  const repairMax = Math.max(0, (opts?.repairMaxAttempts ?? 60) | 0);
  const repairBackWindow = Math.max(1, (opts?.repairBackWindow ?? 40) | 0);
  const constructByBoardBands = (opts?.constructByBoardBands ?? autoRepair) === true;
  const beamWidth = Math.max(1, (opts?.repairBeamWidth ?? 8) | 0);
  const probeSteps = Math.max(200, (opts?.repairProbeSteps ?? Math.min(3000, maxSteps)) | 0);

  const stageCompilerMod = await import('../validator_tools/game/StageCompiler');
  const compileRuntimeFromV2 = cjsPick<(s: any, o?: any) => any>(stageCompilerMod, 'compileRuntimeFromV2');
  if (typeof compileRuntimeFromV2 !== 'function') throw new Error('validator_tools: compileRuntimeFromV2 not found');

  const layerCount = stage?.meta?.layerCount ?? 1;
  const enableStacks = (layerCount | 0) > 1;
  const runtime = compileRuntimeFromV2(stage as any, { enableStacks });

  const boardMod = await import('../validator_tools/game/Board');
  const BoardCtor = cjsPick<any>(boardMod, 'Board');
  if (typeof BoardCtor !== 'function') throw new Error('validator_tools: Board ctor not found');

  let deck: CardData[] = Array.isArray(runtime.cards) ? runtime.cards.map(cloneCard) : [];

  // (역설계) 하단 밴드 수요 기반으로 덱을 한 번 정렬해두면
  // "바닥부터 유닛이 채워가는" 흐름이 되어 STUCK 빈도가 크게 줄어듭니다.
  if (constructByBoardBands && deck.length > 0) {
    deck = reorderDeckByBoardBands(stage, runtime, deck);
  }

  const repair: SimRepairInfo = { enabled: autoRepair, attempts: 0, applied: false, history: [] };
  const tabuSet = new Set<string>();
  const tabuQueue: string[] = []; // 최근 swap만 금지 (무한 금지로 후보 고갈되는 문제 방지)

  const seen = new Set<number>();
  const hashDeck = (d: CardData[]) => {
    // FNV-1a 32bit on a small prefix/suffix to keep it cheap
    let h = 2166136261 >>> 0;
    const n = d.length;
    const prefix = Math.min(n, 256);
    const suffix = Math.min(n, 256);
    for (let i = 0; i < prefix; i++) {
      const c = (d[i]?.colorId ?? -1) | 0;
      const a = (d[i]?.ammo ?? 0) | 0;
      h ^= ((c & 0xff) << 8) ^ (a & 0xff);
      h = Math.imul(h, 16777619) >>> 0;
    }
    for (let i = Math.max(prefix, n - suffix); i < n; i++) {
      const c = (d[i]?.colorId ?? -1) | 0;
      const a = (d[i]?.ammo ?? 0) | 0;
      h ^= ((c & 0xff) << 8) ^ (a & 0xff);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  };

  let last: SimV20Result | null = null;
  const attempts = autoRepair ? Math.max(1, repairMax + 1) : 1;

  for (let it = 0; it < attempts; it++) {
    const res = await simulateOnce(BoardCtor, runtime, deck, maxSteps);
    last = res;

    // 공통 부가 정보(현재 deck 기준)
    res.deck = makeDeckSummary(deck);
    res.suggestedAuthoredCards = makeSuggestedAuthoredCards(deck);
    res.repair = repair;

    if (res.status !== 'STUCK') return res;
    if (!autoRepair) return res;
    if (it >= repairMax) return res;

    const stuck = res.stuck as any;

    // candidate generation (beam): 여러 수정안 중 "짧은 probe"에서 더 나은 진행을 보이는 덱을 선택
    const candidates = makeBeamCandidates(
      deck,
      {
        deckIdx: (stuck?.deckIdx ?? 0) | 0,
        slotColors: Array.isArray(stuck?.slotColors) ? stuck.slotColors : [],
        slotSrcIdx: Array.isArray(stuck?.slotSrcIdx) ? stuck.slotSrcIdx : [],
        waitSrcIdx: Array.isArray(stuck?.waitSrcIdx) ? stuck.waitSrcIdx : [],
        waitCap: (stuck?.waitCap ?? 0) | 0,
        needCounts: Array.isArray(stuck?.needCounts) ? stuck.needCounts : [],
        _tabu: tabuSet,
      },
      repairBackWindow,
      Math.max(4, beamWidth * 2),
    );

    if (!candidates || candidates.length <= 0) return res;

    const curScore = scoreSimResult(res);
    let best = candidates[0];
    let bestScore = -Infinity;
    let bestProbe: SimV20Result | null = null;

    for (const cand of candidates.slice(0, Math.max(1, beamWidth))) {
      const probe = await simulateOnce(BoardCtor, runtime, cand.nextDeck, probeSteps);
      const sc = scoreSimResult(probe);
      if (sc > bestScore) {
        bestScore = sc;
        best = cand;
        bestProbe = probe;
      }
      if (probe.status === 'SOLVED') break;
    }

    // If nothing improves, diversify: local rotate near pivot to escape cycles.
    if (bestScore <= curScore) {
      const pivot = Math.max(0, (stuck?.deckIdx ?? 0) | 0);
      const start = Math.max(0, pivot - Math.max(12, repairBackWindow | 0));
      const end = Math.min(deck.length, pivot + Math.max(18, repairBackWindow | 0));
      if (end - start >= 6) {
        const nd = deck.slice();
        const seg = nd.slice(start, end);
        const k = ((it + 1) * 3 + pivot) % seg.length;
        const rotated = seg.slice(k).concat(seg.slice(0, k));
        for (let i = 0; i < rotated.length; i++) nd[start + i] = rotated[i];
        best = {
          nextDeck: nd,
          pickedNeedColor: (best?.pickedNeedColor ?? -1) | 0,
          swappedA: start,
          swappedB: end - 1,
          reason: 'diversify-rotate',
        };
      }
    }

    // loop detection guard
    const h = hashDeck(best.nextDeck);
    if (seen.has(h)) {
      // one more diversification: partition by need on a window
      const pivot = Math.max(0, (stuck?.deckIdx ?? 0) | 0);
      const start = Math.max(0, pivot - Math.max(10, repairBackWindow | 0));
      const end = Math.min(deck.length, pivot + Math.max(16, repairBackWindow | 0));
      if (end - start >= 8) {
        const nd = best.nextDeck.slice();
        const needOrder = bestNeedOrder(Array.isArray(stuck?.needCounts) ? stuck.needCounts : []);
        const top = new Set<number>(needOrder.slice(0, 3));
        const seg = nd.slice(start, end);
        const a: CardData[] = [];
        const b: CardData[] = [];
        for (const c of seg) (top.has((c?.colorId ?? -1) | 0) ? a : b).push(c);
        const merged = a.concat(b);
        for (let i = 0; i < merged.length; i++) nd[start + i] = merged[i];
        best = { ...best, nextDeck: nd, swappedA: start, swappedB: end - 1, reason: 'diversify-partition' };
      }
    }
    seen.add(hashDeck(best.nextDeck));

    // tabu 업데이트(같은 swap을 반복해서 토글하는 현상 방지)
    if (best.swaps && best.swaps.length > 0) {
      for (const [a, b] of best.swaps) {
        const x = Math.min(a, b);
        const y = Math.max(a, b);
        const k = `${x}-${y}`;
        if (!tabuSet.has(k)) {
          tabuSet.add(k);
          tabuQueue.push(k);
          if (tabuQueue.length > 8) {
            const old = tabuQueue.shift();
            if (old) tabuSet.delete(old);
          }
        }
      }
    } else {
      const x = Math.min(best.swappedA, best.swappedB);
      const y = Math.max(best.swappedA, best.swappedB);
      const k = `${x}-${y}`;
      if (!tabuSet.has(k)) {
        tabuSet.add(k);
        tabuQueue.push(k);
        if (tabuQueue.length > 8) {
          const old = tabuQueue.shift();
          if (old) tabuSet.delete(old);
        }
      }
    }

    deck = best.nextDeck;
    repair.applied = true;
    repair.attempts = it + 1;
    repair.history.push({
      pivotDeckIdx: (stuck?.deckIdx ?? 0) | 0,
      pickedNeedColor: best.pickedNeedColor,
      swappedA: best.swappedA,
      swappedB: best.swappedB,
      swaps: best.swaps,
      reason: best.reason,
    });
  }

  // unreachable, but keep TS happy
  if (!last) {
    return {
      status: 'UNKNOWN',
      steps: 0,
      remaining: 0,
      shotsFired: 0,
      metrics: {},
      deck: makeDeckSummary(deck),
      suggestedAuthoredCards: makeSuggestedAuthoredCards(deck),
      repair,
    };
  }
  return last;
}
