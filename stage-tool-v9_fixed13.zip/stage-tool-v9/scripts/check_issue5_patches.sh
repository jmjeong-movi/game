#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/.."
out="${1:-.issue5_check_result.json}"
python - <<'PY' "$out"
import json,sys,zipfile,os,hashlib
out=sys.argv[1]
res={"checks":{},"overall":"PASS"}
zipf='stage-tool-v9_fixed13.zip'
need=[
 'stage-tool-v9/src/validator_tools/cli.js',
 'stage-tool-v9/src/validator_tools/game/StageCompiler.js',
 'stage-tool-v9/src/validator_tools/engine/sim_equivalent.js',
 'stage-tool-v9/scripts/run_requested_validations.sh',
 'stage-tool-v9/scripts/real_engine_preflight.sh',
 'stage-tool-v9/scripts/validate_real_engine_connected.sh',
 'stage-tool-v9/src/validator_tools/engine/README_REAL_ENGINE.md',
 'stage-tool-v9/src/validator_tools/engine/real_game_validator.js',
]
ok=True
if os.path.exists(zipf):
  with zipfile.ZipFile(zipf) as z:
    names=set(z.namelist())
    for n in need:
      has=n in names
      res['checks'][f'zip_has::{n}']=has
      ok=ok and has
else:
  ok=False
  res['checks']['zip_exists']=False
res['overall']='PASS' if ok else 'FAIL'
open(out,'w',encoding='utf-8').write(json.dumps(res,ensure_ascii=False,indent=2))
print(res['overall'])
if res['overall']!='PASS': raise SystemExit(1)
PY
