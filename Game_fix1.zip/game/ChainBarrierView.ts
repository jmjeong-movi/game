import { _decorator, Component, Vec3, tween, Tween, sp } from 'cc';
import { pad2, toSpriteIndex } from './ColorPalette';

const { ccclass } = _decorator;

/**
 * ✅ 체인블럭(슬라임) 길이 제어 뷰
 * - 스파인 본 Target_Left / Target_Right 의 local X 값을 이용해 좌/우로 늘어나거나 줄어드는 형태
 * - **요구사항**
 *   - 체인 시작 자체는 1x1(스몰블럭 한 셀)
 *   - 머리(head)는 고정, 꼬리(tail)만 늘어나고/줄어듭니다.
 *   - 방향(머리가 왼쪽/오른쪽)은 chainOrder(최소=머리, 최대=꼬리)로 결정됩니다.
 * - 크기 변화 시 'Size' 1회 재생 후 'Idle' 루프
 * - 줄어들 때(및 기본적으로) easing: 'quartOut'
 */
@ccclass('ChainBarrierView')
export class ChainBarrierView extends Component {
    private _board: any = null;
    private _chainId = '';

    private _skel: sp.Skeleton | null = null;
    private _boneL: any = null;
    private _boneR: any = null;

    // 본 로컬 X(현재)
    private _curL = 0;
    private _curR = 0;

    // 본 로컬 X(목표)
    private _goalL = 0;
    private _goalR = 0;
    private _tween: Tween<any> | null = null;

    private _lastLen = -999;
    private _lastDir: 1 | -1 = 1;
    private _lastColorId = -999;

    private _tmpA = new Vec3();
    // (확장 대비) 임시 벡터
    private _tmpB = new Vec3();

    init(board: any, chainId: string) {
        this._board = board;
        this._chainId = String(chainId ?? '');
    }

    onLoad() {
        // prefab 루트/자식 어디에든 sp.Skeleton이 있을 수 있으므로 children까지 탐색
        this._skel = this.getComponent(sp.Skeleton) ?? this.getComponentInChildren(sp.Skeleton);
        if (this._skel && this._skel.isValid) {
            try {
                this._skel.setAnimation(0, 'Idle', true);
            } catch {
                // ignore
            }
            try {
                this._boneL = (this._skel as any).findBone?.('Target_Left') ?? null;
                this._boneR = (this._skel as any).findBone?.('Target_Right') ?? null;
            } catch {
                this._boneL = null;
                this._boneR = null;
            }
        }
    }

    // ✅ spine 업데이트 이후에 본 값을 고정하기 위해 lateUpdate에서 처리
    lateUpdate() {
        const b = this._board;
        if (!b || !(b as any).isValid) {
            if (this.node?.isValid) this.node.destroy();
            return;
        }

        const set: Set<number> | undefined = b.getChainSegIds?.(this._chainId);
        if (!set || set.size <= 0) {
            if (this.node?.isValid) this.node.destroy();
            return;
        }

        // head/tail = chainOrder 기준(최소=머리, 최대=꼬리)
        let head: any = null;
        let tail: any = null;
        let ordMin = 1e9;
        let ordMax = -1e9;

        // 색상(스킨)
        let colorId = -999;

        for (const entId of set) {
            const e = b.getEntById?.(entId);
            if (!e || !e.view?.node?.isValid) continue;
            const spc = e.view.getSpecial?.();
            if (!spc || spc.t !== 'CHAIN_SEG') continue;

            const order = ((spc.order ?? 0) | 0);
            if (order < ordMin) {
                ordMin = order;
                head = e;
            }
            if (order > ordMax) {
                ordMax = order;
                tail = e;
            }

            if (colorId === -999) colorId = (e.view.colorId ?? -999) | 0;
        }

        if (!head) return;
        if (!tail) tail = head;

        // ✅ head 셀 중심에 루트 고정
        head.view.node.getWorldPosition(this._tmpA);
        this.node.setWorldPosition(this._tmpA);

        // ✅ 방향: head 기준 tail이 좌/우 어디인지
        const dCol = ((tail.col ?? 0) | 0) - ((head.col ?? 0) | 0);
        let dir: 1 | -1 = this._lastDir;
        if (dCol > 0) dir = 1;
        else if (dCol < 0) dir = -1;

        // ✅ 길이(셀 단위): 기본 1칸
        // (세그 수가 더 크면 세그 수 우선)
        let lenCells = Math.max(1, Math.abs(dCol) + 1);
        if (set.size > lenCells) lenCells = set.size;

        // 스킨 갱신(Chain_01~12)
        if (this._skel && this._skel.isValid && colorId !== this._lastColorId) {
            this._lastColorId = colorId;
            const idx = toSpriteIndex(colorId, 12);

            // Chain_12가 없는 리소스도 있을 수 있어 fallback
            const tries = [idx, Math.max(1, idx - 1), Math.max(1, idx - 2)];
            for (const t of tries) {
                const skin = `Chain_${pad2(t)}`;
                try {
                    (this._skel as any).setSkin?.(skin);
                    (this._skel as any).skinName = skin;
                    (this._skel as any).setSlotsToSetupPose?.();
                    (this._skel as any).updateWorldTransform?.();
                    break;
                } catch {
                    // try next
                }
            }
        }

        // ✅ 본 좌표(기본 1칸): [-half, +half]
        const tile = Math.max(1, Math.round((b as any).tileSize ?? 56));
        const half = tile * 0.5;
        let targetL = -half;
        let targetR = +half;

        if (lenCells > 1) {
            const extra = (lenCells - 1) * tile;
            if (dir === 1) {
                // head=왼쪽 끝, tail=오른쪽으로 증가
                targetR = +half + extra;
            } else {
                // head=오른쪽 끝, tail=왼쪽으로 증가
                targetL = -half - extra;
            }
        }

        // ✅ 목표가 바뀌었을 때만 Size + Tween을 1회 트리거합니다.
        // - 기존 구현은 tween 진행 중에도 target!=cur 조건으로 매 프레임 tween을 재시작하여
        //   "줄어듦 실패/스턱"처럼 보일 수 있었습니다.
        const first = this._lastLen === -999;
        const goalChanged =
            first ||
            lenCells !== this._lastLen ||
            dir !== this._lastDir ||
            Math.abs(targetL - this._goalL) > 0.01 ||
            Math.abs(targetR - this._goalR) > 0.01;

        if (goalChanged) {
            const prevLen = this._lastLen;
            this._lastLen = lenCells;
            this._lastDir = dir;
            this._goalL = targetL;
            this._goalR = targetR;

            if (first) {
                // 최초 1회는 즉시 세팅
                this._stopTween();
                this._curL = targetL;
                this._curR = targetR;
            } else {
                // 길이가 바뀌는 순간에만 Size 1회
                if (prevLen !== lenCells) this._playSizeOnce();
                this._tweenBones(targetL, targetR);
            }
        }

        // 매 프레임 본 값 강제(애니메이션이 건드리지 않는다는 가정이지만 안전장치)
        if (this._boneL) this._boneL.x = this._curL;
        if (this._boneR) this._boneR.x = this._curR;
        try {
            (this._skel as any)?.updateWorldTransform?.();
        } catch {
            // ignore
        }
    }

    private _playSizeOnce() {
        const sk = this._skel;
        if (!sk || !sk.isValid) return;
        try {
            sk.setAnimation(0, 'Size', false);
            sk.addAnimation(0, 'Idle', true, 0);
        } catch {
            // ignore
        }
    }

    private _tweenBones(targetL: number, targetR: number) {
        this._stopTween();

        const state = { l: this._curL, r: this._curR };
        this._tween = tween(state)
            .to(
                0.2,
                { l: targetL, r: targetR },
                {
                    easing: 'quartOut',
                    onUpdate: () => {
                        this._curL = state.l;
                        this._curR = state.r;
                    },
                }
            )
            .call(() => {
                this._curL = targetL;
                this._curR = targetR;
                this._tween = null;
            })
            .start();
    }

    private _stopTween() {
        if (!this._tween) return;
        try {
            this._tween.stop();
        } catch {
            // ignore
        }
        this._tween = null;
    }
}
