import type { Node, Vec3 } from 'cc';

// 인트로 드랍 연출에 필요한 최소 인자 타입
// - BoardIntroDrop는 보드/엔티티 구현에 의존하지 않도록 any 기반으로 분리합니다.
export type IntroDropPlayArgs = {
    tileLayer: Node;
    cols: number;
    // 배열/MapIterator/Set 등 어떤 반복 가능한 컬렉션이든 허용
    ents: Iterable<any>;
    getEntParentAndLocal: (e: any) => { parent: Node | null; local: Vec3 };
};
