#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/.."
ZIP_NAME="${1:-stage-tool-v9_fixed05.zip}"
REQ=(
  "stage-tool-v9/src/App.tsx"
  "stage-tool-v9/src/lib/replay_repair.ts"
  "stage-tool-v9/src/lib/runtime/stage/compileRuntimeFromV2.ts"
  "stage-tool-v9/src/lib/supply_policy.ts"
  "stage-tool-v9/src/validator_tools/cli.js"
  "stage-tool-v9/src/validator_tools/game/StageCompiler.js"
  "stage-tool-v9/src/validator_tools/engine/sim_equivalent.js"
)
for f in "${REQ[@]}"; do
  [[ -f "$f" ]] || { echo "missing required artifact: $f"; exit 2; }
done
rm -f "$ZIP_NAME"
zip -qr "$ZIP_NAME" stage-tool-v9
unzip -l "$ZIP_NAME" >/dev/null
echo "[repack] wrote $ZIP_NAME"
