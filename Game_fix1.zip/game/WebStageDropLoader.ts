// WebStagePackDropdown.ts
// 역할:
// - (웹 전용) stage-pack(v2) json 파일을 드래그&드롭/파일선택으로 받아 GameFlow에 주입
// - pack의 stage id 목록으로 드롭다운을 만들고, 선택한 stage부터 시작
//
// 퍼포먼스/안정성:
// - JSON.parse는 입력 시 1회
// - 마지막 성공 JSON을 localStorage에 저장(새로고침 후 재로드 가능)
// - 로딩 중 중복 입력 방지

import { _decorator, Component, sys, director } from 'cc';
import { GameFlow } from './GameFlow';

const { ccclass, property } = _decorator;

const LS_KEY_LAST_PACK = 'debug_stage_pack_last_json';

@ccclass('WebStageDropLoader')
export class WebStageDropLoader extends Component {
    @property({ type: GameFlow, tooltip: 'GameFlow(없으면 씬에서 자동 탐색)' })
    gameFlow: GameFlow | null = null;

    @property({ tooltip: '드롭다운 선택 즉시 시작' })
    autoStartOnChange = true;

    @property({ tooltip: '마지막 pack을 localStorage에 저장/복원' })
    persistLastPack = true;

    private _busy = false;

    // DOM refs
    private _rootEl: HTMLDivElement | null = null;
    private _selectEl: HTMLSelectElement | null = null;

    onLoad() {
        if (!sys.isBrowser) return;

        if (!this.gameFlow || !this.gameFlow.isValid) {
            this.gameFlow = this._findGameFlow();
        }

        this._createPanel();
        this._installDragDrop();

        // ✅ GameFlow.start()에서 stageAsset을 읽어 _stagesV2를 채우는 타이밍이
        // WebStageDropLoader.onLoad() 이후일 수 있습니다.
        // 처음 열었을 때 드롭다운이 "No stages"로 고정되지 않도록 다음 프레임에 한 번 더 갱신합니다.
        this.scheduleOnce(() => this._rebuildDropdown(), 0);

        if (this.persistLastPack) {
            this._tryLoadLastPack();
        }
    }

    onDestroy() {
        if (!sys.isBrowser) return;

        // DOM 제거
        if (this._rootEl && this._rootEl.parentElement) {
            this._rootEl.parentElement.removeChild(this._rootEl);
        }
        this._rootEl = null;
        this._selectEl = null;

        // 이벤트 제거(간단히 전체 핸들러를 익명으로 달아둔 구조라, 페이지 종료 기준으로 문제는 적지만)
        // 필요하면 named handler로 바꿔서 removeEventListener 하시면 됩니다.
    }

    // ----------------------
    // Panel
    // ----------------------

    private _createPanel(): void {
        const root = document.createElement('div');
        root.style.position = 'fixed';
        root.style.top = '8px';
        root.style.left = '8px';
        root.style.zIndex = '99999';
        root.style.padding = '8px';
        root.style.borderRadius = '10px';
        root.style.background = 'rgba(0,0,0,0.65)';
        root.style.color = '#fff';
        root.style.fontSize = '12px';
        root.style.display = 'flex';
        root.style.gap = '6px';
        root.style.alignItems = 'center';
        root.style.userSelect = 'none';

        const fileBtn = document.createElement('button');
        fileBtn.textContent = 'Load JSON';
        fileBtn.onclick = () => this.openFilePicker();

        const select = document.createElement('select');
        select.style.maxWidth = '220px';
        select.onchange = () => {
            if (!this.autoStartOnChange) return;
            this._startSelected();
        };

        const startBtn = document.createElement('button');
        startBtn.textContent = 'Start';
        startBtn.onclick = () => this._startSelected();

        const hint = document.createElement('span');
        hint.textContent = ' (drop stage-pack.json)';

        root.appendChild(fileBtn);
        root.appendChild(select);
        root.appendChild(startBtn);
        root.appendChild(hint);

        document.body.appendChild(root);

        this._rootEl = root;
        this._selectEl = select;

        // 초기 상태
        this._rebuildDropdown();
    }

    public openFilePicker(): void {
        if (!sys.isBrowser || this._busy) return;

        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,application/json';
        input.onchange = async () => {
            const file = input.files?.[0];
            if (!file) return;
            await this._loadFromFile(file);
        };
        input.click();
    }

    private _rebuildDropdown(): void {
        const gf = this._ensureGameFlow();
        const sel = this._selectEl;
        if (!sel) return;

        sel.innerHTML = '';

        if (!gf) {
            const opt = document.createElement('option');
            opt.value = '0';
            opt.textContent = 'GameFlow not found';
            sel.appendChild(opt);
            return;
        }

        const entries = gf.getStageEntries();
        if (!entries || entries.length === 0) {
            const opt = document.createElement('option');
            opt.value = '0';
            opt.textContent = 'No stages';
            sel.appendChild(opt);
            return;
        }

        for (let i = 0; i < entries.length; i++) {
            const e = entries[i];
            const opt = document.createElement('option');
            opt.value = String(e.id);
            opt.textContent = `#${e.id} (idx ${e.index})`;
            sel.appendChild(opt);
        }

        // 현재 인덱스에 맞춰 선택
        const cur = gf.getCurrentStageIndex();
                const curIdx = Math.max(0, Math.min(entries.length - 1, cur));
        sel.value = String(entries[curIdx]?.id ?? entries[0]?.id ?? 0);
    }

    private _startSelected(): void {
        const gf = this._ensureGameFlow();
        const sel = this._selectEl;
        if (!gf || !sel) return;

        const stageId = (parseInt(sel.value, 10) | 0);
        if (!Number.isFinite(stageId) || stageId <= 0) return;

        gf.startStageById(stageId);
    }

    // ----------------------
    // Drag & Drop
    // ----------------------

    private _installDragDrop(): void {
        const prevent = (e: DragEvent) => {
            e.preventDefault();
            e.stopPropagation();
        };

        window.addEventListener('dragenter', prevent);
        window.addEventListener('dragover', prevent);

        window.addEventListener('drop', async (e: DragEvent) => {
            prevent(e);
            if (this._busy) return;

            const file = e.dataTransfer?.files?.[0];
            if (!file) return;

            await this._loadFromFile(file);
        });
    }

    private async _loadFromFile(file: File): Promise<void> {
        const name = file.name.toLowerCase();
        if (!name.endsWith('.json')) return;

        this._busy = true;
        try {
            const text = await file.text();
            const pack = JSON.parse(text);

            const gf = this._ensureGameFlow();
            if (!gf) {
                console.error('[WebStagePackDropdown] GameFlow not found.');
                return;
            }

            const ok = gf.setStagePackV2(pack);
            if (!ok) {
                console.error('[WebStagePackDropdown] invalid pack (stages empty or not v2).');
                return;
            }

            if (this.persistLastPack) {
                window.localStorage.setItem(LS_KEY_LAST_PACK, text);
            }

            // 드롭다운 갱신 후, 기본은 첫 항목 선택
            this._rebuildDropdown();

            // 자동 시작(원하시면 false로 꺼도 됨)
            if (this.autoStartOnChange) {
                // 첫 스테이지부터 시작하고 싶으면 아래 줄 유지
                // gf.startStageByIndex(0);

                // "선택된 값"으로 시작(보통 0)
                this._startSelected();
            }

            console.log('[WebStagePackDropdown] loaded pack:', file.name);
        } catch (e) {
            console.error('[WebStagePackDropdown] load failed:', file.name, e);
        } finally {
            this._busy = false;
        }
    }

    private _tryLoadLastPack(): void {
        try {
            const text = window.localStorage.getItem(LS_KEY_LAST_PACK);
            if (!text) return;

            const pack = JSON.parse(text);
            const gf = this._ensureGameFlow();
            if (!gf) return;

            const ok = gf.setStagePackV2(pack);
            if (!ok) return;

            this._rebuildDropdown();

            // 원하면 마지막 pack 복원 시 자동 시작
            // if (this.autoStartOnChange) this._startSelected();
        } catch {
            // ignore
        }
    }

    private _ensureGameFlow(): GameFlow | null {
        const gf = this.gameFlow && this.gameFlow.isValid ? this.gameFlow : this._findGameFlow();
        if (gf) this.gameFlow = gf;
        return gf;
    }

    private _findGameFlow(): GameFlow | null {
        const scene = director.getScene();
        if (!scene || !scene.isValid) return null;

        for (let i = 0; i < scene.children.length; i++) {
            const n = scene.children[i];
            const c = n.getComponentInChildren(GameFlow);
            if (c && c.isValid) return c;
        }
        return null;
    }
}
