// 역할: StageCompiler 내부 유틸(순수 함수)
// - 런타임/툴(검증) 모두에서 동일하게 쓰기 쉽게 'cc' 의존 없이 유지

// 숫자를 [a,b] 범위로 제한합니다.
export function clamp(n: number, a: number, b: number) {
    return Math.max(a, Math.min(b, n));
}

// 시드 기반 RNG를 생성합니다.
export function mulberry32(seed: number) {
    return function () {
        let t = (seed += 0x6d2b79f5);
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

// [min, max) 범위에서 정수를 뽑습니다.
export function rngInt(rng: () => number, min: number, max: number) {
    return Math.floor(rng() * (max - min)) + min;
}

// step 단위로 올림합니다.
export function roundUpToStep(n: number, step: number) {
    if (step <= 1) return Math.ceil(n);
    return Math.ceil(n / step) * step;
}

// step 단위로 내림합니다.
export function roundDownToStep(n: number, step: number) {
    if (step <= 1) return Math.floor(n);
    return Math.floor(n / step) * step;
}
