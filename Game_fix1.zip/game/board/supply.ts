// 역할: Board 공급(supply) 채우기 로직 분리
// - Board.ts 비대화를 줄이고, 공급 규칙을 한 곳에서 유지합니다.

import { SUPPLY_LARGE_BASE } from '../Types';

// 영향을 받은 컬럼의 "위쪽 빈칸"을 supply로 채워 새 엔티티를 반환합니다.
export function fillTopHoles(b: any, cols: number[] | number): any[] {
    const out: any[] = [];

    // 컬럼 uniq 처리(재사용 버퍼)
    const uniq = b._tmpColUniq;
    uniq.length = 0;
    b._tmpColMark.fill(0);

    if (typeof cols === 'number') {
        // mask 경로
        const m = cols | 0;
        for (let c = 0; c < b.cols; c++) {
            if (!(m & (1 << c))) continue;
            uniq.push(c);
        }
    } else {
        for (let i = 0; i < cols.length; i++) {
            const c = cols[i] | 0;
            if (c < 0 || c >= b.cols) continue;
            if (b._tmpColMark[c]) continue;
            b._tmpColMark[c] = 1;
            uniq.push(c);
        }
    }

    const removeTokenFromCol = (col: number, token: number) => {
        const arr = b.colSupply[col];
        if (!Array.isArray(arr) || arr.length <= 0) return;
        for (let i = arr.length - 1; i >= 0; i--) {
            if ((arr[i] | 0) === (token | 0)) {
                arr.splice(i, 1);
                return;
            }
        }
    };

    for (const c0 of uniq) {
        const c = c0 | 0;

        // topmost occupied row
        let topOcc = -1;
        for (let r = b.rows - 1; r >= 0; r--) {
            if (b.occ[b.indexOf(r, c)] >= 0) {
                topOcc = r;
                break;
            }
        }

        // 위쪽 빈칸(row=rows-1..topOcc+1) 채우기
        for (let r = b.rows - 1; r > topOcc; r--) {
            if (b.occ[b.indexOf(r, c)] >= 0) continue;

            const next = b.colSupply[c]?.pop();
            if (typeof next !== 'number') break;

            // 공급 LARGE 토큰 처리: 4개 토큰을 1개의 BIG 엔티티로 합쳐 생성
            if (next >= SUPPLY_LARGE_BASE) {
                const raw = (next - SUPPLY_LARGE_BASE) | 0;
                const idx = Math.floor(raw / 4);
                const cell = raw - idx * 4; // 0..3
                const dx = cell & 1;
                const dy = (cell / 2) | 0;

                const def = b.supplyLargeDefs?.[idx];
                if (!def) {
                    // 정의가 없으면 되돌리고 계속
                    b.colSupply[c]?.push(next);
                    continue;
                }

                const anchorCol = (c - dx) | 0;
                const anchorRow = (r - dy) | 0;

                // 2x2 전체가 비어있어야 BIG 생성 가능
                const canPlace =
                    anchorCol >= 0 &&
                    anchorCol + 1 < b.cols &&
                    anchorRow >= 0 &&
                    anchorRow + 1 < b.rows &&
                    b.occ[b.indexOf(anchorRow, anchorCol)] < 0 &&
                    b.occ[b.indexOf(anchorRow, anchorCol + 1)] < 0 &&
                    b.occ[b.indexOf(anchorRow + 1, anchorCol)] < 0 &&
                    b.occ[b.indexOf(anchorRow + 1, anchorCol + 1)] < 0;

                if (!canPlace) {
                    // 아직 BIG을 놓을 수 없으면 되돌리고 계속(순서 보장)
                    b.colSupply[c]?.push(next);
                    continue;
                }

                const e = b.spawnBig(anchorRow, anchorCol);
                if (!e) {
                    b.colSupply[c]?.push(next);
                    continue;
                }

                e.view.setTop(def.colorId | 0);
                e.view.setHidden(!!def.hidden);
                e.view.setHp((def as any).hp ?? 1, (def as any).hpMax ?? (def as any).hp ?? 1);
                e.view.setSpecial(null);

                // 새로 생성된 블럭은 "위"에서 떨어뜨림(조금 더 자연스럽게)
                // - 너무 멀리 생성하면 라인 레이아웃에서 렌더 오더가 어색해질 수 있어 cap을 둡니다.
                const topRow = (e.row | 0) + (e.h | 0) - 1;
                const emptyAbove = Math.max(0, (b.rows - 1 - topRow) | 0);
                const cellY = b.useLineLayout
                    ? Math.max(1e-3, Math.abs(b.lineDy || b.tileSize))
                    : Math.max(1e-3, Math.abs((b.stepY > 0 ? b.stepY : b.tileSize) || b.tileSize));
                // ✅ 위에서 떨어져 내리는 느낌: 보드 최상단보다 더 위에서 시작해서 목표 셀로 낙하
                // - 기존: row=rows(=한 줄 위)
                // - 변경: row=rows+2(=세 줄 위)
                const startRow = ((b.rows | 0) + 2) | 0;
                const liftRows = Math.max(1, (startRow - (e.row | 0)) | 0);
                const yOff = cellY * liftRows;

                const t = b.entParentAndLocal(e);
                e.view.node.setParent(t.parent);
                e.view.node.setPosition(t.local.x, t.local.y + yOff, 0);

                b.commitEnt(e);
                out.push(e);

                // 나머지 3개 토큰 제거
                for (let cc = 0; cc < 4; cc++) {
                    if (cc === cell) continue;
                    const token = (SUPPLY_LARGE_BASE + idx * 4 + cc) | 0;
                    const odx = cc & 1;
                    const ocol = (anchorCol + odx) | 0;
                    removeTokenFromCol(ocol, token);
                }

                continue;
            }

            const hidden = next < 0;
            const colorId = hidden ? -next - 1 : next;
            if (colorId < 0) break;

            const e = b.spawnSmall(r, c);
            if (!e) break;

            e.view.setTop(colorId);
            e.view.setHidden(hidden);
            e.view.setSpecial(null);

            // 새로 생성된 블럭은 "더 높은 곳(보드 3줄 위)"에서 떨어뜨림(순간이동 느낌 완화)
            // - 기존: row=rows(=10) → 11번째 줄
            // - 변경: row=rows+2(=12) → 13번째 줄(=세 줄 위에서 떨어지는 느낌)
            const cellY = b.useLineLayout
                ? Math.max(1e-3, Math.abs(b.lineDy || b.tileSize))
                : Math.max(1e-3, Math.abs((b.stepY > 0 ? b.stepY : b.tileSize) || b.tileSize));
            const startRow = ((b.rows | 0) + 2) | 0;
            const liftRows = Math.max(1, (startRow - (e.row | 0)) | 0);
            const yOff = cellY * liftRows;

            const t = b.entParentAndLocal(e);
            e.view.node.setParent(t.parent);
            e.view.node.setPosition(t.local.x, t.local.y + yOff, 0);

            b.commitEnt(e);
            out.push(e);
        }
    }

    return out;
}
