/* eslint-disable no-console */

const path = require('path');

function toFail(stageId, reason, extra = {}) {
  return {
    stageId,
    status: 'UNSOLVED',
    reason,
    failStep: extra.failStep ?? -1,
    opsUsed: Array.isArray(extra.opsUsed) ? extra.opsUsed : [],
  };
}

function loadEngine() {
  const override = process.env.VALIDATOR_ENGINE_PATH;
  const enginePath = override
    ? path.resolve(process.cwd(), override)
    : path.resolve(__dirname, '..', 'engine', 'sim_equivalent.js');
  // eslint-disable-next-line import/no-dynamic-require, global-require
  const engine = require(enginePath);
  return { engine, enginePath };
}

async function repairStagePack(pack, opts = {}) {
  const stages = Array.isArray(pack?.stages) ? pack.stages : [];

  let engine = null;
  let enginePath = '';
  try {
    const loaded = loadEngine();
    engine = loaded.engine;
    enginePath = loaded.enginePath;
  } catch {
    engine = null;
  }

  const realEngine = !!(engine && engine.isRealEngine === true && typeof engine.validateStageEquivalent === 'function');
  const results = [];

  for (const st of stages) {
    const id = st?.id ?? -1;
    if (!engine || typeof engine.validateStageEquivalent !== 'function') {
      results.push(toFail(id, 'VALIDATOR_ENGINE_MISSING'));
      continue;
    }
    if (!realEngine) {
      results.push(toFail(id, 'SIM_ENGINE_NOT_REAL'));
      continue;
    }

    try {
      const r = await engine.validateStageEquivalent(st, opts);
      results.push({
        stageId: id,
        status: r?.status === 'SOLVED' ? 'SOLVED' : 'UNSOLVED',
        reason: String(r?.reason ?? (r?.status === 'SOLVED' ? 'OK' : 'UNKNOWN')),
        failStep: Number.isFinite(r?.failStep) ? (r.failStep | 0) : -1,
        opsUsed: Array.isArray(r?.opsUsed) ? r.opsUsed : [],
      });
    } catch (e) {
      results.push(toFail(id, `VALIDATION_EXCEPTION:${e?.message ?? e}`));
    }
  }

  const solved = results.filter((r) => r.status === 'SOLVED').length;
  return {
    pack,
    report: {
      validationMode: 'SIM_EQUIVALENT_SINGLE_PATH',
      validationTrust: realEngine ? 'REAL_ENGINE' : 'UNTRUSTED_ENGINE_BLOCKED',
      enginePath: enginePath || 'N/A',
      results,
      summary: { total: results.length, solved, unsolved: results.length - solved },
    },
  };
}

module.exports = { repairStagePack };
