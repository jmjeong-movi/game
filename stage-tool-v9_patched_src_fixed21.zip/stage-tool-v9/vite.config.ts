import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import commonjs from 'vite-plugin-commonjs';
import path from 'path';

export default defineConfig({
  // validator_tools_v20 dist 산출물은 CommonJS(require/exports) 형태라서
  // dev 서버에서도 변환이 필요합니다.
  plugins: [
    react(),
    commonjs({
      include: [/src\/validator_tools\//],
    }),
  ],
  resolve: {
    alias: {
      // validator_tools_v20이 사용하던 headless cocos("cc") 스텁을 웹 번들에서 그대로 쓰기 위한 alias
      cc: path.resolve(__dirname, 'src/validator_tools/headless/cc.js'),
    },
  },
  // Electron/로컬 파일 실행 시에도 경로가 깨지지 않도록 상대 경로로 빌드
  base: './',
});
