#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
GAME_SRC="$ROOT/../unpack_game/game/stage/compileRuntimeFromV2.ts"
TOOL_DST="$ROOT/src/lib/runtime/stage/compileRuntimeFromV2.ts"
[[ -f "$GAME_SRC" ]] || { echo "missing game compiler: $GAME_SRC"; exit 2; }
cp "$GAME_SRC" "$TOOL_DST"
diff -q "$GAME_SRC" "$TOOL_DST" >/dev/null
echo "[sync] runtime compiler synced"
