import { _decorator, Component, Sprite, Vec3, Color } from 'cc';
import { ColorPalette } from './ColorPalette';

const { ccclass, property } = _decorator;

@ccclass('ProjectileView')
export class ProjectileView extends Component {
    @property({ type: Sprite, tooltip: '프로젝타일 스프라이트' })
    sprite: Sprite | null = null;

    // ✅ 런타임 GC/할당 감소용 Vec3 캐시(프로젝타일 노드마다 1회만 생성)
    // - shoot.ts에서 convertToNodeSpaceAR(out)로 값을 채워 tween에 그대로 사용
    private _v0: Vec3 = new Vec3();
    private _v1: Vec3 = new Vec3();

    // ✅ Sprite tint 적용용 임시 Color(할당 최소화)
    private _tmpTint: Color = new Color();

    // 임시 Vec3(0)
    tmp0(): Vec3 {
        return this._v0;
    }

    // 임시 Vec3(1)
    tmp1(): Vec3 {
        return this._v1;
    }

    // colorId에 맞춰 프로젝타일 색상을 갱신합니다.
    setColor(colorId: number) {
        const s = this.sprite;
        if (!s) return;

        // Sprite.color getter는 Readonly<Color> 이라 채널 직접 수정이 막힐 수 있습니다.
        // 임시 Color에 값을 채워 넣고 setter로 넣는 방식이 안전합니다.
        ColorPalette.applyTo(this._tmpTint, colorId);
        s.color = this._tmpTint;
    }
}
