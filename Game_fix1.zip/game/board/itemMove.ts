// 역할: Board 아이템3(색상 블럭 위로 이동) 로직 분리
// - 기능 변경 없이 Board.ts에서 코드만 분리합니다.

export async function useItemMoveColorBlocksToTop(b: any, colorId: number, moveSec = 0.16): Promise<boolean> {
    // 역할: 선택한 블럭의 "색상"만 보드 최상단(가능한 가장 높은 row)으로 끌어올림
    // - 히든 블록 제외
    // - 체인/락/유닛생성기 등 특수 블록 제외
    // - 블럭 "정렬/재배치" 금지: 좌우(col)는 그대로 유지

    const cid = colorId | 0;

    b._tmpMovableEnts.length = 0;
    b._tmpMoveNewR.length = 0;
    b._tmpMoveNewC.length = 0;
    b._tmpMovedEnts.length = 0;
    b._tmpMoveSelIds.clear();
    b._tmpItemCols.length = 0;

    // 1) 선택 색상(일반 big/small)만 수집
    for (const e of b.ents.values()) {
        if (b.isEntMoving(e.id)) continue;

        const v = e.view;
        if (!v || !v.node?.isValid) continue;

        if ((v as any).isHidden?.()) continue;

        const sp = (v.depth ?? 1) <= 1 ? v.getSpecial?.() : null;
        if (sp) continue;

        if ((v.colorId | 0) !== cid) continue;
        if (e.w <= 0 || e.h <= 0) continue;

        b._tmpMovableEnts.push(e);
        b._tmpMoveNewR.push(e.row);
        b._tmpMoveNewC.push(e.col);
        b._tmpMoveSelIds.add(e.id);
    }

    if (b._tmpMovableEnts.length === 0) return false;

    // 2) 선택된 블럭 footprint를 점유그리드에서 제거(빈칸 생성)
    for (let i = 0; i < b._tmpMovableEnts.length; i++) {
        const e = b._tmpMovableEnts[i];
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const r = e.row + dy;
                const c = e.col + dx;
                if (r < 0 || r >= b.rows || c < 0 || c >= b.cols) continue;
                b._tmpItemCols.push(c);
                const idx = b.indexOf(r, c);
                if (b.occ[idx] === e.id) b.occ[idx] = -1;
            }
        }
    }

    // 3) 나머지 블럭은 중력으로 자연스럽게 내려오게 함(선택된 블럭 제외)
    b._settleGravityExcluding(b._tmpMoveSelIds, b._tmpMovedEnts);

    // 4) 선택된 블럭을 "같은 col"에서 가능한 가장 높은 row로 배치(빅 먼저)
    b._tmpMovableEnts.sort((a: any, bb: any) => {
        const abig = a.w > 1 || a.h > 1 ? 1 : 0;
        const bbig = bb.w > 1 || bb.h > 1 ? 1 : 0;
        if (abig !== bbig) return bbig - abig;
        if (a.row !== bb.row) return bb.row - a.row;
        return a.col - bb.col;
    });

    const rows = b.rows | 0;
    const cols = b.cols | 0;

    const canPlaceAtSameCol = (e: any, r0: number): boolean => {
        const c0 = e.col | 0;
        if (c0 < 0 || c0 + e.w > cols) return false;
        if (r0 < 0 || r0 + e.h > rows) return false;

        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const rr = r0 + dy;
                const cc = c0 + dx;
                const id = b.occ[b.indexOf(rr, cc)];
                if (id >= 0) return false;
            }
        }
        return true;
    };

    const occupyAtSameCol = (e: any, r0: number) => {
        const c0 = e.col | 0;
        for (let dy = 0; dy < e.h; dy++) {
            for (let dx = 0; dx < e.w; dx++) {
                const rr = r0 + dy;
                const cc = c0 + dx;
                b.occ[b.indexOf(rr, cc)] = e.id;
            }
        }
    };

    for (let i = 0; i < b._tmpMovableEnts.length; i++) {
        const e = b._tmpMovableEnts[i];
        const oldR = e.row | 0;

        let placed = false;
        const rStart = rows - e.h;

        for (let r = rStart; r >= 0; r--) {
            if (!canPlaceAtSameCol(e, r)) continue;

            occupyAtSameCol(e, r);
            if (oldR !== r) b._tmpMovedEnts.push(e);

            e.row = r;
            e.view.row = r;
            e.view.col = e.col;

            placed = true;
            break;
        }

        if (!placed) {
            // 안전 복구
            for (let k = 0; k < b._tmpMovableEnts.length; k++) {
                const ee = b._tmpMovableEnts[k];
                const or = b._tmpMoveNewR[k] | 0;
                const oc = b._tmpMoveNewC[k] | 0;
                ee.row = or;
                ee.col = oc;
                ee.view.row = or;
                ee.view.col = oc;
            }

            // occ 재구성
            b.occ.fill(-1);
            for (const ent of b.ents.values()) {
                for (let dy = 0; dy < ent.h; dy++) {
                    for (let dx = 0; dx < ent.w; dx++) {
                        const rr = ent.row + dy;
                        const cc = ent.col + dx;
                        if (rr < 0 || rr >= b.rows || cc < 0 || cc >= b.cols) continue;
                        b.occ[b.indexOf(rr, cc)] = ent.id;
                    }
                }
            }
            return false;
        }
    }

    // 4-1) 선택 블럭 배치 이후 상단 빈칸을 supply로 보충
    const spawned2 = b.fillTopHoles(b._tmpItemCols);
    for (let i = 0; i < spawned2.length; i++) b._tmpMovedEnts.push(spawned2[i]);
    b.revealHiddenAtBottom();

    // ✅ 렌더 오더 동기화(바닥이 항상 앞)
    // - 아이템 이동/공급(setParent/instantiate) 이후에도 UI가 역전되지 않게 정리
    b.syncDrawOrder?.();

    // 5) 이동 애니메이션
    for (let i = 0; i < b._tmpMovedEnts.length; i++) {
        b.moveEnt(b._tmpMovedEnts[i], moveSec).catch(() => {});
    }

    return b._tmpMovedEnts.length > 0;
}
